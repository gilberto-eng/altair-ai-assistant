from ..OCP.IGESDefs import *
