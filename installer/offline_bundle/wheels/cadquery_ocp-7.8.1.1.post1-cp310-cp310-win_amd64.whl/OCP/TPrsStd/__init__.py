from ..OCP.TPrsStd import *
