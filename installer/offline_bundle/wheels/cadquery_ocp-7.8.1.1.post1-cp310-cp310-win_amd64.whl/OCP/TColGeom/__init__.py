from ..OCP.TColGeom import *
