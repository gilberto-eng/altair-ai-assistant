##########################################################
# DO NOT EDIT: GENERATED FILE
# => instead run: $ROOT/js-libs/v4/generate_python.py
##########################################################

# ruff: noqa: E501

from trame_client.widgets.core import AbstractElement, Template  # noqa

USE_LAB = False


def enable_lab():
    global USE_LAB
    USE_LAB = True


class HtmlElement(AbstractElement):
    def __init__(self, _elem_name, children=None, **kwargs):
        super().__init__(_elem_name, children, **kwargs)
        if self.server:
            if USE_LAB:
                from trame_vuetify.module import v4_lab

                self.server.enable_module(v4_lab)
            else:
                from trame_vuetify.module import v4

                self.server.enable_module(v4)


try:
    from numbers import Number

    import numpy as np
except Exception:
    # dataframe_to_grid won't work
    pass

type_mapper = {
    "b": ["textColumn"],
    "i": [],  # ["numericColumn", "numberColumnFilter"],
    "u": [],  # ["numericColumn", "numberColumnFilter"],
    "f": [],  # ["numericColumn", "numberColumnFilter"],
    "c": [],
    "m": [],  # ['timedeltaFormat'],
    "M": [],  # ["dateColumnFilter", "shortDateTimeFormat"],
    "O": [],
    "S": [],
    "U": [],
    "V": [],
}

directives = {
    "v-click-outside": {
        "arguments": [],
        "modifiers": [],
    },
    "v-intersect": {
        "arguments": [],
        "modifiers": ["once", "quiet"],
    },
    "v-mutate": {
        "arguments": [],
        "modifiers": ["attr", "char", "child", "immediate", "once", "sub"],
    },
    "v-resize": {
        "arguments": [],
        "modifiers": [],
    },
    "v-ripple": {
        "arguments": [],
        "modifiers": ["center", "circle", "stop"],
    },
    "v-scroll": {
        "arguments": [],
        "modifiers": [],
    },
    "v-tooltip": {
        "arguments": [
            "top",
            "bottom",
            "start",
            "end",
            "left",
            "right",
            "center",
            "center-center",
            "top-start",
            "top-end",
            "top-left",
            "top-right",
            "top-center",
            "bottom-start",
            "bottom-end",
            "bottom-left",
            "bottom-right",
            "bottom-center",
            "start-top",
            "start-bottom",
            "start-center",
            "end-top",
            "end-bottom",
            "end-center",
            "left-top",
            "left-bottom",
            "left-center",
            "right-top",
            "right-bottom",
            "right-center",
        ],
        "modifiers": [],
    },
    "v-touch": {
        "arguments": [],
        "modifiers": [],
    },
}

for directive, description in directives.items():
    py_directive = directive.replace("-", "_")
    AbstractElement.register_directive(py_directive, directive)

    for argument in description["arguments"]:
        py_argument = argument.replace("-", "_")
        AbstractElement.register_directive(
            f"{py_directive}_{py_argument}", f"{directive}:{argument}"
        )

    for modifier in description["modifiers"]:
        py_modifier = modifier.replace("-", "_")
        AbstractElement.register_directive(
            f"{py_directive}_{py_modifier}", f"{directive}.{modifier}"
        )


def cast_to_serializable(value):
    isoformat = getattr(value, "isoformat", None)
    if (isoformat) and callable(isoformat):
        return isoformat()
    elif isinstance(value, Number):
        if np.isnan(value) or np.isinf(value):
            return value.__str__()
        return value

    return value.__str__()


def dataframe_to_grid(dataframe, options={}):
    """
    Transform a dataframe for use with a VDataTable

    Args:
      dataframe:
        A pandas dataframe
      options:
        Control which columns are sortable, filterable, grouped, aligned, etc.
        A dictionary where keys are the columns from the dataframe and values
        are Vuetify DataTableHeader objects. See more info |header_doc_link|.

    Returns:
      The headers and rows for the table component.

    Usage example:

       headers, rows = vuetify.dataframe_to_grid(dataframe)
       VDataTable(headers=("table_headers", headers), items=("table_rows", rows))

    `Vuetify documentation <https://vuetifyjs.com/en/api/v-data-table/#props-headers>`_
    """
    headers = {}
    for col_name in dataframe.columns:
        headers[col_name] = {"text": col_name, "value": col_name}
        if options.get(col_name):
            headers[col_name].update(options.get(col_name))

    return list(headers.values()), dataframe.map(cast_to_serializable).to_dict(
        orient="records"
    )


slot_names = [
    "actions",
    "activator",
    "additional",
    "append",
    "append-inner",
    "append-item",
    "badge",
    "body",
    "body.append",
    "body.prepend",
    "bottom",
    "browse",
    "caption",
    "category",
    "cell",
    "center",
    "chip",
    "clear",
    "close",
    "colgroup",
    "column-header",
    "controls",
    "counter",
    "data-table-group",
    "data-table-select",
    "day",
    "day-body",
    "day-header",
    "day-label",
    "day-label-header",
    "day-month",
    "decrement",
    "default",
    "details",
    "divider",
    "empty",
    "error",
    "event",
    "expanded",
    "expanded-row",
    "extension",
    "fields",
    "filter",
    "first",
    "footer",
    "footer.prepend",
    "group-header",
    "group-summary",
    "header",
    "header-item",
    "header.data-table-expand",
    "header.data-table-select",
    "headers",
    "headline",
    "icon",
    "image",
    "increment",
    "input",
    "input.append-inner",
    "interval",
    "interval-header",
    "item",
    "item-label",
    "item.append",
    "item.data-table-expand",
    "item.data-table-select",
    "item.prepend",
    "item.title",
    "label",
    "last",
    "legend",
    "legend-text",
    "list.prepend",
    "list.subheader",
    "load-more",
    "loader",
    "loading",
    "media",
    "menu-footer",
    "menu-header",
    "message",
    "mobile.header",
    "month",
    "next",
    "no-data",
    "opposite",
    "overflow",
    "placeholder",
    "prepend",
    "prepend-inner",
    "prepend-item",
    "prev",
    "pullDownPanel",
    "row-header",
    "selection",
    "single",
    "sources",
    "subheader",
    "subtitle",
    "tab",
    "tbody",
    "text",
    "tfoot",
    "thead",
    "thumb",
    "thumb-label",
    "tick-label",
    "title",
    "toggle",
    "tooltip",
    "top",
    "track-false",
    "track-true",
    "value",
    "window",
    "wrapper",
    "year",
]
Template.slot_names.update(slot_names)


__all__ = [
    "Template",
    "VAlert",
    "VAlertTitle",
    "VApp",
    "VAppBar",
    "VAppBarNavIcon",
    "VAppBarTitle",
    "VAutocomplete",
    "VAvatar",
    "VAvatarGroup",
    "VBadge",
    "VBanner",
    "VBannerActions",
    "VBannerText",
    "VBottomNavigation",
    "VBottomSheet",
    "VBreadcrumbs",
    "VBreadcrumbsDivider",
    "VBreadcrumbsItem",
    "VBtn",
    "VBtnGroup",
    "VBtnToggle",
    "VCalendar",
    "VCard",
    "VCardActions",
    "VCardItem",
    "VCardSubtitle",
    "VCardText",
    "VCardTitle",
    "VCarousel",
    "VCarouselItem",
    "VCheckbox",
    "VCheckboxBtn",
    "VChip",
    "VChipGroup",
    "VClassIcon",
    "VCode",
    "VCol",
    "VColorInput",
    "VColorPicker",
    "VCombobox",
    "VCommandPalette",
    "VCommandPaletteItem",
    "VComponentIcon",
    "VConfirmEdit",
    "VContainer",
    "VCounter",
    "VDataIterator",
    "VDataTable",
    "VDataTableFooter",
    "VDataTableHeaders",
    "VDataTableRow",
    "VDataTableRows",
    "VDataTableServer",
    "VDataTableVirtual",
    "VDateInput",
    "VDatePicker",
    "VDatePickerControls",
    "VDatePickerHeader",
    "VDatePickerMonth",
    "VDatePickerMonths",
    "VDatePickerYears",
    "VDateRangePicker",
    "VDefaultsProvider",
    "VDialog",
    "VDialogBottomTransition",
    "VDialogTopTransition",
    "VDialogTransition",
    "VDivider",
    "VEmptyState",
    "VExpandBothTransition",
    "VExpandTransition",
    "VExpandXTransition",
    "VExpansionPanel",
    "VExpansionPanelText",
    "VExpansionPanelTitle",
    "VExpansionPanels",
    "VFab",
    "VFabTransition",
    "VFadeTransition",
    "VField",
    "VFieldLabel",
    "VFileInput",
    "VFileUpload",
    "VFileUploadDropzone",
    "VFileUploadItem",
    "VFileUploadList",
    "VFooter",
    "VForm",
    "VHeatmap",
    "VHeatmapCell",
    "VHeatmapLegend",
    "VHeatmapLegendCell",
    "VHighlight",
    "VHotkey",
    "VHover",
    "VIcon",
    "VIconBtn",
    "VImg",
    "VInfiniteScroll",
    "VInput",
    "VItem",
    "VItemGroup",
    "VKbd",
    "VLabel",
    "VLayout",
    "VLayoutItem",
    "VLazy",
    "VLigatureIcon",
    "VList",
    "VListGroup",
    "VListImg",
    "VListItem",
    "VListItemAction",
    "VListItemMedia",
    "VListItemSubtitle",
    "VListItemTitle",
    "VListSubheader",
    "VLocaleProvider",
    "VMain",
    "VMaskInput",
    "VMenu",
    "VMessages",
    "VMonthPicker",
    "VNavigationDrawer",
    "VNoSsr",
    "VNumberInput",
    "VOtpField",
    "VOtpGroup",
    "VOtpInput",
    "VOtpSeparator",
    "VOverlay",
    "VPagination",
    "VParallax",
    "VPicker",
    "VPickerTitle",
    "VPie",
    "VPieSegment",
    "VPieTooltip",
    "VProgress",
    "VProgressCircular",
    "VProgressLinear",
    "VPullToRefresh",
    "VRadio",
    "VRadioGroup",
    "VRangeSlider",
    "VRating",
    "VResponsive",
    "VRow",
    "VScaleTransition",
    "VScrollXReverseTransition",
    "VScrollXTransition",
    "VScrollYReverseTransition",
    "VScrollYTransition",
    "VSelect",
    "VSelectionControl",
    "VSelectionControlGroup",
    "VSheet",
    "VSkeletonLoader",
    "VSlideGroup",
    "VSlideGroupItem",
    "VSlideXReverseTransition",
    "VSlideXTransition",
    "VSlideYReverseTransition",
    "VSlideYTransition",
    "VSlider",
    "VSnackbar",
    "VSnackbarQueue",
    "VSpacer",
    "VSparkline",
    "VSparklineTooltip",
    "VSpeedDial",
    "VStepper",
    "VStepperActions",
    "VStepperHeader",
    "VStepperItem",
    "VStepperVertical",
    "VStepperVerticalActions",
    "VStepperVerticalItem",
    "VStepperWindow",
    "VStepperWindowItem",
    "VSvgIcon",
    "VSwitch",
    "VSystemBar",
    "VTab",
    "VTable",
    "VTabs",
    "VTabsWindow",
    "VTabsWindowItem",
    "VTextField",
    "VTextarea",
    "VThemeProvider",
    "VTimePicker",
    "VTimePickerClock",
    "VTimePickerControls",
    "VTimeline",
    "VTimelineItem",
    "VToolbar",
    "VToolbarItems",
    "VToolbarTitle",
    "VTooltip",
    "VTreeview",
    "VTreeviewGroup",
    "VTreeviewItem",
    "VValidation",
    "VVideo",
    "VVideoControls",
    "VVideoVolume",
    "VVirtualScroll",
    "VWindow",
    "VWindowItem",
    "dataframe_to_grid",
    "enable_lab",
]


class VAlert(HtmlElement):
    """
    Vuetify's VAlert component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-alert>`_.

    Args:
      title (string):
        Specify a title text for the component.
      text (string):
        Specify content text for the component.
      border (boolean, 'top', 'end', 'bottom', 'start'):
        Adds a colored border to the component.
      border_color (string):
        Specifies the color of the border. Only used in combination with
        **border** prop. Accepts any color value.
      closable (boolean):
        Adds a close icon that can hide the alert.
      close_icon (enum):
        Change the default icon used for **closable** alerts.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      type ('success', 'info', 'warning', 'error'):
        Create a specialized alert that uses a contextual color and has
        a pre-defined icon.
      close_label (string):
        Text used for *aria-label* on **closable** alerts. Can also be
        customized globally in [Internationalization](/customization/internationalization).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          false, string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      model_value (boolean):
        Controls whether the component is visible or hidden.
      prominent (boolean):
        Displays a larger vertically centered icon to draw more attention.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      icon_sizes (enum):
        An array of tuples that define the icon sizes for each named size.

        Enum values: [
          ['default', 'small', 'x-small', 'large', 'x-large', number][]
        ]
      icon_size (string, number):
        The specific size of the icon, can use named sizes.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes the component's border-radius.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      click_close (event):
        Emitted when close icon is clicked.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAlert", children, **kwargs)
        self._attr_names += [
            "title",
            "text",
            "border",
            ("border_color", "borderColor"),
            "closable",
            ("close_icon", "closeIcon"),
            "type",
            ("close_label", "closeLabel"),
            "icon",
            ("model_value", "modelValue"),
            "prominent",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            ("icon_sizes", "iconSizes"),
            ("icon_size", "iconSize"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
        ]
        self._event_names += [
            ("click_close", "click:close"),
            ("update_modelValue", "update:modelValue"),
        ]


class VAlertTitle(HtmlElement):
    """
    Vuetify's VAlertTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-alert-title>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAlertTitle", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VApp(HtmlElement):
    """
    Vuetify's VApp component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-app>`_.

    Args:
      overlaps (string[]):
        **FOR INTERNAL USE ONLY**
      theme (string):
        Specify a theme for this component and all of its children.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VApp", children, **kwargs)
        self._attr_names += [
            "overlaps",
            "theme",
        ]
        self._event_names += []


class VAppBar(HtmlElement):
    """
    Vuetify's VAppBar component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-app-bar>`_.

    Args:
      title (string):
        Specify a title text for the component.
      flat (boolean):
        Removes the component's **box-shadow**.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      density ('default', 'prominent', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Designates a specific height for the toolbar. Overrides the heights
        imposed by other props, e.g. **prominent**, **dense**, **extended**,
        etc.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location ('top', 'bottom'):
        Aligns the component towards the top or bottom.
      absolute (boolean):
        Applies position: absolute to the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Assign a specific name for layout registration.
      image (string):
        Specifies a [v-img](/components/images) as the component's background.
      collapse (boolean):
        Morphs the component into a collapsed state, reducing its maximum width.
      collapse_position ('end', 'start'):
        Specifies side to attach the collapsed toolbar.
      extended (boolean):
        Use this prop to increase the height of the toolbar _without_
        using the `extension` slot for adding content. May be used in
        conjunction with the **extension-height** prop. When false, will
        not show extension slot even if content is present.
      extension_height (string, number):
        Designate an explicit height for the `extension` slot.
      floating (boolean):
        Applies **display: inline-flex** to the component.
      order (string, number):
        Adjust the order of the component in relation to its registration order.
      scroll_target (string):
        The element to target for scrolling events. Uses `window` by default.
      scroll_threshold (string, number):
        The amount of scroll distance down before **scroll-behavior** activates.
      scroll_behavior (enum):
        Specify an action to take when the scroll position of **scroll-target**
        reaches **scroll-threshold**. Accepts any combination of hide,
        inverted, collapse, elevate, and fade-image. Multiple values
        can be used, separated by a space.

        Enum values: [
          (string & {}), 'hide', 'fully-hide', 'inverted', 'collapse',
          'elevate', 'fade-image'
        ]
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAppBar", children, **kwargs)
        self._attr_names += [
            "title",
            "flat",
            "border",
            ("model_value", "modelValue"),
            "density",
            "height",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "absolute",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "name",
            "image",
            "collapse",
            ("collapse_position", "collapsePosition"),
            "extended",
            ("extension_height", "extensionHeight"),
            "floating",
            "order",
            ("scroll_target", "scrollTarget"),
            ("scroll_threshold", "scrollThreshold"),
            ("scroll_behavior", "scrollBehavior"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VAppBarNavIcon(HtmlElement):
    """
    Vuetify's VAppBarNavIcon component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-app-bar-nav-icon>`_.

    Args:
      symbol (any):
        The [Symbol](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)
        used to hook into group functionality for components like [v-btn-toggle](/components/btn-toggle)
        and [v-bottom-navigation](/components/bottom-navigations/).
      text (string, number, boolean):
        Specify content text for the component.
      flat (boolean):
        Removes the button box shadow. This is different than using the 'flat' variant.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/)
        component. The button will become _round_.

        Enum values: [
          boolean, string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      active_color (string):
        The applied color when the component is in an active state.
      base_color (string):
        Sets the color of component when not focused.
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      block (boolean):
        Expands the button to 100% of available space.
      readonly (boolean):
        Puts the button in a readonly state. Cannot be clicked or navigated
        to by keyboard.
      slim (boolean):
        Reduces padding to 0 8px.
      stacked (boolean):
        Displays the button as a flex-column.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAppBarNavIcon", children, **kwargs)
        self._attr_names += [
            "symbol",
            "text",
            "flat",
            "replace",
            "border",
            "icon",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "size",
            "value",
            "active",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "block",
            "readonly",
            "slim",
            "stacked",
            "ripple",
            ("selected_class", "selectedClass"),
            "loading",
            "href",
            "exact",
            "to",
        ]
        self._event_names += []


class VAppBarTitle(HtmlElement):
    """
    Vuetify's VAppBarTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-app-bar-title>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      text (string):
        Specify content text for the component.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAppBarTitle", children, **kwargs)
        self._attr_names += [
            "tag",
            "text",
        ]
        self._event_names += []


class VAutocomplete(HtmlElement):
    """
    Vuetify's VAutocomplete component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-autocomplete>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      search (string):
        Text input used to filter items.
      type (string):
        Sets input type.
      reverse (boolean):
        Reverses the orientation.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      form (string):
        The id of the `<form>` element to associate the hidden input
        used for native form submission with.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      menu (boolean):
        Renders with the menu open by default.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      placeholder (string):
        Sets the input’s placeholder text.
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      theme (string):
        Specify a theme for this component and all of its children.
      items (any[]):
        Can be an array of objects or strings. By default objects should
        have **title** and **value** properties, and can optionally have
        a **props** property containing any [VListItem props](/api/v-list-item/#props).
        Keys to use for these can be changed with the **item-title**,
        **item-value**, and **item-props** props.
      auto_select_first (boolean, 'exact'):
        When searching, will always highlight the first option and select
        it on blur. `exact` will only highlight and select exact matches.
      clear_on_select (boolean):
        Reset the search text when a selection is made while using the
        **multiple** prop.
      close_on_input_click (boolean):
        Clicking the field while the menu is open closes it.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Do not apply filtering when searching. Useful when data is being
        filtered server side.
      custom_filter (FilterFunction):
        Function used to filter items, called for each filterable key
        on each item in the list. The first argument is the filterable
        value from the item, the second is the search term, and the third
        is the internal item object. The function should return true
        if the item should be included in the filtered list, or the index
        of the match in the value if it should be included with the result
        highlighted.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      chips (boolean):
        Changes display of selections to chips.
      closable_chips (boolean):
        Enables the [closable](/api/v-chip/#props-closable) prop on all
        [v-chip](/components/chips/) components.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      hide_selected (boolean):
        Do not display in the select menu items that are already selected.
      list_props (unknown):
        Pass props through to the `v-list` component. Accepts an object
        with anything from [v-list](/api/v-list/#props) props, camelCase
        keys are recommended.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      item_children (SelectItemKey):
        This property currently has **no effect**.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      item_type (SelectItemKey):
        Designates the key on the supplied items that is used for determining
        the nodes type.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      menu_elevation (string, number):
        Sets the elevation of the dropdown menu.
      menu_icon (enum):
        Sets the the spin icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      menu_props (unknown):
        Pass props through to the `v-menu` component. Accepts an object
        with anything from [v-menu](/api/v-menu/#props) props, camelCase
        keys are recommended.
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      open_on_focus (boolean):
        Open the menu when the input receives focus.
      no_data_text (string):
        Text shown when no items are provided to the component.
      open_on_clear (boolean):
        Open's the menu whenever the clear icon is clicked.
      item_color (string):
        Sets color of selected items.
      no_auto_scroll (boolean):
        Prevents the select menu to scroll to the selected item automatically.
      close_text (string):
        Text set to the inputs `aria-label` and `title` when input menu is closed.
      open_text (string):
        Text set to the inputs **aria-label** and **title** when input menu is open.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      update_search (event):
        Event emitted when the search value changes.
      update_menu (event):
        Event that is emitted when the component's menu state changes.
      item_added (event):
        Emitted when an item is added to the model.
      item_removed (event):
        Emitted when an item is removed from the model.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAutocomplete", children, **kwargs)
        self._attr_names += [
            "flat",
            "search",
            "type",
            "reverse",
            "name",
            "error",
            "form",
            "label",
            "menu",
            "autocomplete",
            "disabled",
            "multiple",
            "placeholder",
            "width",
            "id",
            "prefix",
            "role",
            "autofocus",
            "theme",
            "items",
            ("auto_select_first", "autoSelectFirst"),
            ("clear_on_select", "clearOnSelect"),
            ("close_on_input_click", "closeOnInputClick"),
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            "chips",
            ("closable_chips", "closableChips"),
            "eager",
            ("hide_no_data", "hideNoData"),
            ("hide_selected", "hideSelected"),
            ("list_props", "listProps"),
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("item_children", "itemChildren"),
            ("item_props", "itemProps"),
            ("item_type", "itemType"),
            ("return_object", "returnObject"),
            ("value_comparator", "valueComparator"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("menu_elevation", "menuElevation"),
            ("menu_icon", "menuIcon"),
            ("menu_props", "menuProps"),
            ("model_value", "modelValue"),
            ("open_on_focus", "openOnFocus"),
            ("no_data_text", "noDataText"),
            ("open_on_clear", "openOnClear"),
            ("item_color", "itemColor"),
            ("no_auto_scroll", "noAutoScroll"),
            ("close_text", "closeText"),
            ("open_text", "openText"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            "focused",
            ("hide_details", "hideDetails"),
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("update_search", "update:search"),
            ("update_menu", "update:menu"),
            ("item_added", "item:added"),
            ("item_removed", "item:removed"),
        ]


class VAvatar(HtmlElement):
    """
    Vuetify's VAvatar component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-avatar>`_.

    Args:
      text (string):
        Specify content text for the component.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      end (boolean):
        Applies margin at the start of the component.
      start (boolean):
        Applies margin at the end of the component.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      image (string):
        Apply a specific image using [v-img](/components/images/).
      badge (enum):
        Wraps the avatar in a [VBadge](/api/v-badge/). When set to `true`,
        displays a dot badge. Accepts an object of VBadge props for further
        customization.

        Enum values: [
          boolean, (Partial<{      modelValue: boolean      style: StyleValue
               location: Anchor, null      rounded: string, number, boolean
               tile: boolean      tag: string, JSXComponent      floating:
          boolean      bordered: boolean      dot: boolean      inline:
          boolean      label: string      transition:, string, boolean,
          (TransitionProps & { component?: Component, undefined }), null
             }> & {      icon:, string, (string, [string, number])[], js_fn,
          FunctionalComponent      class: any      height: string, number
               maxHeight: string, number      maxWidth: string, number
               minHeight: string, number      minWidth: string, number
               width: string, number      theme: string      color: string
               $children:, VNodeChild, { $stable: false, true }, js_fn,
          js_fn, js_fn, js_fn, js_fn, true      ref_key: string      onVnodeBeforeMount:
          VNodeMountHook, VNodeMountHook[]      onVnodeMounted: VNodeMountHook,
          VNodeMountHook[]      onVnodeBeforeUpdate: VNodeUpdateHook, VNodeUpdateHook[]
               onVnodeUpdated: VNodeUpdateHook, VNodeUpdateHook[]
          onVnodeBeforeUnmount: VNodeMountHook, VNodeMountHook[]      onVnodeUnmounted:
          VNodeMountHook, VNodeMountHook[]      max: string, number
            content: string, number      dotSize: string, number      offsetX:
          string, number      offsetY: string, number      textColor: string
               'v-slot:badge': false, js_fn
        ]
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAvatar", children, **kwargs)
        self._attr_names += [
            "text",
            "border",
            "end",
            "start",
            "icon",
            "density",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "size",
            "image",
            "badge",
        ]
        self._event_names += []


class VAvatarGroup(HtmlElement):
    """
    Vuetify's VAvatarGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-avatar-group>`_.

    Args:
      border (string, number, boolean):
        Applies border styles to the child [v-avatar](/components/avatars) components.
      reverse (boolean):
        Reverses the stacking order of the avatars.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      size (string, number):
        Sets the size of all child avatars.
      gap (string, number):
        Sets the overlap gap between avatars. Negative values cause avatars to overlap.
      hoverable (boolean):
        Enables a hover animation on child avatars.
      items ((string, Record<string, any>)[]):
        An array of strings or objects used for automatically generating
        children components.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      limit (string, number):
        The total number of avatars to display, including the overflow
        indicator. E.g. a limit of `3` with 5 items renders 2 avatars
        and a `+3` overflow indicator.
      overflow_text (string):
        Custom text to display in the overflow avatar. Defaults to `+N`
        where N is the number of hidden items.
      vertical (boolean):
        Stacks avatars vertically instead of horizontally.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VAvatarGroup", children, **kwargs)
        self._attr_names += [
            "border",
            "reverse",
            "tag",
            "size",
            "gap",
            "hoverable",
            "items",
            ("item_props", "itemProps"),
            "limit",
            ("overflow_text", "overflowText"),
            "vertical",
        ]
        self._event_names += []


class VBadge(HtmlElement):
    """
    Vuetify's VBadge component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-badge>`_.

    Args:
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      model_value (boolean):
        Controls whether the component is visible or hidden.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      max (string, number):
        Sets the maximum number allowed when using the **content** prop
        with a `number` like value. If the content number exceeds the
        maximum value, a `+` suffix is added.
      floating (boolean):
        Move the badge further away from the slotted content. Equivalent
        to an 8px offset.
      bordered (boolean):
        Applies a **2px** by default and **1.5px** border around the
        badge when using the **dot** property.
      content (string, number):
        Text content to show in the badge.
      dot (boolean):
        Reduce the size of the badge and hide its contents.
      dot_size (string, number):
        Sets the size of the **dot** variant (includes border when using
        with **bordered**)
      inline (boolean):
        Display as an inline block instead of absolute position. **location**,
        **floating**, and **offset** will have no effect.
      label (string):
        The **aria-label** used for the badge.
      offset_x (string, number):
        Offset the badge on the x-axis.
      offset_y (string, number):
        Offset the badge on the y-axis.
      text_color (string):
        Applies a specified color to the control text - supports utility
        colors with or without `text-` prefix (for example `success`,
        `purple` or `text-purple`) or CSS color (`#033` or `rgba(255,
        0, 0, 0.5)`). Find a list of built-in classes on the [colors
        page](/styles/colors#material-colors).
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBadge", children, **kwargs)
        self._attr_names += [
            "icon",
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "location",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "max",
            "floating",
            "bordered",
            "content",
            "dot",
            ("dot_size", "dotSize"),
            "inline",
            "label",
            ("offset_x", "offsetX"),
            ("offset_y", "offsetY"),
            ("text_color", "textColor"),
            "transition",
        ]
        self._event_names += []


class VBanner(HtmlElement):
    """
    Vuetify's VBanner component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-banner>`_.

    Args:
      text (string):
        Specify content text for the component.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      sticky (boolean):
        Applies `position: sticky` to the component with `top: 0`. You
        can find more information on the [MDN documentation for sticky
        position](https://developer.mozilla.org/en-US/docs/Web/CSS/position).
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      stacked (boolean):
        Forces the banner actions onto a new line. This is not applicable
        when the banner has `lines="one"`.
      avatar (string):
        Designates a specific src image to pass to the thumbnail.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mobile (boolean):
        Applies the mobile banner styles.
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      lines ('one', 'two', 'three'):
        The amount of visible lines of text before it truncates.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBanner", children, **kwargs)
        self._attr_names += [
            "text",
            "border",
            "icon",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "sticky",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "stacked",
            "avatar",
            ("bg_color", "bgColor"),
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "lines",
        ]
        self._event_names += []


class VBannerActions(HtmlElement):
    """
    Vuetify's VBannerActions component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-banner-actions>`_.

    Args:
      density (string):
        Adjusts the vertical height used by the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBannerActions", children, **kwargs)
        self._attr_names += [
            "density",
            "color",
        ]
        self._event_names += []


class VBannerText(HtmlElement):
    """
    Vuetify's VBannerText component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-banner-text>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBannerText", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VBottomNavigation(HtmlElement):
    """
    Vuetify's VBottomNavigation component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-bottom-navigation>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component. A percentage value is relative
        to the layout and ignores `density`.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      absolute (boolean):
        Applies **position: absolute** to the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Assign a specific name for layout registration.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      order (string, number):
        Adjust the order of the component in relation to its registration order.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      base_color (string):
        Sets the color of component when not focused.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mode (string):
        Changes the orientation and active state styling of the component.
      grow (boolean):
        Force all [v-btn](/components/buttons) children to take up all
        available horizontal space.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_active (event):
        Event that is emitted when the active state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBottomNavigation", children, **kwargs)
        self._attr_names += [
            "border",
            ("model_value", "modelValue"),
            "density",
            "height",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "absolute",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "name",
            "disabled",
            "max",
            "multiple",
            "order",
            "active",
            ("base_color", "baseColor"),
            ("selected_class", "selectedClass"),
            ("bg_color", "bgColor"),
            "mode",
            "grow",
            "mandatory",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_active", "update:active"),
        ]


class VBottomSheet(HtmlElement):
    """
    Vuetify's VBottomSheet component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-bottom-sheet>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      absolute (boolean):
        Applies **position: absolute** to the content element.
      theme (string):
        Specify a theme for this component and all of its children.
      disabled (boolean):
        Removes the ability to click or target the component.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          {      component: ComponentPublicInstanceConstructor<
          CreateComponentPublicInstanceWithMixins<          {} & { target?:
          HTMLElement, [x: number, y: number], undefined } & {
             $children?:, VNodeChild, { $stable?: boolean, undefined },
          js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn
        ]
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      inset (boolean):
        Reduces the sheet content maximum width to 70%.
      fullscreen (boolean):
        Changes layout for fullscreen display.
      scrollable (boolean):
        When set to true, expects a `v-card` and a `v-card-text` component
        with a designated height. For more information, check out the
        [scrollable example](/components/dialogs#scrollable).
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of the content
        element when using the persistent prop.
      persistent (boolean):
        Clicking outside of the element or pressing esc key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Activate the component when the activator is clicked.
      open_on_hover (boolean):
        Activate the component when the activator is hovered.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBottomSheet", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "location",
            "absolute",
            "theme",
            "disabled",
            "transition",
            "activator",
            "inset",
            "fullscreen",
            "scrollable",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            "target",
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            "eager",
            ("location_strategy", "locationStrategy"),
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            "attach",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VBreadcrumbs(HtmlElement):
    """
    Vuetify's VBreadcrumbs component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-breadcrumbs>`_.

    Args:
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      active_color (string):
        The applied color when the component is in an active state.
      items (enum):
        An array of strings or objects used for automatically generating
        children components.

        Enum values: [
          (, string, (Partial<LinkProps> & { title: string; disabled: boolean }))[]
        ]
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      divider (string):
        Specifies the dividing character between items.
      active_class (string):
        The class applied to the component when it is in an active state.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBreadcrumbs", children, **kwargs)
        self._attr_names += [
            "icon",
            "density",
            "rounded",
            "tile",
            "tag",
            "color",
            "disabled",
            ("active_color", "activeColor"),
            "items",
            ("bg_color", "bgColor"),
            "divider",
            ("active_class", "activeClass"),
        ]
        self._event_names += []


class VBreadcrumbsDivider(HtmlElement):
    """
    Vuetify's VBreadcrumbsDivider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-breadcrumbs-divider>`_.

    Args:
      divider (string, number):
        Specifies the dividing character between items.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBreadcrumbsDivider", children, **kwargs)
        self._attr_names += [
            "divider",
        ]
        self._event_names += []


class VBreadcrumbsItem(HtmlElement):
    """
    Vuetify's VBreadcrumbsItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-breadcrumbs-item>`_.

    Args:
      title (string):
        Specify a title text for the component.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      max_width (string, number):
        Sets the maximum width for the component.
      width (string, number):
        Sets the width for the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      active_color (string):
        The applied color when the component is in an active state.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      active_class (string):
        The class applied to the component when it matches the current
        route. Find more information about the [active-class prop](https://router.vuejs.org/api/#active-class)
        on the [vue-router](https://router.vuejs.org/) documentation.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBreadcrumbsItem", children, **kwargs)
        self._attr_names += [
            "title",
            "replace",
            ("max_width", "maxWidth"),
            "width",
            "tag",
            "color",
            "disabled",
            "active",
            ("active_color", "activeColor"),
            "href",
            "exact",
            "to",
            ("active_class", "activeClass"),
        ]
        self._event_names += []


class VBtn(HtmlElement):
    """
    Vuetify's VBtn component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-btn>`_.

    Args:
      symbol (any):
        The [Symbol](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)
        used to hook into group functionality for components like [v-btn-toggle](/components/btn-toggle)
        and [v-bottom-navigation](/components/bottom-navigations/).
      text (string, number, boolean):
        Specify content text for the component.
      flat (boolean):
        Removes the button box shadow. This is different than using the 'flat' variant.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/)
        component. The button will become _round_.

        Enum values: [
          boolean, string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      active_color (string):
        The applied color when the component is in an active state.
      base_color (string):
        Sets the color of component when not focused.
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      block (boolean):
        Expands the button to 100% of available space.
      readonly (boolean):
        Puts the button in a readonly state. Cannot be clicked or navigated
        to by keyboard.
      slim (boolean):
        Reduces padding to 0 8px.
      stacked (boolean):
        Displays the button as a flex-column.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      spaced ('end', 'start', 'both'):
        Extends content to the edges to move main content from prepend and append slots.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBtn", children, **kwargs)
        self._attr_names += [
            "symbol",
            "text",
            "flat",
            "replace",
            "border",
            "icon",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "size",
            "value",
            "active",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "block",
            "readonly",
            "slim",
            "stacked",
            "ripple",
            ("selected_class", "selectedClass"),
            "loading",
            "href",
            "exact",
            "to",
            "spaced",
        ]
        self._event_names += [
            ("group_selected", "group:selected"),
        ]


class VBtnGroup(HtmlElement):
    """
    Vuetify's VBtnGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-btn-group>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      base_color (string):
        Sets the color of component when not focused.
      divided (boolean):
        Add dividers between children [v-btn](/components/buttons) components.
      direction ('vertical', 'horizontal'):
        Control how children components are arranged - in a row or column.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBtnGroup", children, **kwargs)
        self._attr_names += [
            "border",
            "density",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "size",
            ("base_color", "baseColor"),
            "divided",
            "direction",
        ]
        self._event_names += []


class VBtnToggle(HtmlElement):
    """
    Vuetify's VBtnToggle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-btn-toggle>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Round edge buttons.
      tile (boolean):
        Removes the component's border-radius.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      base_color (string):
        Sets the color of component when not focused.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      divided (boolean):
        Add dividers between children [v-btn](/components/buttons) components.
      direction ('vertical', 'horizontal'):
        Control how children components are arranged - in a row or column.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VBtnToggle", children, **kwargs)
        self._attr_names += [
            "border",
            ("model_value", "modelValue"),
            "density",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "max",
            "multiple",
            "size",
            ("base_color", "baseColor"),
            ("selected_class", "selectedClass"),
            "mandatory",
            "divided",
            "direction",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VCalendar(HtmlElement):
    """
    Vuetify's VCalendar component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-calendar>`_.

    Args:
      end (string, number, Date):
        The ending date on the calendar (inclusive) in the format of
        `YYYY-MM-DD`. This may be ignored depending on the `type` of
        the calendar.
      start (string, number, Date):
        The starting date on the calendar (inclusive) in the format of
        `YYYY-MM-DD`. This may be ignored depending on the `type` of
        the calendar.
      type (enum):
        A string which is one of `month`, `week`, `day`, `4day`, `custom-weekly`,
        `custom-daily`, and `category`. The custom types look at the
        `start` and `end` dates passed to the component as opposed to
        the `value`.

        Enum values: [
          'category', 'day', 'month', 'week', '4day', 'custom-weekly', 'custom-daily'
        ]
      model_value (string, number, Date):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      category_days (string, number):
        The number of days to render in the `category` view.
      categories (enum):
        Specifies what categories to display in the `category` view.
        This controls the order of the categories as well. If the calendar
        uses events any categories specified in those events not specified
        in this value are dynamically rendered in the view unless `category-hide-dynamic`
        is true.

        Enum values: [
          string, (string, { name: string; categoryName: string; [string]: any })[]
        ]
      category_text (string, ((      category: string, js_fn):
        If categories is a list of objects, you can use this to determine
        what property to print out as the category text on the calendar.
        You can provide a function to do some logic or just define the
        prop name. It's similar to item-text on v-select
      category_hide_dynamic (boolean):
        Sets whether categories specified in an event should be hidden
        if it's not defined in `categories`.
      category_show_all (boolean):
        Set whether the `category` view should show all defined `categories`
        even if there are no events for a category.
      category_for_invalid (string):
        The category to place events in that have invalid categories.
        A category is invalid when it is not a string. By default events
        without a category are not displayed until this value is specified.
      interval_highlight (string, boolean):
        Highlights the interval row under the cursor in the `day`, `week`,
        and `category` views. Pass a color string to tint the highlight,
        otherwise the theme's `surface-variant` is used.
      weekdays (string, number[]):
        An array of weekdays to display. Does not affect the order.
      first_day_of_week (string, number):
        Sets the first day of the week, starting with 0 for Sunday. (Note:
        not guaranteed to work when using custom date adapters.)
      first_day_of_year (string, number):
        Sets the day that determines the first week of the year, starting
        with 0 for Sunday. For ISO 8601 this should be 4. (Note: not
        guaranteed to work when using custom date adapters.)
      weekday_format (CalendarTimestamp):
        Formats day of the week string that appears in the header to specified locale
      day_format (CalendarTimestamp):
        Formats day of the month string that appears in a day to a specified locale
      locale (string):
        The locale of the calendar.
      now (string):
        Override the day & time which is considered now. This is in the
        format of `YYYY-MM-DD hh:mm:ss`. The calendar is styled according
        to now.
      format ('ampm', '24hr'):
        Forces a clock convention for interval labels and event times,
        overriding the locale.
      events ({ [string]: any }[]):
        An array of event objects with a property for a start timestamp
        and optionally a name and end timestamp. If an end timestamp
        is not given, the value of start will be used. If no name is
        given, you must provide an implementation for the `event` slot.
      event_start (string):
        Set property of *event*'s start timestamp.
      event_end (string):
        Set property of *event*'s end timestamp.
      event_timed (string, js_fn):
        If Dates or milliseconds are used as the start or end timestamp
        of an event, this prop can be a string to a property on the event
        that is truthy if the event is a timed event or a function which
        takes the event and returns a truthy value if the event is a
        timed event.
      event_category (string, js_fn):
        Set property of *event*'s category. Instead of a property a function
        can be given which takes an event and returns the category.
      event_height (number):
        The height of an event in pixels in the `month` view and at the
        top of the `day` views.
      event_color (string, js_fn):
        A background color for all events or a function which accepts
        an event object passed to the calendar to return a color.
      event_text_color (string, js_fn):
        A text color for all events or a function which accepts an event
        object passed to the calendar to return a color.
      event_name (CalendarEventParsed):
        Set property of *event*'s displayed name, or a function which
        accepts an event object passed to the calendar as the first argument
        and a flag signalling whether the name is for a timed event (true)
        or an event over a day.
      event_overlap_threshold (string, number):
        A value in minutes that's used to determine whether two timed
        events should be placed in column beside each other or should
        be treated as slightly overlapping events.
      event_overlap_mode (CalendarEventParsed):
        One of `stack`, `column`, or a custom render function
      event_more (boolean):
        Whether the more 'button' is displayed on a calendar with too
        many events in a given day. It will say something like '5 more'
        and when clicked generates a `click:more` event.
      event_more_text (string):
        The text to display in the more 'button' given the number of hidden events.
      event_ripple (boolean, Record<string, any>):
        Applies the `v-ripple` directive.
      event_margin_bottom (number):
        Margin bottom for event
      max_days (number):
        The maximum number of days to display in the custom calendar
        if an `end` day is not set.
      interval_height (string, number):
        The height of an interval in pixels in the `day` view.
      interval_width (string, number):
        The width of the interval gutter on the left side in the `day` view.
      interval_minutes (string, number):
        The number of minutes the intervals are in the `day` view. A
        common interval is 60 minutes so the intervals are an hour.
      first_interval (string, number):
        The first interval to display in the `day` view. If `intervalMinutes`
        is set to 60 and this is set to 9 the first time in the view
        is 9am.
      first_time (string, number, { hour: number; minute: number }):
        The first time to display in the `day` view. If specified, this
        overwrites any `firstInterval` value specified. This can be the
        number of minutes since midnight, a string in the format of `HH:mm`,
        or an object with number properties hour and minute.
      interval_count (string, number):
        The number of intervals to display in the `day` view.
      interval_format (CalendarTimestamp):
        Formats time of day string that appears in the interval gutter
        of the `day` and `week` view to specified locale
      interval_style (CalendarTimestamp):
        Returns CSS styling to apply to the interval.
      show_interval_label (CalendarTimestamp):
        Checks if a given day and time should be displayed in the interval
        gutter of the `day` view.
      [`${string}_date`] (event):
        Any event on the day of the month link. The second argument is
        the day & time object.
      [`${string}_dayCategory`] (event):
        Any event on a day in the `category` view. The second argument
        is the day object.
      [`${string}_day`] (event):
        Any event on a day. The second argument is the day object.
      [`${string}_event`] (event):
        Any event on a specific event. The second argument is the day & time object.
      [`${string}_interval`] (event):
        Any event at a specific interval label in the `day` view. The
        second argument is the day & time object.
      [`${string}_more`] (event):
        Any event on the `X more` button on views with too many events
        in a day. The second argument is the day & time object.
      [`${string}_timeCategory`] (event):
        Any event at a specific time in the `category` view. The second
        argument is the day & time object.
      [`${string}_time`] (event):
        Any event at a specific time in the `day` view. The second argument
        is the day & time object.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCalendar", children, **kwargs)
        self._attr_names += [
            "end",
            "start",
            "type",
            ("model_value", "modelValue"),
            ("category_days", "categoryDays"),
            "categories",
            ("category_text", "categoryText"),
            ("category_hide_dynamic", "categoryHideDynamic"),
            ("category_show_all", "categoryShowAll"),
            ("category_for_invalid", "categoryForInvalid"),
            ("interval_highlight", "intervalHighlight"),
            "weekdays",
            ("first_day_of_week", "firstDayOfWeek"),
            ("first_day_of_year", "firstDayOfYear"),
            ("weekday_format", "weekdayFormat"),
            ("day_format", "dayFormat"),
            "locale",
            "now",
            "format",
            "events",
            ("event_start", "eventStart"),
            ("event_end", "eventEnd"),
            ("event_timed", "eventTimed"),
            ("event_category", "eventCategory"),
            ("event_height", "eventHeight"),
            ("event_color", "eventColor"),
            ("event_text_color", "eventTextColor"),
            ("event_name", "eventName"),
            ("event_overlap_threshold", "eventOverlapThreshold"),
            ("event_overlap_mode", "eventOverlapMode"),
            ("event_more", "eventMore"),
            ("event_more_text", "eventMoreText"),
            ("event_ripple", "eventRipple"),
            ("event_margin_bottom", "eventMarginBottom"),
            ("max_days", "maxDays"),
            ("interval_height", "intervalHeight"),
            ("interval_width", "intervalWidth"),
            ("interval_minutes", "intervalMinutes"),
            ("first_interval", "firstInterval"),
            ("first_time", "firstTime"),
            ("interval_count", "intervalCount"),
            ("interval_format", "intervalFormat"),
            ("interval_style", "intervalStyle"),
            ("show_interval_label", "showIntervalLabel"),
        ]
        self._event_names += [
            ("[`${string}_date`]", "[`${string}:date`]"),
            ("[`${string}_dayCategory`]", "[`${string}:dayCategory`]"),
            ("[`${string}_day`]", "[`${string}:day`]"),
            ("[`${string}_event`]", "[`${string}:event`]"),
            ("[`${string}_interval`]", "[`${string}:interval`]"),
            ("[`${string}_more`]", "[`${string}:more`]"),
            ("[`${string}_timeCategory`]", "[`${string}:timeCategory`]"),
            ("[`${string}_time`]", "[`${string}:time`]"),
        ]


class VCard(HtmlElement):
    """
    Vuetify's VCard component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-card>`_.

    Args:
      title (string, number, boolean):
        Specify a title text for the component.
      text (string, number, boolean):
        Specify content text for the component.
      flat (boolean):
        Removes the card's elevation.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      link (boolean):
        Designates that the component is a link. This is automatic when
        using the href or to prop.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      image (string):
        Apply a specific background image to the component.
      prepend_icon (enum):
        Prepends a [v-icon](/components/icons/) component to the header.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      subtitle (string, number, boolean):
        Specify a subtitle text for the component.
      append_avatar (string):
        Appends a [v-avatar](/components/avatars/) component after default
        content in the **append** slot.
      hover (boolean):
        Applies **3dp** (level 2) of elevation when hovered (default
        1dp). You can find more information on the [elevation page](/styles/elevation).
      prepend_avatar (string):
        Prepends a [v-avatar](/components/avatars/) component in the
        **prepend** slot before default content.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCard", children, **kwargs)
        self._attr_names += [
            "title",
            "text",
            "flat",
            "replace",
            "link",
            "border",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "image",
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "ripple",
            "loading",
            "href",
            "exact",
            "to",
            "subtitle",
            ("append_avatar", "appendAvatar"),
            "hover",
            ("prepend_avatar", "prependAvatar"),
        ]
        self._event_names += []


class VCardActions(HtmlElement):
    """
    Vuetify's VCardActions component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-card-actions>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCardActions", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VCardItem(HtmlElement):
    """
    Vuetify's VCardItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-card-item>`_.

    Args:
      title (string, number, boolean):
        Specify a title text for the component.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      subtitle (string, number, boolean):
        Specify a subtitle text for the component.
      append_avatar (string):
        Appends a [v-avatar](/components/avatars/) component after default
        content in the **append** slot.
      prepend_avatar (string):
        Prepends a [v-avatar](/components/avatars/) component in the
        **prepend** slot before default content.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCardItem", children, **kwargs)
        self._attr_names += [
            "title",
            "density",
            "tag",
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "subtitle",
            ("append_avatar", "appendAvatar"),
            ("prepend_avatar", "prependAvatar"),
        ]
        self._event_names += []


class VCardSubtitle(HtmlElement):
    """
    Vuetify's VCardSubtitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-card-subtitle>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      opacity (string, number):
        Sets the component's opacity value
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCardSubtitle", children, **kwargs)
        self._attr_names += [
            "tag",
            "opacity",
        ]
        self._event_names += []


class VCardText(HtmlElement):
    """
    Vuetify's VCardText component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-card-text>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      opacity (string, number):
        Sets the component's opacity value
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCardText", children, **kwargs)
        self._attr_names += [
            "tag",
            "opacity",
        ]
        self._event_names += []


class VCardTitle(HtmlElement):
    """
    Vuetify's VCardTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-card-title>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCardTitle", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VCarousel(HtmlElement):
    """
    Vuetify's VCarousel component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-carousel>`_.

    Args:
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      reverse (boolean):
        Reverse the normal transition direction.
      height (string, number):
        Sets the height for the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies a color to the navigation dots - supports utility colors
        (for example `success` or `purple`) or css color (`#033` or `rgba(255,
        0, 0, 0.5)`). Find a list of built-in classes on the [colors
        page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      progress (string, boolean):
        Displays a carousel progress bar. Requires the **cycle** prop and **interval**.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      direction ('vertical', 'horizontal'):
        The transition direction when changing windows.
      interval (string, number):
        The duration between image cycles. Requires the **cycle** prop.
      cycle (boolean):
        Determines if the carousel should cycle through images.
      delimiter_icon (enum):
        Sets icon for carousel delimiter.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      hide_delimiters (boolean):
        Hides the carousel's bottom delimiters.
      hide_delimiter_background (boolean):
        Hides the bottom delimiter background.
      continuous (boolean):
        Determines whether carousel is continuous.
      next_icon (enum):
        The displayed icon for forcing pagination to the next item.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prev_icon (enum):
        The displayed icon for forcing pagination to the previous item.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      show_arrows (string, boolean):
        Displays arrows for next/previous navigation.
      touch (TouchHandlers):
        Provide a custom **left** and **right** function when swiped left or right.
      crossfade (boolean):
        Enables crossfade transition.
      transition_duration (number):
        Overrides transition duration. Does not work in firefox, safari
        <18, or with `prefers-reduced-motion: reduce`.
      vertical_arrows (boolean, 'left', 'right'):
        Displays the navigation arrows vertically instead of horizontally.
      vertical_delimiters (boolean, 'left', 'right'):
        Displays carousel delimiters vertically.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCarousel", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "reverse",
            "height",
            "tag",
            "theme",
            "color",
            "disabled",
            ("selected_class", "selectedClass"),
            "progress",
            "mandatory",
            "direction",
            "interval",
            "cycle",
            ("delimiter_icon", "delimiterIcon"),
            ("hide_delimiters", "hideDelimiters"),
            ("hide_delimiter_background", "hideDelimiterBackground"),
            "continuous",
            ("next_icon", "nextIcon"),
            ("prev_icon", "prevIcon"),
            ("show_arrows", "showArrows"),
            "touch",
            "crossfade",
            ("transition_duration", "transitionDuration"),
            ("vertical_arrows", "verticalArrows"),
            ("vertical_delimiters", "verticalDelimiters"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VCarouselItem(HtmlElement):
    """
    Vuetify's VCarouselItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-carousel-item>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      position (string):
        Applies [object-position](https://developer.mozilla.org/en-US/docs/Web/CSS/object-position)
        styles to the image and placeholder elements.
      absolute (boolean):
        Applies position: absolute to the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      alt (string):
        Alternate text for screen readers. Leave empty for decorative images.
      disabled (boolean):
        Prevents the item from becoming active when using the "next"
        and "prev" buttons or the `toggle` method.
      src (enum):
        The image URL. This prop is mandatory.

        Enum values: [
          string, { src: string; srcset: string; lazySrc: string; aspect: number }
        ]
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      draggable (boolean, 'true', 'false'):
        Controls the `draggable` behavior of the image. See [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/draggable).
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      inline (boolean):
        Display as an inline element instead of a block, also disables flex-grow.
      transition (string, boolean):
        The transition to use when switching from `lazy-src` to `src`.
        Can be one of the [built in](/styles/transitions/) or custom
        transition.
      content_class (any):
        Apply a custom class to the internal content element.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      options (IntersectionObserverInit):
        Options that are passed to the [Intersection observer](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)
        constructor.
      cover (boolean):
        Resizes the background image to cover the entire container.
      gradient (string):
        The gradient to apply to the image. Only supports [linear-gradient](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/linear-gradient)
        syntax, anything else should be done with classes.
      image_class (any):
        Applies CSS classes to the inner `<img>` element.
      lazy_src (string):
        Something to show while waiting for the main image to load, typically
        a small base64-encoded thumbnail. Has a slight blur filter applied.
          NOTE: This prop has no effect unless either `height` or `aspect-ratio`
        are provided.
      sizes (string):
        For use with `srcset`, see [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#attr-sizes).
      srcset (string):
        A set of alternate images to use based on device size. [Read
        more...](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#attr-srcset).
      aspect_ratio (string, number):
        Calculated as `width/height`, so for a 1920x1080px image this
        will be `1.7778`. Will be calculated automatically if omitted.
      crossorigin ('', 'anonymous', 'use-credentials'):
        Specify that images should be fetched with CORS enabled [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#crossorigin)
      referrerpolicy (enum):
        Define which referrer is sent when fetching the resource [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#referrerpolicy)

        Enum values: [
          'origin', 'no-referrer', 'no-referrer-when-downgrade', 'origin-when-cross-origin',
          'same-origin', 'strict-origin', 'strict-origin-when-cross-origin',
          'unsafe-url'
        ]
      reverse_transition (string, boolean):
        Sets the reverse transition.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCarouselItem", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "position",
            "absolute",
            "rounded",
            "tile",
            "color",
            "alt",
            "disabled",
            "src",
            "value",
            "draggable",
            ("selected_class", "selectedClass"),
            "inline",
            "transition",
            ("content_class", "contentClass"),
            "eager",
            "options",
            "cover",
            "gradient",
            ("image_class", "imageClass"),
            ("lazy_src", "lazySrc"),
            "sizes",
            "srcset",
            ("aspect_ratio", "aspectRatio"),
            "crossorigin",
            "referrerpolicy",
            ("reverse_transition", "reverseTransition"),
        ]
        self._event_names += []


class VCheckbox(HtmlElement):
    """
    Vuetify's VCheckbox component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-checkbox>`_.

    Args:
      type (string):
        Provides the default type for children selection controls.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      indeterminate (boolean):
        Sets an indeterminate state for the checkbox.
      multiple (boolean):
        Changes expected model to an array.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      true_value (any):
        Sets value for truthy state.
      false_value (any):
        Sets value for falsy state.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        The icon used when in an indeterminate state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCheckbox", children, **kwargs)
        self._attr_names += [
            "type",
            ("model_value", "modelValue"),
            "error",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "theme",
            "color",
            "name",
            "disabled",
            "indeterminate",
            "multiple",
            "value",
            "id",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "ripple",
            "label",
            "messages",
            ("center_affix", "centerAffix"),
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("true_value", "trueValue"),
            ("false_value", "falseValue"),
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
        ]


class VCheckboxBtn(HtmlElement):
    """
    Vuetify's VCheckboxBtn component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-checkbox-btn>`_.

    Args:
      type (string):
        Provides the default type for children selection controls.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      indeterminate (boolean):
        Puts the control in an indeterminate state. Used with the [indeterminate-icon](#props-indeterminate-icon)
        property.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      inline (boolean):
        Puts children inputs into a row.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      true_value (any):
        Sets value for truthy state.
      false_value (any):
        Sets value for falsy state.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        Icon used when the component is in an indeterminate state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_indeterminate (event):
        Event that is emitted when the component's indeterminate state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCheckboxBtn", children, **kwargs)
        self._attr_names += [
            "type",
            ("model_value", "modelValue"),
            "error",
            "density",
            "theme",
            "color",
            "name",
            "disabled",
            "indeterminate",
            "multiple",
            "value",
            "id",
            ("base_color", "baseColor"),
            "readonly",
            "ripple",
            "inline",
            "label",
            ("true_value", "trueValue"),
            ("false_value", "falseValue"),
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_indeterminate", "update:indeterminate"),
        ]


class VChip(HtmlElement):
    """
    Vuetify's VChip component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-chip>`_.

    Args:
      text (string, number, boolean):
        Specify content text for the component.
      filter (boolean):
        Displays a selection icon when selected.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      link (boolean):
        Designates that the component is a link. This is automatic when
        using the href or to prop.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      closable (boolean):
        Adds remove button and then a chip can be closed.
      close_icon (enum):
        Change the default icon used for **close** chips.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      close_label (string):
        Text used for *aria-label* on the close button in **close** chips.
        Can also be customized globally in [Internationalization](/customization/internationalization).
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height, padding and the font size of the component.
        Accepts only predefined options: **x-small**, **small**, **default**,
        **large**, and **x-large**.
      value (any):
        The value used when a child of a [v-chip-group](/components/chip-groups).
      draggable (boolean):
        Makes the chip draggable.
      base_color (string):
        Sets the color of component when not focused.
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      label (boolean):
        Applies a medium size border radius.
      active_class (string):
        The class applied to the component when it matches the current
        route. Find more information about the [active-class prop](https://router.vuejs.org/api/#active-class)
        on the [vue-router](https://router.vuejs.org/) documentation.
      append_avatar (string):
        Appends a [v-avatar](/components/avatars/) component after default
        content in the **append** slot.
      prepend_avatar (string):
        Prepends a [v-avatar](/components/avatars/) component in the
        **prepend** slot before default content.
      filter_icon (enum):
        Change the default icon used for **filter** chips.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      pill (boolean):
        Remove `v-avatar` padding.
      click_close (event):
        Emitted when close icon is clicked.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VChip", children, **kwargs)
        self._attr_names += [
            "text",
            "filter",
            "replace",
            "link",
            "border",
            "closable",
            ("close_icon", "closeIcon"),
            ("close_label", "closeLabel"),
            ("model_value", "modelValue"),
            "density",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "size",
            "value",
            "draggable",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "ripple",
            ("selected_class", "selectedClass"),
            "href",
            "exact",
            "to",
            "label",
            ("active_class", "activeClass"),
            ("append_avatar", "appendAvatar"),
            ("prepend_avatar", "prependAvatar"),
            ("filter_icon", "filterIcon"),
            "pill",
        ]
        self._event_names += [
            ("click_close", "click:close"),
            ("update_modelValue", "update:modelValue"),
            "click",
            ("group_selected", "group:selected"),
        ]


class VChipGroup(HtmlElement):
    """
    Vuetify's VChipGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-chip-group>`_.

    Args:
      symbol (any):
        The [Symbol](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)
        used to hook into group functionality for components like [v-btn-toggle](/components/btn-toggle)
        and [v-bottom-navigation](/components/bottom-navigations/).
      filter (boolean):
        Applies an checkmark icon in front of every chip for using it like a filter.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      base_color (string):
        Sets the color of component when not focused. Recommended with
        `color` or `filter` to properly highlight selected items.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Sets the designated mobile breakpoint for the component.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      content_class (any):
        Adds classes to the slide group item.
      direction ('vertical', 'horizontal'):
        Switch between horizontal and vertical modes.
      column (boolean):
        Remove horizontal pagination and wrap items as needed.
      next_icon (enum):
        Specify the icon to use for the next icon.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prev_icon (enum):
        Specify the icon to use for the prev icon.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      show_arrows (string, boolean):
        Force the display of the pagination arrows.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      center_active (boolean):
        Forces the selected chip to be centered.
      scroll_distance (string, number):
        How far the arrows scroll, in pixels or as a percentage of the
        area within container
      scroll_snap ('end', 'start', 'center'):
        Snap items while scrolling or using the arrows.
      scroll_to_active (boolean):
        Keeps the last active element visible when resizing the scrollable container.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VChipGroup", children, **kwargs)
        self._attr_names += [
            "symbol",
            "filter",
            ("model_value", "modelValue"),
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "max",
            "multiple",
            ("base_color", "baseColor"),
            ("selected_class", "selectedClass"),
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "mandatory",
            ("content_class", "contentClass"),
            "direction",
            "column",
            ("next_icon", "nextIcon"),
            ("prev_icon", "prevIcon"),
            ("show_arrows", "showArrows"),
            ("value_comparator", "valueComparator"),
            ("center_active", "centerActive"),
            ("scroll_distance", "scrollDistance"),
            ("scroll_snap", "scrollSnap"),
            ("scroll_to_active", "scrollToActive"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VClassIcon(HtmlElement):
    """
    Vuetify's VClassIcon component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-class-icon>`_.

    Args:
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VClassIcon", children, **kwargs)
        self._attr_names += [
            "icon",
            "tag",
        ]
        self._event_names += []


class VCode(HtmlElement):
    """
    Vuetify's VCode component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-code>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCode", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VCol(HtmlElement):
    r"""
    Vuetify's VCol component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-col>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      order (string, number):
        Deprecated, use **order-\*** class
      sm (string, number, boolean):
        Changes the number of columns on small and greater breakpoints.
      md (string, number, boolean):
        Changes the number of columns on medium and greater breakpoints.
      lg (string, number, boolean):
        Changes the number of columns on large and greater breakpoints.
      xl (string, number, boolean):
        Changes the number of columns on extra large and greater breakpoints.
      xxl (string, number, boolean):
        Changes the number of columns on extra extra large and greater breakpoints.
      offset (string, number):
        Sets the default offset for the column. Similarly to **cols**,
        accepts `{n}/{size}` syntax (e.g. 1/5 or 3/24).
      cols (string, number, boolean):
        Sets the default number of columns the component extends. Available
        options are: **1 -> 12** and **auto**. It accepts `{n}/{size}`
        syntax (e.g. 1/5 or 3/24) that overrides grid columns count for
        size calculation.
      offset_sm (string, number):
        Changes the offset of the component on small and greater breakpoints.
      offset_md (string, number):
        Changes the offset of the component on medium and greater breakpoints.
      offset_lg (string, number):
        Changes the offset of the component on large and greater breakpoints.
      offset_xl (string, number):
        Changes the offset of the component on extra large and greater breakpoints.
      offset_xxl (string, number):
        Changes the offset of the component on extra extra large and
        greater breakpoints.
      order_sm (string, number):
        Deprecated, use **order-sm-\*** class
      order_md (string, number):
        Deprecated, use **order-md-\*** class
      order_lg (string, number):
        Deprecated, use **order-lg-\*** class
      order_xl (string, number):
        Deprecated, use **order-xl-\*** class
      order_xxl (string, number):
        Deprecated, use **order-xxl-\*** class
      align_self ('end', 'start', 'center', 'auto', 'baseline', 'stretch'):
        Deprecated, use **align-self-\*** class. Available options are:
        **start**, **center**, **end**, **auto**, **baseline** and **stretch**.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCol", children, **kwargs)
        self._attr_names += [
            "tag",
            "order",
            "sm",
            "md",
            "lg",
            "xl",
            "xxl",
            "offset",
            "cols",
            ("offset_sm", "offsetSm"),
            ("offset_md", "offsetMd"),
            ("offset_lg", "offsetLg"),
            ("offset_xl", "offsetXl"),
            ("offset_xxl", "offsetXxl"),
            ("order_sm", "orderSm"),
            ("order_md", "orderMd"),
            ("order_lg", "orderLg"),
            ("order_xl", "orderXl"),
            ("order_xxl", "orderXxl"),
            ("align_self", "alignSelf"),
        ]
        self._event_names += []


class VColorInput(HtmlElement):
    """
    Vuetify's VColorInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-color-input>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      type (string):
        Sets input type.
      reverse (boolean):
        Reverses the orientation.
      name (string):
        Sets the component's name attribute.
      mode ('rgb', 'rgba', 'hsl', 'hsla', 'hex', 'hexa'):
        The current selected input type. Syncable with `v-model:mode`.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      title (string):
        Specify a title text for the component.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      placeholder (string):
        Sets the input’s placeholder text.
      width (string, number):
        Sets the width of the color picker.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      theme (string):
        Specify a theme for this component and all of its children.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      menu_props (unknown):
        Pass props through to the `v-menu` component. Accepts an object
        with anything from [v-menu](/api/v-menu/#props) props, camelCase
        keys are recommended.
      model_value (string, Record<string, unknown>):
        Represents the committed v-model value
      open_on_focus (boolean):
        Open the color picker menu when the input receives focus.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      hide_pip (boolean):
        Hide pip icon
      color_pip (boolean):
        Synchronize pip color with current value
      pip_icon (string):
        The icon used for pip
      pip_location ('append', 'prepend', 'prepend-inner', 'append-inner'):
        Move pip icon to a different slot
      pip_variant ('flat', 'text', 'elevated', 'tonal', 'outlined', 'plain'):
        Variant of the pip control
      dot_size (string, number):
        Changes the size of the selection dot on the canvas.
      canvas_height (string, number):
        Height of canvas.
      hide_canvas (boolean):
        Hides canvas.
      hide_sliders (boolean):
        Hides sliders.
      hide_inputs (boolean):
        Hides inputs.
      hide_input_labels (boolean):
        Hides input labels.
      modes (('rgb', 'rgba', 'hsl', 'hsla', 'hex', 'hexa')[]):
        Sets available input types.
      show_swatches (boolean):
        Displays color swatches.
      swatches_max_height (string, number):
        Sets the maximum height of the swatches section.
      divided (boolean):
        Adds a divider between the header and controls.
      landscape (boolean):
        Puts the picker into landscape mode.
      hide_header (boolean):
        Hide the picker header.
      hide_title (boolean):
        Hide the picker title.
      position ('fixed', 'relative', 'absolute', 'static', 'sticky'):
        Sets the position for the component.
      hide_eye_dropper (boolean):
        Hides eyedropper icon.
      eye_dropper_icon (enum):
        Icon used to trigger EyeDropper API.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      swatches (enum):
        Sets the available color swatches to select from. 2D array of
        rows and columns, accepts any color format the picker does.

        Enum values: [
          (, string, number, {      readonly h: number      readonly s:
          number      readonly v: number      readonly a?: number, undefined
             }, {      readonly r: number      readonly g: number
          readonly b: number      readonly a?: number, undefined    },
          {      readonly h: number      readonly s: number      readonly
          l: number      readonly a?: number, undefined    })[][]
        ]
      cancel_text (string):
        Text for the cancel button
      ok_text (string):
        Text for the ok button
      hide_actions (boolean):
        Prevent showing the default actions buttons. Does not affect
        `<component :is="actions" />`
      picker_props (unknown):
        Pass props through to the picker component. Intended for props
        that conflict with `v-text-field` (`color`, `width`, `rounded`,
        etc.)
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VColorInput", children, **kwargs)
        self._attr_names += [
            "flat",
            "tag",
            "type",
            "reverse",
            "name",
            "mode",
            "error",
            "label",
            "title",
            "autocomplete",
            "disabled",
            "placeholder",
            "width",
            "id",
            "prefix",
            "role",
            "autofocus",
            "theme",
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "border",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("menu_props", "menuProps"),
            ("model_value", "modelValue"),
            ("open_on_focus", "openOnFocus"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
            ("hide_pip", "hidePip"),
            ("color_pip", "colorPip"),
            ("pip_icon", "pipIcon"),
            ("pip_location", "pipLocation"),
            ("pip_variant", "pipVariant"),
            ("dot_size", "dotSize"),
            ("canvas_height", "canvasHeight"),
            ("hide_canvas", "hideCanvas"),
            ("hide_sliders", "hideSliders"),
            ("hide_inputs", "hideInputs"),
            ("hide_input_labels", "hideInputLabels"),
            "modes",
            ("show_swatches", "showSwatches"),
            ("swatches_max_height", "swatchesMaxHeight"),
            "divided",
            "landscape",
            ("hide_header", "hideHeader"),
            ("hide_title", "hideTitle"),
            "position",
            ("hide_eye_dropper", "hideEyeDropper"),
            ("eye_dropper_icon", "eyeDropperIcon"),
            "swatches",
            ("cancel_text", "cancelText"),
            ("ok_text", "okText"),
            ("hide_actions", "hideActions"),
            ("picker_props", "pickerProps"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
        ]


class VColorPicker(HtmlElement):
    """
    Vuetify's VColorPicker component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-color-picker>`_.

    Args:
      title (string):
        Specify a title text for the component.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (string, Record<string, unknown>):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width of the color picker.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      readonly (boolean):
        Puts the color picker in a readonly state.
      dot_size (string, number):
        Changes the size of the selection dot on the canvas.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mode ('rgb', 'rgba', 'hsl', 'hsla', 'hex', 'hexa'):
        The current selected input type. Syncable with `v-model:mode`.
      divided (boolean):
        Adds a divider between the header and controls.
      hide_header (boolean):
        Hide the picker header.
      canvas_height (string, number):
        Height of canvas.
      hide_canvas (boolean):
        Hides canvas.
      hide_sliders (boolean):
        Hides sliders.
      hide_inputs (boolean):
        Hides inputs.
      hide_input_labels (boolean):
        Hides input labels.
      modes (('rgb', 'rgba', 'hsl', 'hsla', 'hex', 'hexa')[]):
        Sets available input types.
      show_swatches (boolean):
        Displays color swatches.
      swatches_max_height (string, number):
        Sets the maximum height of the swatches section.
      landscape (boolean):
        Puts the picker into landscape mode.
      hide_title (boolean):
        Hide the picker title.
      hide_eye_dropper (boolean):
        Hides eyedropper icon.
      eye_dropper_icon (enum):
        Icon used to trigger EyeDropper API.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      swatches (enum):
        Sets the available color swatches to select from. 2D array of
        rows and columns, accepts any color format the picker does.

        Enum values: [
          (, string, number, {      readonly h: number      readonly s:
          number      readonly v: number      readonly a?: number, undefined
             }, {      readonly r: number      readonly g: number
          readonly b: number      readonly a?: number, undefined    },
          {      readonly h: number      readonly s: number      readonly
          l: number      readonly a?: number, undefined    })[][]
        ]
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_mode (event):
        Selected mode.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VColorPicker", children, **kwargs)
        self._attr_names += [
            "title",
            "border",
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "disabled",
            "readonly",
            ("dot_size", "dotSize"),
            ("bg_color", "bgColor"),
            "mode",
            "divided",
            ("hide_header", "hideHeader"),
            ("canvas_height", "canvasHeight"),
            ("hide_canvas", "hideCanvas"),
            ("hide_sliders", "hideSliders"),
            ("hide_inputs", "hideInputs"),
            ("hide_input_labels", "hideInputLabels"),
            "modes",
            ("show_swatches", "showSwatches"),
            ("swatches_max_height", "swatchesMaxHeight"),
            "landscape",
            ("hide_title", "hideTitle"),
            ("hide_eye_dropper", "hideEyeDropper"),
            ("eye_dropper_icon", "eyeDropperIcon"),
            "swatches",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_mode", "update:mode"),
        ]


class VCombobox(HtmlElement):
    """
    Vuetify's VCombobox component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-combobox>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      type (string):
        Sets input type.
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      reverse (boolean):
        Reverses the orientation.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'filled', 'underlined', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      name (string):
        Sets the component's name attribute.
      delimiters (string[]):
        Accepts an array of strings that will trigger a new tag when
        typing. Does not replace the normal Tab and Enter keys.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      form (string):
        The id of the `<form>` element to associate the hidden input
        used for native form submission with.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      placeholder (string):
        Sets the input’s placeholder text.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      items (any[]):
        Can be an array of objects or strings. By default objects should
        have **title** and **value** properties, and can optionally have
        a **props** property containing any [VListItem props](/api/v-list-item/#props).
        Keys to use for these can be changed with the **item-title**,
        **item-value**, and **item-props** props.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      menu (boolean):
        Renders with the menu open by default.
      open_on_focus (boolean):
        Open the menu when the input receives focus.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      always_filter (boolean):
        When enabled, dropdown list will always show items matching non-empty
        value within the field. Recommended when the list is meant to
        show suggestions rather than options to choose from. For optimal
        UX, should be combined with `:menu-icon="false"` and `hide-selected`.
      auto_select_first (boolean, 'exact'):
        When searching, will always highlight the first option and select
        it on blur. `exact` will only highlight and select exact matches.
      clear_on_select (boolean):
        Reset the search text when a selection is made while using the
        **multiple** prop.
      close_on_input_click (boolean):
        Clicking the field while the menu is open closes it.
      trim_values (boolean):
        Trims leading and trailing whitespace from entered values, and
        discards entries that are empty once trimmed.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function used to filter items, called for each filterable key
        on each item in the list. The first argument is the filterable
        value from the item, the second is the search term, and the third
        is the internal item object. The function should return true
        if the item should be included in the filtered list, or the index
        of the match in the value if it should be included with the result
        highlighted.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      chips (boolean):
        Changes display of selections to chips.
      closable_chips (boolean):
        Enables the [closable](/api/v-chip/#props-closable) prop on all
        [v-chip](/components/chips/) components.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      hide_selected (boolean):
        Do not display in the select menu items that are already selected.
      list_props (unknown):
        Pass props through to the `v-list` component. Accepts an object
        with anything from [v-list](/api/v-list/#props) props, camelCase
        keys are recommended.
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      item_children (SelectItemKey):
        This property currently has **no effect**.
      item_type (SelectItemKey):
        Designates the key on the supplied items that is used for determining
        the nodes type.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      menu_elevation (string, number):
        Sets the elevation of the dropdown menu.
      menu_icon (enum):
        Sets the the spin icon.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      menu_props (unknown):
        Pass props through to the `v-menu` component. Accepts an object
        with anything from [v-menu](/api/v-menu/#props) props, camelCase
        keys are recommended.
      no_data_text (string):
        Text shown when no items are provided to the component.
      open_on_clear (boolean):
        Open's the menu whenever the clear icon is clicked.
      item_color (string):
        Sets color of selected items.
      no_auto_scroll (boolean):
        Prevents the select menu to scroll to the selected item automatically.
      close_text (string):
        Text set to the inputs `aria-label` and `title` when input menu is closed.
      open_text (string):
        Text set to the inputs **aria-label** and **title** when input menu is open.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      update_search (event):
        Event emitted when the search value changes.
      update_menu (event):
        Event that is emitted when the component's menu state changes.
      item_added (event):
        Emitted when an item is added to the model.
      item_removed (event):
        Emitted when an item is removed from the model.
      item_created (event):
        Emitted when a value is committed that does not match any existing
        item (free-text create). Also emits **item:added**.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCombobox", children, **kwargs)
        self._attr_names += [
            "flat",
            "type",
            ("model_value", "modelValue"),
            "error",
            "reverse",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "rounded",
            "tile",
            "theme",
            "color",
            "variant",
            "name",
            "delimiters",
            "autocomplete",
            "disabled",
            "form",
            "multiple",
            "placeholder",
            "id",
            "prefix",
            "role",
            "autofocus",
            "active",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "loading",
            "label",
            "items",
            ("item_props", "itemProps"),
            ("bg_color", "bgColor"),
            "menu",
            ("open_on_focus", "openOnFocus"),
            "eager",
            "messages",
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            "focused",
            ("hide_details", "hideDetails"),
            ("value_comparator", "valueComparator"),
            ("always_filter", "alwaysFilter"),
            ("auto_select_first", "autoSelectFirst"),
            ("clear_on_select", "clearOnSelect"),
            ("close_on_input_click", "closeOnInputClick"),
            ("trim_values", "trimValues"),
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            "chips",
            ("closable_chips", "closableChips"),
            ("hide_no_data", "hideNoData"),
            ("hide_selected", "hideSelected"),
            ("list_props", "listProps"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("item_children", "itemChildren"),
            ("item_type", "itemType"),
            ("return_object", "returnObject"),
            ("menu_elevation", "menuElevation"),
            ("menu_icon", "menuIcon"),
            ("menu_props", "menuProps"),
            ("no_data_text", "noDataText"),
            ("open_on_clear", "openOnClear"),
            ("item_color", "itemColor"),
            ("no_auto_scroll", "noAutoScroll"),
            ("close_text", "closeText"),
            ("open_text", "openText"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("update_search", "update:search"),
            ("update_menu", "update:menu"),
            ("item_added", "item:added"),
            ("item_removed", "item:removed"),
            ("item_created", "item:created"),
        ]


class VCommandPalette(HtmlElement):
    """
    Vuetify's VCommandPalette component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-command-palette>`_.

    Args:
      search (string):
        The current search query. Use `v-model:search` to control or
        monitor the search input value.
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      placeholder (string):
        Placeholder text displayed in the search input.
      width (string, number):
        Sets the width for the component.
      offset_top (string, number):
        Distance from the top of the viewport.
      theme (string):
        Specify a theme for this component and all of its children.
      items (enum):
        Array of command palette items. Objects should have **title**
        and optionally **subtitle**, **prependIcon**, **appendIcon**,
        **prependAvatar**, **appendAvatar**, **hotkey**, **onClick**,
        **to**, **href**, and **value** properties. Use `type: 'subheader'`
        with a **title** for section headers, or `type: 'divider'` for
        visual separators between groups.

        Enum values: [
          (, {      type: 'item'      onClick: (event: MouseEvent, js_fn,
          RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
             href: string    }, { type: 'subheader'; title: string; inset:
          boolean }, { type: 'divider'; inset: boolean })[]
        ]
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function used to filter items, called for each filterable key
        on each item in the list. The first argument is the filterable
        value from the item, the second is the search term, and the third
        is the internal item object. The function should return true
        if the item should be included in the filtered list, or the index
        of the match in the value if it should be included with the result
        highlighted.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      list_props (unknown):
        Pass props through to the `v-list` component. Accepts an object
        with anything from [v-list](/api/v-list/#props) props, camelCase
        keys are recommended.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      absolute (boolean):
        Applies **position: absolute** to the content element.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of the content
        element when using the persistent prop.
      model_value (boolean):
        Controls the visibility of the command palette dialog. Use `v-model`
        for two-way binding.
      persistent (boolean):
        Clicking outside of the element or pressing esc key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Activate the component when the activator is clicked.
      open_on_hover (boolean):
        Activate the component when the activator is hovered.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          {      component: ComponentPublicInstanceConstructor<
          CreateComponentPublicInstanceWithMixins<          {} & { target?:
          HTMLElement, [x: number, y: number], undefined } & {
             $children?:, VNodeChild, { $stable?: boolean, undefined },
          js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn
        ]
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      no_data_text (string):
        Text displayed when no items match the current search query.
      input_icon (string):
        Icon to display at the start of the search input field.
      hotkey (string):
        Global keyboard shortcut to toggle the palette. Accepts hotkey
        strings like `'ctrl+shift+p'` or `'meta+j'`. The shortcut is
        automatically registered on mount and cleaned up on unmount.
      close_on_select (boolean):
        Controls whether the palette closes automatically after selecting
        an actionable item. Set to **false** to keep it open for external
        drill-in and nested navigation flows.
      fullscreen (boolean):
        Changes layout for fullscreen display.
      scrollable (boolean):
        When set to true, expects a `v-card` and a `v-card-text` component
        with a designated height. For more information, check out the
        [scrollable example](/components/dialogs#scrollable).
      update_modelValue (event):
        Emitted when the dialog visibility changes.
      update_search (event):
        Emitted when the search query changes.
      click_item (event):
        Emitted when an item is clicked or activated via Enter key. The
        payload includes the selected item object and the triggering
        event (MouseEvent or KeyboardEvent).
      before_select (event):
        Emitted before the default auto-close behavior for actionable
        item selection. The payload includes the selected item, the triggering
        event, and a **preventDefault** callback. Call **preventDefault()**
        to keep the palette open.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCommandPalette", children, **kwargs)
        self._attr_names += [
            "search",
            "disabled",
            "height",
            "placeholder",
            "width",
            ("offset_top", "offsetTop"),
            "theme",
            "items",
            ("filter_mode", "filterMode"),
            "target",
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            "eager",
            ("list_props", "listProps"),
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "activator",
            "absolute",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            ("model_value", "modelValue"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            ("location_strategy", "locationStrategy"),
            "location",
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            "transition",
            "attach",
            ("no_data_text", "noDataText"),
            ("input_icon", "inputIcon"),
            "hotkey",
            ("close_on_select", "closeOnSelect"),
            "fullscreen",
            "scrollable",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_search", "update:search"),
            ("click_item", "click:item"),
            ("before_select", "before-select"),
        ]


class VCommandPaletteItem(HtmlElement):
    """
    Vuetify's VCommandPaletteItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-command-palette-item>`_.

    Args:
      item (enum):
        The command palette item data object.

        Enum values: [
          {  type: 'item'  onClick: (event: MouseEvent, js_fn, RouteLocationAsRelativeGeneric,
          RouteLocationAsPathGeneric  href: string}
        ]
      index (number):
        The index of the item within the command palette list.
      execute (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VCommandPaletteItem.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCommandPaletteItem", children, **kwargs)
        self._attr_names += [
            "item",
            "index",
        ]
        self._event_names += [
            "execute",
        ]


class VComponentIcon(HtmlElement):
    """
    Vuetify's VComponentIcon component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-component-icon>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VComponentIcon", children, **kwargs)
        self._attr_names += [
            "tag",
            "icon",
        ]
        self._event_names += []


class VConfirmEdit(HtmlElement):
    """
    Vuetify's VConfirmEdit component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-confirm-edit>`_.

    Args:
      disabled (boolean, ('cancel', 'save')[]):
        Control the disabled state of action buttons. If not provided,
        internal logic will be used to determine the disabled state.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (unknown):
        Represents the committed v-model value
      cancel_text (string):
        Text for the cancel button
      ok_text (string):
        Text for the ok button
      hide_actions (boolean):
        Prevent showing the default actions buttons. Does not affect
        `<component :is="actions" />`
      cancel (event):
        The event emitted when the user clicks the Cancel button
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      save (event):
        The event emitted when the user clicks the Save button
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VConfirmEdit", children, **kwargs)
        self._attr_names += [
            "disabled",
            "color",
            ("model_value", "modelValue"),
            ("cancel_text", "cancelText"),
            ("ok_text", "okText"),
            ("hide_actions", "hideActions"),
        ]
        self._event_names += [
            "cancel",
            ("update_modelValue", "update:modelValue"),
            "save",
        ]


class VContainer(HtmlElement):
    """
    Vuetify's VContainer component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-container>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      fluid (boolean):
        Removes viewport maximum-width size breakpoints.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VContainer", children, **kwargs)
        self._attr_names += [
            "tag",
            "height",
            "width",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "fluid",
        ]
        self._event_names += []


class VCounter(HtmlElement):
    """
    Vuetify's VCounter component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-counter>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      max (string, number):
        Sets the maximum allowed value.
      value (string, number):
        Sets the current counter value.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          { component: Component }
        ]
      active (boolean):
        Determines whether the counter is visible or not.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VCounter", children, **kwargs)
        self._attr_names += [
            "disabled",
            "max",
            "value",
            "transition",
            "active",
        ]
        self._event_names += []


class VDataIterator(HtmlElement):
    """
    Vuetify's VDataIterator component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-iterator>`_.

    Args:
      search (string):
        Text input used to filter items.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      items (unknown[]):
        An array of strings or objects used for automatically generating
        children components.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function to filter items.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      opened (string[]):
        Array of group IDs that should be open. Can be bound to external
        variable using **v-model:opened**.
      select_strategy ('single', 'page', 'all'):
        Defines the strategy of selecting items in the list. Possible
        values are: 'single' (only one item can be selected at a time),
        'page' ('Select all' button will select only items on the current
        page), 'all' ('Select all' button will select all items in the
        list).
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      model_value (any[]):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          { component: Component; hideOnLeave: boolean }
        ]
      loading (boolean):
        If `true` and no items are provided, then a loading text will be shown.
      items_length (string, number):
        The total number of items. Useful when using server-side pagination
        to correctly compute page counts.
      item_selectable (SelectItemKey):
        Property on supplied `items` that contains the boolean value
        indicating if the item is selectable.
      show_select (boolean):
        Shows the column with checkboxes for selecting items in the list.
      page (string, number):
        The current displayed page number (1-indexed).
      initial_sort_order ('desc', 'asc'):
        Specifies the initial sort order when an **toggleSort** is called
        for unsorted property.
      sort_by (SortItem):
        Array of column keys and sort orders that determines the sort
        order of the table.
      multi_sort (enum):
        Let user sort by multiple properties/columns.  - **key**: (optional)
        when set to `ctrl`, user is required to hold a keyboard key (Ctrl
        on PC and Command on Mac) - **mode**: when user selects a new
        column to sort by, it will be set first (`prepend`) or last (`append`)
        in the sort priority. Defaults to `append` - **modifier**: (optional)
        allows user to use both multi-sort modes (`append` and `prepend`)
        simultaneously

        Enum values: [
          boolean, { key: 'ctrl'; mode: 'append', 'prepend'; modifier: 'shift', 'alt' }
        ]
      must_sort (boolean):
        Forces sorting on the column(s).
      custom_key_sort (unknown):
        Function used on specific keys within the item object. `customSort`
        is skipped for columns with `customKeySort` specified.
      items_per_page (string, number):
        Changes how many items per page should be visible. Can be bound
        to external variable using **v-model:itemsPerPage**.. Setting
        this prop to `-1` will display all items on the page.
      page_by ('item', 'auto', 'any'):
        Controls how pagination counts items. - **item** paginates by
        individual items, - **auto** paginates by top-level groups and
        falls back to regular items if **group-by** is empty, - **any**
        paginates by both items and groups combined
      expand_on_click (boolean):
        Expands item when the row is clicked.
      show_expand (boolean):
        Shows the expand icon.
      expanded (string[]):
        Array of expanded items. Can be bound to external variable using
        **v-model:expanded**.
      expand_strategy ('multiple', 'single'):
        Controls how many rows can be expanded at once. Use `single`
        to collapse the previously expanded row when another is opened.
      group_by (SortItem):
        Configures attributes (and sort order) to group items together.
      open_all (boolean):
        Opens all groups by default. Synchronizes with **v-model:opened**,
        so closed groups are not re-opened accidentally.
      group_key ((options: { key: string; value: any; parentKey: string }) => string):
        Custom function to generate group IDs. Receives `{ key, value,
        parentKey }` where `parentKey` is `null` for top-level groups.
        Useful when group values contain special characters or are non-string
        types.
      update_opened (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataIterator.json))
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_expanded (event):
        Emits when the **expanded** items are updated.
      update_groupBy (event):
        Emits when the **group-by** prop is updated.
      update_page (event):
        Emits when the **page** prop is updated.
      update_itemsPerPage (event):
        Emits when the **items-per-page** prop is updated.
      update_sortBy (event):
        Emits when the **sortBy** prop is updated.
      update_options (event):
        Emits when pagination related properties (page, itemsPerPage,
        sortBy, groupBy, search) is updated.
      update_currentItems (event):
        Emits with the items currently being displayed.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataIterator", children, **kwargs)
        self._attr_names += [
            "search",
            "tag",
            "items",
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            "opened",
            ("select_strategy", "selectStrategy"),
            ("item_value", "itemValue"),
            ("return_object", "returnObject"),
            ("value_comparator", "valueComparator"),
            ("model_value", "modelValue"),
            "transition",
            "loading",
            ("items_length", "itemsLength"),
            ("item_selectable", "itemSelectable"),
            ("show_select", "showSelect"),
            "page",
            ("initial_sort_order", "initialSortOrder"),
            ("sort_by", "sortBy"),
            ("multi_sort", "multiSort"),
            ("must_sort", "mustSort"),
            ("custom_key_sort", "customKeySort"),
            ("items_per_page", "itemsPerPage"),
            ("page_by", "pageBy"),
            ("expand_on_click", "expandOnClick"),
            ("show_expand", "showExpand"),
            "expanded",
            ("expand_strategy", "expandStrategy"),
            ("group_by", "groupBy"),
            ("open_all", "openAll"),
            ("group_key", "groupKey"),
        ]
        self._event_names += [
            ("update_opened", "update:opened"),
            ("update_modelValue", "update:modelValue"),
            ("update_expanded", "update:expanded"),
            ("update_groupBy", "update:groupBy"),
            ("update_page", "update:page"),
            ("update_itemsPerPage", "update:itemsPerPage"),
            ("update_sortBy", "update:sortBy"),
            ("update_options", "update:options"),
            ("update_currentItems", "update:currentItems"),
        ]


class VDataTable(HtmlElement):
    """
    Vuetify's VDataTable component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table>`_.

    Args:
      search (string):
        Text input used to filter items.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      height (string, number):
        Set an explicit height of table.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      items (any[]):
        An array of strings or objects used for automatically generating
        children components.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function to filter items.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      expand_icon (enum):
        Icon to display when the expandable row is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the expandable row is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      opened (string[]):
        Array of group IDs that should be open. Can be bound to external
        variable using **v-model:opened**.
      select_strategy ('single', 'page', 'all'):
        Defines the strategy of selecting items in the list. Possible
        values are: 'single' (only one item can be selected at a time),
        'page' ('Select all' button will select only items on the current
        page), 'all' ('Select all' button will select all items in the
        list).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height of the table rows.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      color (string):
        Applies a color to checkboxes, page size dropdown and sort badges
        in the table header.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      no_data_text (string):
        Text shown when no items are provided to the component.
      loading (string, boolean):
        Displays `loading` slot if set to `true`
      get_matches (DataTableItem):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableRow.json))
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      sticky (boolean):
        Deprecated, use `fixed-header` instead.
      item_selectable (SelectItemKey):
        Property on supplied `items` that indicates whether the item is selectable.
      show_select (boolean):
        Shows the select checkboxes in both the header and rows (if using default rows).
      page (string, number):
        The current displayed page number (1-indexed).
      initial_sort_order ('desc', 'asc'):
        Specifies the initial sort order when an unsorted column is clicked.
      sort_by (SortItem):
        Changes which item property (or properties) should be used for
        sort order. Can be bound to external variable using **v-model:sortBy**..
      multi_sort (enum):
        Let user sort by multiple properties/columns.  - **key**: (optional)
        when set to `ctrl`, user is required to hold a keyboard key (Ctrl
        on PC and Command on Mac) - **mode**: when user selects a new
        column to sort by, it will be set first (`prepend`) or last (`append`)
        in the sort priority. Defaults to `append` - **modifier**: (optional)
        allows user to use both multi-sort modes (`append` and `prepend`)
        simultaneously

        Enum values: [
          boolean, { key: 'ctrl'; mode: 'append', 'prepend'; modifier: 'shift', 'alt' }
        ]
      must_sort (boolean):
        Forces sorting on the column(s).
      custom_key_sort (unknown):
        Function used on specific keys within the item object. `customSort`
        is skipped for columns with `customKeySort` specified.
      items_per_page (string, number):
        Changes how many items per page should be visible. Can be bound
        to external variable using **v-model:itemsPerPage**.. Setting
        this prop to `-1` will display all items on the page.
      page_by ('item', 'auto', 'any'):
        Controls how pagination counts items. - **item** paginates by
        individual items, - **auto** paginates by top-level groups and
        falls back to regular items if **group-by** is empty, - **any**
        paginates by both items and groups combined
      expand_on_click (boolean):
        Expands item when the row is clicked.
      show_expand (boolean):
        Shows the expand toggle in default rows.
      expanded (string[]):
        Array of expanded items. Can be bound to external variable using
        **v-model:expanded**.
      expand_strategy ('multiple', 'single'):
        Controls how many rows can be expanded at once. Use `single`
        to collapse the previously expanded row when another is opened.
      group_by (SortItem):
        Configures attributes (and sort order) to group items together.
        Can be customized further with `group-header` and `group-summary`
        slots.
      open_all (boolean):
        Opens all groups by default. Synchronizes with **v-model:opened**,
        so closed groups are not re-opened accidentally.
      group_key ((options: { key: string; value: any; parentKey: string }) => string):
        Custom function to generate group IDs. Receives `{ key, value,
        parentKey }` where `parentKey` is `null` for top-level groups.
        Useful when group values contain special characters or are non-string
        types.
      header_props (unknown):
        Pass props to the default header. See [`v-data-table-headers`
        API](/api/v-data-table-headers) for more information.
      cell_props (enum):
        An object of additional props to be passed to each `<td>` in
        the table body. Also accepts a function that will be called for
        each cell. If the same prop is defined both here and in `cellProps`
        in a headers object, the value from the headers object will be
        used.

        Enum values: [
          Record<string, any>, ((      data: Pick<        ItemKeySlot<any>,
                 'value', 'item', 'index', 'internalItem', js_fn
        ]
      disable_sort (boolean):
        Toggles rendering of sort button.
      headers (enum):
        An array of objects that each describe a header column.

        Enum values: [
          {  readonly key?:, (string & {}), 'data-table-group', 'data-table-select',
          'data-table-expand', undefined  readonly value?: SelectItemKey<any>
           readonly title?: string, undefined  readonly fixed?: boolean,
          'start', 'end', undefined  readonly align?: 'start', 'end', 'center',
          undefined  readonly width?: string, number, undefined  readonly
          minWidth?: string, number, undefined  readonly maxWidth?: string,
          number, undefined  readonly nowrap?: boolean, undefined  readonly
          indent?: number, undefined  readonly headerProps?: { readonly
          [x: string]: any }, undefined  readonly cellProps?:, { readonly
          [x: string]: any }, HeaderCellPropsFunction, undefined  readonly
          sortable?: boolean, undefined  readonly sort?: DataTableCompareFunction<any>,
          undefined  readonly sortRaw?: DataTableCompareFunction<any>,
          undefined  readonly filter?: FilterFunction, undefined  readonly
          children?: readonly any[], undefined}[]
        ]
      loading_text (string):
        Text shown when the data is loading.
      expand_transition (enum):
        Transition used to animate the `expanded` slot content. Pass
        a string transition name, a component via `{ component }`, or
        any `<Transition>` props object.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      group_collapse_icon (enum):
        Icon to display when the row group is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      group_expand_icon (enum):
        Icon to display when the row group is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      row_props (enum):
        An object of additional props to be passed to each `<tr>` in
        the table body. Also accepts a function that will be called for
        each row.

        Enum values: [
          Record<string, any>, ((      data: Pick<ItemKeySlot<any>, 'item', 'index', js_fn
        ]
      hide_default_body (boolean):
        Hides the default body.
      hide_default_footer (boolean):
        Hides the default footer.
      hide_default_header (boolean):
        Hides the default header.
      fixed_header (boolean):
        Fixed header to top of table.
      sort_icon (enum):
        Icon used for unsorted columns. By default it uses either **sortAscIcon**
        or **sortDescIcon** depending on **initialSortOrder**, but can
        be customized to show a neutral icon instead.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_asc_icon (enum):
        Icon used for ascending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_desc_icon (enum):
        Icon used for descending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      select_all_label (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      gridlines (boolean, 'horizontal', 'vertical', 'all'):
        Controls cell borders - **horizontal** draws lines between rows
        - **vertical** between columns (keeps horizontal lines of header
        and footer rows) - **all** / `true` draws both vertical and horizontal
        lines - `false` removes all lines.
      fixed_footer (boolean):
        Makes the footer stick to the bottom of the table while scrolling.
        Requires the **height** prop.
      hover (boolean):
        Adds a hover effects to a table rows.
      striped ('odd', 'even'):
        Applies a background to either **even** or **odd** rows.
      prev_icon (enum):
        Previous icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Next icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      first_icon (enum):
        First icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      last_icon (enum):
        Last icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      items_per_page_text (string):
        Text for items-per-page dropdown.
      page_text (string):
        Label for page number.
      first_page_label (string):
        Label for first page.
      prev_page_label (string):
        Label for previous page.
      next_page_label (string):
        Label for next page.
      last_page_label (string):
        Label for last page.
      items_per_page_options ((number, { title: string; value: number })[]):
        Array of options to show in the items-per-page dropdown.
      show_current_page (boolean):
        Show current page number between prev/next icons.
      show_first_last_page (boolean, 'only-first'):
        Show buttons for going to first and last page. Since v4.1.0 it
        accepts `'only-first'`, to only the first page button.
      update_opened (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTable.json))
      update_modelValue (event):
        Emits when the component's model changes.
      update_expanded (event):
        Emits when the **expanded** items are updated.
      update_groupBy (event):
        Emits when the **group-by** prop is updated.
      update_page (event):
        Emits when the **page** prop is updated.
      update_itemsPerPage (event):
        Emits when the **items-per-page** prop is updated.
      update_sortBy (event):
        Emits when the **sortBy** prop is updated.
      update_options (event):
        Emits when pagination related properties (page, itemsPerPage,
        sortBy, groupBy, search) is updated.
      update_currentItems (event):
        Emits with the items currently being displayed.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTable", children, **kwargs)
        self.ttsSensitive()
        self._attr_names += [
            "search",
            "tag",
            "height",
            "width",
            "theme",
            "items",
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            ("hide_no_data", "hideNoData"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "opened",
            ("select_strategy", "selectStrategy"),
            "density",
            ("item_value", "itemValue"),
            ("return_object", "returnObject"),
            ("value_comparator", "valueComparator"),
            "color",
            ("model_value", "modelValue"),
            ("no_data_text", "noDataText"),
            "loading",
            ("get_matches", "getMatches"),
            "mobile",
            "sticky",
            ("item_selectable", "itemSelectable"),
            ("show_select", "showSelect"),
            "page",
            ("initial_sort_order", "initialSortOrder"),
            ("sort_by", "sortBy"),
            ("multi_sort", "multiSort"),
            ("must_sort", "mustSort"),
            ("custom_key_sort", "customKeySort"),
            ("items_per_page", "itemsPerPage"),
            ("page_by", "pageBy"),
            ("expand_on_click", "expandOnClick"),
            ("show_expand", "showExpand"),
            "expanded",
            ("expand_strategy", "expandStrategy"),
            ("group_by", "groupBy"),
            ("open_all", "openAll"),
            ("group_key", "groupKey"),
            ("header_props", "headerProps"),
            ("cell_props", "cellProps"),
            ("disable_sort", "disableSort"),
            "headers",
            ("loading_text", "loadingText"),
            ("expand_transition", "expandTransition"),
            ("mobile_breakpoint", "mobileBreakpoint"),
            ("group_collapse_icon", "groupCollapseIcon"),
            ("group_expand_icon", "groupExpandIcon"),
            ("row_props", "rowProps"),
            ("hide_default_body", "hideDefaultBody"),
            ("hide_default_footer", "hideDefaultFooter"),
            ("hide_default_header", "hideDefaultHeader"),
            ("fixed_header", "fixedHeader"),
            ("sort_icon", "sortIcon"),
            ("sort_asc_icon", "sortAscIcon"),
            ("sort_desc_icon", "sortDescIcon"),
            ("select_all_label", "selectAllLabel"),
            "gridlines",
            ("fixed_footer", "fixedFooter"),
            "hover",
            "striped",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("first_icon", "firstIcon"),
            ("last_icon", "lastIcon"),
            ("items_per_page_text", "itemsPerPageText"),
            ("page_text", "pageText"),
            ("first_page_label", "firstPageLabel"),
            ("prev_page_label", "prevPageLabel"),
            ("next_page_label", "nextPageLabel"),
            ("last_page_label", "lastPageLabel"),
            ("items_per_page_options", "itemsPerPageOptions"),
            ("show_current_page", "showCurrentPage"),
            ("show_first_last_page", "showFirstLastPage"),
        ]
        self._event_names += [
            ("update_opened", "update:opened"),
            ("update_modelValue", "update:modelValue"),
            ("update_expanded", "update:expanded"),
            ("update_groupBy", "update:groupBy"),
            ("update_page", "update:page"),
            ("update_itemsPerPage", "update:itemsPerPage"),
            ("update_sortBy", "update:sortBy"),
            ("update_options", "update:options"),
            ("update_currentItems", "update:currentItems"),
        ]


class VDataTableFooter(HtmlElement):
    """
    Vuetify's VDataTableFooter component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table-footer>`_.

    Args:
      color (string):
        Applies specified color to the selected page button - supports
        utility colors (for example `success` or `purple`) or css color
        (`#033` or `rgba(255, 0, 0, 0.5)`). Find a list of built-in classes
        on the [colors page](/styles/colors#material-colors).
      prev_icon (enum):
        Previous icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Next icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      first_icon (enum):
        First icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      last_icon (enum):
        Last icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      items_per_page_text (string):
        Text for items-per-page dropdown.
      page_text (string):
        Label for page number.
      first_page_label (string):
        Label for first page.
      prev_page_label (string):
        Label for previous page.
      next_page_label (string):
        Label for next page.
      last_page_label (string):
        Label for last page.
      items_per_page_options ((number, { title: string; value: number })[]):
        Array of options to show in the items-per-page dropdown.
      show_current_page (boolean):
        Show current page number between prev/next icons.
      show_first_last_page (boolean, 'only-first'):
        Show buttons for going to first and last page. Since v4.1.0 it
        accepts `'only-first'`, to only the first page button.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTableFooter", children, **kwargs)
        self._attr_names += [
            "color",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("first_icon", "firstIcon"),
            ("last_icon", "lastIcon"),
            ("items_per_page_text", "itemsPerPageText"),
            ("page_text", "pageText"),
            ("first_page_label", "firstPageLabel"),
            ("prev_page_label", "prevPageLabel"),
            ("next_page_label", "nextPageLabel"),
            ("last_page_label", "lastPageLabel"),
            ("items_per_page_options", "itemsPerPageOptions"),
            ("show_current_page", "showCurrentPage"),
            ("show_first_last_page", "showFirstLastPage"),
        ]
        self._event_names += []


class VDataTableHeaders(HtmlElement):
    """
    Vuetify's VDataTableHeaders component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table-headers>`_.

    Args:
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      color (string):
        Applies a color to checkboxes, page size dropdown and sort badges
        in the table header.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      sticky (boolean):
        Deprecated, use `fixed-header` instead.
      initial_sort_order ('desc', 'asc'):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      multi_sort (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      header_props (unknown):
        Additional props to be be passed to the default header
      disable_sort (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      fixed_header (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      sort_icon (enum):
        Icon used for unsorted columns. By default it uses either **sortAscIcon**
        or **sortDescIcon** depending on **initialSortOrder**, but can
        be customized to show a neutral icon instead.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_asc_icon (enum):
        Icon used for ascending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_desc_icon (enum):
        Icon used for descending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      select_all_label (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTableHeaders", children, **kwargs)
        self._attr_names += [
            "density",
            "color",
            "loading",
            "mobile",
            "sticky",
            ("initial_sort_order", "initialSortOrder"),
            ("multi_sort", "multiSort"),
            ("header_props", "headerProps"),
            ("disable_sort", "disableSort"),
            ("mobile_breakpoint", "mobileBreakpoint"),
            ("fixed_header", "fixedHeader"),
            ("sort_icon", "sortIcon"),
            ("sort_asc_icon", "sortAscIcon"),
            ("sort_desc_icon", "sortDescIcon"),
            ("select_all_label", "selectAllLabel"),
        ]
        self._event_names += []


class VDataTableRow(HtmlElement):
    """
    Vuetify's VDataTableRow component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table-row>`_.

    Args:
      item (unknown):
        Data (key, index and column values) of the displayed item.
      expand_icon (enum):
        Icon to display when the expandable row is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the expandable row is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      get_matches (DataTableItem):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableRow.json))
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      index (number):
        Row index.
      cell_props (enum):
        Props to be applied to the cell.

        Enum values: [
          Record<string, any>, ((      data: Pick<        ItemKeySlot<unknown>,
                 'value', 'item', 'index', 'internalItem', js_fn
        ]
      select_row_label (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableRow.json))
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      contextmenu (event):
        The event emitted when the user clicks the context menu button.
      dblclick (event):
        The event emitted when the user double clicks the row.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTableRow", children, **kwargs)
        self._attr_names += [
            "item",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "density",
            "color",
            ("get_matches", "getMatches"),
            "mobile",
            "index",
            ("cell_props", "cellProps"),
            ("select_row_label", "selectRowLabel"),
            ("mobile_breakpoint", "mobileBreakpoint"),
        ]
        self._event_names += [
            "click",
            "contextmenu",
            "dblclick",
        ]


class VDataTableRows(HtmlElement):
    """
    Vuetify's VDataTableRows component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table-rows>`_.

    Args:
      items (DataTableItem):
        An array of strings or objects used for automatically generating
        children components.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      expand_icon (enum):
        Icon to display when the expandable row is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the expandable row is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      no_data_text (string):
        Text shown when no items are provided to the component.
      loading (enum):
        Displays `loading` slot if set to `true`

        Enum values: [
          string, boolean, { side: 'start', 'end', 'both'; color: string }
        ]
      get_matches (DataTableItem):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableRow.json))
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      cell_props (enum):
        An object of additional props to be passed to each `<td>` in
        the table body. Also accepts a function that will be called for
        each cell. If the same prop is defined both here and in `cellProps`
        in a headers object, the value from the headers object will be
        used.

        Enum values: [
          Record<string, any>, ((      data: Pick<        ItemKeySlot<any>,
                 'value', 'item', 'index', 'internalItem', js_fn
        ]
      loading_text (string):
        Text shown when the data is loading.
      expand_transition (enum):
        Transition used to animate the `expanded` slot content. Pass
        a string transition name, a component via `{ component }`, or
        any `<Transition>` props object.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      group_collapse_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableGroupHeaderRow.json))

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      group_expand_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableGroupHeaderRow.json))

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      row_props (enum):
        An object of additional props to be passed to each `<tr>` in
        the table body. Also accepts a function that will be called for
        each row.

        Enum values: [
          Record<string, any>, ((      data: Pick<ItemKeySlot<any>, 'item', 'index', js_fn
        ]
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTableRows", children, **kwargs)
        self._attr_names += [
            "items",
            ("hide_no_data", "hideNoData"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "density",
            "color",
            ("no_data_text", "noDataText"),
            "loading",
            ("get_matches", "getMatches"),
            "mobile",
            ("cell_props", "cellProps"),
            ("loading_text", "loadingText"),
            ("expand_transition", "expandTransition"),
            ("mobile_breakpoint", "mobileBreakpoint"),
            ("group_collapse_icon", "groupCollapseIcon"),
            ("group_expand_icon", "groupExpandIcon"),
            ("row_props", "rowProps"),
        ]
        self._event_names += []


class VDataTableServer(HtmlElement):
    """
    Vuetify's VDataTableServer component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table-server>`_.

    Args:
      search (string):
        Text input used to filter items.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      height (string, number):
        Use the height prop to set the height of the table.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      items (any[]):
        An array of strings or objects used for automatically generating
        children components.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      expand_icon (enum):
        Icon to display when the expandable row is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the expandable row is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      opened (string[]):
        Array of group IDs that should be open. Can be bound to external
        variable using **v-model:opened**.
      select_strategy ('single', 'page', 'all'):
        Defines the strategy of selecting items in the list. Possible
        values are: 'single' (only one item can be selected at a time),
        'page' ('Select all' button will select only items on the current
        page), 'all' ('Select all' button will select all items in the
        list).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      color (string):
        Applies a color to checkboxes, page size dropdown and sort badges
        in the table header.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      no_data_text (string):
        Text shown when no items are provided to the component.
      loading (string, boolean):
        Displays `loading` slot if set to `true`
      get_matches (DataTableItem):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableRow.json))
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      sticky (boolean):
        Deprecated, use `fixed-header` instead.
      items_length (string, number):
        Number of all items.
      item_selectable (SelectItemKey):
        Property on supplied `items` that indicates whether the item is selectable.
      show_select (boolean):
        Shows the column with checkboxes for selecting items in the list.
      page (string, number):
        The current displayed page number (1-indexed).
      initial_sort_order ('desc', 'asc'):
        Specifies the initial sort order when an unsorted column is clicked.
      sort_by (SortItem):
        Array of column keys and sort orders that determines the sort
        order of the table.
      multi_sort (enum):
        Let user sort by multiple properties/columns.  - **key**: (optional)
        when set to `ctrl`, user is required to hold a keyboard key (Ctrl
        on PC and Command on Mac) - **mode**: when user selects a new
        column to sort by, it will be set first (`prepend`) or last (`append`)
        in the sort priority. Defaults to `append` - **modifier**: (optional)
        allows user to use both multi-sort modes (`append` and `prepend`)
        simultaneously

        Enum values: [
          boolean, { key: 'ctrl'; mode: 'append', 'prepend'; modifier: 'shift', 'alt' }
        ]
      must_sort (boolean):
        Forces sorting on the column(s).
      custom_key_sort (unknown):
        Function used on specific keys within the item object. `customSort`
        is skipped for columns with `customKeySort` specified.
      items_per_page (string, number):
        The number of items to display on each page.
      page_by ('item', 'auto', 'any'):
        Controls how pagination counts items. - **item** paginates by
        individual items, - **auto** paginates by top-level groups and
        falls back to regular items if **group-by** is empty, - **any**
        paginates by both items and groups combined
      expand_on_click (boolean):
        Expands item when the row is clicked.
      show_expand (boolean):
        Shows the expand icon.
      expanded (string[]):
        Array of expanded items. Can be bound to external variable using
        **v-model:expanded**.
      expand_strategy ('multiple', 'single'):
        Controls how many rows can be expanded at once. Use `single`
        to collapse the previously expanded row when another is opened.
      group_by (SortItem):
        Defines the grouping of the table items.
      open_all (boolean):
        Opens all groups by default. Synchronizes with **v-model:opened**,
        so closed groups are not re-opened accidentally.
      group_key ((options: { key: string; value: any; parentKey: string }) => string):
        Custom function to generate group IDs. Receives `{ key, value,
        parentKey }` where `parentKey` is `null` for top-level groups.
        Useful when group values contain special characters or are non-string
        types.
      header_props (unknown):
        Pass props to the default header. See [`v-data-table-server`
        API](/api/v-data-table-server) for more information.
      cell_props (enum):
        An object of additional props to be passed to each `<td>` in
        the table body. Also accepts a function that will be called for
        each cell. If the same prop is defined both here and in `cellProps`
        in a headers object, the value from the headers object will be
        used.

        Enum values: [
          Record<string, any>, ((      data: Pick<        ItemKeySlot<any>,
                 'value', 'item', 'index', 'internalItem', js_fn
        ]
      disable_sort (boolean):
        Toggles rendering of sort button.
      headers (enum):
        An array of objects that each describe a header column.

        Enum values: [
          {  readonly key?:, (string & {}), 'data-table-group', 'data-table-select',
          'data-table-expand', undefined  readonly value?: SelectItemKey<any>
           readonly title?: string, undefined  readonly fixed?: boolean,
          'start', 'end', undefined  readonly align?: 'start', 'end', 'center',
          undefined  readonly width?: string, number, undefined  readonly
          minWidth?: string, number, undefined  readonly maxWidth?: string,
          number, undefined  readonly nowrap?: boolean, undefined  readonly
          indent?: number, undefined  readonly headerProps?: { readonly
          [x: string]: any }, undefined  readonly cellProps?:, { readonly
          [x: string]: any }, HeaderCellPropsFunction, undefined  readonly
          sortable?: boolean, undefined  readonly sort?: DataTableCompareFunction<any>,
          undefined  readonly sortRaw?: DataTableCompareFunction<any>,
          undefined  readonly filter?: FilterFunction, undefined  readonly
          children?: readonly any[], undefined}[]
        ]
      loading_text (string):
        Text shown when the data is loading.
      expand_transition (enum):
        Transition used to animate the `expanded` slot content. Pass
        a string transition name, a component via `{ component }`, or
        any `<Transition>` props object.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      group_collapse_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableGroupHeaderRow.json))

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      group_expand_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableGroupHeaderRow.json))

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      row_props (enum):
        An object of additional props to be passed to each `<tr>` in
        the table body. Also accepts a function that will be called for
        each row.

        Enum values: [
          Record<string, any>, ((      data: Pick<ItemKeySlot<any>, 'item', 'index', js_fn
        ]
      hide_default_body (boolean):
        Hides the default body.
      hide_default_footer (boolean):
        Hides the default footer.
      hide_default_header (boolean):
        Hides the default header.
      fixed_header (boolean):
        Makes the header stick to the top of the table while scrolling.
        Requires the **height** prop.
      sort_icon (enum):
        Icon used for unsorted columns. By default it uses either **sortAscIcon**
        or **sortDescIcon** depending on **initialSortOrder**, but can
        be customized to show a neutral icon instead.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_asc_icon (enum):
        Icon used for ascending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_desc_icon (enum):
        Icon used for descending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      select_all_label (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      gridlines (boolean, 'horizontal', 'vertical', 'all'):
        Controls cell borders - **horizontal** draws lines between rows
        - **vertical** between columns (keeps horizontal lines of header
        and footer rows) - **all** / `true` draws both vertical and horizontal
        lines - `false` removes all lines.
      fixed_footer (boolean):
        Makes the footer stick to the bottom of the table while scrolling.
        Requires the **height** prop.
      hover (boolean):
        Will add a hover effect to a table's row when the mouse is over it.
      striped ('odd', 'even'):
        Applies a background to either **even** or **odd** rows.
      prev_icon (enum):
        Previous icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Next icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      first_icon (enum):
        First icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      last_icon (enum):
        Last icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      items_per_page_text (string):
        Text for items-per-page dropdown.
      page_text (string):
        Label for page number.
      first_page_label (string):
        Label for first page.
      prev_page_label (string):
        Label for previous page.
      next_page_label (string):
        Label for next page.
      last_page_label (string):
        Label for last page.
      items_per_page_options ((number, { title: string; value: number })[]):
        Array of options to show in the items-per-page dropdown.
      show_current_page (boolean):
        Show current page number between prev/next icons.
      show_first_last_page (boolean, 'only-first'):
        Show buttons for going to first and last page. Since v4.1.0 it
        accepts `'only-first'`, to only the first page button.
      update_opened (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableServer.json))
      update_modelValue (event):
        Emits when the component's model changes.
      update_expanded (event):
        Emits when the **expanded** prop is updated.
      update_groupBy (event):
        Emits when the **group-by** prop is updated.
      update_page (event):
        Emits when the **page** prop is updated.
      update_itemsPerPage (event):
        Emits when the **items-per-page** prop is updated.
      update_sortBy (event):
        Emits when the **sortBy** prop is updated.
      update_options (event):
        Emits when pagination related properties (page, itemsPerPage,
        sortBy, groupBy, search) is updated.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTableServer", children, **kwargs)
        self._attr_names += [
            "search",
            "tag",
            "height",
            "width",
            "theme",
            "items",
            ("hide_no_data", "hideNoData"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "opened",
            ("select_strategy", "selectStrategy"),
            "density",
            ("item_value", "itemValue"),
            ("return_object", "returnObject"),
            ("value_comparator", "valueComparator"),
            "color",
            ("model_value", "modelValue"),
            ("no_data_text", "noDataText"),
            "loading",
            ("get_matches", "getMatches"),
            "mobile",
            "sticky",
            ("items_length", "itemsLength"),
            ("item_selectable", "itemSelectable"),
            ("show_select", "showSelect"),
            "page",
            ("initial_sort_order", "initialSortOrder"),
            ("sort_by", "sortBy"),
            ("multi_sort", "multiSort"),
            ("must_sort", "mustSort"),
            ("custom_key_sort", "customKeySort"),
            ("items_per_page", "itemsPerPage"),
            ("page_by", "pageBy"),
            ("expand_on_click", "expandOnClick"),
            ("show_expand", "showExpand"),
            "expanded",
            ("expand_strategy", "expandStrategy"),
            ("group_by", "groupBy"),
            ("open_all", "openAll"),
            ("group_key", "groupKey"),
            ("header_props", "headerProps"),
            ("cell_props", "cellProps"),
            ("disable_sort", "disableSort"),
            "headers",
            ("loading_text", "loadingText"),
            ("expand_transition", "expandTransition"),
            ("mobile_breakpoint", "mobileBreakpoint"),
            ("group_collapse_icon", "groupCollapseIcon"),
            ("group_expand_icon", "groupExpandIcon"),
            ("row_props", "rowProps"),
            ("hide_default_body", "hideDefaultBody"),
            ("hide_default_footer", "hideDefaultFooter"),
            ("hide_default_header", "hideDefaultHeader"),
            ("fixed_header", "fixedHeader"),
            ("sort_icon", "sortIcon"),
            ("sort_asc_icon", "sortAscIcon"),
            ("sort_desc_icon", "sortDescIcon"),
            ("select_all_label", "selectAllLabel"),
            "gridlines",
            ("fixed_footer", "fixedFooter"),
            "hover",
            "striped",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("first_icon", "firstIcon"),
            ("last_icon", "lastIcon"),
            ("items_per_page_text", "itemsPerPageText"),
            ("page_text", "pageText"),
            ("first_page_label", "firstPageLabel"),
            ("prev_page_label", "prevPageLabel"),
            ("next_page_label", "nextPageLabel"),
            ("last_page_label", "lastPageLabel"),
            ("items_per_page_options", "itemsPerPageOptions"),
            ("show_current_page", "showCurrentPage"),
            ("show_first_last_page", "showFirstLastPage"),
        ]
        self._event_names += [
            ("update_opened", "update:opened"),
            ("update_modelValue", "update:modelValue"),
            ("update_expanded", "update:expanded"),
            ("update_groupBy", "update:groupBy"),
            ("update_page", "update:page"),
            ("update_itemsPerPage", "update:itemsPerPage"),
            ("update_sortBy", "update:sortBy"),
            ("update_options", "update:options"),
        ]


class VDataTableVirtual(HtmlElement):
    """
    Vuetify's VDataTableVirtual component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-data-table-virtual>`_.

    Args:
      search (string):
        Text input used to filter items.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      height (string, number):
        Use the height prop to set the height of the table.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      items (any[]):
        An array of strings or objects used for automatically generating
        children components.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function used to filter items, called for each filterable key
        on each item in the list. The first argument is the filterable
        value from the item, the second is the search term, and the third
        is the internal item object. The function should return true
        if the item should be included in the filtered list, or the index
        of the match in the value if it should be included with the result
        highlighted.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      expand_icon (enum):
        Icon to display when the expandable row is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the expandable row is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      opened (string[]):
        Array of group IDs that should be open. Can be bound to external
        variable using **v-model:opened**.
      select_strategy ('single', 'page', 'all'):
        Defines the strategy of selecting items in the list. Possible
        values are: 'single' (only one item can be selected at a time),
        'page' ('Select all' button will select only items on the current
        page), 'all' ('Select all' button will select all items in the
        list).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      color (string):
        Applies a color to checkboxes, page size dropdown and sort badges
        in the table header.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      no_data_text (string):
        Text shown when no items are provided to the component.
      loading (string, boolean):
        Displays `loading` slot if set to `true`
      get_matches (DataTableItem):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableRow.json))
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      sticky (boolean):
        Deprecated, use `fixed-header` instead.
      item_selectable (SelectItemKey):
        Property on supplied `items` that indicates whether the item is selectable.
      show_select (boolean):
        Shows the column with checkboxes for selecting items in the list.
      initial_sort_order ('desc', 'asc'):
        Specifies the initial sort order when an unsorted column is clicked.
      sort_by (SortItem):
        Array of column keys and sort orders that determines the sort
        order of the table.
      multi_sort (enum):
        Let user sort by multiple properties/columns.  - **key**: (optional)
        when set to `ctrl`, user is required to hold a keyboard key (Ctrl
        on PC and Command on Mac) - **mode**: when user selects a new
        column to sort by, it will be set first (`prepend`) or last (`append`)
        in the sort priority. Defaults to `append` - **modifier**: (optional)
        allows user to use both multi-sort modes (`append` and `prepend`)
        simultaneously

        Enum values: [
          boolean, { key: 'ctrl'; mode: 'append', 'prepend'; modifier: 'shift', 'alt' }
        ]
      must_sort (boolean):
        Forces sorting on the column(s).
      custom_key_sort (unknown):
        Function used on specific keys within the item object. `customSort`
        is skipped for columns with `customKeySort` specified.
      expand_on_click (boolean):
        Expands item when the row is clicked.
      show_expand (boolean):
        Shows the expand icon.
      expanded (string[]):
        Array of expanded items. Can be bound to external variable using
        **v-model:expanded**.
      expand_strategy ('multiple', 'single'):
        Controls how many rows can be expanded at once. Use `single`
        to collapse the previously expanded row when another is opened.
      group_by (SortItem):
        Defines the grouping of the table items.
      open_all (boolean):
        Opens all groups by default. Synchronizes with **v-model:opened**,
        so closed groups are not re-opened accidentally.
      group_key ((options: { key: string; value: any; parentKey: string }) => string):
        Custom function to generate group IDs. Receives `{ key, value,
        parentKey }` where `parentKey` is `null` for top-level groups.
        Useful when group values contain special characters or are non-string
        types.
      header_props (unknown):
        Pass props to the default header.
      cell_props (enum):
        An object of additional props to be passed to each `<td>` in
        the table body. Also accepts a function that will be called for
        each cell. If the same prop is defined both here and in `cellProps`
        in a headers object, the value from the headers object will be
        used.

        Enum values: [
          Record<string, any>, ((      data: Pick<        ItemKeySlot<any>,
                 'value', 'item', 'index', 'internalItem', js_fn
        ]
      disable_sort (boolean):
        Toggles rendering of sort button.
      headers (enum):
        An array of objects that each describe a header column.

        Enum values: [
          {  readonly key?:, (string & {}), 'data-table-group', 'data-table-select',
          'data-table-expand', undefined  readonly value?: SelectItemKey<any>
           readonly title?: string, undefined  readonly fixed?: boolean,
          'start', 'end', undefined  readonly align?: 'start', 'end', 'center',
          undefined  readonly width?: string, number, undefined  readonly
          minWidth?: string, number, undefined  readonly maxWidth?: string,
          number, undefined  readonly nowrap?: boolean, undefined  readonly
          indent?: number, undefined  readonly headerProps?: { readonly
          [x: string]: any }, undefined  readonly cellProps?:, { readonly
          [x: string]: any }, HeaderCellPropsFunction, undefined  readonly
          sortable?: boolean, undefined  readonly sort?: DataTableCompareFunction<any>,
          undefined  readonly sortRaw?: DataTableCompareFunction<any>,
          undefined  readonly filter?: FilterFunction, undefined  readonly
          children?: readonly any[], undefined}[]
        ]
      loading_text (string):
        Text shown when the data is loading.
      expand_transition (enum):
        Transition used to animate the `expanded` slot content. Pass
        a string transition name, a component via `{ component }`, or
        any `<Transition>` props object.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      group_collapse_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableGroupHeaderRow.json))

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      group_expand_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableGroupHeaderRow.json))

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      row_props (enum):
        An object of additional props to be passed to each `<tr>` in
        the table body. Also accepts a function that will be called for
        each row.

        Enum values: [
          Record<string, any>, ((      data: Pick<ItemKeySlot<any>, 'item', 'index', js_fn
        ]
      hide_default_body (boolean):
        Hides the default body.
      hide_default_header (boolean):
        Hides the default header.
      fixed_header (boolean):
        Makes the header stick to the top of the table while scrolling.
        Requires the **height** prop.
      sort_icon (enum):
        Icon used for unsorted columns. By default it uses either **sortAscIcon**
        or **sortDescIcon** depending on **initialSortOrder**, but can
        be customized to show a neutral icon instead.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_asc_icon (enum):
        Icon used for ascending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      sort_desc_icon (enum):
        Icon used for descending sort button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      select_all_label (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableHeaders.json))
      gridlines (boolean, 'horizontal', 'vertical', 'all'):
        Controls cell borders - **horizontal** draws lines between rows
        - **vertical** between columns (keeps horizontal lines of header
        and footer rows) - **all** / `true` draws both vertical and horizontal
        lines - `false` removes all lines.
      fixed_footer (boolean):
        Makes the footer stick to the bottom of the table while scrolling.
        Requires the **height** prop.
      hover (boolean):
        Will add a hover effect to a table's row when the mouse is over it.
      striped ('odd', 'even'):
        Applies a background to either **even** or **odd** rows.
      item_height (string, number):
        Height in pixels of each item to display.
      item_key (SelectItemKey):
        The property on each item that is used as a unique key.
      update_opened (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDataTableVirtual.json))
      update_modelValue (event):
        Emits when the component's model changes.
      update_expanded (event):
        Emits when the **expanded** prop is updated.
      update_groupBy (event):
        Emits when the **group-by** prop is updated.
      update_sortBy (event):
        Emits when the **sortBy** prop is updated.
      update_options (event):
        Emits when pagination related properties (page, itemsPerPage,
        sortBy, groupBy, search) is updated.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDataTableVirtual", children, **kwargs)
        self._attr_names += [
            "search",
            "tag",
            "height",
            "width",
            "theme",
            "items",
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            ("hide_no_data", "hideNoData"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "opened",
            ("select_strategy", "selectStrategy"),
            "density",
            ("item_value", "itemValue"),
            ("return_object", "returnObject"),
            ("value_comparator", "valueComparator"),
            "color",
            ("model_value", "modelValue"),
            ("no_data_text", "noDataText"),
            "loading",
            ("get_matches", "getMatches"),
            "mobile",
            "sticky",
            ("item_selectable", "itemSelectable"),
            ("show_select", "showSelect"),
            ("initial_sort_order", "initialSortOrder"),
            ("sort_by", "sortBy"),
            ("multi_sort", "multiSort"),
            ("must_sort", "mustSort"),
            ("custom_key_sort", "customKeySort"),
            ("expand_on_click", "expandOnClick"),
            ("show_expand", "showExpand"),
            "expanded",
            ("expand_strategy", "expandStrategy"),
            ("group_by", "groupBy"),
            ("open_all", "openAll"),
            ("group_key", "groupKey"),
            ("header_props", "headerProps"),
            ("cell_props", "cellProps"),
            ("disable_sort", "disableSort"),
            "headers",
            ("loading_text", "loadingText"),
            ("expand_transition", "expandTransition"),
            ("mobile_breakpoint", "mobileBreakpoint"),
            ("group_collapse_icon", "groupCollapseIcon"),
            ("group_expand_icon", "groupExpandIcon"),
            ("row_props", "rowProps"),
            ("hide_default_body", "hideDefaultBody"),
            ("hide_default_header", "hideDefaultHeader"),
            ("fixed_header", "fixedHeader"),
            ("sort_icon", "sortIcon"),
            ("sort_asc_icon", "sortAscIcon"),
            ("sort_desc_icon", "sortDescIcon"),
            ("select_all_label", "selectAllLabel"),
            "gridlines",
            ("fixed_footer", "fixedFooter"),
            "hover",
            "striped",
            ("item_height", "itemHeight"),
            ("item_key", "itemKey"),
        ]
        self._event_names += [
            ("update_opened", "update:opened"),
            ("update_modelValue", "update:modelValue"),
            ("update_expanded", "update:expanded"),
            ("update_groupBy", "update:groupBy"),
            ("update_sortBy", "update:sortBy"),
            ("update_options", "update:options"),
        ]


class VDateInput(HtmlElement):
    """
    Vuetify's VDateInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-input>`_.

    Args:
      title (string):
        Specify a title text for the component.
      text (string):
        Specify content text for the component.
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      type (string):
        Sets input type.
      model_value (unknown):
        Represents the committed v-model value
      error (boolean):
        Puts the input in a manual error state.
      reverse (boolean):
        Reverses the orientation.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Width of the picker.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the date picker's location. Can combine by using a
        space separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'filled', 'underlined', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      name (string):
        Sets the component's name attribute.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      max (unknown):
        Maximum allowed date/month (ISO 8601 format).
      min (unknown):
        Minimum allowed date/month (ISO 8601 format).
      multiple (number, boolean, (string & {}), 'range'):
        Allow the selection of multiple dates. The **range** value selects
        all dates between two selections.
      placeholder (string):
        Sets the input’s placeholder text.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      header (string):
        Text shown when no **display-date** is set.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Makes the picker readonly (doesn't allow to select new date).
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      transition (string):
        The transition used when changing months into the future
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      menu (boolean):
        Renders with the menu open by default.
      open_on_focus (boolean):
        Open the date picker menu when the input receives focus.
      divided (boolean):
        Adds a divider between the header and controls.
      weekdays ((0, 1, 2, 4, 5, 6, 3)[]):
        An array of weekdays to display. Does not affect the order.
      first_day_of_week (string, number):
        Sets the first day of the week, starting with 0 for Sunday. (Note:
        not guaranteed to work when using custom date adapters.)
      first_day_of_year (string, number):
        Sets the day that determines the first week of the year, starting
        with 0 for Sunday. For ISO 8601 this should be 4. (Note: not
        guaranteed to work when using custom date adapters.)
      weekday_format ('long', 'short', 'narrow'):
        Allows you to customize the format of the weekday string that
        appears in the body of the calendar. Uses `'narrow'` by default.
        (Note: not guaranteed to work when using custom date adapters.)
      month (string, number):
        Sets the month.
      events (enum):
        Array of dates or object defining events or colors or function
        returning boolean/color/array of colors.

        Enum values: [
          string[], js_fn, boolean, string[]), Record<string, string, boolean, string[]>
        ]
      event_color (enum):
        Sets the color for event dots. It can be string (all events will
        have the same color) or `object` where attribute is the event
        date and value is boolean/color/array of colors for specified
        date or `function` taking date as a parameter and returning boolean/color/array
        of colors for that date.

        Enum values: [
          string, boolean, string[], Record<string, string, boolean, string[]>,
          js_fn, boolean, string[])
        ]
      year (number):
        Sets the year.
      show_week (boolean):
        Toggles visibility of the week numbers in the body of the calendar.
      hide_header (boolean):
        Hide the picker header.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      next_icon (enum):
        Icon used for the next button.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prev_icon (enum):
        Icon used for the previous button.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      reverse_transition (string):
        The transition used when changing months into the past
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      landscape (boolean):
        Puts the picker into landscape mode.
      hide_title (boolean):
        Hide the picker title.
      menu_props (unknown):
        Pass props through to the `v-menu` component. Accepts an object
        with anything from [v-menu](/api/v-menu/#props) props, camelCase
        keys are recommended.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      display_format (string, js_fn):
        The format of the date that is displayed in the input. Can use
        any format [here](/features/dates/#format-options) or a custom
        function.
      update_on (('blur', 'enter')[]):
        Specifies when the text input should update the model value.
        If empty, the text field will go into read-only state.
      header_color (string):
        Allows you to set a different color for the header when used
        in conjunction with the `color` prop.
      header_date_format (string):
        Allows you to customize the format of the date selection text
        that appears in the header of the calendar.
      landscape_header_width (string, number):
        Sets header width when in landscape mode.
      control_height (string, number):
        Sets the height of the controls.
      control_variant ('docked', 'modal'):
        - **docked:** Separate control groups for month and year. - **modal:**
        Month and year are displayed together, clicking the text opens
        a month picker, clicking the dropdown arrow opens a year picker.
        There are also arrow buttons to scroll between months.
      no_month_picker (boolean):
        Only applies to `controlVariant="modal"`, the month and year
        picker buttons are combined into one that only opens the year
        picker.
      mode_icon (enum):
        Icon used for the mode button.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      view_mode ('month', 'year', 'months'):
        Sets the view mode of the date picker.
      hide_weekdays (boolean):
        Hides the weekdays.
      no_auto_navigation (boolean):
        Prevents the displayed month from automatically following the
        selected value. Useful when building multi-calendar layouts where
        each picker manages its own view.
      show_adjacent_months (boolean):
        Toggles visibility of days from previous and next months.
      weeks_in_month ('static', 'dynamic'):
        A dynamic number of weeks in a month will grow and shrink depending
        on how many days are in the month. A static number always shows
        7 weeks.
      allowed_dates (unknown[], js_fn):
        Restricts which dates can be selected.
      preview_value (unknown):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))
      allowed_months (number[], js_fn):
        Restricts which months can be selected.
      allowed_years (number[], js_fn):
        Restricts which years can be selected.
      input_format (string):
        Format for manual date input. Use yyyy, mm, dd with separators
        '.', '-', '/' (e.g. 'yyyy-mm-dd', 'dd/mm/yyyy').
      cancel_text (string):
        Text for the cancel button
      ok_text (string):
        Text for the ok button
      hide_actions (boolean):
        Hide the Cancel and OK buttons, and automatically update the
        value when a date is selected.
      picker_props (unknown):
        Pass props through to the picker component. Intended for props
        that conflict with `v-text-field` (`color`, `width`, `rounded`,
        etc.)
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      cancel (event):
        The event emitted when the user clicks the Cancel button
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      update_menu (event):
        Event that is emitted when the component's menu state changes.
      save (event):
        The event emitted when the user clicks the Save button
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDateInput", children, **kwargs)
        self._attr_names += [
            "title",
            "text",
            "flat",
            "border",
            "type",
            ("model_value", "modelValue"),
            "error",
            "reverse",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "name",
            "autocomplete",
            "disabled",
            "max",
            "min",
            "multiple",
            "placeholder",
            "id",
            "prefix",
            "role",
            "autofocus",
            "header",
            "active",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "loading",
            "label",
            "transition",
            ("bg_color", "bgColor"),
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "menu",
            ("open_on_focus", "openOnFocus"),
            "divided",
            "weekdays",
            ("first_day_of_week", "firstDayOfWeek"),
            ("first_day_of_year", "firstDayOfYear"),
            ("weekday_format", "weekdayFormat"),
            "month",
            "events",
            ("event_color", "eventColor"),
            "year",
            ("show_week", "showWeek"),
            ("hide_header", "hideHeader"),
            "messages",
            ("next_icon", "nextIcon"),
            ("prev_icon", "prevIcon"),
            ("reverse_transition", "reverseTransition"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            "landscape",
            ("hide_title", "hideTitle"),
            ("menu_props", "menuProps"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
            ("display_format", "displayFormat"),
            ("update_on", "updateOn"),
            ("header_color", "headerColor"),
            ("header_date_format", "headerDateFormat"),
            ("landscape_header_width", "landscapeHeaderWidth"),
            ("control_height", "controlHeight"),
            ("control_variant", "controlVariant"),
            ("no_month_picker", "noMonthPicker"),
            ("mode_icon", "modeIcon"),
            ("view_mode", "viewMode"),
            ("hide_weekdays", "hideWeekdays"),
            ("no_auto_navigation", "noAutoNavigation"),
            ("show_adjacent_months", "showAdjacentMonths"),
            ("weeks_in_month", "weeksInMonth"),
            ("allowed_dates", "allowedDates"),
            ("preview_value", "previewValue"),
            ("allowed_months", "allowedMonths"),
            ("allowed_years", "allowedYears"),
            ("input_format", "inputFormat"),
            ("cancel_text", "cancelText"),
            ("ok_text", "okText"),
            ("hide_actions", "hideActions"),
            ("picker_props", "pickerProps"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "cancel",
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("update_menu", "update:menu"),
            "save",
        ]


class VDatePicker(HtmlElement):
    """
    Vuetify's VDatePicker component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-picker>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      header (string):
        Text shown when no **display-date** is set.
      title (string):
        Specify a title text for the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      max (unknown):
        Maximum allowed date/month (ISO 8601 format).
      min (unknown):
        Minimum allowed date/month (ISO 8601 format).
      multiple (number, boolean, (string & {}), 'range'):
        Allow the selection of multiple dates. The **range** value selects
        all dates between two selections.
      width (string, number):
        Width of the picker.
      theme (string):
        Specify a theme for this component and all of its children.
      text (string):
        Specify content text for the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      transition (string):
        The transition used when changing months into the future
      readonly (boolean):
        Makes the picker readonly (doesn't allow to select new date).
      divided (boolean):
        Adds a divider between the header and controls.
      landscape (boolean):
        Changes the picker to landscape mode.
      hide_header (boolean):
        Hides the header.
      hide_title (boolean):
        Hide the picker title.
      position ('fixed', 'relative', 'absolute', 'static', 'sticky'):
        Sets the position for the component.
      prev_icon (enum):
        Sets the icon for previous month/year button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Sets the icon for next month/year button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      year (number):
        Sets the year.
      month (string, number):
        Sets the month.
      header_color (string):
        Allows you to set a different color for the header when used
        in conjunction with the `color` prop.
      header_date_format (string):
        Allows you to customize the format of the date selection text
        that appears in the header of the calendar.
      landscape_header_width (string, number):
        Sets header width when in landscape mode.
      control_height (string, number):
        Sets the height of the controls.
      control_variant ('docked', 'modal'):
        - **docked:** Separate control groups for month and year. - **modal:**
        Month and year are displayed together, clicking the text opens
        a month picker, clicking the dropdown arrow opens a year picker.
        There are also arrow buttons to scroll between months.
      no_month_picker (boolean):
        Only applies to `controlVariant="modal"`, the month and year
        picker buttons are combined into one that only opens the year
        picker.
      mode_icon (enum):
        Icon displayed next to the current month and year, toggles year
        selection when clicked.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      view_mode ('year', 'month', 'months'):
        Determines which picker in the date or month picker is being
        displayed. Allowed values: `'month'`, `'months'`, `'year'`.
      hide_weekdays (boolean):
        Hides the weekdays.
      show_week (boolean):
        Toggles visibility of the week numbers in the body of the calendar.
      reverse_transition (string):
        The transition used when changing months into the past
      events (enum):
        Array of dates or object defining events or colors or function
        returning boolean/color/array of colors.

        Enum values: [
          string[], js_fn, boolean, string[]), Record<string, string, boolean, string[]>
        ]
      event_color (enum):
        Sets the color for event dots. It can be string (all events will
        have the same color) or `object` where attribute is the event
        date and value is boolean/color/array of colors for specified
        date or `function` taking date as a parameter and returning boolean/color/array
        of colors for that date.

        Enum values: [
          string, boolean, string[], Record<string, string, boolean, string[]>,
          js_fn, boolean, string[])
        ]
      no_auto_navigation (boolean):
        Prevents the displayed month from automatically following the
        selected value. Useful when building multi-calendar layouts where
        each picker manages its own view.
      show_adjacent_months (boolean):
        Toggles visibility of days from previous and next months.
      weekdays ((0, 1, 2, 3, 4, 5, 6)[]):
        An array of weekdays to display. Does not affect the order.
      weeks_in_month ('static', 'dynamic'):
        A dynamic number of weeks in a month will grow and shrink depending
        on how many days are in the month. A static number always shows
        7 weeks.
      first_day_of_week (string, number):
        Sets the first day of the week, starting with 0 for Sunday. (Note:
        not guaranteed to work when using custom date adapters.)
      first_day_of_year (string, number):
        Sets the day that determines the first week of the year, starting
        with 0 for Sunday. For ISO 8601 this should be 4. (Note: not
        guaranteed to work when using custom date adapters.)
      allowed_dates (unknown[], js_fn):
        Restricts which dates can be selected.
      weekday_format ('long', 'short', 'narrow'):
        Allows you to customize the format of the weekday string that
        appears in the body of the calendar. Uses `'narrow'` by default.
        (Note: not guaranteed to work when using custom date adapters.)
      preview_value (unknown):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))
      allowed_months (number[], js_fn):
        Restricts which months can be selected.
      allowed_years (number[], js_fn):
        Restricts which years can be selected.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_month (event):
        Emitted when the month changes.
      update_year (event):
        Emitted when the year changes.
      update_previewValue (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePicker.json))
      update_viewMode (event):
        Emitted when the view mode changes.
      boundary_navigate (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePicker.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDatePicker", children, **kwargs)
        self._attr_names += [
            "tag",
            "header",
            "title",
            "disabled",
            "height",
            "max",
            "min",
            "multiple",
            "width",
            "theme",
            "text",
            ("bg_color", "bgColor"),
            "border",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            ("model_value", "modelValue"),
            "location",
            "transition",
            "readonly",
            "divided",
            "landscape",
            ("hide_header", "hideHeader"),
            ("hide_title", "hideTitle"),
            "position",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            "year",
            "month",
            ("header_color", "headerColor"),
            ("header_date_format", "headerDateFormat"),
            ("landscape_header_width", "landscapeHeaderWidth"),
            ("control_height", "controlHeight"),
            ("control_variant", "controlVariant"),
            ("no_month_picker", "noMonthPicker"),
            ("mode_icon", "modeIcon"),
            ("view_mode", "viewMode"),
            ("hide_weekdays", "hideWeekdays"),
            ("show_week", "showWeek"),
            ("reverse_transition", "reverseTransition"),
            "events",
            ("event_color", "eventColor"),
            ("no_auto_navigation", "noAutoNavigation"),
            ("show_adjacent_months", "showAdjacentMonths"),
            "weekdays",
            ("weeks_in_month", "weeksInMonth"),
            ("first_day_of_week", "firstDayOfWeek"),
            ("first_day_of_year", "firstDayOfYear"),
            ("allowed_dates", "allowedDates"),
            ("weekday_format", "weekdayFormat"),
            ("preview_value", "previewValue"),
            ("allowed_months", "allowedMonths"),
            ("allowed_years", "allowedYears"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_month", "update:month"),
            ("update_year", "update:year"),
            ("update_previewValue", "update:previewValue"),
            ("update_viewMode", "update:viewMode"),
            ("boundary_navigate", "boundary-navigate"),
        ]


class VDatePickerControls(HtmlElement):
    """
    Vuetify's VDatePickerControls component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-picker-controls>`_.

    Args:
      disabled (string, boolean, string[]):
        Removes the ability to click or target the component.
      text (string):
        Specify content text for the component.
      active (string, string[]):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      prev_icon (enum):
        Icon used for the previous button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Icon used for the next button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      control_height (string, number):
        Sets the height of the controls.
      control_variant ('docked', 'modal'):
        - **docked:** Separate control groups for month and year. - **modal:**
        Month and year are displayed together, clicking the text opens
        a month picker, clicking the dropdown arrow opens a year picker.
        There are also arrow buttons to scroll between months.
      no_month_picker (boolean):
        Only applies to `controlVariant="modal"`, the month and year
        picker buttons are combined into one that only opens the year
        picker.
      mode_icon (enum):
        Icon used for the mode button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      month_text (string):
        Text displayed for the current month.
      year_text (string):
        Text displayed for the current year.
      view_mode ('year', 'month', 'months'):
        Sets the view mode of the date picker.
      click_year (event):
        Event fired when clicking the date text.
      click_month (event):
        Event fired when clicking on the month.
      click_prev (event):
        Event fired when clicking the previous button.
      click_next (event):
        Event fired when clicking the next button.
      click_prev_year (event):
        Event fired when clicking the previous year button.
      click_next_year (event):
        Event fired when clicking the next year button.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDatePickerControls", children, **kwargs)
        self._attr_names += [
            "disabled",
            "text",
            "active",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("control_height", "controlHeight"),
            ("control_variant", "controlVariant"),
            ("no_month_picker", "noMonthPicker"),
            ("mode_icon", "modeIcon"),
            ("month_text", "monthText"),
            ("year_text", "yearText"),
            ("view_mode", "viewMode"),
        ]
        self._event_names += [
            ("click_year", "click:year"),
            ("click_month", "click:month"),
            ("click_prev", "click:prev"),
            ("click_next", "click:next"),
            ("click_prev_year", "click:prev-year"),
            ("click_next_year", "click:next-year"),
        ]


class VDatePickerHeader(HtmlElement):
    """
    Vuetify's VDatePickerHeader component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-picker-header>`_.

    Args:
      header (string):
        Sets the header content.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      transition (string):
        Sets the transition when the header changes.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      click_append (event):
        Emitted when appended icon is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDatePickerHeader", children, **kwargs)
        self._attr_names += [
            "header",
            "color",
            "transition",
            ("append_icon", "appendIcon"),
        ]
        self._event_names += [
            "click",
            ("click_append", "click:append"),
        ]


class VDatePickerMonth(HtmlElement):
    """
    Vuetify's VDatePickerMonth component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-picker-month>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      max (unknown):
        Sets the maximum date of the month.
      min (unknown):
        Sets the minimum date of the month.
      multiple (number, boolean, (string & {}), 'range'):
        Sets the multiple of the month.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      transition (string):
        The transition used when changing months into the future
      readonly (boolean):
        Puts the picker in a readonly state.
      year (string, number):
        Sets the year.
      month (string, number):
        Sets the month.
      hide_weekdays (boolean):
        Hide the days of the week letters.
      show_week (boolean):
        Show the week number.
      reverse_transition (string):
        The transition used when changing months into the past
      events (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))

        Enum values: [
          string[], js_fn, boolean, string[]), Record<string, string, boolean, string[]>
        ]
      event_color (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))

        Enum values: [
          string, boolean, string[], Record<string, string, boolean, string[]>,
          js_fn, boolean, string[])
        ]
      no_auto_navigation (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))
      show_adjacent_months (boolean):
        Show adjacent months.
      weekdays ((0, 1, 2, 3, 4, 5, 6)[]):
        An array of weekdays to display. Does not affect the order.
      weeks_in_month ('static', 'dynamic'):
        A dynamic number of weeks in a month will grow and shrink depending
        on how many days are in the month. A static number always shows
        7 weeks.
      first_day_of_week (string, number):
        Sets the first day of the week, starting with 0 for Sunday. (Note:
        not guaranteed to work when using custom date adapters.)
      first_day_of_year (string, number):
        Sets the day that determines the first week of the year, starting
        with 0 for Sunday. For ISO 8601 this should be 4. (Note: not
        guaranteed to work when using custom date adapters.)
      allowed_dates (unknown[], js_fn):
        Sets the allowed dates of the month.
      weekday_format ('long', 'short', 'narrow'):
        Allows you to customize the format of the weekday string that
        appears in the body of the calendar. Uses `'narrow'` by default.
        (Note: not guaranteed to work when using custom date adapters.)
      preview_value (unknown):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_month (event):
        Fired when the month changes.
      update_year (event):
        Fired when the year changes.
      update_previewValue (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))
      boundary_navigate (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonth.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDatePickerMonth", children, **kwargs)
        self._attr_names += [
            "disabled",
            "max",
            "min",
            "multiple",
            "color",
            ("model_value", "modelValue"),
            "transition",
            "readonly",
            "year",
            "month",
            ("hide_weekdays", "hideWeekdays"),
            ("show_week", "showWeek"),
            ("reverse_transition", "reverseTransition"),
            "events",
            ("event_color", "eventColor"),
            ("no_auto_navigation", "noAutoNavigation"),
            ("show_adjacent_months", "showAdjacentMonths"),
            "weekdays",
            ("weeks_in_month", "weeksInMonth"),
            ("first_day_of_week", "firstDayOfWeek"),
            ("first_day_of_year", "firstDayOfYear"),
            ("allowed_dates", "allowedDates"),
            ("weekday_format", "weekdayFormat"),
            ("preview_value", "previewValue"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_month", "update:month"),
            ("update_year", "update:year"),
            ("update_previewValue", "update:previewValue"),
            ("boundary_navigate", "boundary-navigate"),
        ]


class VDatePickerMonths(HtmlElement):
    """
    Vuetify's VDatePickerMonths component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-picker-months>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max (unknown):
        Sets the maximum selectable date. Months after this date will be disabled.
      min (unknown):
        Sets the minimum selectable date. Months before this date will be disabled.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      columns (number):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonths.json))
      year (number):
        Sets the year for the given months.
      allowed_months (number[], js_fn):
        Restricts which months can be selected.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      escape (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerMonths.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDatePickerMonths", children, **kwargs)
        self._attr_names += [
            "height",
            "max",
            "min",
            "color",
            ("model_value", "modelValue"),
            "columns",
            "year",
            ("allowed_months", "allowedMonths"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "escape",
        ]


class VDatePickerYears(HtmlElement):
    """
    Vuetify's VDatePickerYears component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-picker-years>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max (unknown):
        Sets the maximum date of the month.
      min (unknown):
        Sets the minimum date of the month.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      columns (number):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerYears.json))
      allowed_years (number[], js_fn):
        Restricts which years can be selected.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      escape (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VDatePickerYears.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDatePickerYears", children, **kwargs)
        self._attr_names += [
            "height",
            "max",
            "min",
            "color",
            ("model_value", "modelValue"),
            "columns",
            ("allowed_years", "allowedYears"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "escape",
        ]


class VDateRangePicker(HtmlElement):
    """
    Vuetify's VDateRangePicker component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-date-range-picker>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      title (string):
        Specify a title text for the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      max (unknown):
        Sets the maximum date of the month.
      min (unknown):
        Sets the minimum date of the month.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      transition (string):
        The transition used when changing months into the future
      readonly (boolean):
        Puts the picker in a readonly state.
      divided (boolean):
        Adds a divider between the header and controls.
      landscape (boolean):
        Puts the picker into landscape mode.
      hide_header (boolean):
        Hide the picker header.
      hide_title (boolean):
        Hide the picker title.
      position ('fixed', 'relative', 'absolute', 'static', 'sticky'):
        Sets the position for the component.
      prev_icon (enum):
        Icon used for the previous button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Icon used for the next button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      control_height (string, number):
        Sets the height of the controls.
      hide_weekdays (boolean):
        Hide the days of the week letters.
      show_week (boolean):
        Show the week number.
      reverse_transition (string):
        The transition used when changing months into the past
      weekdays ((0, 1, 2, 3, 4, 5, 6)[]):
        An array of weekdays to display. Does not affect the order.
      weeks_in_month ('static', 'dynamic'):
        A dynamic number of weeks in a month will grow and shrink depending
        on how many days are in the month. A static number always shows
        7 weeks.
      first_day_of_week (string, number):
        Sets the first day of the week, starting with 0 for Sunday. (Note:
        not guaranteed to work when using custom date adapters.)
      first_day_of_year (string, number):
        Sets the day that determines the first week of the year, starting
        with 0 for Sunday. For ISO 8601 this should be 4. (Note: not
        guaranteed to work when using custom date adapters.)
      allowed_dates (unknown[], js_fn):
        Sets the allowed dates of the month.
      weekday_format ('long', 'short', 'narrow'):
        Allows you to customize the format of the weekday string that
        appears in the body of the calendar. Uses `'narrow'` by default.
        (Note: not guaranteed to work when using custom date adapters.)
      allowed_months (number[], js_fn):
        Restricts which months can be selected.
      allowed_years (number[], js_fn):
        Restricts which years can be selected.
      independent_months (boolean):
        Decouples the two calendar panels so each month can be navigated independently.
      update_modelValue (event):
        Emitted when the range selection changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDateRangePicker", children, **kwargs)
        self._attr_names += [
            "tag",
            "title",
            "disabled",
            "height",
            "max",
            "min",
            "width",
            "theme",
            ("bg_color", "bgColor"),
            "border",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            ("model_value", "modelValue"),
            "location",
            "transition",
            "readonly",
            "divided",
            "landscape",
            ("hide_header", "hideHeader"),
            ("hide_title", "hideTitle"),
            "position",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("control_height", "controlHeight"),
            ("hide_weekdays", "hideWeekdays"),
            ("show_week", "showWeek"),
            ("reverse_transition", "reverseTransition"),
            "weekdays",
            ("weeks_in_month", "weeksInMonth"),
            ("first_day_of_week", "firstDayOfWeek"),
            ("first_day_of_year", "firstDayOfYear"),
            ("allowed_dates", "allowedDates"),
            ("weekday_format", "weekdayFormat"),
            ("allowed_months", "allowedMonths"),
            ("allowed_years", "allowedYears"),
            ("independent_months", "independentMonths"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VDefaultsProvider(HtmlElement):
    """
    Vuetify's VDefaultsProvider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-defaults-provider>`_.

    Args:
      reset (string, number):
        Reset the default values up the nested chain by {n} amount.
      disabled (boolean):
        Turns off all calculations of new default values for improved
        performance in situations where defaults propagation isn't necessary.
      root (string, boolean):
        Force current defaults to match the application root defaults.
      scoped (boolean):
        Prevents the ability for default values to be inherited from parent components.
      defaults ({  global: Record<string, unknown>  [string]: Record<string, unknown>}):
        Specify new default prop values for components. Keep in mind
        that this will be merged with previously defined values.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDefaultsProvider", children, **kwargs)
        self._attr_names += [
            "reset",
            "disabled",
            "root",
            "scoped",
            "defaults",
        ]
        self._event_names += []


class VDialog(HtmlElement):
    """
    Vuetify's VDialog component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-dialog>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      absolute (boolean):
        Applies **position: absolute** to the content element.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of a `v-dialog`'s
        content when using the **persistent** prop.
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      persistent (boolean):
        Clicking outside of the element or pressing **esc** key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Activate the component when the activator is clicked.
      open_on_hover (boolean):
        Designates whether component should activate when its activator is hovered.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          {      component: ComponentPublicInstanceConstructor<
          CreateComponentPublicInstanceWithMixins<          {} & { target?:
          HTMLElement, [x: number, y: number], undefined } & {
             $children?:, VNodeChild, { $stable?: boolean, undefined },
          js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn
        ]
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      fullscreen (boolean):
        Changes layout for fullscreen display.
      scrollable (boolean):
        When set to true, expects a `v-card` and a `v-card-text` component
        with a designated height. For more information, check out the
        [scrollable example](/components/dialogs#scrollable).
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      afterEnter (event):
        Event that fires after the overlay has finished transitioning in.
      afterLeave (event):
        Event that fires after the overlay has finished transitioning out.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDialog", children, **kwargs)
        self._attr_names += [
            "disabled",
            "height",
            "width",
            "theme",
            "target",
            "eager",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "activator",
            "absolute",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            ("model_value", "modelValue"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            ("location_strategy", "locationStrategy"),
            "location",
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            "transition",
            "attach",
            "fullscreen",
            "scrollable",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "afterEnter",
            "afterLeave",
        ]


class VDialogBottomTransition(HtmlElement):
    """
    Vuetify's VDialogBottomTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-dialog-bottom-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDialogBottomTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VDialogTopTransition(HtmlElement):
    """
    Vuetify's VDialogTopTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-dialog-top-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDialogTopTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VDialogTransition(HtmlElement):
    """
    Vuetify's VDialogTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-dialog-transition>`_.

    Args:
      target (HTMLElement, [number, number]):
        Sets the target element for the transition.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDialogTransition", children, **kwargs)
        self._attr_names += [
            "target",
        ]
        self._event_names += []


class VDivider(HtmlElement):
    """
    Vuetify's VDivider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-divider>`_.

    Args:
      length (string, number):
        Sets the dividers length. Default unit is px.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('dotted', 'dashed', 'solid', 'double'):
        Applies `border-style`.
      opacity (string, number):
        Sets the component's opacity value
      vertical (boolean):
        Displays dividers vertically.
      gradient (boolean):
        Adds fading effect for both sides.
      inset (boolean):
        Adds indentation (72px) for **normal** dividers, reduces max
        height for **vertical**.
      thickness (string, number):
        Sets the dividers thickness. Default unit is px.
      content_offset (string, number, (string, number)[]):
        Increases content spacing from the lines. When passed as an array,
        the second value shifts slot content down (or right in vertical
        mode).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VDivider", children, **kwargs)
        self._attr_names += [
            "length",
            "theme",
            "color",
            "variant",
            "opacity",
            "vertical",
            "gradient",
            "inset",
            "thickness",
            ("content_offset", "contentOffset"),
        ]
        self._event_names += []


class VEmptyState(HtmlElement):
    """
    Vuetify's VEmptyState component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-empty-state>`_.

    Args:
      title (string):
        Specify a title text for the component.
      height (string, number):
        Sets the height for the component.
      size (string, number):
        The size used to control the dimensions of the media element
        inside the component. Can be specified as a number or a string
        (e.g., '50%', '100px').
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      text (string):
        Specify content text for the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      image (string):
        Apply a specific image using [v-img](/components/images/).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      to (string):
        The URL the action button links to.
      href (string):
        The URL the action button links to.
      headline (string):
        A large headline often used for 404 pages.
      action_text (string):
        The text used for the action button.
      justify ('start', 'end', 'center'):
        Control the justification of the text.
      text_width (string, number):
        Sets the width of the text container.
      click_action (event):
        Event emitted when the action button is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VEmptyState", children, **kwargs)
        self._attr_names += [
            "title",
            "height",
            "size",
            "width",
            "theme",
            "text",
            ("bg_color", "bgColor"),
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "color",
            "image",
            "icon",
            "to",
            "href",
            "headline",
            ("action_text", "actionText"),
            "justify",
            ("text_width", "textWidth"),
        ]
        self._event_names += [
            ("click_action", "click:action"),
        ]


class VExpandBothTransition(HtmlElement):
    """
    Vuetify's VExpandBothTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expand-both-transition>`_.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpandBothTransition", children, **kwargs)
        self._attr_names += []
        self._event_names += []


class VExpandTransition(HtmlElement):
    """
    Vuetify's VExpandTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expand-transition>`_.

    Args:
      mode ('default', 'in-out', 'out-in'):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpandTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "group",
            ("hide_on_leave", "hideOnLeave"),
        ]
        self._event_names += []


class VExpandXTransition(HtmlElement):
    """
    Vuetify's VExpandXTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expand-x-transition>`_.

    Args:
      mode ('default', 'in-out', 'out-in'):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpandXTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "group",
            ("hide_on_leave", "hideOnLeave"),
        ]
        self._event_names += []


class VExpansionPanel(HtmlElement):
    """
    Vuetify's VExpansionPanel component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expansion-panel>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      title (string):
        Specify a title text for the component.
      disabled (boolean):
        Disables the expansion-panel content.
      height (string, number):
        Sets the height for the component.
      value (any):
        Controls the opened/closed state of content.
      width (string, number):
        Sets the width for the component.
      text (string):
        Specify content text for the component.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      expand_icon (enum):
        Icon used when the expansion panel is in a expandable state.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon used when the expansion panel is in a collapsable state.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      static (boolean):
        Remove title size expansion when selected.
      readonly (boolean):
        Makes the expansion panel content read only.
      hide_actions (boolean):
        Hide the expand icon in the content title.
      hover (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VExpansionPanelTitle.json))
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      focusable (boolean):
        Makes the expansion panel content focusable.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpansionPanel", children, **kwargs)
        self._attr_names += [
            "tag",
            "title",
            "disabled",
            "height",
            "value",
            "width",
            "text",
            "eager",
            ("bg_color", "bgColor"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "static",
            "readonly",
            ("hide_actions", "hideActions"),
            "hover",
            ("selected_class", "selectedClass"),
            "focusable",
            "ripple",
        ]
        self._event_names += [
            ("group_selected", "group:selected"),
        ]


class VExpansionPanelText(HtmlElement):
    """
    Vuetify's VExpansionPanelText component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expansion-panel-text>`_.

    Args:
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpansionPanelText", children, **kwargs)
        self._attr_names += [
            "eager",
        ]
        self._event_names += []


class VExpansionPanelTitle(HtmlElement):
    """
    Vuetify's VExpansionPanelTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expansion-panel-title>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      expand_icon (enum):
        Icon used when the expansion panel is in a expandable state.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon used when the expansion panel is in a collapsable state.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      static (boolean):
        Remove title size expansion when selected.
      readonly (boolean):
        Makes the expansion panel content read only.
      hide_actions (boolean):
        Hide the expand icon in the content title.
      hover (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VExpansionPanelTitle.json))
      focusable (boolean):
        Makes the expansion panel headers focusable.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpansionPanelTitle", children, **kwargs)
        self._attr_names += [
            "height",
            "width",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "color",
            "static",
            "readonly",
            ("hide_actions", "hideActions"),
            "hover",
            "focusable",
            "ripple",
        ]
        self._event_names += []


class VExpansionPanels(HtmlElement):
    """
    Vuetify's VExpansionPanels component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-expansion-panels>`_.

    Args:
      flat (boolean):
        Removes the expansion-panel's elevation and borders.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      theme (string):
        Specify a theme for this component and all of its children.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      expand_icon (enum):
        Icon used when the expansion panel is in a expandable state.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon used when the expansion panel is in a collapsable state.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      rounded (string, number, boolean, (string, number)[]):
        Applies a border radius to the first and last panel. Since v4.1.0
        accepts array of two values to customize inner radius.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('default', 'inset', 'accordion', 'popout'):
        Applies a distinct style to the component.
      model_value (unknown):
        Controls expanded panel(s). Defaults to an empty array when using
        **multiple** prop. It is recommended to set unique `value` prop
        for the panels inside, otherwise index is used instead.
      static (boolean):
        Remove title size expansion when selected.
      readonly (boolean):
        Makes the entire expansion panel read only.
      hide_actions (boolean):
        Hide the expand icon in the content title.
      hover (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VExpansionPanelTitle.json))
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      focusable (boolean):
        Makes the expansion-panel headers focusable.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      gap (string, number):
        Sets the gap between panels. Hides the divider automatically.
      no_divider (boolean):
        Hides the dividers between adjacent panels.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VExpansionPanels", children, **kwargs)
        self._attr_names += [
            "flat",
            "tag",
            "disabled",
            "max",
            "multiple",
            "theme",
            "eager",
            ("bg_color", "bgColor"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "mandatory",
            "elevation",
            "rounded",
            "tile",
            "color",
            "variant",
            ("model_value", "modelValue"),
            "static",
            "readonly",
            ("hide_actions", "hideActions"),
            "hover",
            ("selected_class", "selectedClass"),
            "focusable",
            "ripple",
            "gap",
            ("no_divider", "noDivider"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VFab(HtmlElement):
    """
    Vuetify's VFab component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-fab>`_.

    Args:
      symbol (any):
        The [Symbol](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)
        used to hook into group functionality for components like [v-btn-toggle](/components/btn-toggle)
        and [v-bottom-navigation](/components/bottom-navigations/).
      flat (boolean):
        Removes the button box shadow. This is different than using the 'flat' variant.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      name (string):
        Assign a specific name for layout registration.
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      width (string, number):
        Sets the width for the component.
      layout (boolean):
        If true, will effect layout dimensions based on size and position.
      theme (string):
        Specify a theme for this component and all of its children.
      text (string, number, boolean):
        Specify content text for the component.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      base_color (string):
        Sets the color of component when not focused.
      active_color (string):
        The applied color when the component is in an active state.
      slim (boolean):
        Reduces padding to 0 8px.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('flat', 'text', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      absolute (boolean):
        Applies **position: absolute** to the component.
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      location (Anchor):
        The location of the fab relative to the layout. Only works when using **app**.
      offset (boolean):
        Translates the Fab up or down, depending on if location is set
        to **top** or **bottom**.
      block (boolean):
        Expands the button to 100% of available space.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      readonly (boolean):
        Puts the button in a readonly state. Cannot be clicked or navigated
        to by keyboard.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/)
        component. The button will become _round_.

        Enum values: [
          boolean, string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      position ('fixed', 'relative', 'absolute', 'static', 'sticky'):
        Sets the position for the component.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      app (boolean):
        If true, attaches to the closest layout and positions according
        to the value of **location**.
      appear (boolean):
        Used to control the animation of the FAB.
      extended (boolean):
        An alternate style for the FAB that expects text.
      stacked (boolean):
        Displays the button as a flex-column.
      order (string, number):
        Adjust the order of the component in relation to its registration order.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFab", children, **kwargs)
        self._attr_names += [
            "symbol",
            "flat",
            "replace",
            "tag",
            "name",
            "disabled",
            "height",
            "size",
            "value",
            "width",
            "layout",
            "theme",
            "text",
            "exact",
            ("base_color", "baseColor"),
            ("active_color", "activeColor"),
            "slim",
            "border",
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "variant",
            "absolute",
            ("model_value", "modelValue"),
            "location",
            "offset",
            "block",
            "transition",
            ("append_icon", "appendIcon"),
            ("prepend_icon", "prependIcon"),
            "readonly",
            "active",
            "loading",
            "icon",
            "position",
            "to",
            "href",
            ("selected_class", "selectedClass"),
            "ripple",
            "app",
            "appear",
            "extended",
            "stacked",
            "order",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VFabTransition(HtmlElement):
    """
    Vuetify's VFabTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-fab-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFabTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VFadeTransition(HtmlElement):
    """
    Vuetify's VFadeTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-fade-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFadeTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VField(HtmlElement):
    """
    Vuetify's VField component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-field>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      reverse (boolean):
        Reverses the orientation.
      error (boolean):
        Puts the input in a manual error state.
      details (boolean):
        Controls whether the field generates an `aria-describedby` attribute
        for accessibility.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      disabled (boolean):
        Removes the ability to click or target the input.
      id (string):
        Sets the DOM id on the component.
      theme (string):
        Specify a theme for this component and all of its children.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      focused (boolean):
        Forces a focused state styling on the component.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      label_id (string):
        Sets the DOM id on the inner label element. Useful for associating
        the label with custom input elements.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VField", children, **kwargs)
        self._attr_names += [
            "flat",
            "reverse",
            "error",
            "details",
            "label",
            "disabled",
            "id",
            "theme",
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("model_value", "modelValue"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            "focused",
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("label_id", "labelId"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
        ]


class VFieldLabel(HtmlElement):
    """
    Vuetify's VFieldLabel component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-field-label>`_.

    Args:
      floating (boolean):
        Elevates the label above the slotted content.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFieldLabel", children, **kwargs)
        self._attr_names += [
            "floating",
        ]
        self._event_names += []


class VFileInput(HtmlElement):
    """
    Vuetify's VFileInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-file-input>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      reverse (boolean):
        Reverses the orientation.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      disabled (boolean):
        Removes the ability to click or target the input.
      multiple (boolean):
        Adds the **multiple** attribute to the input, allowing multiple file selections.
      placeholder (string):
        Sets the input’s placeholder text.
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      theme (string):
        Specify a theme for this component and all of its children.
      chips (boolean):
        Changes display of selections to chips.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      model_value (File, File[]):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      counter (boolean):
        Displays the number of selected files.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      counter_size_string (string):
        The text displayed when using the **counter** and **show-size**
        props. Can also be customized globally on the [internationalization
        page](/customization/internationalization).
      counter_string (string):
        The text displayed when using the **counter** prop. Can also
        be customized globally on the [internationalization page](/customization/internationalization).
      hide_input (boolean):
        Display the icon only without the input (file names).
      show_size (boolean, 1000, 1024):
        Sets the displayed size of selected file(s). When using **true**
        will default to _1000_ displaying (**kB, MB, GB**) while _1024_
        will display (**KiB, MiB, GiB**).
      truncate_length (string, number):
        The length of a filename before it is truncated with ellipsis.
      filter_by_type (string):
        Make the input accept only files matched by one or more [unique
        file type specifiers](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file#Unique_file_type_specifiers).
        Applies to drag & drop and selecting folders. Emits `rejected`
        event when some files do not pass through to make it possible
        to notify user and deliver better user experience.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      click_control (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VFileInput.json))
      mousedown_control (event):
        Event that is emitted when using mousedown on the main control area.
      rejected (event):
        Emitted when some of the files from user input, drop or folder
        selection did not pass through `strict-accept` filter.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFileInput", children, **kwargs)
        self._attr_names += [
            "flat",
            "reverse",
            "name",
            "error",
            "label",
            "disabled",
            "multiple",
            "placeholder",
            "width",
            "id",
            "theme",
            "chips",
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("model_value", "modelValue"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("counter_size_string", "counterSizeString"),
            ("counter_string", "counterString"),
            ("hide_input", "hideInput"),
            ("show_size", "showSize"),
            ("truncate_length", "truncateLength"),
            ("filter_by_type", "filterByType"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("click_control", "click:control"),
            ("mousedown_control", "mousedown:control"),
            "rejected",
        ]


class VFileUpload(HtmlElement):
    """
    Vuetify's VFileUpload component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-file-upload>`_.

    Args:
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      title (string):
        Specify a title text for the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      multiple (boolean):
        Allows multiple files to be uploaded.
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      theme (string):
        Specify a theme for this component and all of its children.
      subtitle (string):
        Specify a subtitle text for the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (File, File[]):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      scrim (string, boolean):
        Determines whether an overlay is used when hovering over the
        component with files. Accepts true/false to enable background,
        and string to define color.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the input is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      clearable (boolean):
        Allows for the component to be cleared.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      show_size (boolean):
        Shows the size of the file.
      filter_by_type (string):
        Make the input accept only files matched by one or more [unique
        file type specifiers](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file#Unique_file_type_specifiers).
        Applies to drag & drop and selecting folders. Emits `rejected`
        event when some files do not pass through to make it possible
        to notify user and deliver better user experience.
      browse_text (string):
        Text for the browse button.
      divider_text (string):
        Text in the divider.
      inset_file_list (boolean):
        Renders the file list inside the dropzone container instead of below it.
      hide_browse (boolean):
        Hides the browse button.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
      rejected (event):
        Emitted when some of the files from user input, drop or folder
        selection did not pass through `strict-accept` filter.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFileUpload", children, **kwargs)
        self._attr_names += [
            "name",
            "error",
            "label",
            "title",
            "disabled",
            "multiple",
            "width",
            "id",
            "theme",
            "subtitle",
            ("base_color", "baseColor"),
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "color",
            ("model_value", "modelValue"),
            "scrim",
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            "clearable",
            "loading",
            "icon",
            ("show_size", "showSize"),
            ("filter_by_type", "filterByType"),
            ("browse_text", "browseText"),
            ("divider_text", "dividerText"),
            ("inset_file_list", "insetFileList"),
            ("hide_browse", "hideBrowse"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            "rejected",
        ]


class VFileUploadDropzone(HtmlElement):
    """
    Vuetify's VFileUploadDropzone component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-file-upload-dropzone>`_.

    Args:
      title (string):
        Specify a title text for the component.
      length (string, number):
        Sets the dividers length. Default unit is px.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      model_value (File[]):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the dropzone in an error state, changing the border color.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      multiple (boolean):
        Allows multiple files to be uploaded.
      readonly (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VFileUploadDropzone.json))
      opacity (string, number):
        Sets the component's opacity value
      scrim (string, boolean):
        Determines whether an overlay is used when hovering over the
        component with files. Accepts true/false to enable background,
        and string to define color.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      subtitle (string):
        Specify a subtitle text for the component.
      clearable (boolean):
        Allows for the component to be cleared.
      browse_text (string):
        Text for the browse button.
      divider_text (string):
        Text in the divider.
      hide_browse (boolean):
        Hides the browse button.
      inset_file_list (boolean):
        Renders the file list inside the dropzone container instead of below it.
      show_size (boolean):
        Shows the size of the file.
      thickness (string, number):
        Sets the dividers thickness. Default unit is px.
      drop (event):
        Emitted when files are dropped onto the dropzone.
      click_browse (event):
        Emitted when the browse button is clicked.
      click_remove (event):
        Emitted when a file's remove button is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFileUploadDropzone", children, **kwargs)
        self._attr_names += [
            "title",
            "length",
            "border",
            "icon",
            ("model_value", "modelValue"),
            "error",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "disabled",
            "multiple",
            "readonly",
            "opacity",
            "scrim",
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            "subtitle",
            "clearable",
            ("browse_text", "browseText"),
            ("divider_text", "dividerText"),
            ("hide_browse", "hideBrowse"),
            ("inset_file_list", "insetFileList"),
            ("show_size", "showSize"),
            "thickness",
        ]
        self._event_names += [
            "drop",
            ("click_browse", "click:browse"),
            ("click_remove", "click:remove"),
        ]


class VFileUploadItem(HtmlElement):
    """
    Vuetify's VFileUploadItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-file-upload-item>`_.

    Args:
      title (string, number, boolean):
        Generates a `v-list-item-title` component with the supplied value.
        Note that this overrides the native [`title`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/title)
        attribute, that must be set with `v-bind:title.attr` instead.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      link (boolean):
        Designates that the component is a link. This is automatic when
        using the href or to prop.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control when in an **active**
        state or **input-value** is **true** - supports utility colors
        (for example `success` or `purple`) or css color (`#033` or `rgba(255,
        0, 0, 0.5)`). Find a list of built-in classes on the [colors
        page](/styles/colors#material-colors),
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      value (any):
        The value used for selection. Obtained from [`v-list`](/api/v-list)'s
        `v-model:selected` when the item is selected.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      active_color (string):
        Deprecated, use `color` instead.
      base_color (string):
        Sets the color of component when not focused.
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      slim (boolean):
        Reduces horizontal spacing for badges, icons, tooltips, and avatars
        to create a more compact visual representation.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      lines (false, 'one', 'two', 'three'):
        The line declaration specifies the minimum height of the item
        and can also be controlled from v-list with the same prop.
      nav (boolean):
        Reduces the width v-list-item takes up as well as adding a border radius.
      active_class (string):
        The class applied to the component when it matches the current
        route. Find more information about the [active-class prop](https://router.vuejs.org/api/#active-class)
        on the [vue-router](https://router.vuejs.org/) documentation.
      subtitle (string, number, boolean):
        Specify a subtitle text for the component.
      append_avatar (string):
        Appends a [v-avatar](/components/avatars/) component after default
        content in the **append** slot.
      prepend_avatar (string):
        Prepends a [v-avatar](/components/avatars/) component in the
        **prepend** slot before default content.
      prepend_gap (string, number):
        Sets the horizontal spacing between prepend slot and the main
        content. Also affects indent to ensure expected alignment of
        group children.
      clearable (boolean):
        Allows for the component to be cleared.
      show_size (boolean):
        Show the size of the file
      file (File):
        The file object uploaded
      file_icon (string):
        The icon prepending each uploaded file. This will be a preview
        image if the file is an image.
      index (number):
        The index of the file in the upload list.
      tabindex (string, number):
        Controls the tabindex of the list item. When set, overrides the
        default tabindex behavior. Automatically set to -1 by VList when
        using `navigationStrategy="track"` to prevent Tab key navigation
        into items.
      click_remove (event):
        Emitted when the remove icon is clicked
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFileUploadItem", children, **kwargs)
        self._attr_names += [
            "title",
            "replace",
            "link",
            "border",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "value",
            "active",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "slim",
            "ripple",
            "href",
            "exact",
            "to",
            "lines",
            "nav",
            ("active_class", "activeClass"),
            "subtitle",
            ("append_avatar", "appendAvatar"),
            ("prepend_avatar", "prependAvatar"),
            ("prepend_gap", "prependGap"),
            "clearable",
            ("show_size", "showSize"),
            "file",
            ("file_icon", "fileIcon"),
            "index",
            "tabindex",
        ]
        self._event_names += [
            "click",
            ("click_remove", "click:remove"),
        ]


class VFileUploadList(HtmlElement):
    """
    Vuetify's VFileUploadList component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-file-upload-list>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      activated (any):
        Array of ids of activated nodes.
      disabled (boolean):
        Puts all children inputs into a disabled state.
      files (File[]):
        An array of File objects to display in the list. When used inside
        a VFileUpload, this is provided automatically via injection.
      active_color (string):
        Deprecated, use `color` instead.
      base_color (string):
        Sets the color of component when not focused.
      slim (boolean):
        Reduces horizontal spacing for badges, icons, tooltips, and avatars
        within slim list items to create a more compact visual representation.
      items (any[]):
        Can be an array of objects or strings. By default objects should
        have a **title** property, and can optionally have a **props**
        property containing any [VListItem props](/api/v-list-item/#props),
        a **value** property to allow selection, and a **children** property
        containing more item objects. Keys to use for these can be changed
        with the **item-title**, **item-value**, **item-props**, and
        **item-children** props.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      lines (false, 'one', 'two', 'three'):
        Designates a **minimum-height** for all children `v-list-item`
        components. This prop uses [line-clamp](https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-line-clamp)
        and is not supported in all browsers.
      nav (boolean):
        An alternative styling that reduces `v-list-item` width and rounds
        the corners. Typically used with **[v-navigation-drawer](/components/navigation-drawers)**.
      mandatory (boolean):
        Forces at least one item to always be selected (if available).
      active_class (string):
        The class applied to the component when it is in an active state.
      selected (any):
        An array containing the values of currently selected items. Can
        be two-way bound with `v-model:selected`.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      filterable (boolean):
        **FOR INTERNAL USE ONLY** Prevents list item selection using
        [space] key and pass it back to the text input. Used internally
        for VAutocomplete and VCombobox.
      expand_icon (enum):
        Icon to display when the list item is collapsed.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      collapse_icon (enum):
        Icon to display when the list item is expanded.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prepend_gap (string, number):
        Sets the horizontal spacing between prepend slot and the main
        content within list item. Also affects indent to ensure expected
        alignment of group children.
      indent (string, number):
        Overrides the indent size for nested groups.
      navigation_strategy ('focus', 'track'):
        Determines keyboard navigation behavior. **focus** (default)
        moves DOM focus to items, suitable for traditional lists. **track**
        provides visual keyboard focus without moving DOM focus, ideal
        for command palettes and autocomplete where an external element
        retains focus. When track mode is active, items automatically
        receive `tabindex="-1"`, proper `aria-activedescendant` is set
        on the list container, and keyboard-focused items display focus-visible
        styling with auto-scrolling.
      navigation_index (number):
        Specifies the currently selected navigation index when using
        `navigationStrategy="track"`. Can be used with `v-model:navigationIndex`
        for two-way binding. Items at this index receive visual keyboard
        focus styling and automatic scrolling. Note: Only works with
        the `items` prop, not with slotted items.
      activatable (boolean):
        Designates whether the list items are activatable. Additionally,
        sets necessary accessibility attributes internally.
      selectable (boolean):
        Designates whether the list items are selectable. Additionally,
        sets necessary accessibility attributes internally.
      opened (any):
        An array containing the values of currently opened groups. Can
        be two-way bound with `v-model:opened`.
      items_registration ('props', 'render'):
        When set to 'props', skips rendering collapsed items/nodes (for
        significant performance gains).
      active_strategy (ActiveStrategy):
        Affects how items with children behave when activated. If not
        specified, the **single-independent** strategy will be used.
        - **leaf:** Only leaf nodes (items without children) can be activated.
        - **single-leaf:** Similar as **leaf**, but only a single item
        can be activated at a time. - **independent:** All nodes can
        be activated whether they have children or not. - **single-independent:**
        Similar as **independent**, but only a single item can be activated
        at a time.
      select_strategy (SelectStrategy):
        Affects how items with children behave when selected. - **leaf:**
        Only leaf nodes (items without children) can be selected. - **independent:**
        All nodes can be selected whether they have children or not.
        - **classic:** Selecting a parent node will cause all children
        to be selected, parent nodes will be displayed as selected if
        all their descendants are selected. Only leaf nodes will be added
        to the model. - **trunk**: Same as classic but if all of a node's
        children are selected then only that node will be added to the
        model. - **branch**: Same as classic but if any of a node's children
        are selected then that node will also be added to the model.
      open_strategy (OpenStrategy):
        Affects how items with children behave when expanded. - **multiple:**
        Any number of groups can be open at once. - **single:** Only
        one group at each level can be open, opening a group will cause
        others to close. - **list:** Multiple, but all other groups will
        close when an item is selected.
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      item_children (SelectItemKey):
        Property on supplied `items` that contains its children.
      item_type (SelectItemKey):
        Designates the key on the supplied items that is used for determining
        the nodes type.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      clearable (boolean):
        Allows for the component to be cleared.
      show_size (boolean):
        Shows the size of each file.
      click_open (event):
        Emitted when the list item is opened.
      click_select (event):
        Emitted when the list item is selected.
      update_opened (event):
        Emitted when the list item is opened.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFileUploadList", children, **kwargs)
        self._attr_names += [
            "border",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "activated",
            "disabled",
            "files",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            "slim",
            "items",
            ("item_props", "itemProps"),
            ("bg_color", "bgColor"),
            "lines",
            "nav",
            "mandatory",
            ("active_class", "activeClass"),
            "selected",
            ("value_comparator", "valueComparator"),
            "filterable",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("prepend_gap", "prependGap"),
            "indent",
            ("navigation_strategy", "navigationStrategy"),
            ("navigation_index", "navigationIndex"),
            "activatable",
            "selectable",
            "opened",
            ("items_registration", "itemsRegistration"),
            ("active_strategy", "activeStrategy"),
            ("select_strategy", "selectStrategy"),
            ("open_strategy", "openStrategy"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("item_children", "itemChildren"),
            ("item_type", "itemType"),
            ("return_object", "returnObject"),
            "clearable",
            ("show_size", "showSize"),
        ]
        self._event_names += [
            ("click_open", "click:open"),
            ("click_select", "click:select"),
            ("update_opened", "update:opened"),
        ]


class VFooter(HtmlElement):
    """
    Vuetify's VFooter component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-footer>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      height (string, number):
        Sets the height for the component. Percentage values are relative to the layout.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      absolute (boolean):
        Applies **position: absolute** to the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Assign a specific name for layout registration.
      order (string, number):
        Adjust the order of the component in relation to its registration order.
      app (boolean):
        Determines the position of the footer. If true, the footer would
        be given a fixed position at the bottom of the viewport. If false,
        the footer is set to the bottom of the page.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VFooter", children, **kwargs)
        self._attr_names += [
            "border",
            "height",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "absolute",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "name",
            "order",
            "app",
        ]
        self._event_names += []


class VForm(HtmlElement):
    """
    Vuetify's VForm component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-form>`_.

    Args:
      model_value (boolean):
        The value representing the validity of the form. If the value
        is `null` then no validation has taken place yet, or the form
        has been reset. Otherwise the value will be a `boolean` that
        indicates if validation has passed or not.
      disabled (boolean):
        Puts all children inputs into a disabled state.
      readonly (boolean):
        Puts all children inputs into a readonly state.
      validate_on (enum):
        Changes the events in which validation occurs.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      fast_fail (boolean):
        Stop validation as soon as any rules fail.
      update_modelValue (event):
        Event emitted when the form's validity changes.
      submit (event):
        Emitted when form is submitted.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VForm", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "disabled",
            "readonly",
            ("validate_on", "validateOn"),
            ("fast_fail", "fastFail"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "submit",
        ]


class VHeatmap(HtmlElement):
    """
    Vuetify's VHeatmap component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-heatmap>`_.

    Args:
      rounded (string, number):
        Cell corner radius. Accepts a number or string with `px` or `%`
        units only — the value is passed directly to the SVG `<rect>`
        `rx`/`ry` attributes.
      theme (string):
        Specify a theme for this component and all of its children.
      gap (string, number):
        Spacing between cells.
      items (Record<string, any>[]):
        Data items to render.
      item_props (Record<string, any>, js_fn):
        Additional props to pass to each `v-heatmap-cell`.
      legend (enum):
        Controls the legend rendered below the grid. Accepts boolean
        or an object allowing you to configure labels and legend cell
        size.

        Enum values: [
          boolean, { labels: string[]; cellSize: string, number, (string, number)[] }
        ]
      hover (boolean):
        Enables the hover interaction that scales a cell when hovered.
      item_value (SelectItemKey):
        Property name or function that returns the numeric value of an
        item, used for cell color matching.
      columns (any[]):
        Explicit list of column keys. When omitted, columns are derived from the items.
      cell_size (string, number, (string, number)[]):
        Sets size of each cell. A single value sets both width and height.
        Accepts `[width, height]` tuple.
      group_gap (string, number):
        Spacing between column groups, in pixels.
      hide_column_headers (boolean):
        Hides the column labels.
      hide_row_headers (boolean):
        Hides the row labels.
      hover_scale (string, number):
        Controls the cell's scale factor applied on hover.
      item_row (SelectItemKey):
        Property name or function that returns the row key of an item.
      item_column (SelectItemKey):
        Property name or function that returns the column key of an item.
      thresholds (enum):
        Controls how each item's value maps to a cell color. Two forms:
        - **Buckets:** an array of `{ min, color }` stops. Each cell
        takes the color of the highest stop whose `min` it meets or exceeds.
        - **Linear:** a `{ from, to }` pair that interpolates between
        two stops via `color-mix`. Optional `colorSpace` (e.g. `'oklch'`)
        picks the interpolation space, and `hueInterpolation` (`'shorter'`
        / `'longer'``) controls hue path in polar spaces.

        Enum values: [
          { min: number; color: string }[], {      from: { min: number;
          color: string }      to: { min: number; color: string }
          colorSpace:, 'hsl', 'srgb', 'srgb-linear', 'hwb', 'lab', 'lch',
          'oklab', 'oklch'      hueInterpolation: 'shorter', 'longer'
            }
        ]
      empty_color (string):
        Fill color for cells with `null` value.
      group_by (SelectItemKey):
        Property name or function used to split items into separate column
        groups (e.g. by month).
      rows (any[]):
        Explicit list of row keys. When omitted, rows are derived from
        the items in insertion order.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHeatmap", children, **kwargs)
        self._attr_names += [
            "rounded",
            "theme",
            "gap",
            "items",
            ("item_props", "itemProps"),
            "legend",
            "hover",
            ("item_value", "itemValue"),
            "columns",
            ("cell_size", "cellSize"),
            ("group_gap", "groupGap"),
            ("hide_column_headers", "hideColumnHeaders"),
            ("hide_row_headers", "hideRowHeaders"),
            ("hover_scale", "hoverScale"),
            ("item_row", "itemRow"),
            ("item_column", "itemColumn"),
            "thresholds",
            ("empty_color", "emptyColor"),
            ("group_by", "groupBy"),
            "rows",
        ]
        self._event_names += []


class VHeatmapCell(HtmlElement):
    """
    Vuetify's VHeatmapCell component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-heatmap-cell>`_.

    Args:
      height (number):
        Cell height in pixels.
      width (number):
        Cell width in pixels.
      disabled (boolean):
        Renders the cell in a disabled when toggled off using interactive legend state.
      item ({  value: number  bucketIndex: number  mixPercentage: number  color: string  raw: Record<string, any>  row: any  column: any  groupKey: string}):
        Heatmap cell data. Exposes `value` and `color` for use in slot content.
      x (number):
        Horizontal offset of the cell within the parent SVG.
      y (number):
        Vertical offset of the cell within the parent SVG.
      cell_props (unknown):
        Additional attributes spread on the cell `<g>` element. A `title`
        value renders as an SVG `<title>` child (native tooltip).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHeatmapCell", children, **kwargs)
        self._attr_names += [
            "height",
            "width",
            "disabled",
            "item",
            "x",
            "y",
            ("cell_props", "cellProps"),
        ]
        self._event_names += []


class VHeatmapLegend(HtmlElement):
    """
    Vuetify's VHeatmapLegend component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-heatmap-legend>`_.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHeatmapLegend", children, **kwargs)
        self._attr_names += []
        self._event_names += []


class VHeatmapLegendCell(HtmlElement):
    """
    Vuetify's VHeatmapLegendCell component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-heatmap-legend-cell>`_.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHeatmapLegendCell", children, **kwargs)
        self._attr_names += []
        self._event_names += []


class VHighlight(HtmlElement):
    """
    Vuetify's VHighlight component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-highlight>`_.

    Args:
      text (string):
        Specify content text for the component.
      match_all (boolean):
        When enabled, all occurrences of each query term are highlighted.
        When disabled, only the first occurrence of each term is highlighted.
        Has no effect when **matches** is provided.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      color (string):
        Applies a theme or CSS color to highlighted matches. The background
        is derived by mixing this color with the theme's highlight opacity.
      matches ([number, number][]):
        Pre-computed match ranges as `[start, end]` pairs. Takes priority
        over **query** when provided and non-empty.
      opacity (string, number):
        Overrides the background opacity of highlighted matches. Accepts
        only CSS `<percentage>` - use `30%` instead of `0.3`.
      query (string, string[]):
        The search string or array of strings to highlight within the text.
      ignore_accents (k):
        Folds accents before matching. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the text, or `true`
        for both.
      ignore_case (boolean):
        When enabled, matching is case-insensitive.
      mark_class (string):
        Additional CSS class(es) applied to each `<mark>` element wrapping
        a highlighted match.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHighlight", children, **kwargs)
        self._attr_names += [
            "text",
            ("match_all", "matchAll"),
            "tag",
            "color",
            "matches",
            "opacity",
            "query",
            ("ignore_accents", "ignoreAccents"),
            ("ignore_case", "ignoreCase"),
            ("mark_class", "markClass"),
        ]
        self._event_names += []


class VHotkey(HtmlElement):
    """
    Vuetify's VHotkey component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-hotkey>`_.

    Args:
      keys (string):
        String representing keyboard shortcuts to display. Supports multiple
        formats: - **Single keys:** `"k"`, `"enter"`, `"escape"` - **Key
        combinations:** `"ctrl+k"`, `"meta+shift+p"`, `"alt+arrowup"`
        - **Sequential actions:** `"ctrl+k-then-p"` (use dash for 'then'
        relationships) - **Multiple shortcuts:** `"ctrl+k meta+p"` (space-separated
        for alternative shortcuts)  Supports platform-aware key names
        like `meta` (becomes Cmd on Mac, Ctrl on PC) and `alt` (becomes
        Option on Mac).
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Controls the visual style and presentation of the hotkey component.
        Supports standard Vuetify variants plus a special contained variant:
         **Standard Variants** (apply styling to individual key elements):
        - **elevated (default):** Raised appearance with shadow, good
        for standalone hotkey displays - **flat:** Solid background without
        shadow, clean and minimal - **tonal:** Subtle tinted background
        without border, balances visibility with restraint - **outlined:**
        Border-only styling without elevation, lightweight and unobtrusive
        - **text:** Minimal styling with text color emphasis only, blends
        with content - **plain:** No background or border, most subtle
        option  **Special Variant** (different visual structure): - **contained:**
        Follows MDN's nested `<kbd>` pattern - wraps all keys in a single
        styled container with unstyled nested elements. Creates a cohesive
        visual unit that clearly groups related keys together. Cannot
        be combined with standard variants. Ideal for complex key combinations
        where you want to show the entire sequence as one unit.

        Enum values: [
          'text', 'flat', 'elevated', 'tonal', 'outlined', 'plain', 'contained'
        ]
      disabled (boolean):
        Applies a disabled visual state to the component.
      prefix (string):
        Text to display before the hotkey.
      inline (boolean):
        Optimizes the component for seamless integration within text
        content and documentation. Applies compact styling with baseline
        alignment, constrained height (1lh), and responsive typography
        that inherits from parent text. Ideal for help documentation,
        tooltips, and instructional content. When using multiple inline
        hotkeys in the same paragraph, increase line-height to prevent
        visual overlap on text wrapping.
      suffix (string):
        Text to display after the hotkey.
      display_mode ('symbol', 'text', 'icon'):
        Controls how keyboard keys are visually represented. Affects
        the entire component's appearance: - **icon:** Uses SVG icons
        for keys when appropriate (default) - **symbol:** Uses Unicode
        symbols (⌘, ⌃, ⇧, ⌥) - Allows you to manage presentation of modifier
        keys with fonts - **text:** Uses full text labels (Command, Control,
        Shift, Alt) - most accessible and descriptive
      key_map (unknown):
        Custom key mapping object that defines how individual keys should
        be displayed. Users can import and modify the exported `hotkeyMap`
        to create custom configurations. Each key maps to a `PlatformKeyConfig`
        object with:  ```typescript {   mac?: { symbol?: string, icon?:
        string, text: string },   default: { symbol?: string, icon?:
        string, text: string } } ```  **Usage Example:** ```typescript
        import { hotkeyMap } from 'vuetify/labs/VHotkey'  const customKeyMap
        = {   ...hotkeyMap,   'custom-key': {     default: { text: 'Custom',
        icon: 'custom-icon' },     mac: { text: 'Custom', symbol: '⚡'
        }   } } ```  This enables: - **Custom key definitions:** Add
        support for application-specific keys - **Localization:** Override
        text representations for different languages - **Brand customization:**
        Change how modifier keys appear - **Platform-specific styling:**
        Different representations for Mac vs other platforms  Recommended
        to set at the application level via component defaults rather
        than per-instance for consistency.
      platform ('auto', 'pc', 'mac'):
        Controls platform-specific rendering behavior for keyboard shortcuts.
        Accepts three values: - **`'auto'` (default):** Automatically
        detects the user's platform based on user agent and renders appropriately
        - **`'mac'`:** Forces Mac-style rendering (Command symbols, icons,
        Option key, etc.) - **`'pc'`:** Forces PC-style rendering (Ctrl
        text, Alt key, etc.)  This is particularly useful for: - **Cross-platform
        testing:** Verify how shortcuts appear on different platforms
        - **Design consistency:** Ensure specific platform rendering
        in demos and prototypes - **Development workflow:** Test platform-specific
        behaviors without switching devices - **Documentation:** Show
        platform-specific examples in help content
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHotkey", children, **kwargs)
        self._attr_names += [
            "keys",
            "border",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "theme",
            "color",
            "variant",
            "disabled",
            "prefix",
            "inline",
            "suffix",
            ("display_mode", "displayMode"),
            ("key_map", "keyMap"),
            "platform",
        ]
        self._event_names += []


class VHover(HtmlElement):
    """
    Vuetify's VHover component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-hover>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      disabled (boolean):
        Removes hover functionality.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VHover", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "disabled",
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VIcon(HtmlElement):
    """
    Vuetify's VIcon component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-icon>`_.

    Args:
      end (boolean):
        Applies margin at the start of the component.
      start (boolean):
        Applies margin at the end of the component.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      opacity (string, number):
        Sets the component's opacity value
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VIcon", children, **kwargs)
        self._attr_names += [
            "end",
            "start",
            "icon",
            "tag",
            "theme",
            "color",
            "disabled",
            "size",
            "opacity",
        ]
        self._event_names += []


class VIconBtn(HtmlElement):
    """
    Vuetify's VIconBtn component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-icon-btn>`_.

    Args:
      text (string, number, boolean):
        Specify content text for the component.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      icon_sizes (enum):
        An array of tuples that define the icon sizes for each named size.

        Enum values: [
          ['default', 'small', 'x-small', 'large', 'x-large', number][]
        ]
      icon_size (string, number):
        The specific size of the icon, can use named sizes.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height and width of the component.
      active (boolean):
        When undefined (default), the component utilizes its default
        variant, otherwise it will use the activeVariant if active is
        true, or the baseVariant if active is false.
      active_color (string):
        The applied color when the component is in an active state.
      readonly (boolean):
        Puts the button in a readonly state. Cannot be clicked or navigated
        to by keyboard.
      loading (boolean):
        Displays circular progress bar in place of the icon.
      opacity (string, number):
        Sets the component's opacity value
      sizes (enum):
        An array of tuples that define the button sizes for each named size.

        Enum values: [
          ['default', 'small', 'x-small', 'large', 'x-large', number][]
        ]
      icon_color (string):
        Explicit color applied to the icon.
      base_variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        When active is a boolean, this variant is used when active is false.
      hide_overlay (boolean):
        Hides overlay from being displayed when active or focused.
      rotate (string, number):
        The rotation of the icon in degrees.
      active_icon (enum):
        When active is a boolean, this icon is used when active is true.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      active_variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        When active is a boolean, this variant is used when active is true.
      update_active (event):
        Event that is emitted when the active state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VIconBtn", children, **kwargs)
        self._attr_names += [
            "text",
            "border",
            "icon",
            "height",
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            ("icon_sizes", "iconSizes"),
            ("icon_size", "iconSize"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "size",
            "active",
            ("active_color", "activeColor"),
            "readonly",
            "loading",
            "opacity",
            "sizes",
            ("icon_color", "iconColor"),
            ("base_variant", "baseVariant"),
            ("hide_overlay", "hideOverlay"),
            "rotate",
            ("active_icon", "activeIcon"),
            ("active_variant", "activeVariant"),
        ]
        self._event_names += [
            ("update_active", "update:active"),
        ]


class VImg(HtmlElement):
    """
    Vuetify's VImg component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-img>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      position (string):
        Applies [object-position](https://developer.mozilla.org/en-US/docs/Web/CSS/object-position)
        styles to the image and placeholder elements.
      absolute (boolean):
        Applies position: absolute to the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      alt (string):
        Alternate text for screen readers. Leave empty for decorative images.
      src (enum):
        The image URL. This prop is mandatory.

        Enum values: [
          string, { src: string; srcset: string; lazySrc: string; aspect: number }
        ]
      draggable (boolean, 'true', 'false'):
        Controls the `draggable` behavior of the image. See [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/draggable).
      inline (boolean):
        Display as an inline element instead of a block, also disables flex-grow.
      transition (enum):
        The transition to use when switching from `lazy-src` to `src`.
        Can be one of the [built in](/styles/transitions/) or custom
        transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      content_class (any):
        Apply a custom class to the internal content element.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      options (IntersectionObserverInit):
        Options that are passed to the [Intersection observer](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)
        constructor.
      cover (boolean):
        Resizes the background image to cover the entire container.
      gradient (string):
        The gradient to apply to the image. Only supports [linear-gradient](https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/linear-gradient)
        syntax, anything else should be done with classes.
      image_class (any):
        Applies CSS classes to the inner `<img>` element.
      lazy_src (string):
        Something to show while waiting for the main image to load, typically
        a small base64-encoded thumbnail. Has a slight blur filter applied.
          NOTE: This prop has no effect unless either `height` or `aspect-ratio`
        are provided.
      sizes (string):
        For use with `srcset`, see [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#attr-sizes).
      srcset (string):
        A set of alternate images to use based on device size. [Read
        more...](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#attr-srcset).
      aspect_ratio (string, number):
        Calculated as `width/height`, so for a 1920x1080px image this
        will be `1.7778`. Will be calculated automatically if omitted.
      crossorigin ('', 'anonymous', 'use-credentials'):
        Specify that images should be fetched with CORS enabled [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#crossorigin)
      referrerpolicy (enum):
        Define which referrer is sent when fetching the resource [MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img#referrerpolicy)

        Enum values: [
          'origin', 'no-referrer', 'no-referrer-when-downgrade', 'origin-when-cross-origin',
          'same-origin', 'strict-origin', 'strict-origin-when-cross-origin',
          'unsafe-url'
        ]
      error (event):
        Emitted if the image fails to load.
      load (event):
        Emitted when the image is loaded.
      loadstart (event):
        Emitted when the image starts to load.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VImg", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "position",
            "absolute",
            "rounded",
            "tile",
            "color",
            "alt",
            "src",
            "draggable",
            "inline",
            "transition",
            ("content_class", "contentClass"),
            "eager",
            "options",
            "cover",
            "gradient",
            ("image_class", "imageClass"),
            ("lazy_src", "lazySrc"),
            "sizes",
            "srcset",
            ("aspect_ratio", "aspectRatio"),
            "crossorigin",
            "referrerpolicy",
        ]
        self._event_names += [
            "error",
            "load",
            "loadstart",
        ]


class VInfiniteScroll(HtmlElement):
    """
    Vuetify's VInfiniteScroll component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-infinite-scroll>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mode ('manual', 'intersect'):
        Specifies if content should load automatically when scrolling
        (**intersect**) or manually (**manual**).
      direction ('vertical', 'horizontal'):
        Specifies if scroller is **vertical** or **horizontal**.
      side ('end', 'start', 'both'):
        Specifies the side where new content should appear. Either the
        **start**, **end**, or **both** sides.
      margin (string, number):
        Value sent to the intersection observer. Will make the observer
        trigger earlier, by the margin (px) value supplied.
      load_more_text (string):
        Text shown in default load more button, when in manual mode.
      empty_text (string):
        Text shown when there is no more content to load.
      load (event):
        Emitted when reaching the start / end threshold, or if triggered
        when using manual mode.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VInfiniteScroll", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "tag",
            "color",
            "mode",
            "direction",
            "side",
            "margin",
            ("load_more_text", "loadMoreText"),
            ("empty_text", "emptyText"),
        ]
        self._event_names += [
            "load",
        ]


class VInput(HtmlElement):
    """
    Vuetify's VInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-input>`_.

    Args:
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      direction ('vertical', 'horizontal'):
        Changes the direction of the input.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the input is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VInput", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "error",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "theme",
            "color",
            "name",
            "disabled",
            "id",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "label",
            "direction",
            "messages",
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
        ]


class VItem(HtmlElement):
    """
    Vuetify's VItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-item>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VItem", children, **kwargs)
        self._attr_names += [
            "disabled",
            "value",
            ("selected_class", "selectedClass"),
        ]
        self._event_names += [
            ("group_selected", "group:selected"),
        ]


class VItemGroup(HtmlElement):
    """
    Vuetify's VItemGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-item-group>`_.

    Args:
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      selected_class (string):
        Configure the selected CSS class. This class will be available
        in `v-item` default scoped slot.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VItemGroup", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "tag",
            "theme",
            "disabled",
            "max",
            "multiple",
            ("selected_class", "selectedClass"),
            "mandatory",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VKbd(HtmlElement):
    """
    Vuetify's VKbd component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-kbd>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VKbd", children, **kwargs)
        self._attr_names += [
            "border",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
        ]
        self._event_names += []


class VLabel(HtmlElement):
    """
    Vuetify's VLabel component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-label>`_.

    Args:
      text (string):
        Specify content text for the component.
      theme (string):
        Specify a theme for this component and all of its children.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VLabel", children, **kwargs)
        self._attr_names += [
            "text",
            "theme",
        ]
        self._event_names += [
            "click",
        ]


class VLayout(HtmlElement):
    """
    Vuetify's VLayout component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-layout>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      full_height (boolean):
        Sets the component height to 100%.
      overlaps (string[]):
        **FOR INTERNAL USE ONLY**
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VLayout", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            ("full_height", "fullHeight"),
            "overlaps",
        ]
        self._event_names += []


class VLayoutItem(HtmlElement):
    """
    Vuetify's VLayoutItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-layout-item>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      position ('top', 'bottom', 'left', 'right'):
        The position of the item.
      absolute (boolean):
        Applies **position: absolute** to the component.
      name (string):
        Assign a specific name for layout registration.
      size (string, number):
        The size of the item. Percentage values are relative to the layout.
      order (string, number):
        Adjust the order of the component in relation to its registration order.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VLayoutItem", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "position",
            "absolute",
            "name",
            "size",
            "order",
        ]
        self._event_names += []


class VLazy(HtmlElement):
    """
    Vuetify's VLazy component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-lazy>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      options (IntersectionObserverInit):
        Options that are passed to the [Intersection observer](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)
        constructor.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VLazy", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "tag",
            "transition",
            "options",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VLigatureIcon(HtmlElement):
    """
    Vuetify's VLigatureIcon component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-ligature-icon>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VLigatureIcon", children, **kwargs)
        self._attr_names += [
            "tag",
            "icon",
        ]
        self._event_names += []


class VList(HtmlElement):
    """
    Vuetify's VList component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      activated (unknown):
        Array of ids of activated nodes.
      disabled (boolean):
        Puts all children inputs into a disabled state.
      active_color (string):
        Deprecated, use `color` instead.
      base_color (string):
        Sets the color of component when not focused.
      slim (boolean):
        Reduces horizontal spacing for badges, icons, tooltips, and avatars
        within slim list items to create a more compact visual representation.
      items (any[]):
        Can be an array of objects or strings. By default objects should
        have a **title** property, and can optionally have a **props**
        property containing any [VListItem props](/api/v-list-item/#props),
        a **value** property to allow selection, and a **children** property
        containing more item objects. Keys to use for these can be changed
        with the **item-title**, **item-value**, **item-props**, and
        **item-children** props.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      lines (false, 'one', 'two', 'three'):
        Designates a **minimum-height** for all children `v-list-item`
        components. This prop uses [line-clamp](https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-line-clamp)
        and is not supported in all browsers.
      nav (boolean):
        An alternative styling that reduces `v-list-item` width and rounds
        the corners. Typically used with **[v-navigation-drawer](/components/navigation-drawers)**.
      mandatory (boolean):
        Forces at least one item to always be selected (if available).
      active_class (string):
        The class applied to the component when it is in an active state.
      selected (unknown):
        An array containing the values of currently selected items. Can
        be two-way bound with `v-model:selected`.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      filterable (boolean):
        **FOR INTERNAL USE ONLY** Prevents list item selection using
        [space] key and pass it back to the text input. Used internally
        for VAutocomplete and VCombobox.
      expand_icon (enum):
        Icon to display when the list item is collapsed.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      collapse_icon (enum):
        Icon to display when the list item is expanded.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prepend_gap (string, number):
        Sets the horizontal spacing between prepend slot and the main
        content within list item. Also affects indent to ensure expected
        alignment of group children.
      indent (string, number):
        Overrides the indent size for nested groups.
      navigation_strategy ('focus', 'track'):
        Determines keyboard navigation behavior. **focus** (default)
        moves DOM focus to items, suitable for traditional lists. **track**
        provides visual keyboard focus without moving DOM focus, ideal
        for command palettes and autocomplete where an external element
        retains focus. When track mode is active, items automatically
        receive `tabindex="-1"`, proper `aria-activedescendant` is set
        on the list container, and keyboard-focused items display focus-visible
        styling with auto-scrolling.
      navigation_index (number):
        Specifies the currently selected navigation index when using
        `navigationStrategy="track"`. Can be used with `v-model:navigationIndex`
        for two-way binding. Items at this index receive visual keyboard
        focus styling and automatic scrolling. Note: Only works with
        the `items` prop, not with slotted items.
      activatable (boolean):
        Designates whether the list items are activatable. Additionally,
        sets necessary accessibility attributes internally.
      selectable (boolean):
        Designates whether the list items are selectable. Additionally,
        sets necessary accessibility attributes internally.
      opened (unknown):
        An array containing the values of currently opened groups. Can
        be two-way bound with `v-model:opened`.
      items_registration ('props', 'render'):
        When set to 'props', skips rendering collapsed items/nodes (for
        significant performance gains).
      active_strategy (ActiveStrategy):
        Affects how items with children behave when activated. If not
        specified, the **single-independent** strategy will be used.
        - **leaf:** Only leaf nodes (items without children) can be activated.
        - **single-leaf:** Similar as **leaf**, but only a single item
        can be activated at a time. - **independent:** All nodes can
        be activated whether they have children or not. - **single-independent:**
        Similar as **independent**, but only a single item can be activated
        at a time.
      select_strategy (SelectStrategy):
        Affects how items with children behave when selected. - **leaf:**
        Only leaf nodes (items without children) can be selected. - **independent:**
        All nodes can be selected whether they have children or not.
        - **classic:** Selecting a parent node will cause all children
        to be selected, parent nodes will be displayed as selected if
        all their descendants are selected. Only leaf nodes will be added
        to the model. - **trunk**: Same as classic but if all of a node's
        children are selected then only that node will be added to the
        model. - **branch**: Same as classic but if any of a node's children
        are selected then that node will also be added to the model.
      open_strategy (OpenStrategy):
        Affects how items with children behave when expanded. - **multiple:**
        Any number of groups can be open at once. - **single:** Only
        one group at each level can be open, opening a group will cause
        others to close. - **list:** Multiple, but all other groups will
        close when an item is selected.
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      item_children (SelectItemKey):
        Property on supplied `items` that contains its children.
      item_type (SelectItemKey):
        Designates the key on the supplied items that is used for determining
        the nodes type.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      click_open (event):
        Emitted when the list item is opened.
      click_select (event):
        Emitted when the list item is selected.
      update_opened (event):
        Emitted when the list item is opened.
      update_selected (event):
        Emitted when the list item is selected.
      update_activated (event):
        Emitted when the list item is activated.
      update_navigationIndex (event):
        Emitted when keyboard navigation occurs in `navigationStrategy="track"`.
        The event payload is the new index of the selected item. Automatically
        skips non-selectable items like dividers and subheaders.
      click_activate (event):
        Emitted when the list item is activated.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VList", children, **kwargs)
        self._attr_names += [
            "border",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "activated",
            "disabled",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            "slim",
            "items",
            ("item_props", "itemProps"),
            ("bg_color", "bgColor"),
            "lines",
            "nav",
            "mandatory",
            ("active_class", "activeClass"),
            "selected",
            ("value_comparator", "valueComparator"),
            "filterable",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("prepend_gap", "prependGap"),
            "indent",
            ("navigation_strategy", "navigationStrategy"),
            ("navigation_index", "navigationIndex"),
            "activatable",
            "selectable",
            "opened",
            ("items_registration", "itemsRegistration"),
            ("active_strategy", "activeStrategy"),
            ("select_strategy", "selectStrategy"),
            ("open_strategy", "openStrategy"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("item_children", "itemChildren"),
            ("item_type", "itemType"),
            ("return_object", "returnObject"),
        ]
        self._event_names += [
            ("click_open", "click:open"),
            ("click_select", "click:select"),
            ("update_opened", "update:opened"),
            ("update_selected", "update:selected"),
            ("update_activated", "update:activated"),
            ("update_navigationIndex", "update:navigationIndex"),
            ("click_activate", "click:activate"),
        ]


class VListGroup(HtmlElement):
    """
    Vuetify's VListGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-group>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      title (string):
        Specify a title text for the component.
      disabled (boolean):
        Puts all children inputs into a disabled state.
      value (any):
        Expands / Collapse the list-group.
      base_color (string):
        Sets the color of component when not focused.
      active_color (string):
        Deprecated, use `color` instead.
      expand_icon (enum):
        Icon to display when the list item is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the list item is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      fluid (boolean):
        Removes the left padding assigned for action icons from group items.
      raw_id (string, number):
        Defines the root element's id attribute in the component. If
        it is provided, the id attribute will be dynamically generated
        in the format: "v-list-group--id-[rawId]".
      subgroup (boolean):
        Designate the component as nested list group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListGroup", children, **kwargs)
        self._attr_names += [
            "tag",
            "title",
            "disabled",
            "value",
            ("base_color", "baseColor"),
            ("active_color", "activeColor"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "color",
            ("append_icon", "appendIcon"),
            ("prepend_icon", "prependIcon"),
            "fluid",
            ("raw_id", "rawId"),
            "subgroup",
        ]
        self._event_names += []


class VListImg(HtmlElement):
    """
    Vuetify's VListImg component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-img>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListImg", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VListItem(HtmlElement):
    """
    Vuetify's VListItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-item>`_.

    Args:
      title (string, number, boolean):
        Generates a `v-list-item-title` component with the supplied value.
        Note that this overrides the native [`title`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/title)
        attribute, that must be set with `v-bind:title.attr` instead.
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      link (boolean):
        Designates that the component is a link. This is automatic when
        using the href or to prop.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control when in an **active**
        state or **input-value** is **true** - supports utility colors
        (for example `success` or `purple`) or css color (`#033` or `rgba(255,
        0, 0, 0.5)`). Find a list of built-in classes on the [colors
        page](/styles/colors#material-colors),
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      value (any):
        The value used for selection. Obtained from [`v-list`](/api/v-list)'s
        `v-model:selected` when the item is selected.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      active_color (string):
        Deprecated, use `color` instead.
      base_color (string):
        Sets the color of component when not focused.
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      slim (boolean):
        Reduces horizontal spacing for badges, icons, tooltips, and avatars
        to create a more compact visual representation.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      lines (false, 'one', 'two', 'three'):
        The line declaration specifies the minimum height of the item
        and can also be controlled from v-list with the same prop.
      nav (boolean):
        Reduces the width v-list-item takes up as well as adding a border radius.
      active_class (string):
        The class applied to the component when it matches the current
        route. Find more information about the [active-class prop](https://router.vuejs.org/api/#active-class)
        on the [vue-router](https://router.vuejs.org/) documentation.
      subtitle (string, number, boolean):
        Specify a subtitle text for the component.
      append_avatar (string):
        Appends a [v-avatar](/components/avatars/) component after default
        content in the **append** slot.
      prepend_avatar (string):
        Prepends a [v-avatar](/components/avatars/) component in the
        **prepend** slot before default content.
      prepend_gap (string, number):
        Sets the horizontal spacing between prepend slot and the main
        content. Also affects indent to ensure expected alignment of
        group children.
      index (number):
        The index of the item within the list. Used internally for keyboard
        navigation and selection.
      tabindex (string, number):
        Controls the tabindex of the list item. When set, overrides the
        default tabindex behavior. Automatically set to -1 by VList when
        using `navigationStrategy="track"` to prevent Tab key navigation
        into items.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListItem", children, **kwargs)
        self._attr_names += [
            "title",
            "replace",
            "link",
            "border",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "value",
            "active",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "slim",
            "ripple",
            "href",
            "exact",
            "to",
            "lines",
            "nav",
            ("active_class", "activeClass"),
            "subtitle",
            ("append_avatar", "appendAvatar"),
            ("prepend_avatar", "prependAvatar"),
            ("prepend_gap", "prependGap"),
            "index",
            "tabindex",
        ]
        self._event_names += [
            "click",
        ]


class VListItemAction(HtmlElement):
    """
    Vuetify's VListItemAction component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-item-action>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      start (boolean):
        Applies margin at the end of the component.
      end (boolean):
        Applies margin at the start of the component.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListItemAction", children, **kwargs)
        self._attr_names += [
            "tag",
            "start",
            "end",
        ]
        self._event_names += []


class VListItemMedia(HtmlElement):
    """
    Vuetify's VListItemMedia component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-item-media>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      start (boolean):
        Applies margin at the end of the component.
      end (boolean):
        Applies margin at the start of the component.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListItemMedia", children, **kwargs)
        self._attr_names += [
            "tag",
            "start",
            "end",
        ]
        self._event_names += []


class VListItemSubtitle(HtmlElement):
    """
    Vuetify's VListItemSubtitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-item-subtitle>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      opacity (string, number):
        Sets the component's opacity value
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListItemSubtitle", children, **kwargs)
        self._attr_names += [
            "tag",
            "opacity",
        ]
        self._event_names += []


class VListItemTitle(HtmlElement):
    """
    Vuetify's VListItemTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-item-title>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListItemTitle", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VListSubheader(HtmlElement):
    """
    Vuetify's VListSubheader component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-list-subheader>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      title (string):
        Specify a title text for the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      sticky (boolean):
        Sticks the header to the top of the table.
      inset (boolean):
        Insets the subheader without additional spacing, aligning it
        flush with the surrounding content.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VListSubheader", children, **kwargs)
        self._attr_names += [
            "tag",
            "title",
            "color",
            "sticky",
            "inset",
        ]
        self._event_names += []


class VLocaleProvider(HtmlElement):
    """
    Vuetify's VLocaleProvider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-locale-provider>`_.

    Args:
      locale (string):
        Specify a locale to use.
      rtl (boolean):
        Specify a RTL mode.
      messages (unknown):
        Displays a list of messages or a single message if using a string.
      fallback_locale (string):
        Specify a fallback locale to use when a locale is not found.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VLocaleProvider", children, **kwargs)
        self._attr_names += [
            "locale",
            "rtl",
            "messages",
            ("fallback_locale", "fallbackLocale"),
        ]
        self._event_names += []


class VMain(HtmlElement):
    """
    Vuetify's VMain component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-main>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      scrollable (boolean):
        Specify a custom scrollable function.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VMain", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "tag",
            "scrollable",
        ]
        self._event_names += []


class VMaskInput(HtmlElement):
    """
    Vuetify's VMaskInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-mask-input>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      type (string):
        Sets input type.
      reverse (boolean):
        Reverses the orientation.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      placeholder (string):
        Sets the input’s placeholder text.
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      theme (string):
        Specify a theme for this component and all of its children.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      mask (enum):
        Apply a mask to the input. See [guide](/components/mask-inputs/#guide)
        for more information.

        Enum values: [
          string, {      mask: string      tokens: Record<        string,,
          js_fn, js_fn, { pattern: RegExp; test: undefined }      >
          }
        ]
      return_masked_value (boolean):
        Returns the unmodified masked string.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VMaskInput", children, **kwargs)
        self._attr_names += [
            "flat",
            "type",
            "reverse",
            "name",
            "error",
            "label",
            "autocomplete",
            "disabled",
            "placeholder",
            "width",
            "id",
            "prefix",
            "role",
            "autofocus",
            "theme",
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("model_value", "modelValue"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
            "mask",
            ("return_masked_value", "returnMaskedValue"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
        ]


class VMenu(HtmlElement):
    """
    Vuetify's VMenu component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-menu>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component. Use `auto` to use the activator width.
      width (string, number):
        Sets the width for the component.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      theme (string):
        Specify a theme for this component and all of its children.
      disabled (boolean):
        Removes the ability to click or target the component.
      id (string):
        The unique identifier of the component.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          {      component: ComponentPublicInstanceConstructor<
          CreateComponentPublicInstanceWithMixins<          {} & { target?:
          HTMLElement, [x: number, y: number], undefined } & {
             $children?:, VNodeChild, { $stable?: boolean, undefined },
          js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn
        ]
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of the content
        element when using the persistent prop.
      persistent (boolean):
        Clicking outside of the element or pressing esc key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Designates whether menu should open on activator click.
      open_on_hover (boolean):
        Designates whether menu should open on activator hover.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Designates if menu should close when its content is clicked.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only works with
        the **open-on-hover** prop.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only works with
        the **open-on-hover** prop.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      disable_initial_focus (boolean):
        Deprecated, use `capture-focus` instead. Prevents automatic redirect
        of first `focusin` event. Intended to use on permanently open
        menus or VSpeedDial.
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default. Generally
        not recommended except as a last resort: the default positioning
        algorithm should handle most scenarios better than is possible
        without teleporting, and you may have unexpected behavior if
        the menu ends up as child of its activator.
      submenu (boolean):
        Opens with right arrow and closes on left instead of up/down.
        Implies `location="end"`. Directions are reversed for RTL.
      open_on_arrow (boolean):
        Using keyboard arrows up/down on the activator should open the
        menu and move focus into its content. Disable to handle arrow
        keys in the activator itself, e.g. when the menu holds a virtualized
        list.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VMenu", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "location",
            "theme",
            "disabled",
            "id",
            "transition",
            "activator",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            "target",
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            "eager",
            ("location_strategy", "locationStrategy"),
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            ("disable_initial_focus", "disableInitialFocus"),
            "attach",
            "submenu",
            ("open_on_arrow", "openOnArrow"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VMessages(HtmlElement):
    """
    Vuetify's VMessages component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-messages>`_.

    Args:
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      active (boolean):
        Determines whether the messages are visible or not.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          { component: Component; leaveAbsolute: boolean; group: boolean
          }
        ]
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VMessages", children, **kwargs)
        self._attr_names += [
            "color",
            "active",
            "transition",
            "messages",
        ]
        self._event_names += []


class VMonthPicker(HtmlElement):
    """
    Vuetify's VMonthPicker component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-month-picker>`_.

    Args:
      title (string):
        Specify a title text for the component.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (unknown):
        The selected month in `YYYY-MM` format, or null if no month is
        selected. When `multiple` is set, expects an array of strings.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      max (string):
        Maximum selectable date in `YYYY-MM` format.
      min (string):
        Minimum selectable date in `YYYY-MM` format.
      multiple (boolean, 'range'):
        Allows multiple month selections. When set to `true`, enables
        multi-select. When set to `'range'`, enables range selection
        where the first and last selected months define the range boundaries.
      readonly (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VMonthPicker.json))
      transition (string):
        The transition used when changing year into the future
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      divided (boolean):
        Adds a divider between the header and controls.
      hide_header (boolean):
        Hide the picker header.
      next_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VMonthPicker.json))

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prev_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VMonthPicker.json))

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      reverse_transition (string):
        The transition used when changing year into the past
      hide_title (boolean):
        Hide the picker title.
      header_color (string):
        Overrides the color used for the header and title areas. Falls
        back to `color` when not set.
      mode_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VMonthPicker.json))

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      allowed_months (number[], js_fn):
        Restricts which months can be selected. Accepts an array of month
        numbers (0-11) or a function that receives a month number and
        returns a boolean.
      allowed_years (number[], js_fn):
        Restricts which years can be selected in years view.
      selected_icon (enum):
        Icon to display next to selected months in list view.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      months_columns (string, number):
        Number of columns to use when displaying months in grid view.
        When set to `1`, switches to list view.
      years_columns (string, number):
        Number of columns to use when displaying years in year selection view.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VMonthPicker", children, **kwargs)
        self._attr_names += [
            "title",
            "border",
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "disabled",
            "max",
            "min",
            "multiple",
            "readonly",
            "transition",
            ("bg_color", "bgColor"),
            "divided",
            ("hide_header", "hideHeader"),
            ("next_icon", "nextIcon"),
            ("prev_icon", "prevIcon"),
            ("reverse_transition", "reverseTransition"),
            ("hide_title", "hideTitle"),
            ("header_color", "headerColor"),
            ("mode_icon", "modeIcon"),
            ("allowed_months", "allowedMonths"),
            ("allowed_years", "allowedYears"),
            ("selected_icon", "selectedIcon"),
            ("months_columns", "monthsColumns"),
            ("years_columns", "yearsColumns"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VNavigationDrawer(HtmlElement):
    """
    Vuetify's VNavigationDrawer component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-navigation-drawer>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      width (string, number):
        Sets the width for the component. Percentage values are relative
        to the layout, not the viewport.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location ('top', 'end', 'bottom', 'start', 'left', 'right'):
        Controls the edge of the screen the drawer is attached to.
      absolute (boolean):
        Applies **position: absolute** to the component.
      sticky (boolean):
        When true, the drawer will remain visible when scrolling past
        the top of the page.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Assign a specific name for layout registration.
      image (string):
        Apply a specific background image to the component.
      floating (boolean):
        A floating drawer has no visible container (no border-right).
      order (string, number):
        Adjust the order of the component in relation to its registration order.
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Sets the designated mobile breakpoint for the component. This
        will apply alternate styles for mobile devices such as the `temporary`
        prop, or activate the `bottom` prop when the breakpoint value
        is met. Setting the value to `0` will disable this functionality.
      persistent (boolean):
        Clicking outside or pressing **esc** key will not dismiss the dialog.
      scrim (string, boolean):
        Determines whether an overlay is used when a **temporary** drawer
        is open. Accepts true/false to enable background, and string
        to define color.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      disable_resize_watcher (boolean):
        Prevents the automatic opening or closing of the drawer when
        resized, based on whether the device is mobile or desktop.
      disable_route_watcher (boolean):
        Disables opening of navigation drawer when route changes.
      expand_on_hover (boolean):
        Collapses the drawer to a **rail-variant** until hovering with the mouse.
      permanent (boolean):
        The drawer remains visible regardless of screen size.
      rail (boolean):
        Sets the component width to the **rail-width** value.
      rail_width (string, number):
        Sets the width for the component when `rail` is enabled. Percentage
        values are relative to the layout.
      temporary (boolean):
        A temporary drawer sits above its application and uses a scrim
        (overlay) to darken the background.
      touchless (boolean):
        Disable mobile touch functionality.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_rail (event):
        Event that is emitted when the rail model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VNavigationDrawer", children, **kwargs)
        self._attr_names += [
            "border",
            ("model_value", "modelValue"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "absolute",
            "sticky",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "name",
            "image",
            "floating",
            "order",
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "persistent",
            "scrim",
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            ("disable_resize_watcher", "disableResizeWatcher"),
            ("disable_route_watcher", "disableRouteWatcher"),
            ("expand_on_hover", "expandOnHover"),
            "permanent",
            "rail",
            ("rail_width", "railWidth"),
            "temporary",
            "touchless",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_rail", "update:rail"),
        ]


class VNoSsr(HtmlElement):
    """
    Vuetify's VNoSsr component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-no-ssr>`_.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VNoSsr", children, **kwargs)
        self._attr_names += []
        self._event_names += []


class VNumberInput(HtmlElement):
    """
    Vuetify's VNumberInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-number-input>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      type (string):
        **IGNORED** underlying input is always of type 'text'
      model_value (number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      reverse (boolean):
        Reverses the orientation.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'filled', 'underlined', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      name (string):
        Sets the component's name attribute.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      max (number):
        Specifies the maximum allowable value for the input.
      min (number):
        Specifies the minimum allowable value for the input.
      placeholder (string):
        Sets the input’s placeholder text.
      step (number):
        Defines the interval between allowed values when the user increments
        or decrements the input
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      inset (boolean):
        Applies an indentation to the dividers used in the stepper buttons.
      decimal_separator (string):
        Expects single character to be used as decimal separator.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      control_variant ('default', 'split', 'hidden', 'stacked'):
        Controls layout of the stepper buttons.
      hide_input (boolean):
        Hide the input field.
      precision (number):
        Enforces strict precision. It is expected to be an integer value
        in range between `0` and `15`, or null for unrestricted.
      min_fraction_digits (number):
        Specifies the minimum fraction digits to be displayed (capped
        to `precision`). Defaults to `precision` when not explicitly
        set.
      grouping (boolean, 'auto', 'always', 'min2'):
        Enables grouping using current locale or specific character passed
        to `group-separator`. Note: `'auto'` is recommended over `true`.
      group_separator (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VNumberInput.json))
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VNumberInput", children, **kwargs)
        self._attr_names += [
            "flat",
            "type",
            ("model_value", "modelValue"),
            "error",
            "reverse",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "rounded",
            "tile",
            "theme",
            "color",
            "variant",
            "name",
            "autocomplete",
            "disabled",
            "max",
            "min",
            "placeholder",
            "step",
            "id",
            "prefix",
            "role",
            "autofocus",
            "active",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "loading",
            "label",
            ("bg_color", "bgColor"),
            "inset",
            ("decimal_separator", "decimalSeparator"),
            "messages",
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            "focused",
            ("hide_details", "hideDetails"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
            ("control_variant", "controlVariant"),
            ("hide_input", "hideInput"),
            "precision",
            ("min_fraction_digits", "minFractionDigits"),
            "grouping",
            ("group_separator", "groupSeparator"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
        ]


class VOtpField(HtmlElement):
    """
    Vuetify's VOtpField component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-otp-field>`_.

    Args:
      index (number):
        Logical position of the slot within the OTP value.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VOtpField", children, **kwargs)
        self._attr_names += [
            "index",
        ]
        self._event_names += []


class VOtpGroup(HtmlElement):
    """
    Vuetify's VOtpGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-otp-group>`_.

    Args:
      merged (boolean):
        Merges fields within this group into a single visual block.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VOtpGroup", children, **kwargs)
        self._attr_names += [
            "merged",
        ]
        self._event_names += []


class VOtpInput(HtmlElement):
    """
    Vuetify's VOtpInput component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-otp-input>`_.

    Args:
      length (string, number):
        The OTP field's length.
      type ('number', 'text', 'password'):
        Supported types: `text`, `password`, `number`.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      disabled (boolean):
        Removes the ability to click or target the input.
      height (string, number):
        Sets the height for the component.
      pattern (enum):
        Restricts input to characters matching the given pattern. Accepts
        `’numeric’`, `’alpha’`, `’alphanumeric’`, `’unicode-alpha’` (any
        Unicode letter, e.g. CJK / Cyrillic / Arabic), `’unicode-alphanumeric’`,
        or a custom `RegExp`. Defaults to `’numeric’` when `type="number"`.

        Enum values: [
          RegExp, 'numeric', 'alpha', 'alphanumeric', 'unicode-alpha',
          'unicode-alphanumeric'
        ]
      placeholder (string):
        Sets the input’s placeholder text.
      width (string, number):
        Sets the width for the component.
      autofocus (boolean):
        Automatically focuses the first input on page load
      theme (string):
        Specify a theme for this component and all of its children.
      divider (string):
        Specifies the dividing character between items.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      model_value (string, number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      focused (boolean):
        Forces a focused state styling on the component.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      merged (boolean):
        Renders all fields in a single merged group with shared elevation
        and border radius.
      focus_all (boolean):
        Puts all inputs into a focus state when any are focused
      masked (boolean):
        Hides the entered characters with bullets, similar to a password
        input, but makes it possible to also restrict characters to digits
        with `type="number"`.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_focused (event):
        Emitted when the input is focused or blurred
      finish (event):
        Emitted when all slots have been filled.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VOtpInput", children, **kwargs)
        self._attr_names += [
            "length",
            "type",
            "error",
            "label",
            "disabled",
            "height",
            "pattern",
            "placeholder",
            "width",
            "autofocus",
            "theme",
            "divider",
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "rounded",
            "color",
            "variant",
            ("model_value", "modelValue"),
            "focused",
            "loading",
            "merged",
            ("focus_all", "focusAll"),
            "masked",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_focused", "update:focused"),
            "finish",
        ]


class VOtpSeparator(HtmlElement):
    """
    Vuetify's VOtpSeparator component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-otp-separator>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VOtpSeparator", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VOverlay(HtmlElement):
    """
    Vuetify's VOverlay component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-overlay>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      absolute (boolean):
        Applies **position: absolute** to the content element.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of the content
        element when using the persistent prop.
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      persistent (boolean):
        Clicking outside of the element or pressing esc key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Activate the component when the activator is clicked.
      open_on_hover (boolean):
        Activate the component when the activator is hovered.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      keydown (event):
        Emitted when **any** key is pressed.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_outside (event):
        Event that fires when clicking outside an active overlay.
      afterEnter (event):
        Event that fires after the overlay has finished transitioning in.
      afterLeave (event):
        Event that fires after the overlay has finished transitioning out.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VOverlay", children, **kwargs)
        self._attr_names += [
            "disabled",
            "height",
            "width",
            "theme",
            "target",
            "eager",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "activator",
            "absolute",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            ("model_value", "modelValue"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            ("location_strategy", "locationStrategy"),
            "location",
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            "transition",
            "attach",
        ]
        self._event_names += [
            "keydown",
            ("update_modelValue", "update:modelValue"),
            ("click_outside", "click:outside"),
            "afterEnter",
            "afterLeave",
        ]


class VPagination(HtmlElement):
    """
    Vuetify's VPagination component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-pagination>`_.

    Args:
      length (string, number):
        The number of pages.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      aria_label (string):
        Label for the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      active_color (string):
        The applied color when the component is in an active state.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the selected page button - supports
        utility colors (for example `success` or `purple`) or css color
        (`#033` or `rgba(255, 0, 0, 0.5)`). Find a list of built-in classes
        on the [colors page](/styles/colors#material-colors).
      variant ('flat', 'text', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      model_value (number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      start (string, number):
        Specify the starting page.
      prev_icon (enum):
        The icon to use for the prev button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        The icon to use for the next button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      first_icon (enum):
        The icon to use for the first button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      last_icon (enum):
        The icon to use for the last button.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      total_visible (string, number):
        Specify the total visible pagination numbers.
      page_aria_label (string):
        Label for each page button.
      current_page_aria_label (string):
        Label for the currently selected page.
      first_aria_label (string):
        Label for the go to first button.
      previous_aria_label (string):
        Label for the previous button.
      next_aria_label (string):
        Label for the next button.
      last_aria_label (string):
        Label for the go to last button.
      ellipsis (string):
        Text to show between page buttons when truncating the list.
      show_first_last_page (boolean, 'only-first'):
        Show buttons for going to first and last page. Since v4.1.0 it
        accepts `'only-first'`, to only the first page button.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      next (event):
        Emitted when clicking on go to next button.
      prev (event):
        Emitted when clicking on go to previous button.
      first (event):
        Emitted when clicking on go to first button.
      last (event):
        Emitted when clicking on go to last button.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPagination", children, **kwargs)
        self._attr_names += [
            "length",
            "tag",
            "disabled",
            "size",
            ("aria_label", "ariaLabel"),
            "theme",
            ("active_color", "activeColor"),
            "border",
            "density",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("model_value", "modelValue"),
            "start",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("first_icon", "firstIcon"),
            ("last_icon", "lastIcon"),
            ("total_visible", "totalVisible"),
            ("page_aria_label", "pageAriaLabel"),
            ("current_page_aria_label", "currentPageAriaLabel"),
            ("first_aria_label", "firstAriaLabel"),
            ("previous_aria_label", "previousAriaLabel"),
            ("next_aria_label", "nextAriaLabel"),
            ("last_aria_label", "lastAriaLabel"),
            "ellipsis",
            ("show_first_last_page", "showFirstLastPage"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "next",
            "prev",
            "first",
            "last",
        ]


class VParallax(HtmlElement):
    """
    Vuetify's VParallax component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-parallax>`_.

    Args:
      scale (string, number):
        The scale of the parallax image.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VParallax", children, **kwargs)
        self._attr_names += [
            "scale",
        ]
        self._event_names += []


class VPicker(HtmlElement):
    """
    Vuetify's VPicker component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-picker>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      title (string):
        Specify a title text for the component.
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      divided (boolean):
        Adds a divider between the header and controls.
      landscape (boolean):
        Puts the picker into landscape mode.
      hide_header (boolean):
        Hide the picker header.
      hide_title (boolean):
        Hide the picker title.
      position ('fixed', 'relative', 'absolute', 'static', 'sticky'):
        Sets the position for the component.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPicker", children, **kwargs)
        self._attr_names += [
            "tag",
            "title",
            "height",
            "width",
            "theme",
            ("bg_color", "bgColor"),
            "border",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "location",
            "divided",
            "landscape",
            ("hide_header", "hideHeader"),
            ("hide_title", "hideTitle"),
            "position",
        ]
        self._event_names += []


class VPickerTitle(HtmlElement):
    """
    Vuetify's VPickerTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-picker-title>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPickerTitle", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VPie(HtmlElement):
    """
    Vuetify's VPie component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-pie>`_.

    Args:
      title (string):
        Specify a title text for the component.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      rounded (string, number):
        Number passed as corner radius relative to 100x100 SVG viewport
      size (string, number):
        Sets the height and width of the chart (excluding title and legend).
      gap (string, number):
        Reduces segment size by a specified angle. Recommended to in range (0-10).
      items (Record<string, any>, { color: string; pattern: string }[]):
        Data items expected to contain `key`, `title` and `value`.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      legend (enum):
        Controls legend visibility, position and text format.

        Enum values: [
          boolean, {      position: 'top', 'bottom', 'left', 'right'
             textFormat:, string, ((v: {            key: string, number,
          js_fn
        ]
      tooltip (enum):
        Controls tooltip visibility, transition, offset from the cursor
        and formats of title and subtitle.

        Enum values: [
          boolean, {      titleFormat:, string, ((v: {            key:
          string, number, js_fn, string, ((v: {            key: string,
          number, js_fn, false, true, TransitionProps      offset: number
             }
        ]
      item_title (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VPie.json))
      item_value (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VPie.json))
      hover_scale (string, number):
        Enables interactive behavior by reducing segment size until it
        gets hovered. Expects fraction value (0-0.25).
      rotate (string, number):
        Rotates the chart segments clockwise.
      palette ((string, { color: string; pattern: string })[]):
        Defines colors and patterns to be applied based on the data items
        order. Data items can also define their colors.
      item_key (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VPie.json))
      gauge_cut (string, number):
        Allows removing bottom part of the chart to make it into a gauge.
        Expects angle (0-180).
      inner_cut (string, number):
        Specifies inner radius for a donut-style chart as a percent (0-100).
        Without `hide-slice`, inner slice is visible with translucent
        color matching the item.
      animation (enum):
        Controls duration and easing of the expand/collapse and hover
        effect. Defaults to `easeInOutCubic` over 400ms.

        Enum values: [
          boolean, {      duration: number      easing:, 'linear', 'easeInQuad',
          'easeOutQuad', 'easeInOutQuad', 'easeInCubic', 'easeOutCubic',
          'easeInOutCubic', 'easeInQuart', 'easeOutQuart', 'easeInOutQuart',
          'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 'instant'
           }
        ]
      hide_slice (boolean):
        Makes inner slice invisible instead of semi-transparent.
      reveal (boolean, { duration: number }):
        Enables and controls duration for initial reveal animation. Easing
        function is shared with `animation` prop.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPie", children, **kwargs)
        self._attr_names += [
            "title",
            "density",
            "rounded",
            "size",
            "gap",
            "items",
            ("bg_color", "bgColor"),
            "legend",
            "tooltip",
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("hover_scale", "hoverScale"),
            "rotate",
            "palette",
            ("item_key", "itemKey"),
            ("gauge_cut", "gaugeCut"),
            ("inner_cut", "innerCut"),
            "animation",
            ("hide_slice", "hideSlice"),
            "reveal",
        ]
        self._event_names += []


class VPieSegment(HtmlElement):
    """
    Vuetify's VPieSegment component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-pie-segment>`_.

    Args:
      pattern (string):
        Decal pattern to put on top of the outer slice.
      value (number):
        The value used for calculate segment/arc angle size.
      rounded (string, number):
        Number passed as corner radius relative to 100x100 SVG viewport
      color (string):
        Sets segment color to be passed straight to CSS style attribute.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      gap (string, number):
        Reduces segment size by a specified angle. Recommended to in range (0-10).
      rotate (string, number):
        Sets segment offset angle.
      inner_cut (string, number):
        Sets inner slice size in percent (0-100).
      hover_scale (string, number):
        Reduces outer radius until segment is hovered. Expects fraction value (0-0.25)
      animation (enum):
        Controls duration and easing of the expand/collapse and hover
        effect. Defaults to `easeInOutCubic` over 400ms.

        Enum values: [
          boolean, {      duration: number      easing:, 'linear', 'easeInQuad',
          'easeOutQuad', 'easeInOutQuad', 'easeInCubic', 'easeOutCubic',
          'easeInOutCubic', 'easeInQuart', 'easeOutQuart', 'easeInOutQuart',
          'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 'instant'
           }
        ]
      hide_slice (boolean):
        Makes inner slice invisible instead of semi-transparent.
      reveal (boolean, { duration: number }):
        Enables and controls duration for initial reveal animation. Easing
        function is shared with `animation` prop.
      update_active (event):
        Emitted when the segment's active (hovered) state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPieSegment", children, **kwargs)
        self._attr_names += [
            "pattern",
            "value",
            "rounded",
            "color",
            "active",
            "gap",
            "rotate",
            ("inner_cut", "innerCut"),
            ("hover_scale", "hoverScale"),
            "animation",
            ("hide_slice", "hideSlice"),
            "reveal",
        ]
        self._event_names += [
            ("update_active", "update:active"),
        ]


class VPieTooltip(HtmlElement):
    """
    Vuetify's VPieTooltip component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-pie-tooltip>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      transition (enum):
        The transition used when hovering between chart segments

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      item (enum):
        Data item related to hovered segment

        Enum values: [
          {  key: string, number, symbol  color: string  value: number
           title: string  pattern: string  isActive: boolean  raw: Record<string,
          any>}
        ]
      target ([number, number]):
        The coordinates used to position the tooltip.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      title_format (string, ((v: {      key: string, number, js_fn):
        Formatter definition or function. When passed as String macros
        for `[title]` and `[value]` get replaced dynamically.
      subtitle_format (string, ((v: {      key: string, number, js_fn):
        Formatter definition or function. When passed as String macros
        for `[title]` and `[value]` get replaced dynamically.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPieTooltip", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "transition",
            "item",
            "target",
            "offset",
            ("title_format", "titleFormat"),
            ("subtitle_format", "subtitleFormat"),
        ]
        self._event_names += []


class VProgress(HtmlElement):
    """
    Vuetify's VProgress component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-progress>`_.

    Args:
      type ('linear', 'circular'):
        Determines which progress indicator to render.
      label (string):
        Text displayed alongside the progress indicator and placed in `aria-label`.
      indeterminate (boolean):
        Constantly animates, use when loading progress is unknown.
      max (string, number):
        Sets the maximum value for the progress indicator.
      theme (string):
        Specify a theme for this component and all of its children.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      rounded (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VProgress.json))
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      absolute (boolean):
        Positions the component absolutely within its parent, centering
        the progress indicator and placing details without affecting
        layout.
      model_value (string, number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      transition (boolean, { duration: string, number }):
        Controls the animation to a new value. Pass `{ duration }` in
        milliseconds or as a CSS duration (`0.4s`), or `false` to remove
        it. Does not affect the `indeterminate` animation.
      reveal (boolean, { duration: number }):
        Animates the progress indicator from 0 to its model value when
        the component mounts.
      details_position ('top', 'bottom'):
        Controls the position of the details (label and value) relative
        to the progress indicator.
      value_format (string, js_fn):
        Formatter for the visible value text and `aria-valuetext`. Use
        `[value]` and `[max]` as placeholders in strings, or pass a function
        that receives `{ value, max }` and returns a string.
      hide_label (boolean):
        Hides the label text.
      hide_value (boolean):
        Hides the value text.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VProgress", children, **kwargs)
        self._attr_names += [
            "type",
            "label",
            "indeterminate",
            "max",
            "theme",
            ("bg_color", "bgColor"),
            "rounded",
            "color",
            "absolute",
            ("model_value", "modelValue"),
            "transition",
            "reveal",
            ("details_position", "detailsPosition"),
            ("value_format", "valueFormat"),
            ("hide_label", "hideLabel"),
            ("hide_value", "hideValue"),
        ]
        self._event_names += []


class VProgressCircular(HtmlElement):
    """
    Vuetify's VProgressCircular component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-progress-circular>`_.

    Args:
      model_value (string, number):
        The percentage value for current progress.
      width (string, number):
        Sets the stroke of the circle in pixels.
      rounded (boolean):
        Rounds the ends of the progress arc for a softer appearance.
        When enabled, the progress stroke will have rounded caps instead
        of square ends.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      indeterminate (boolean, 'disable-shrink'):
        Constantly animates, use when loading progress is unknown. If
        set to the string `'disable-shrink'` it will use a simpler animation
        that does not run on the main thread.
      size (string, number):
        Sets the diameter of the circle in pixels.
      transition (boolean, { duration: string, number }):
        Controls the animation to a new value. Pass `{ duration }` in
        milliseconds or as a CSS duration (e.g. `0.4s`), or `false` to
        remove it. Does not affect the `indeterminate` and `reveal` animations.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      rotate (string, number):
        Rotates the circle start point in degrees.
      reveal (boolean, { duration: number }):
        Animates the progress circle from 0 to its model value when the
        component mounts.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VProgressCircular", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "width",
            "rounded",
            "tag",
            "theme",
            "color",
            "indeterminate",
            "size",
            "transition",
            ("bg_color", "bgColor"),
            "rotate",
            "reveal",
        ]
        self._event_names += []


class VProgressLinear(HtmlElement):
    """
    Vuetify's VProgressLinear component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-progress-linear>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      reverse (boolean):
        Displays reversed progress (right to left in LTR mode and left to right in RTL).
      height (string, number):
        Sets the height for the component.
      indeterminate (boolean):
        Constantly animates, use when loading progress is unknown.
      max (string, number):
        Sets the maximum value the progress can reach.
      theme (string):
        Specify a theme for this component and all of its children.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('split'):
        Applies a distinct style to the component. **split** visually
        divides the progress bar at the current value, separating the
        filled and unfilled portions with a gap.
      absolute (boolean):
        Applies position: absolute to the component.
      opacity (string, number):
        Set the opacity of the progress bar.
      model_value (string, number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      transition (boolean, { duration: string, number }):
        Controls the animation to a new value. Pass `{ duration }` in
        milliseconds or as a CSS duration (e.g. `0.4s`), or `false` to
        remove it. Does not affect `indeterminate`, `stream` or `striped`
        animations.
      active (boolean):
        Reduce the height to 0, hiding component.
      striped (boolean):
        Adds a stripe background to the filled portion of the progress component.
      stream (boolean):
        An alternative style for portraying loading that works in tandem
        with **buffer-value**.
      reveal (boolean, { duration: number }):
        Animates the progress bar from 0 to its model value when the component mounts.
      bg_opacity (string, number):
        Background opacity, if null it defaults to 0.3 if background
        color is not specified or 1 otherwise.
      buffer_value (string, number):
        The percentage value for the buffer.
      buffer_color (string):
        Sets the color of the buffer bar.
      buffer_opacity (string, number):
        Set the opacity of the buffer bar.
      clickable (boolean):
        Clicking on the progress track will automatically set the value.
      rounded_bar (boolean):
        Applies a border radius to the progress bar.
      chunk_count (string, number):
        Specifies amount of chunks to divide the bar into.
      chunk_width (string, number):
        Defines chunk absolute size. Useful when chunk is narrow.
      chunk_gap (string, number):
        Defines size of the gap between chunks.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VProgressLinear", children, **kwargs)
        self._attr_names += [
            "tag",
            "reverse",
            "height",
            "indeterminate",
            "max",
            "theme",
            ("bg_color", "bgColor"),
            "rounded",
            "tile",
            "color",
            "variant",
            "absolute",
            "opacity",
            ("model_value", "modelValue"),
            "location",
            "transition",
            "active",
            "striped",
            "stream",
            "reveal",
            ("bg_opacity", "bgOpacity"),
            ("buffer_value", "bufferValue"),
            ("buffer_color", "bufferColor"),
            ("buffer_opacity", "bufferOpacity"),
            "clickable",
            ("rounded_bar", "roundedBar"),
            ("chunk_count", "chunkCount"),
            ("chunk_width", "chunkWidth"),
            ("chunk_gap", "chunkGap"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VPullToRefresh(HtmlElement):
    """
    Vuetify's VPullToRefresh component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-pull-to-refresh>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      pull_down_threshold (number):
        The distance the user must pull down to trigger a refresh.
      load (event):
        Emitted when the user pulls down past the threshold.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VPullToRefresh", children, **kwargs)
        self._attr_names += [
            "disabled",
            ("pull_down_threshold", "pullDownThreshold"),
        ]
        self._event_names += [
            "load",
        ]


class VRadio(HtmlElement):
    """
    Vuetify's VRadio component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-radio>`_.

    Args:
      type (string):
        Provides the default type for children selection controls.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      disabled (boolean):
        Removes the ability to click or target the component.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      id (string):
        Sets the DOM id on the component.
      theme (string):
        Specify a theme for this component and all of its children.
      base_color (string):
        Sets the color of the input when it is not focused.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      readonly (boolean):
        Puts input in readonly state.
      inline (boolean):
        Puts children inputs into a row.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      true_value (any):
        Sets value for truthy state.
      false_value (any):
        Sets value for falsy state.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VRadio", children, **kwargs)
        self._attr_names += [
            "type",
            "name",
            "error",
            "label",
            "disabled",
            "multiple",
            "value",
            "id",
            "theme",
            ("base_color", "baseColor"),
            "density",
            ("value_comparator", "valueComparator"),
            "color",
            ("model_value", "modelValue"),
            "readonly",
            "inline",
            "ripple",
            ("true_value", "trueValue"),
            ("false_value", "falseValue"),
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VRadioGroup(HtmlElement):
    """
    Vuetify's VRadioGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-radio-group>`_.

    Args:
      type (string):
        Provides the default type for children selection controls.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      inline (boolean):
        Displays radio buttons in row.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/SelectionControlGroup.json))

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VRadioGroup", children, **kwargs)
        self._attr_names += [
            "type",
            ("model_value", "modelValue"),
            "error",
            "density",
            "height",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "theme",
            "color",
            "name",
            "disabled",
            "id",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "ripple",
            "inline",
            "label",
            "messages",
            ("center_affix", "centerAffix"),
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
        ]


class VRangeSlider(HtmlElement):
    """
    Vuetify's VRangeSlider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-range-slider>`_.

    Args:
      reverse (boolean):
        Reverses the slider direction.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      disabled (boolean):
        Removes the ability to click or target the component.
      max (string, number):
        Sets the maximum allowed value.
      min (string, number):
        Sets the minimum allowed value.
      step (string, number):
        If greater than 0, sets step interval for ticks.
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      theme (string):
        Specify a theme for this component and all of its children.
      base_color (string):
        Sets the color of the input when it is not focused.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value ((string, number)[]):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the input is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      direction ('horizontal', 'vertical'):
        Changes the direction of the input.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      ripple (boolean):
        Applies the [v-ripple](/directives/ripple) directive.
      thumb_color (string):
        Sets the thumb and thumb label color.
      thumb_label (boolean, 'hover', 'always'):
        Show thumb label. If `true` it shows label when using slider.
        If set to `'always'` it always shows label. Use `'hover'` to
        show label when hovering over the thumb.
      thumb_size (string, number):
        Controls the size of the thumb label.
      show_ticks (boolean, 'always'):
        Show track ticks. If `true` it shows ticks when using slider.
        If set to `'always'` it always shows ticks.
      ticks (number[], Record<number, string>):
        Show track ticks. If `true` it shows ticks when using slider.
        If set to `'always'` it always shows ticks.
      tick_size (string, number):
        Controls the size of **ticks**
      track_color (string):
        Sets the track's color
      track_fill_color (string):
        Sets the track's fill color
      track_size (string, number):
        Sets the track's size (height).
      no_keyboard (boolean):
        **FOR INTERNAL USE ONLY** Ignore keyboard events.
      strict (boolean):
        Disallows dragging the ending thumb past the starting thumb and vice versa.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
      start (event):
        Slider value emitted at start of slider movement.
      end (event):
        Slider value emitted at the end of slider movement.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VRangeSlider", children, **kwargs)
        self._attr_names += [
            "reverse",
            "name",
            "error",
            "label",
            "disabled",
            "max",
            "min",
            "step",
            "width",
            "id",
            "theme",
            ("base_color", "baseColor"),
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            ("model_value", "modelValue"),
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            "direction",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            "ripple",
            ("thumb_color", "thumbColor"),
            ("thumb_label", "thumbLabel"),
            ("thumb_size", "thumbSize"),
            ("show_ticks", "showTicks"),
            "ticks",
            ("tick_size", "tickSize"),
            ("track_color", "trackColor"),
            ("track_fill_color", "trackFillColor"),
            ("track_size", "trackSize"),
            ("no_keyboard", "noKeyboard"),
            "strict",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            "start",
            "end",
        ]


class VRating(HtmlElement):
    """
    Vuetify's VRating component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-rating>`_.

    Args:
      length (string, number):
        The amount of items to show.
      model_value (string, number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      active_color (string):
        The applied color when the component is in an active state.
      readonly (boolean):
        Removes all hover effects and pointer events.
      ripple (boolean):
        Applies the [v-ripple](/directives/ripple) directive.
      hover (boolean):
        Provides visual feedback when hovering over icons.
      clearable (boolean):
        Allows for the component to be cleared by clicking on the current value.
      item_aria_label (string):
        The **aria-label** used for each item.
      empty_icon (enum):
        The icon displayed when empty.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      full_icon (enum):
        The icon displayed when full.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      half_increments (boolean):
        Allows the selection of half increments.
      item_label_position (string):
        Position of item labels. Accepts 'top' and 'bottom'.
      item_labels (string[]):
        Array of labels to display next to each item..
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VRating", children, **kwargs)
        self._attr_names += [
            "length",
            ("model_value", "modelValue"),
            "density",
            "tag",
            "theme",
            "color",
            "name",
            "disabled",
            "size",
            ("active_color", "activeColor"),
            "readonly",
            "ripple",
            "hover",
            "clearable",
            ("item_aria_label", "itemAriaLabel"),
            ("empty_icon", "emptyIcon"),
            ("full_icon", "fullIcon"),
            ("half_increments", "halfIncrements"),
            ("item_label_position", "itemLabelPosition"),
            ("item_labels", "itemLabels"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VResponsive(HtmlElement):
    """
    Vuetify's VResponsive component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-responsive>`_.

    Args:
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      inline (boolean):
        Display as an inline element instead of a block, also disables flex-grow.
      content_class (any):
        Apply a custom class to the internal content element.
      aspect_ratio (string, number):
        Sets a base aspect ratio, calculated as width/height. This will
        only set a **minimum** height, the component can still grow if
        it has a lot of content.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VResponsive", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "inline",
            ("content_class", "contentClass"),
            ("aspect_ratio", "aspectRatio"),
        ]
        self._event_names += []


class VRow(HtmlElement):
    r"""
    Vuetify's VRow component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-row>`_.

    Args:
      density ('default', 'comfortable', 'compact'):
        Adjusts the spacing between `v-col`s. Available options are:
        **default**, **comfortable**, **compact**.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      align ('end', 'start', 'center', 'baseline', 'stretch'):
        Deprecated, use **align-\*** class. Available options are: **start**,
        **center**, **end**, **baseline** and **stretch**.
      size (string, number):
        Sets the number of columns.
      gap (string, number, (string, number)[]):
        Sets the gap between `v-col`s. Can be a single value for both
        row and column gap, or the array of two values [column gap, row
        gap].
      dense (boolean):
        Deprecated, use `density` with **compact** instead.
      justify (enum):
        Deprecated, use **justify-\***. Available options are: **start**,
        **center**, **end**, **space-between** and **space-around**.

        Enum values: [
          'end', 'start', 'center', 'space-around', 'space-between', 'space-evenly'
        ]
      align_sm ('end', 'start', 'center', 'baseline', 'stretch'):
        Deprecated, use **align-sm-\*** class
      align_md ('end', 'start', 'center', 'baseline', 'stretch'):
        Deprecated, use **align-md-\*** class
      align_lg ('end', 'start', 'center', 'baseline', 'stretch'):
        Deprecated, use **align-lg-\*** class
      align_xl ('end', 'start', 'center', 'baseline', 'stretch'):
        Deprecated, use **align-xl-\*** class
      align_xxl ('end', 'start', 'center', 'baseline', 'stretch'):
        Deprecated, use **align-xxl-\*** class
      justify_sm (enum):
        Deprecated, use **justify-sm-\*** class

        Enum values: [
          'end', 'start', 'center', 'space-around', 'space-between', 'space-evenly'
        ]
      justify_md (enum):
        Deprecated, use **justify-md-\*** class

        Enum values: [
          'end', 'start', 'center', 'space-around', 'space-between', 'space-evenly'
        ]
      justify_lg (enum):
        Deprecated, use **justify-lg-\*** class

        Enum values: [
          'end', 'start', 'center', 'space-around', 'space-between', 'space-evenly'
        ]
      justify_xl (enum):
        Deprecated, use **justify-xl-\*** class

        Enum values: [
          'end', 'start', 'center', 'space-around', 'space-between', 'space-evenly'
        ]
      justify_xxl (enum):
        Deprecated, use **justify-xxl-\*** class

        Enum values: [
          'end', 'start', 'center', 'space-around', 'space-between', 'space-evenly'
        ]
      align_content (enum):
        Deprecated, use **align-content-\***. Available options are:
        **start**, **center**, **end**, **space-between**, **space-around**
        and **stretch**.

        Enum values: [
          'end', 'start', 'center', 'stretch', 'space-around', 'space-between',
          'space-evenly'
        ]
      align_content_sm (enum):
        Deprecated, use **align-content-sm-\*** class

        Enum values: [
          'end', 'start', 'center', 'stretch', 'space-around', 'space-between',
          'space-evenly'
        ]
      align_content_md (enum):
        Deprecated, use **align-content-md-\*** class

        Enum values: [
          'end', 'start', 'center', 'stretch', 'space-around', 'space-between',
          'space-evenly'
        ]
      align_content_lg (enum):
        Deprecated, use **align-content-lg-\*** class

        Enum values: [
          'end', 'start', 'center', 'stretch', 'space-around', 'space-between',
          'space-evenly'
        ]
      align_content_xl (enum):
        Deprecated, use **align-content-xl-\*** class

        Enum values: [
          'end', 'start', 'center', 'stretch', 'space-around', 'space-between',
          'space-evenly'
        ]
      align_content_xxl (enum):
        Deprecated, use **align-content-xxl-\*** class

        Enum values: [
          'end', 'start', 'center', 'stretch', 'space-around', 'space-between',
          'space-evenly'
        ]
      no_gutters (boolean):
        Removes the gutter between `v-col`s (same as `gap='0'`).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VRow", children, **kwargs)
        self._attr_names += [
            "density",
            "tag",
            "align",
            "size",
            "gap",
            "dense",
            "justify",
            ("align_sm", "alignSm"),
            ("align_md", "alignMd"),
            ("align_lg", "alignLg"),
            ("align_xl", "alignXl"),
            ("align_xxl", "alignXxl"),
            ("justify_sm", "justifySm"),
            ("justify_md", "justifyMd"),
            ("justify_lg", "justifyLg"),
            ("justify_xl", "justifyXl"),
            ("justify_xxl", "justifyXxl"),
            ("align_content", "alignContent"),
            ("align_content_sm", "alignContentSm"),
            ("align_content_md", "alignContentMd"),
            ("align_content_lg", "alignContentLg"),
            ("align_content_xl", "alignContentXl"),
            ("align_content_xxl", "alignContentXxl"),
            ("no_gutters", "noGutters"),
        ]
        self._event_names += []


class VScaleTransition(HtmlElement):
    """
    Vuetify's VScaleTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-scale-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VScaleTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VScrollXReverseTransition(HtmlElement):
    """
    Vuetify's VScrollXReverseTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-scroll-x-reverse-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VScrollXReverseTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VScrollXTransition(HtmlElement):
    """
    Vuetify's VScrollXTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-scroll-x-transition>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VScrollXTransition", children, **kwargs)
        self._attr_names += [
            "disabled",
            "mode",
            "group",
            "origin",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VScrollYReverseTransition(HtmlElement):
    """
    Vuetify's VScrollYReverseTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-scroll-y-reverse-transition>`_.

    Args:
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      disabled (boolean):
        Removes the ability to click or target the component.
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VScrollYReverseTransition", children, **kwargs)
        self._attr_names += [
            "mode",
            "disabled",
            "origin",
            "group",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VScrollYTransition(HtmlElement):
    """
    Vuetify's VScrollYTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-scroll-y-transition>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VScrollYTransition", children, **kwargs)
        self._attr_names += [
            "disabled",
            "mode",
            "group",
            "origin",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VSelect(HtmlElement):
    """
    Vuetify's VSelect component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-select>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      search (string):
        Text input used to filter items.
      type (string):
        Sets input type.
      reverse (boolean):
        Reverses the orientation.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      form (string):
        The id of the `<form>` element to associate the hidden input
        used for native form submission with.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      menu (boolean):
        Renders with the menu open by default.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      placeholder (string):
        Sets the input’s placeholder text.
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      theme (string):
        Specify a theme for this component and all of its children.
      items (any[]):
        Can be an array of objects or strings. By default objects should
        have **title** and **value** properties, and can optionally have
        a **props** property containing any [VListItem props](/api/v-list-item/#props).
        Keys to use for these can be changed with the **item-title**,
        **item-value**, and **item-props** props.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function used to filter items, called for each filterable key
        on each item in the list. The first argument is the filterable
        value from the item, the second is the search term, and the third
        is the internal item object. The function should return true
        if the item should be included in the filtered list, or the index
        of the match in the value if it should be included with the result
        highlighted.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      chips (boolean):
        Changes display of selections to chips.
      closable_chips (boolean):
        Enables the [closable](/api/v-chip/#props-closable) prop on all
        [v-chip](/components/chips/) components.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      hide_selected (boolean):
        Do not display in the select menu items that are already selected.
      list_props (unknown):
        Pass props through to the `v-list` component. Accepts an object
        with anything from [v-list](/api/v-list/#props) props, camelCase
        keys are recommended.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width of the select's `v-menu` content.
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Set property of **items**'s value - **must be primitive**. Dot
        notation is supported. **Note:** This is currently not supported
        with `v-combobox` [GitHub Issue](https://github.com/vuetifyjs/vuetify/issues/5479).
      item_children (SelectItemKey):
        This property currently has **no effect**.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      item_type (SelectItemKey):
        Designates the key on the supplied items that is used for determining
        the nodes type.
      return_object (boolean):
        Changes the selection behavior to return the object directly
        rather than the value specified with **item-value**.
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      menu_elevation (string, number):
        Sets the elevation of the dropdown menu.
      menu_icon (enum):
        Sets the the spin icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      menu_props (unknown):
        Pass props through to the `v-menu` component. Accepts an object
        with anything from [v-menu](/api/v-menu/#props) props, camelCase
        keys are recommended.
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      open_on_focus (boolean):
        Open the menu when the input receives focus.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          { component: Component }
        ]
      no_data_text (string):
        Text shown when no items are provided to the component.
      open_on_clear (boolean):
        When using the **clearable** prop, once cleared, the select menu
        will either open or stay open, depending on the current state.
      item_color (string):
        Sets color of selected items.
      no_auto_scroll (boolean):
        Prevents the select menu to scroll to the selected item automatically.
      close_text (string):
        Text set to the inputs `aria-label` and `title` when input menu is closed.
      open_text (string):
        Text set to the inputs **aria-label** and **title** when input menu is open.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      update_search (event):
        Event emitted when the search value changes.
      update_menu (event):
        Event that is emitted when the component's menu state changes.
      item_added (event):
        Emitted when an item is added to the model.
      item_removed (event):
        Emitted when an item is removed from the model.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSelect", children, **kwargs)
        self.ttsSensitive()
        self._attr_names += [
            "flat",
            "search",
            "type",
            "reverse",
            "name",
            "error",
            "form",
            "label",
            "menu",
            "autocomplete",
            "disabled",
            "multiple",
            "placeholder",
            "width",
            "id",
            "prefix",
            "role",
            "autofocus",
            "theme",
            "items",
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            "chips",
            ("closable_chips", "closableChips"),
            "eager",
            ("hide_no_data", "hideNoData"),
            ("hide_selected", "hideSelected"),
            ("list_props", "listProps"),
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("item_children", "itemChildren"),
            ("item_props", "itemProps"),
            ("item_type", "itemType"),
            ("return_object", "returnObject"),
            ("value_comparator", "valueComparator"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("menu_elevation", "menuElevation"),
            ("menu_icon", "menuIcon"),
            ("menu_props", "menuProps"),
            ("model_value", "modelValue"),
            ("open_on_focus", "openOnFocus"),
            "transition",
            ("no_data_text", "noDataText"),
            ("open_on_clear", "openOnClear"),
            ("item_color", "itemColor"),
            ("no_auto_scroll", "noAutoScroll"),
            ("close_text", "closeText"),
            ("open_text", "openText"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            "focused",
            ("hide_details", "hideDetails"),
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("update_search", "update:search"),
            ("update_menu", "update:menu"),
            ("item_added", "item:added"),
            ("item_removed", "item:removed"),
        ]


class VSelectionControl(HtmlElement):
    """
    Vuetify's VSelectionControl component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-selection-control>`_.

    Args:
      type (string):
        Provides the default type for children selection controls.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      indeterminate (boolean):
        Styles the control as an intermediate 'partially selected' state.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      inline (boolean):
        Puts children inputs into a row.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      true_value (any):
        Sets value for truthy state.
      false_value (any):
        Sets value for falsy state.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        The icon used when the control is in the indeterminate state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSelectionControl", children, **kwargs)
        self._attr_names += [
            "type",
            ("model_value", "modelValue"),
            "error",
            "density",
            "theme",
            "color",
            "name",
            "disabled",
            "indeterminate",
            "multiple",
            "value",
            "id",
            ("base_color", "baseColor"),
            "readonly",
            "ripple",
            "inline",
            "label",
            ("true_value", "trueValue"),
            ("false_value", "falseValue"),
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VSelectionControlGroup(HtmlElement):
    """
    Vuetify's VSelectionControlGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-selection-control-group>`_.

    Args:
      type (string):
        Provides the default type for children selection controls.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      multiple (boolean):
        Changes select to multiple. Accepts array for value.
      id (string):
        Sets the DOM id on the component.
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      inline (boolean):
        Puts children inputs into a row.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/SelectionControlGroup.json))

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSelectionControlGroup", children, **kwargs)
        self._attr_names += [
            "type",
            ("model_value", "modelValue"),
            "error",
            "density",
            "theme",
            "color",
            "name",
            "disabled",
            "multiple",
            "id",
            "readonly",
            "ripple",
            "inline",
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VSheet(HtmlElement):
    """
    Vuetify's VSheet component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-sheet>`_.

    Args:
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSheet", children, **kwargs)
        self._attr_names += [
            "border",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
        ]
        self._event_names += []


class VSkeletonLoader(HtmlElement):
    """
    Vuetify's VSkeletonLoader component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-skeleton-loader>`_.

    Args:
      type (enum):
        A string delimited list of skeleton components to create such
        as `type="text@3"` or `type="card, list-item"`. Will recursively
        generate a corresponding skeleton from the provided string. Also
        supports short-hand for multiple elements such as **article@3**
        and **paragraph@2** which will generate 3 _article_ skeletons
        and 2 _paragraph_ skeletons. Please see below for a list of available
        pre-defined options.

        Enum values: [
          'text', (string & {}), 'image', 'button', 'actions', 'avatar',
          'article', 'table', 'divider', 'subtitle', 'table-cell', 'table-row',
          'list-item', 'chip', 'heading', 'sentences', 'paragraph', 'ossein',
          'card', 'card-avatar', 'chip-group', 'date-picker', 'date-picker-options',
          'date-picker-days', 'list-item-avatar', 'list-item-two-line',
          'list-item-avatar-two-line', 'list-item-three-line', 'list-item-avatar-three-line',
          'table-heading', 'table-thead', 'table-tbody', 'table-row-divider',
          'table-tfoot', (, 'text', (string & {}), 'image', 'button', 'actions',
          'avatar', 'article', 'table', 'divider', 'subtitle', 'table-cell',
          'table-row', 'list-item', 'chip', 'heading', 'sentences', 'paragraph',
          'ossein', 'card', 'card-avatar', 'chip-group', 'date-picker',
          'date-picker-options', 'date-picker-days', 'list-item-avatar',
          'list-item-two-line', 'list-item-avatar-two-line', 'list-item-three-line',
          'list-item-avatar-three-line', 'table-heading', 'table-thead',
          'table-tbody', 'table-row-divider', 'table-tfoot'    )[]
        ]
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      loading (boolean):
        Applies a loading animation with a on-hover loading cursor. A
        value of **false** will only work when there is content in the
        `default` slot.
      boilerplate (boolean):
        Remove the loading animation from the skeleton.
      loading_text (string):
        aria-label for the element in a loading state.
      types (unknown):
        A custom types object that will be combined with the pre-defined
        options (e.g. `{ product: 'image, heading, actions' }`). You
        can reuse a built-in name to replace the definition.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSkeletonLoader", children, **kwargs)
        self._attr_names += [
            "type",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "theme",
            "color",
            "loading",
            "boilerplate",
            ("loading_text", "loadingText"),
            "types",
        ]
        self._event_names += []


class VSlideGroup(HtmlElement):
    """
    Vuetify's VSlideGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slide-group>`_.

    Args:
      symbol (any):
        The [Symbol](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)
        used to hook into group functionality for components like [v-btn-toggle](/components/btn-toggle)
        and [v-bottom-navigation](/components/bottom-navigations/).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Sets the designated mobile breakpoint for the component.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      content_class (any):
        Adds classes to the slide group item.
      direction ('vertical', 'horizontal'):
        Switch between horizontal and vertical modes.
      next_icon (enum):
        The appended slot when arrows are shown.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prev_icon (enum):
        The prepended slot when arrows are shown.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      show_arrows (string, boolean):
        Change when the overflow arrow indicators are shown. By **default**,
        arrows *always* display on Desktop when the container is overflowing.
        When the container overflows on mobile, arrows are not shown
        by default. A **show-arrows** value of `true` allows these arrows
        to show on Mobile if the container overflowing. A value of `desktop`
        *always* displays arrows on Desktop while a value of `mobile`
        always displays arrows on Mobile. A value of `always` always
        displays arrows on Desktop *and* Mobile. Use **never** to turn
        arrows off. Find more information on how to customize breakpoint
        thresholds on the [breakpoints page](/customizing/breakpoints).
      center_active (boolean):
        Forces the selected component to be centered.
      scroll_distance (string, number):
        How far the arrows scroll, in pixels or as a percentage of the
        area within container
      scroll_snap ('end', 'start', 'center'):
        Snap items while scrolling or using the arrows.
      scroll_to_active (boolean):
        Keeps the last active element visible when resizing the scrollable container.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      edge (event):
        Emitted when scrolling reaches the start or the end of the group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlideGroup", children, **kwargs)
        self._attr_names += [
            "symbol",
            ("model_value", "modelValue"),
            "tag",
            "disabled",
            "max",
            "multiple",
            ("selected_class", "selectedClass"),
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "mandatory",
            ("content_class", "contentClass"),
            "direction",
            ("next_icon", "nextIcon"),
            ("prev_icon", "prevIcon"),
            ("show_arrows", "showArrows"),
            ("center_active", "centerActive"),
            ("scroll_distance", "scrollDistance"),
            ("scroll_snap", "scrollSnap"),
            ("scroll_to_active", "scrollToActive"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "edge",
        ]


class VSlideGroupItem(HtmlElement):
    """
    Vuetify's VSlideGroupItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slide-group-item>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlideGroupItem", children, **kwargs)
        self._attr_names += [
            "disabled",
            "value",
            ("selected_class", "selectedClass"),
        ]
        self._event_names += [
            ("group_selected", "group:selected"),
        ]


class VSlideXReverseTransition(HtmlElement):
    """
    Vuetify's VSlideXReverseTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slide-x-reverse-transition>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlideXReverseTransition", children, **kwargs)
        self._attr_names += [
            "disabled",
            "mode",
            "group",
            "origin",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VSlideXTransition(HtmlElement):
    """
    Vuetify's VSlideXTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slide-x-transition>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlideXTransition", children, **kwargs)
        self._attr_names += [
            "disabled",
            "mode",
            "group",
            "origin",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VSlideYReverseTransition(HtmlElement):
    """
    Vuetify's VSlideYReverseTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slide-y-reverse-transition>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlideYReverseTransition", children, **kwargs)
        self._attr_names += [
            "disabled",
            "mode",
            "group",
            "origin",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VSlideYTransition(HtmlElement):
    """
    Vuetify's VSlideYTransition component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slide-y-transition>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      mode (string):
        Sets the transition mode (does not apply to transition-group).
        You can find more information on the Vue documentation [for transition
        modes](https://vuejs.org/api/built-in-components.html#transition).
      group (boolean):
        Creates a `transition-group` component. You can find more information
        in the [vue docs](https://vuejs.org/api/built-in-components.html#transitiongroup).
      origin (string):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      hide_on_leave (boolean):
        Hides the leaving element (no exit animation).
      leave_absolute (boolean):
        Absolutely positions the leaving element (useful for [FLIP](https://aerotwist.com/blog/flip-your-animations/)).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlideYTransition", children, **kwargs)
        self._attr_names += [
            "disabled",
            "mode",
            "group",
            "origin",
            ("hide_on_leave", "hideOnLeave"),
            ("leave_absolute", "leaveAbsolute"),
        ]
        self._event_names += []


class VSlider(HtmlElement):
    """
    Vuetify's VSlider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-slider>`_.

    Args:
      model_value (string, number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      reverse (boolean):
        Reverses the slider direction.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      max (string, number):
        Sets the maximum allowed value.
      min (string, number):
        Sets the minimum allowed value.
      step (string, number):
        If greater than 0, sets step interval for ticks.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean):
        Applies the [v-ripple](/directives/ripple) directive.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      direction ('vertical', 'horizontal'):
        Changes the direction of the input.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the input is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      thumb_color (string):
        Sets the thumb and thumb label color.
      thumb_label (boolean, 'hover', 'always'):
        Show thumb label. If `true` it shows label when using slider.
        If set to `'always'` it always shows label. Use `'hover'` to
        show label when hovering over the thumb.
      thumb_size (string, number):
        Controls the size of the thumb label.
      show_ticks (boolean, 'always'):
        Show track ticks. If `true` it shows ticks when using slider.
        If set to `'always'` it always shows ticks.
      ticks (number[], Record<number, string>):
        Show track ticks. If `true` it shows ticks when using slider.
        If set to `'always'` it always shows ticks.
      tick_size (string, number):
        Controls the size of **ticks**
      track_color (string):
        Sets the track's color
      track_fill_color (string):
        Sets the track's fill color
      track_size (string, number):
        Sets the track's size (height).
      no_keyboard (boolean):
        **FOR INTERNAL USE ONLY** Ignore keyboard events.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
      end (event):
        Slider value emitted at the end of slider movement.
      start (event):
        Slider value emitted at start of slider movement.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSlider", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "error",
            "reverse",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "theme",
            "color",
            "name",
            "disabled",
            "max",
            "min",
            "step",
            "id",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "ripple",
            "label",
            "direction",
            "messages",
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("thumb_color", "thumbColor"),
            ("thumb_label", "thumbLabel"),
            ("thumb_size", "thumbSize"),
            ("show_ticks", "showTicks"),
            "ticks",
            ("tick_size", "tickSize"),
            ("track_color", "trackColor"),
            ("track_fill_color", "trackFillColor"),
            ("track_size", "trackSize"),
            ("no_keyboard", "noKeyboard"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            "end",
            "start",
        ]


class VSnackbar(HtmlElement):
    """
    Vuetify's VSnackbar component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-snackbar>`_.

    Args:
      title (string):
        Specify a title text for the component.
      text (string):
        Specify content text for the component.
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      absolute (boolean):
        Applies **position: absolute** to the content element.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      prepend_icon (enum):
        Displays an icon in the prepend area.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      loading (boolean):
        Displays a loading spinner in the prepend area.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition. Supports special location-aware mode with
        **slide-auto** and **scroll-auto**

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      vertical (boolean):
        Stacks snackbar content on top of the actions (button).
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      z_index (string, number):
        The z-index used for the component.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Activate the component when the activator is clicked.
      open_on_hover (boolean):
        Activate the component when the activator is hovered.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      prepend_avatar (string):
        Displays an avatar in the prepend area using the provided image source.
      queue_gap (number):
        Sets the offset to show collapsed snackbars as a stack. Requires
        value in pixels.
      queue_index (number):
        The index position of this snackbar within a queue.
      reverse_timer (boolean):
        Reverses the direction of the timer progress bar, filling up
        instead of depleting.
      timer (boolean, 'top', 'bottom'):
        Display a progress bar that counts down until the snackbar closes.
        Use `bottom` to change the default placement.
      timer_color (string):
        Sets the color of the timer progress bar.
      timeout (string, number):
        Time (in milliseconds) to wait until snackbar is automatically
        hidden. Use `-1` to keep open indefinitely. It is recommended
        for this number to be between `4000` and `10000`. Changes to
        this property will reset the countdown.
      collapsed ({ width: number; height: number }):
        Alters the element size fit behind front snackbar in the queue.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSnackbar", children, **kwargs)
        self._attr_names += [
            "title",
            "text",
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "location",
            "position",
            "absolute",
            "rounded",
            "tile",
            "theme",
            "color",
            "variant",
            "disabled",
            ("prepend_icon", "prependIcon"),
            "loading",
            "transition",
            "vertical",
            "activator",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("z_index", "zIndex"),
            "target",
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            "eager",
            ("location_strategy", "locationStrategy"),
            "origin",
            "attach",
            ("prepend_avatar", "prependAvatar"),
            ("queue_gap", "queueGap"),
            ("queue_index", "queueIndex"),
            ("reverse_timer", "reverseTimer"),
            "timer",
            ("timer_color", "timerColor"),
            "timeout",
            "collapsed",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VSnackbarQueue(HtmlElement):
    """
    Vuetify's VSnackbarQueue component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-snackbar-queue>`_.

    Args:
      title (string):
        Specify a title text for the component.
      text (string):
        Specify content text for the component.
      closable (string, boolean):
        Adds a dismiss button that closes the active snackbar.
      model_value (Anchor):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      absolute (boolean):
        Applies **position: absolute** to the content element.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      prepend_icon (enum):
        Displays an icon in the prepend area.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      loading (boolean):
        Displays a loading spinner in the prepend area.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition. Supports special location-aware mode with
        **slide-auto** and **scroll-auto**

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      gap (string, number):
        Sets the gap between stacked snackbars. Requires value in pixels.
      vertical (boolean):
        Stacks snackbar content on top of the actions (button).
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      z_index (string, number):
        The z-index used for the component.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Activate the component when the activator is clicked.
      open_on_hover (boolean):
        Activate the component when the activator is hovered.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only applies to
        hover and focus events.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only applies to
        hover and focus events.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      prepend_avatar (string):
        Displays an avatar in the prepend area using the provided image source.
      close_text (string):
        The text used in the close button when using the **closable** prop.
      reverse_timer (boolean):
        Reverses the direction of the timer progress bar, filling up
        instead of depleting.
      timer (boolean, 'top', 'bottom'):
        Display a progress bar that counts down until the snackbar closes.
        Use `bottom` to change the default placement.
      timer_color (string):
        Sets the color of the timer progress bar.
      timeout (string, number):
        Time (in milliseconds) to wait until snackbar is automatically
        hidden. Use `-1` to keep open indefinitely. It is recommended
        for this number to be between `4000` and `10000`. Changes to
        this property will reset the countdown.
      collapsed (boolean):
        Puts the visible snackbars behind each other (expands on hover).
      display_strategy ('overflow', 'hold'):
        Determines how new snackbars are handled when the queue is full.
        **hold** (default) keeps new messages queued until a slot opens.
        **overflow** dismisses the oldest snackbar to make room for the
        new one.
      total_visible (string, number):
        Specify the total visible snackbars.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSnackbarQueue", children, **kwargs)
        self._attr_names += [
            "title",
            "text",
            "closable",
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "location",
            "position",
            "absolute",
            "rounded",
            "tile",
            "theme",
            "color",
            "variant",
            "disabled",
            ("prepend_icon", "prependIcon"),
            "loading",
            "transition",
            "gap",
            "vertical",
            "activator",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("z_index", "zIndex"),
            "target",
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            "eager",
            ("location_strategy", "locationStrategy"),
            "origin",
            "attach",
            ("prepend_avatar", "prependAvatar"),
            ("close_text", "closeText"),
            ("reverse_timer", "reverseTimer"),
            "timer",
            ("timer_color", "timerColor"),
            "timeout",
            "collapsed",
            ("display_strategy", "displayStrategy"),
            ("total_visible", "totalVisible"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VSpacer(HtmlElement):
    """
    Vuetify's VSpacer component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-spacer>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSpacer", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VSparkline(HtmlElement):
    """
    Vuetify's VSparkline component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-sparkline>`_.

    Args:
      type ('bar', 'trend'):
        Choose between a trendline or bars.
      model_value ((number, { value: number })[]):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      fill (boolean):
        Using the **fill** property allows you to better customize the
        look and feel of your sparkline.
      height (string, number):
        Height of the SVG container.
      width (string, number):
        Width of the SVG container.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      labels ((string, (number, { value: number }))[]):
        An array of string labels that correspond to the same index as
        its data counterpart.
      max (string, number):
        The maximum value of the sparkline.
      min (string, number):
        The minimum value of the sparkline.
      id (string):
        The id of the component.
      inset (boolean):
        Extends the line beyond the chart boundary so it runs edge-to-edge.
      gradient (string[]):
        An array of colors to use as a linear-gradient.
      smooth (string, number, boolean):
        Controls the curve tension. `true` defaults to 8, `false` or
        `0` gives straight lines. Higher values produce smoother curves.
      tooltip (boolean, js_fn, true    }):
        Displays a tooltip on the active data point. Requires **interactive**.
        Can be `true` or an object with `titleFormat`, `offset`, and
        `showCrosshair` options.
      padding (string, number):
        Low `smooth` or high `line-width` values may result in cropping,
        increase padding to compensate.
      item_value (string):
        The value of the item.
      animation (boolean, { duration: number; easing: string }):
        Enables smooth transitions when values change. When `true`, uses
        default duration (300ms) and easing (`ease`). Can be an object
        with `duration` (ms) and `easing` (CSS easing) properties.
      interactive (boolean):
        Enables hover tracking, keyboard navigation (arrow keys), and
        focus support. Required for **tooltip** to work.
      auto_line_width (boolean):
        Automatically expand bars to use space efficiently.
      auto_draw (boolean, 'once'):
        Trace the length of the line when first rendered. Since 4.1.0
        it accepts `'once'`, to make the animation play only on mount
        and make the subsequent value changes interpolate smoothly.
      auto_draw_duration (string, number):
        Amount of time (in ms) to run the trace animation.
      auto_draw_easing (string):
        The easing function to use for the trace animation.
      gradient_direction ('top', 'bottom', 'left', 'right'):
        The direction the gradient should run.
      label_size (string, number):
        The label font size.
      line_width (string, number):
        The thickness of the line, in px.
      marker_size (string, number):
        The diameter of marker circles, in px.
      marker_stroke (string):
        The stroke (border) color applied to marker circles.
      show_labels (boolean):
        Show labels below each data point.
      show_markers (boolean):
        Show circle markers at each data point.
      smooth_mode ('default', 'monotone'):
        The interpolation algorithm to use. `default` uses corner-rounding
        which can cause the line to appear away from actual values. `monotone`
        makes the line stick to exact data points. In `monotone` mode,
        **smooth** is limited to 8.
      update_currentIndex (event):
        Emitted when the active data point changes via mouse hover, keyboard
        navigation, or focus. The payload is the point index, or `null`
        when no point is active.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSparkline", children, **kwargs)
        self._attr_names += [
            "type",
            ("model_value", "modelValue"),
            "fill",
            "height",
            "width",
            "color",
            "labels",
            "max",
            "min",
            "id",
            "inset",
            "gradient",
            "smooth",
            "tooltip",
            "padding",
            ("item_value", "itemValue"),
            "animation",
            "interactive",
            ("auto_line_width", "autoLineWidth"),
            ("auto_draw", "autoDraw"),
            ("auto_draw_duration", "autoDrawDuration"),
            ("auto_draw_easing", "autoDrawEasing"),
            ("gradient_direction", "gradientDirection"),
            ("label_size", "labelSize"),
            ("line_width", "lineWidth"),
            ("marker_size", "markerSize"),
            ("marker_stroke", "markerStroke"),
            ("show_labels", "showLabels"),
            ("show_markers", "showMarkers"),
            ("smooth_mode", "smoothMode"),
        ]
        self._event_names += [
            ("update_currentIndex", "update:currentIndex"),
        ]


class VSparklineTooltip(HtmlElement):
    """
    Vuetify's VSparklineTooltip component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-sparkline-tooltip>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      location (Anchor):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VSparklineTooltip.json))
      value (number):
        Value of the active data point. Forwarded to **title-format**
        and the default slot.
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      target ([number, number]):
        The coordinates used to position the tooltip.
      offset (number):
        Distance in pixels between the tooltip and the target point.
      index (number):
        Index of the active data point. Pass `null` to hide the tooltip content.
      title_format ((item: { index: number; value: number }) => string):
        Function used to format the tooltip body when no slot is provided.
        Receives `{ index, value }`.
      afterLeave (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VSparklineTooltip.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSparklineTooltip", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "location",
            "value",
            ("content_class", "contentClass"),
            "target",
            "offset",
            "index",
            ("title_format", "titleFormat"),
        ]
        self._event_names += [
            "afterLeave",
        ]


class VSpeedDial(HtmlElement):
    """
    Vuetify's VSpeedDial component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-speed-dial>`_.

    Args:
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      theme (string):
        Specify a theme for this component and all of its children.
      disabled (boolean):
        Removes the ability to click or target the component.
      id (string):
        The unique identifier of the component.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component }),
          {      component: ComponentPublicInstanceConstructor<
          CreateComponentPublicInstanceWithMixins<          {} & { target?:
          HTMLElement, [x: number, y: number], undefined } & {
             $children?:, VNodeChild, { $stable?: boolean, undefined },
          js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn, [x: number, y: number], undefined } & {
                     $children?:, VNodeChild, { $stable?: boolean, undefined
          }, js_fn, js_fn, undefined }            'v-slots'?:, { default?:
          false, js_fn, undefined }, undefined          } & { 'v-slot:default'?:
          false, js_fn, js_fn
        ]
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of the content
        element when using the persistent prop.
      persistent (boolean):
        Clicking outside of the element or pressing esc key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Designates whether menu should open on activator click.
      open_on_hover (boolean):
        Opens speed-dial on hover.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Designates if menu should close when its content is clicked.
      close_delay (string, number):
        Milliseconds to wait before closing component. Only works with
        the **open-on-hover** prop.
      open_delay (string, number):
        Milliseconds to wait before opening component. Only works with
        the **open-on-hover** prop.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      retain_focus (boolean):
        Captures and keeps focus within the content element when using
        **Tab** and **Shift**+**Tab**. Recommended to be `false` when
        using external tools that require focus such as TinyMCE or vue-clipboard.
      capture_focus (boolean):
        When enabled, focus will be trapped within the component's content,
        preventing Tab navigation from moving focus outside. Useful for
        modals, dialogs, and overlays to maintain accessibility.
      disable_initial_focus (boolean):
        Deprecated, use `capture-focus` instead. Prevents automatic redirect
        of first `focusin` event. Intended to use on permanently open
        menus or VSpeedDial.
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      submenu (boolean):
        Opens with right arrow and closes on left instead of up/down.
        Implies `location="end"`. Directions are reversed for RTL.
      open_on_arrow (boolean):
        Using keyboard arrows up/down on the activator should open the
        menu and move focus into its content. Disable to handle arrow
        keys in the activator itself, e.g. when the menu holds a virtualized
        list.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSpeedDial", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "location",
            "theme",
            "disabled",
            "id",
            "transition",
            "activator",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            "target",
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            "eager",
            ("location_strategy", "locationStrategy"),
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            ("retain_focus", "retainFocus"),
            ("capture_focus", "captureFocus"),
            ("disable_initial_focus", "disableInitialFocus"),
            "attach",
            "submenu",
            ("open_on_arrow", "openOnArrow"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VStepper(HtmlElement):
    """
    Vuetify's VStepper component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper>`_.

    Args:
      flat (boolean):
        Removes the stepper's elevation.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      items ((string, Record<string, any>)[]):
        An array of strings or objects used for automatically generating
        children components.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mobile (boolean):
        Forces the stepper into a mobile state, removing labels from stepper items.
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      hide_actions (boolean):
        Hide actions bar (prev and next buttons).
      alt_labels (boolean):
        Places the labels beneath the step.
      complete_icon (enum):
        Icon to display when step is marked as completed.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      edit_icon (enum):
        Icon to display when step is editable.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      editable (boolean):
        Marks step as editable.
      error_icon (enum):
        Icon to display when step has an error.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      non_linear (boolean):
        Allow user to jump to any step.
      prev_text (string):
        The text used for the Prev button.
      next_text (string):
        The text used for the Next button.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepper", children, **kwargs)
        self._attr_names += [
            "flat",
            "border",
            ("model_value", "modelValue"),
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "disabled",
            "max",
            "multiple",
            ("selected_class", "selectedClass"),
            "items",
            ("item_props", "itemProps"),
            ("bg_color", "bgColor"),
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "mandatory",
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("hide_actions", "hideActions"),
            ("alt_labels", "altLabels"),
            ("complete_icon", "completeIcon"),
            ("edit_icon", "editIcon"),
            "editable",
            ("error_icon", "errorIcon"),
            ("non_linear", "nonLinear"),
            ("prev_text", "prevText"),
            ("next_text", "nextText"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VStepperActions(HtmlElement):
    """
    Vuetify's VStepperActions component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-actions>`_.

    Args:
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean, 'prev', 'next'):
        Removes the ability to click or target the component.
      prev_text (string):
        The text used for the Prev button.
      next_text (string):
        The text used for the Next button.
      click_prev (event):
        Event emitted when clicking the prev button.
      click_next (event):
        Event emitted when clicking the next button.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperActions", children, **kwargs)
        self._attr_names += [
            "color",
            "disabled",
            ("prev_text", "prevText"),
            ("next_text", "nextText"),
        ]
        self._event_names += [
            ("click_prev", "click:prev"),
            ("click_next", "click:next"),
        ]


class VStepperHeader(HtmlElement):
    """
    Vuetify's VStepperHeader component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-header>`_.

    Args:
      tag (string):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperHeader", children, **kwargs)
        self._attr_names += [
            "tag",
        ]
        self._event_names += []


class VStepperItem(HtmlElement):
    """
    Vuetify's VStepperItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-item>`_.

    Args:
      title (string):
        Specify a title text for the component.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      error (boolean):
        Puts the stepper item in a manual error state.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      subtitle (string):
        Specify a subtitle text for the component.
      rules (ValidationRule):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.
      complete_icon (enum):
        Icon to display when step is marked as completed.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      edit_icon (enum):
        Icon to display when step is editable.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      editable (boolean):
        Marks step as editable.
      error_icon (enum):
        Icon to display when step has an error.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      complete (boolean):
        Marks step as complete.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperItem", children, **kwargs)
        self._attr_names += [
            "title",
            "icon",
            "error",
            "color",
            "disabled",
            "value",
            "ripple",
            ("selected_class", "selectedClass"),
            "subtitle",
            "rules",
            ("complete_icon", "completeIcon"),
            ("edit_icon", "editIcon"),
            "editable",
            ("error_icon", "errorIcon"),
            "complete",
        ]
        self._event_names += [
            ("group_selected", "group:selected"),
        ]


class VStepperVertical(HtmlElement):
    """
    Vuetify's VStepperVertical component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-vertical>`_.

    Args:
      flat (boolean):
        Removes the expansion-panel's elevation and borders.
      model_value (unknown):
        Controls expanded panel(s). Defaults to an empty array when using
        **multiple** prop. It is recommended to set unique `value` prop
        for the panels inside, otherwise index is used instead.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      rounded (string, number, boolean, (string, number)[]):
        Applies a border radius to the first and last panel. Since v4.1.0
        accepts array of two values to customize inner radius.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('default', 'inset', 'accordion', 'popout'):
        Applies a distinct style to the component.
      disabled (boolean):
        Puts all children components into a disabled state.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      readonly (boolean):
        Makes the entire expansion panel read only.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      gap (string, number):
        Sets the gap between panels. Hides the divider automatically.
      items ((string, Record<string, any>)[]):
        An array of strings or objects used for automatically generating
        children components.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mobile (boolean):
        Forces the stepper into a mobile state, removing labels from stepper items.
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Overrides the display configuration default screen size that
        the component should be considered in mobile.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      hover (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VExpansionPanelTitle.json))
      expand_icon (enum):
        Icon used when the expansion panel is in a expandable state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      collapse_icon (enum):
        Icon used when the expansion panel is in a collapsable state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      hide_actions (boolean):
        Hide the expand icon in the content title.
      alt_labels (boolean):
        Places the labels beneath the step.
      complete_icon (enum):
        Icon to display when step is marked as completed.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      edit_icon (enum):
        Icon to display when step is editable.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      editable (boolean):
        Marks step as editable.
      error_icon (enum):
        Icon to display when step has an error.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      non_linear (boolean):
        Allow user to jump to any step.
      prev_text (string):
        The text used for the Prev button.
      next_text (string):
        The text used for the Next button.
      no_divider (boolean):
        Hides the dividers between adjacent panels.
      focusable (boolean):
        Makes the expansion-panel headers focusable.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperVertical", children, **kwargs)
        self._attr_names += [
            "flat",
            ("model_value", "modelValue"),
            "elevation",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "max",
            "multiple",
            "readonly",
            "ripple",
            ("selected_class", "selectedClass"),
            "gap",
            "items",
            ("item_props", "itemProps"),
            ("bg_color", "bgColor"),
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            "mandatory",
            "eager",
            "hover",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("hide_actions", "hideActions"),
            ("alt_labels", "altLabels"),
            ("complete_icon", "completeIcon"),
            ("edit_icon", "editIcon"),
            "editable",
            ("error_icon", "errorIcon"),
            ("non_linear", "nonLinear"),
            ("prev_text", "prevText"),
            ("next_text", "nextText"),
            ("no_divider", "noDivider"),
            "focusable",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VStepperVerticalActions(HtmlElement):
    """
    Vuetify's VStepperVerticalActions component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-vertical-actions>`_.

    Args:
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean, 'prev', 'next'):
        Removes the ability to click or target the component.
      prev_text (string):
        The text used for the Prev button.
      next_text (string):
        The text used for the Next button.
      click_prev (event):
        Event emitted when clicking the prev button.
      click_next (event):
        Event emitted when clicking the next button.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperVerticalActions", children, **kwargs)
        self._attr_names += [
            "color",
            "disabled",
            ("prev_text", "prevText"),
            ("next_text", "nextText"),
        ]
        self._event_names += [
            ("click_prev", "click:prev"),
            ("click_next", "click:next"),
        ]


class VStepperVerticalItem(HtmlElement):
    """
    Vuetify's VStepperVerticalItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-vertical-item>`_.

    Args:
      title (string):
        Specify a title text for the component.
      text (string):
        Specify content text for the component.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      error (boolean):
        Puts the stepper item in a manual error state.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      static (boolean):
        Remove title size expansion when selected.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Disables the expansion-panel content.
      value (any):
        Controls the opened/closed state of content.
      readonly (boolean):
        Makes the expansion panel content read only.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      subtitle (string):
        Specify a subtitle text for the component.
      hover (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VExpansionPanelTitle.json))
      rules (ValidationRule):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.
      expand_icon (enum):
        Icon used when the expansion panel is in a expandable state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      collapse_icon (enum):
        Icon used when the expansion panel is in a collapsable state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      hide_actions (boolean):
        Hide the expand icon in the content title.
      complete_icon (enum):
        Icon to display when step is marked as completed.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      edit_icon (enum):
        Icon to display when step is editable.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      editable (boolean):
        Marks step as editable.
      error_icon (enum):
        Icon to display when step has an error.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      complete (boolean):
        Marks step as complete.
      focusable (boolean):
        Makes the expansion panel content focusable.
      click_prev (event):
        Event emitted when clicking the previous button
      click_next (event):
        Event emitted when clicking the next button
      click_finish (event):
        Event emitted when clicking the finish button
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperVerticalItem", children, **kwargs)
        self._attr_names += [
            "title",
            "text",
            "icon",
            "error",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "static",
            "rounded",
            "tile",
            "tag",
            "color",
            "disabled",
            "value",
            "readonly",
            "ripple",
            ("selected_class", "selectedClass"),
            ("bg_color", "bgColor"),
            "eager",
            "subtitle",
            "hover",
            "rules",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("hide_actions", "hideActions"),
            ("complete_icon", "completeIcon"),
            ("edit_icon", "editIcon"),
            "editable",
            ("error_icon", "errorIcon"),
            "complete",
            "focusable",
        ]
        self._event_names += [
            ("click_prev", "click:prev"),
            ("click_next", "click:next"),
            ("click_finish", "click:finish"),
        ]


class VStepperWindow(HtmlElement):
    """
    Vuetify's VStepperWindow component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-window>`_.

    Args:
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      reverse (boolean):
        Reverse the normal transition direction.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      disabled (boolean):
        Removes the ability to click or target the component.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      direction ('vertical', 'horizontal'):
        The transition direction when changing windows.
      crossfade (boolean):
        Enables crossfade transition.
      transition_duration (number):
        Overrides transition duration. Does not work in firefox, safari
        <18, or with `prefers-reduced-motion: reduce`.
      vertical_arrows (boolean, 'left', 'right'):
        Displays the navigation arrows vertically instead of horizontally.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperWindow", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "reverse",
            "tag",
            "theme",
            "disabled",
            ("selected_class", "selectedClass"),
            "direction",
            "crossfade",
            ("transition_duration", "transitionDuration"),
            ("vertical_arrows", "verticalArrows"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VStepperWindowItem(HtmlElement):
    """
    Vuetify's VStepperWindowItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-stepper-window-item>`_.

    Args:
      disabled (boolean):
        Prevents the item from becoming active when using the "next"
        and "prev" buttons or the `toggle` method.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      transition (string, boolean):
        The transition used when the component progressing through items.
        Can be one of the [built in](/styles/transitions/) or custom
        transition.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      reverse_transition (string, boolean):
        Sets the reverse transition.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VStepperWindowItem", children, **kwargs)
        self._attr_names += [
            "disabled",
            "value",
            ("selected_class", "selectedClass"),
            "transition",
            "eager",
            ("reverse_transition", "reverseTransition"),
        ]
        self._event_names += []


class VSvgIcon(HtmlElement):
    """
    Vuetify's VSvgIcon component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-svg-icon>`_.

    Args:
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/) component.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSvgIcon", children, **kwargs)
        self._attr_names += [
            "icon",
            "tag",
        ]
        self._event_names += []


class VSwitch(HtmlElement):
    """
    Vuetify's VSwitch component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-switch>`_.

    Args:
      flat (boolean):
        Display component without elevation. Default elevation for thumb
        is 4dp, `flat` resets it.
      type (string):
        Provides the default type for children selection controls.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      indeterminate (boolean):
        Sets an indeterminate state for the switch.
      multiple (boolean):
        Changes expected model to an array.
      size (string, number):
        Scales the track and thumb. Accepts the predefined sizes **x-small**,
        **small**, **default**, **large**, and **x-large**, or a numeric
        value for a custom scale.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      id (string):
        Sets the DOM id on the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      loading (string, boolean):
        Displays circular progress bar. Can either be a String which
        specifies which color is applied to the progress bar (any material
        color or theme color - primary, secondary, success, info, warning,
        error) or a Boolean which uses the component color (set by color
        prop - if it's supported by the component) or the primary color.
      inline (boolean):
        Puts children inputs into a row.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      inset (boolean, 'tonal', 'square', 'material'):
        Controls the track and thumb styling - **tonal** (or `true`)
        enlarges the track to encompass the thumb - **material** applies
        the Material Design 3 treatment: an outlined track that fills
        when on and a thumb that morphs between states - **square** is
        the **material** variant with less round corners.  Non-boolean
        values were introduced in v4.1.0.
      direction ('vertical', 'horizontal'):
        Changes the direction of the input.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      true_value (any):
        Sets value for truthy state.
      false_value (any):
        Sets value for falsy state.
      defaults_target (string):
        The target component to provide defaults values for.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        The icon used when the control is in the indeterminate state.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      thumb_color (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VSwitch.json))
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
      update_indeterminate (event):
        Event that is emitted when the component's indeterminate state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSwitch", children, **kwargs)
        self._attr_names += [
            "flat",
            "type",
            ("model_value", "modelValue"),
            "error",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "theme",
            "color",
            "name",
            "disabled",
            "indeterminate",
            "multiple",
            "size",
            "value",
            "id",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "ripple",
            "loading",
            "inline",
            "label",
            "inset",
            "direction",
            "messages",
            ("center_affix", "centerAffix"),
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("true_value", "trueValue"),
            ("false_value", "falseValue"),
            ("defaults_target", "defaultsTarget"),
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
            ("thumb_color", "thumbColor"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("update_indeterminate", "update:indeterminate"),
        ]


class VSystemBar(HtmlElement):
    """
    Vuetify's VSystemBar component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-system-bar>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      name (string):
        Assign a specific name for layout registration.
      height (string, number):
        Sets the height for the component. Percentage values are relative to the layout.
      theme (string):
        Specify a theme for this component and all of its children.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      absolute (boolean):
        Applies **position: absolute** to the component.
      order (string, number):
        Adjust the order of the component in relation to its registration order.
      window (boolean):
        Increases the system bar height to 32px (24px default).
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VSystemBar", children, **kwargs)
        self._attr_names += [
            "tag",
            "name",
            "height",
            "theme",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "absolute",
            "order",
            "window",
        ]
        self._event_names += []


class VTab(HtmlElement):
    """
    Vuetify's VTab component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-tab>`_.

    Args:
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      fixed (boolean):
        Forces component to take up all available space up to their maximum
        width (300px), and centers it.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      text (string, number, boolean):
        Specify content text for the component.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      base_color (string):
        Sets the color of component when not focused.
      active_color (string):
        The applied color when the component is in an active state.
      slim (boolean):
        Reduces padding to 0 8px.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('flat', 'text', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      direction ('horizontal', 'vertical'):
        Changes the direction of the tabs. Can be either `horizontal` or `vertical`.
      readonly (boolean):
        Puts the button in a readonly state. Cannot be clicked or navigated
        to by keyboard.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      icon (enum):
        Apply a specific icon using the [v-icon](/components/icons/)
        component. The button will become _round_.

        Enum values: [
          boolean, string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      inset (boolean):
        Changes the slider to take full height. Automatically propagated from VTabs.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      stacked (boolean):
        Displays the tab as a flex-column.
      spaced ('start', 'end', 'both'):
        Extends content to the edges to move main content from prepend and append slots.
      slider_color (string):
        Applies specified color to the slider when active on that component
        - supports utility colors (for example `success` or `purple`)
        or css color (`#033` or `rgba(255, 0, 0, 0.5)`). Find a list
        of built-in classes on the [colors page](/styles/colors#material-colors).
      slider_transition_duration (string, number):
        Applies custom slider transition duration. Default duration depends
        on transition type (fade: 400, grow: 350, shift: 225).
      hide_slider (boolean):
        Hides the active tab slider component (no exit or enter animation).
      slider_transition ('shift', 'grow', 'fade'):
        Changes slider transition to one of the predefined animation presets.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTab", children, **kwargs)
        self._attr_names += [
            "replace",
            "fixed",
            "tag",
            "disabled",
            "height",
            "size",
            "value",
            "width",
            "theme",
            "text",
            "exact",
            ("base_color", "baseColor"),
            ("active_color", "activeColor"),
            "slim",
            "border",
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("append_icon", "appendIcon"),
            ("prepend_icon", "prependIcon"),
            "direction",
            "readonly",
            "loading",
            "icon",
            "to",
            "href",
            "inset",
            ("selected_class", "selectedClass"),
            "ripple",
            "stacked",
            "spaced",
            ("slider_color", "sliderColor"),
            ("slider_transition_duration", "sliderTransitionDuration"),
            ("hide_slider", "hideSlider"),
            ("slider_transition", "sliderTransition"),
        ]
        self._event_names += []


class VTable(HtmlElement):
    """
    Vuetify's VTable component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-table>`_.

    Args:
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Use the height prop to set the height of the table.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      hover (boolean):
        Will add a hover effect to a table's row when the mouse is over it.
      gridlines (boolean, 'vertical', 'horizontal', 'all'):
        Controls cell borders - **horizontal** draws lines between rows
        - **vertical** between columns (keeps horizontal lines of header
        and footer rows) - **all** / `true` draws both vertical and horizontal
        lines - `false` removes all lines.
      fixed_header (boolean):
        Makes the header stick to the top of the table while scrolling.
        Requires the **height** prop.
      fixed_footer (boolean):
        Makes the footer stick to the bottom of the table while scrolling.
        Requires the **height** prop.
      striped ('odd', 'even'):
        Applies a background to either **even** or **odd** rows.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTable", children, **kwargs)
        self._attr_names += [
            "density",
            "height",
            "tag",
            "theme",
            "hover",
            "gridlines",
            ("fixed_header", "fixedHeader"),
            ("fixed_footer", "fixedFooter"),
            "striped",
        ]
        self._event_names += []


class VTabs(HtmlElement):
    """
    Vuetify's VTabs component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-tabs>`_.

    Args:
      symbol (any):
        The [Symbol](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)
        used to hook into group functionality for components like [v-btn-toggle](/components/btn-toggle)
        and [v-bottom-navigation](/components/bottom-navigations/).
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      disabled (boolean):
        Puts all children components into a disabled state.
      height (string, number):
        Sets the height of the tabs bar.
      max (number):
        Sets a maximum number of selections that can be made.
      multiple (boolean):
        Allows one to select multiple items.
      items (unknown[]):
        The items to display in the component. This can be an array of
        strings or objects with a property `text`.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      color (string):
        Applies specified color to the selected tab - supports utility
        colors (for example `success` or `purple`) or css color (`#033`
        or `rgba(255, 0, 0, 0.5)`). Find a list of built-in classes on
        the [colors page](/styles/colors#material-colors).
      scroll_to_active (boolean):
        Keeps the last active element visible when resizing the scrollable container.
      content_class (any):
        Adds classes to the slide group item.
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      direction ('horizontal', 'vertical'):
        Changes the direction of the tabs. Can be either `horizontal` or `vertical`.
      mobile (boolean):
        Determines the display mode of the component. If true, the component
        will be displayed in mobile mode. If false, the component will
        be displayed in desktop mode. If null, will be based on the current
        mobile-breakpoint
      mobile_breakpoint (number, 'xs', 'sm', 'md', 'lg', 'xl', 'xxl'):
        Sets the designated mobile breakpoint for the component.
      prev_icon (enum):
        Left pagination icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Right pagination icon.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      inset (boolean):
        Changes the slider to take full height. Tabs will also get some
        spacing and customizable rounding.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      stacked (boolean):
        Apply the stacked prop to all children v-tab components.
      spaced ('start', 'end', 'both'):
        Extends content to the edges to move main content from prepend and append slots.
      slider_color (string):
        Changes the background color of an auto-generated `v-tabs-slider`.
      grow (boolean):
        Forces tabs to take up all available space.
      slider_transition_duration (string, number):
        Applies custom slider transition duration. Default duration depends
        on transition type (fade: 400, grow: 350, shift: 225).
      hide_slider (boolean):
        Hide's the generated `v-tabs-slider`.
      slider_transition ('shift', 'grow', 'fade'):
        Changes slider transition to one of the predefined animation presets.
      align_tabs ('title', 'start', 'end', 'center'):
        Aligns the tabs to the `start`, `center`, or `end` of container.
        Also accepts `title` to align with the `v-toolbar-title` component.
      fixed_tabs (boolean):
        Tabs will be centered and each tab item will grow up to 300px width.
      inset_padding (string, number):
        Sets custom spacing between tabs for `inset` mode.
      inset_radius (string, number):
        Sets custom border radius for the tabs container `inset` mode.
        Rounding for individual tabs is calculated by subtracting the
        padding.
      center_active (boolean):
        Forces the selected tab to be centered.
      scroll_distance (string, number):
        How far the arrows scroll, in pixels or as a percentage of the
        area within container
      scroll_snap ('start', 'end', 'center'):
        Snap items while scrolling or using the arrows.
      show_arrows (string, boolean):
        Show pagination arrows if the tab items overflow their container.
        For mobile devices, arrows will only display when using this
        prop.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTabs", children, **kwargs)
        self._attr_names += [
            "symbol",
            "tag",
            "disabled",
            "height",
            "max",
            "multiple",
            "items",
            ("bg_color", "bgColor"),
            "mandatory",
            "density",
            "color",
            ("scroll_to_active", "scrollToActive"),
            ("content_class", "contentClass"),
            ("model_value", "modelValue"),
            "direction",
            "mobile",
            ("mobile_breakpoint", "mobileBreakpoint"),
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            "inset",
            ("selected_class", "selectedClass"),
            "stacked",
            "spaced",
            ("slider_color", "sliderColor"),
            "grow",
            ("slider_transition_duration", "sliderTransitionDuration"),
            ("hide_slider", "hideSlider"),
            ("slider_transition", "sliderTransition"),
            ("align_tabs", "alignTabs"),
            ("fixed_tabs", "fixedTabs"),
            ("inset_padding", "insetPadding"),
            ("inset_radius", "insetRadius"),
            ("center_active", "centerActive"),
            ("scroll_distance", "scrollDistance"),
            ("scroll_snap", "scrollSnap"),
            ("show_arrows", "showArrows"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VTabsWindow(HtmlElement):
    """
    Vuetify's VTabsWindow component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-tabs-window>`_.

    Args:
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      reverse (boolean):
        Reverse the normal transition direction.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      disabled (boolean):
        Removes the ability to click or target the component.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      direction ('vertical', 'horizontal'):
        The transition direction when changing windows.
      crossfade (boolean):
        Enables crossfade transition.
      transition_duration (number):
        Overrides transition duration. Does not work in firefox, safari
        <18, or with `prefers-reduced-motion: reduce`.
      vertical_arrows (boolean, 'left', 'right'):
        Displays the navigation arrows vertically instead of horizontally.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTabsWindow", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "reverse",
            "tag",
            "theme",
            "disabled",
            ("selected_class", "selectedClass"),
            "direction",
            "crossfade",
            ("transition_duration", "transitionDuration"),
            ("vertical_arrows", "verticalArrows"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VTabsWindowItem(HtmlElement):
    """
    Vuetify's VTabsWindowItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-tabs-window-item>`_.

    Args:
      disabled (boolean):
        Prevents the item from becoming active when using the "next"
        and "prev" buttons or the `toggle` method.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      transition (string, boolean):
        The transition used when the component progressing through items.
        Can be one of the [built in](/styles/transitions/) or custom
        transition.
      reverse_transition (string, boolean):
        Sets the reverse transition.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTabsWindowItem", children, **kwargs)
        self._attr_names += [
            "disabled",
            "value",
            "eager",
            "transition",
            ("reverse_transition", "reverseTransition"),
            ("selected_class", "selectedClass"),
        ]
        self._event_names += []


class VTextField(HtmlElement):
    """
    Vuetify's VTextField component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-text-field>`_.

    Args:
      flat (boolean):
        Removes elevation (shadow) added to element when using the **solo**
        or **solo-inverted** props.
      type (string):
        Sets input type.
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      reverse (boolean):
        Reverses the input orientation.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      rounded (string, number, boolean):
        Adds a border radius to the input.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'filled', 'underlined', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      name (string):
        Sets the component's name attribute.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      placeholder (string):
        Sets the input’s placeholder text.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      role (string):
        The role attribute applied to the input.
      autofocus (boolean):
        Enables autofocus.
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      base_color (string):
        Sets the color of the input when it is not focused.
      prepend_icon (enum):
        Prepends an icon to the outside the component's input, uses the
        same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      readonly (boolean):
        Puts input in readonly state.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        Applied when using **clearable** and the input is dirty.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Prepends an icon inside the component's input, uses the same syntax as `v-icon`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      counter_value (number, js_fn):
        Function returns the counter display text.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when append icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      click_control (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VTextField.json))
      mousedown_control (event):
        Event that is emitted when using mousedown on the main control area.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTextField", children, **kwargs)
        self._attr_names += [
            "flat",
            "type",
            ("model_value", "modelValue"),
            "error",
            "reverse",
            "density",
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "width",
            "rounded",
            "tile",
            "theme",
            "color",
            "variant",
            "name",
            "autocomplete",
            "disabled",
            "placeholder",
            "id",
            "prefix",
            "role",
            "autofocus",
            "active",
            ("base_color", "baseColor"),
            ("prepend_icon", "prependIcon"),
            ("append_icon", "appendIcon"),
            "readonly",
            "loading",
            "label",
            ("bg_color", "bgColor"),
            "messages",
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("click_control", "click:control"),
            ("mousedown_control", "mousedown:control"),
        ]


class VTextarea(HtmlElement):
    """
    Vuetify's VTextarea component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-textarea>`_.

    Args:
      flat (boolean):
        Removes box shadow when using a variant with elevation.
      reverse (boolean):
        Reverses the orientation.
      name (string):
        Sets the component's name attribute.
      error (boolean):
        Puts the input in a manual error state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      autocomplete (string):
        Helps influence browser's suggestions. Special value **suppress**
        manipulates fields `name` attribute while **off** relies on browser's
        good will to stop suggesting values. Any other value is passed
        to the native `autocomplete` on the underlying element.
      disabled (boolean):
        Removes the ability to click or target the input.
      placeholder (string):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VTextarea.json))
      width (string, number):
        Sets the width for the component.
      id (string):
        Sets the DOM id on the component.
      prefix (string):
        Displays prefix text.
      autofocus (boolean):
        The element should be focused as soon as the page loads.
      theme (string):
        Specify a theme for this component and all of its children.
      base_color (string):
        Sets the color of the input when it is not focused.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Alternative for **max-rows**. Specifies the maximum height in
        pixels (including the field padding) for **auto-grow**.
      max_width (string, number):
        Sets the maximum width for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant (enum):
        Applies a distinct style to the component.

        Enum values: [
          'outlined', 'plain', 'underlined', 'filled', 'solo', 'solo-inverted',
          'solo-filled'
        ]
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      counter (string, number, boolean):
        Creates counter for input length; if no number is specified,
        it defaults to 25. Does not apply any validation.
      persistent_placeholder (boolean):
        Forces placeholder to always be visible.
      persistent_counter (boolean):
        Forces counter to always be visible.
      suffix (string):
        Displays suffix text.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      center_affix (boolean):
        Vertically align **appendInner**, **prependInner**, **clearIcon**
        and **label** in the center.
      glow (boolean):
        Makes prepend/append icons full opacity when the field is focused
        and apply color.
      icon_color (string, boolean):
        Sets the color of the prepend/append icons.
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      details_active (boolean):
        Overrides the automatic check for details content when [hide-details](#props-hide-details)
        is set to `auto`.
      hide_spin_buttons (boolean):
        Hides spin buttons on the input when type is set to `number`.
      hint (string):
        Displays hint text below the input when focused. Force this always
        open with the [persistent-hint](#props-persistent-hint) property.
      indent_details (boolean):
        Adds / removes inline padding in inputs details. Useful when
        trying to align different variants of fields and selection controls.
      persistent_hint (boolean):
        Forces [hint](#props-hint) to always be visible.
      messages (string, string[]):
        Displays a list of messages or a single message if using a string.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      readonly (boolean):
        Puts input in readonly state.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      hide_details (boolean, 'auto'):
        Hides hint and validation errors. When set to `auto` messages
        will be rendered only if there's a message (hint, error message,
        counter value etc) to display.
      append_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **append-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      clearable (boolean):
        Allows for the component to be cleared.
      clear_icon (enum):
        The icon used when the **clearable** prop is set to true.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      dirty (boolean):
        Manually apply the dirty state styling.
      persistent_clear (boolean):
        Always show the clearable icon when the input is dirty (By default
        it only shows on hover).
      prepend_inner_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend-inner** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      single_line (boolean):
        Label does not move on focus/dirty.
      loading (string, boolean):
        Displays linear progress bar. Can either be a String which specifies
        which color is applied to the progress bar (any material color
        or theme color - **primary**, **secondary**, **success**, **info**,
        **warning**, **error**) or a Boolean which uses the component
        **color** (set by color prop - if it's supported by the component)
        or the primary color.
      counter_value ((value: any) => number):
        Display the input length but do not provide any validation.
      model_modifiers (unknown):
        **FOR INTERNAL USE ONLY**
      auto_grow (boolean):
        Automatically grow the textarea depending on amount of text.
      no_resize (boolean):
        Remove resize handle.
      rows (string, number):
        Default row count.
      max_rows (string, number):
        Specifies the maximum number of rows for **auto-grow**.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_prepend (event):
        Emitted when prepended icon is clicked.
      click_append (event):
        Emitted when appended icon is clicked.
      update_focused (event):
        Emitted when the input is focused or blurred
      click_clear (event):
        Emitted when clearable icon clicked.
      click_appendInner (event):
        Emitted when appended inner icon is clicked.
      click_prependInner (event):
        Emitted when prepended inner icon is clicked.
      click_control (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VTextarea.json))
      mousedown_control (event):
        Event that is emitted when using mousedown on the main control area.
      update_rows (event):
        Emitted when the number of rows changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTextarea", children, **kwargs)
        self._attr_names += [
            "flat",
            "reverse",
            "name",
            "error",
            "label",
            "autocomplete",
            "disabled",
            "placeholder",
            "width",
            "id",
            "prefix",
            "autofocus",
            "theme",
            ("base_color", "baseColor"),
            ("bg_color", "bgColor"),
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_width", "minWidth"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("model_value", "modelValue"),
            "counter",
            ("persistent_placeholder", "persistentPlaceholder"),
            ("persistent_counter", "persistentCounter"),
            "suffix",
            ("append_icon", "appendIcon"),
            ("center_affix", "centerAffix"),
            "glow",
            ("icon_color", "iconColor"),
            ("prepend_icon", "prependIcon"),
            ("details_active", "detailsActive"),
            ("hide_spin_buttons", "hideSpinButtons"),
            "hint",
            ("indent_details", "indentDetails"),
            ("persistent_hint", "persistentHint"),
            "messages",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "readonly",
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
            ("hide_details", "hideDetails"),
            ("append_inner_icon", "appendInnerIcon"),
            "clearable",
            ("clear_icon", "clearIcon"),
            "active",
            "dirty",
            ("persistent_clear", "persistentClear"),
            ("prepend_inner_icon", "prependInnerIcon"),
            ("single_line", "singleLine"),
            "loading",
            ("counter_value", "counterValue"),
            ("model_modifiers", "modelModifiers"),
            ("auto_grow", "autoGrow"),
            ("no_resize", "noResize"),
            "rows",
            ("max_rows", "maxRows"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_prepend", "click:prepend"),
            ("click_append", "click:append"),
            ("update_focused", "update:focused"),
            ("click_clear", "click:clear"),
            ("click_appendInner", "click:appendInner"),
            ("click_prependInner", "click:prependInner"),
            ("click_control", "click:control"),
            ("mousedown_control", "mousedown:control"),
            ("update_rows", "update:rows"),
        ]


class VThemeProvider(HtmlElement):
    """
    Vuetify's VThemeProvider component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-theme-provider>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      with_background (boolean):
        Wraps its children in an element and applies the current theme's
        background color to it.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VThemeProvider", children, **kwargs)
        self._attr_names += [
            "tag",
            "theme",
            ("with_background", "withBackground"),
        ]
        self._event_names += []


class VTimePicker(HtmlElement):
    """
    Vuetify's VTimePicker component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-time-picker>`_.

    Args:
      title (string):
        Specify a title text for the component.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (any):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Width of the picker.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string.
      position ('fixed', 'static', 'relative', 'absolute', 'sticky'):
        Sets the position for the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('input', 'dial'):
        Applies a distinct style to the component.
      disabled (boolean):
        Removes the ability to click or target the component.
      max (string):
        Maximum allowed time.
      min (string):
        Minimum allowed time.
      readonly (boolean):
        Puts picker in readonly state.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      scrollable (boolean):
        Allows changing hour/minute with mouse scroll.
      divided (boolean):
        Adds a divider between the header and controls.
      format ('ampm', '24hr'):
        Defines the format of a time displayed in picker. Available options
        are `ampm` and `24hr`.
      hide_header (boolean):
        Hide the picker header.
      hide_title (boolean):
        Hide the picker title.
      view_mode ('hour', 'minute', 'second'):
        The current view mode of the picker.`
      period ('am', 'pm'):
        Sets period for 12hr format.
      use_seconds (boolean):
        Toggles the use of seconds in picker.
      allowed_hours (number[], js_fn):
        Restricts which hours can be selected.
      allowed_minutes (number[], js_fn):
        Restricts which minutes can be selected.
      allowed_seconds (number[], js_fn):
        Restricts which seconds can be selected.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_viewMode (event):
        Emitted when the view mode changes.
      update_hour (event):
        Emitted when user selects the hour.
      update_minute (event):
        Emitted when user selects the minute.
      update_period (event):
        Emitted when user clicks the AM/PM button.
      update_second (event):
        Emitted when user selects the second.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTimePicker", children, **kwargs)
        self._attr_names += [
            "title",
            "border",
            ("model_value", "modelValue"),
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "position",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "disabled",
            "max",
            "min",
            "readonly",
            ("bg_color", "bgColor"),
            "scrollable",
            "divided",
            "format",
            ("hide_header", "hideHeader"),
            ("hide_title", "hideTitle"),
            ("view_mode", "viewMode"),
            "period",
            ("use_seconds", "useSeconds"),
            ("allowed_hours", "allowedHours"),
            ("allowed_minutes", "allowedMinutes"),
            ("allowed_seconds", "allowedSeconds"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_viewMode", "update:viewMode"),
            ("update_hour", "update:hour"),
            ("update_minute", "update:minute"),
            ("update_period", "update:period"),
            ("update_second", "update:second"),
        ]


class VTimePickerClock(HtmlElement):
    """
    Vuetify's VTimePickerClock component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-time-picker-clock>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      max (number):
        Defines the maximum time value that can be selected.
      min (number):
        Defines the minimum time value that can be selected.
      step (number):
        Defines the increments between selectable times, such as a step
        of 1 for every minute or a larger step for every 5 or 15 minutes.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      model_value (number):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      readonly (boolean):
        When true, the picker is in a read-only state, and users cannot
        modify the selected time.
      scrollable (boolean):
        Allows the time selection to be scrollable, enhancing user experience
        for devices with scroll inputs.
      double (boolean):
        If set, this probably indicates a double rotation or a mode where
        more than one set of values (like hours and minutes) is displayed
        on the clock at the same time.
      rotate (number):
        Controls rotation, specifying the degree of rotation for the clock hands.
      ampm (boolean):
        Displays time in a 12-hour format.
      displayed_value (any):
        Used to display a custom value on the clock.
      format (Function):
        Specifies the format of the displayed time, either 12-hour or
        24-hour, depending on the component's setup.
      allowed_values ((value: number) => boolean):
        Restricts which hours can be selected.
      change (event):
        The event that is triggered when the selected time is changed.
      input (event):
        The updated bound model.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTimePickerClock", children, **kwargs)
        self._attr_names += [
            "disabled",
            "max",
            "min",
            "step",
            "color",
            ("model_value", "modelValue"),
            "readonly",
            "scrollable",
            "double",
            "rotate",
            "ampm",
            ("displayed_value", "displayedValue"),
            "format",
            ("allowed_values", "allowedValues"),
        ]
        self._event_names += [
            "change",
            "input",
        ]


class VTimePickerControls(HtmlElement):
    """
    Vuetify's VTimePickerControls component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-time-picker-controls>`_.

    Args:
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      disabled (boolean):
        Removes the ability to click or target the component.
      max (string):
        Maximum allowed time.
      min (string):
        Minimum allowed time.
      value (number):
        The current value of the timepicker.
      readonly (boolean):
        Makes the timepicker readonly.
      ampm (boolean):
        Enables AM/PM mode.
      hour (string, number):
        The current hour value.
      minute (string, number):
        The current minute value.
      view_mode ('hour', 'minute', 'second'):
        The current view mode of the timepicker. Can be either `hour`,
        `minute`, or `second`.
      second (string, number):
        The current second value.
      period ('am', 'pm'):
        The current period value. either `am` or `pm`.
      use_seconds (boolean):
        Enables the display and selection of seconds in the timepicker.
      allowed_hours (number[], js_fn):
        Restricts which hours can be selected. Can be an array of allowed
        hours, a function that returns true for allowed hours, or an
        object with `min` and `max` properties.
      allowed_minutes (number[], js_fn):
        Restricts which minutes can be selected. Can be an array of allowed
        minutes, a function that returns true for allowed minutes, or
        an object with `min` and `max` properties.
      allowed_seconds (number[], js_fn):
        Restricts which seconds can be selected. Can be an array of allowed
        seconds, a function that returns true for allowed seconds, or
        an object with `min` and `max` properties.
      input_hints (boolean):
        Displays labels below the time input controls.
      update_viewMode (event):
        Emitted when the view mode is changed. The event payload is either
        `hour`, `minute`, or `second`.
      update_hour (event):
        Emitted when the hour value changes.
      update_minute (event):
        Emitted when the minute value changes.
      update_period (event):
        Emitted when the period is changed. The event payload is either `am` or `pm`.
      update_second (event):
        Emitted when the second value changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTimePickerControls", children, **kwargs)
        self._attr_names += [
            "color",
            "disabled",
            "max",
            "min",
            "value",
            "readonly",
            "ampm",
            "hour",
            "minute",
            ("view_mode", "viewMode"),
            "second",
            "period",
            ("use_seconds", "useSeconds"),
            ("allowed_hours", "allowedHours"),
            ("allowed_minutes", "allowedMinutes"),
            ("allowed_seconds", "allowedSeconds"),
            ("input_hints", "inputHints"),
        ]
        self._event_names += [
            ("update_viewMode", "update:viewMode"),
            ("update_hour", "update:hour"),
            ("update_minute", "update:minute"),
            ("update_period", "update:period"),
            ("update_second", "update:second"),
        ]


class VTimeline(HtmlElement):
    """
    Vuetify's VTimeline component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-timeline>`_.

    Args:
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      align ('start', 'center'):
        Places the timeline dot at the top or center of the timeline item.
      size (string, number):
        Sets the height and width of the component. Default unit is px.
        Can also use the following predefined sizes: **x-small**, **small**,
        **default**, **large**, and **x-large**.
      direction ('vertical', 'horizontal'):
        Display timeline in a **vertical** or **horizontal** direction.
      icon_color (string):
        Color of the icon.
      justify ('center', 'auto'):
        Places timeline line at the center or automatically on the left or right side.
      side ('end', 'start'):
        Display all timeline items on one side of the timeline, either
        **start** or **end**.
      line_thickness (string, number):
        Thickness of the timeline line.
      line_color (string):
        Color of the timeline line.
      dot_color (string):
        Color of the item dot.
      fill_dot (boolean):
        Remove outer border of item dot, making the color fill the entire dot.
      hide_opposite (boolean):
        Hide opposite content if it exists.
      line_inset (string, number):
        Specifies the distance between the line and the dot of timeline items.
      truncate_line ('end', 'start', 'both'):
        Truncate timeline directly at the **start** or **end** of the
        line, or on **both** ends.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTimeline", children, **kwargs)
        self._attr_names += [
            "density",
            "tag",
            "theme",
            "align",
            "size",
            "direction",
            ("icon_color", "iconColor"),
            "justify",
            "side",
            ("line_thickness", "lineThickness"),
            ("line_color", "lineColor"),
            ("dot_color", "dotColor"),
            ("fill_dot", "fillDot"),
            ("hide_opposite", "hideOpposite"),
            ("line_inset", "lineInset"),
            ("truncate_line", "truncateLine"),
        ]
        self._event_names += []


class VTimelineItem(HtmlElement):
    """
    Vuetify's VTimelineItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-timeline-item>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      height (string, number):
        Sets the height for the component.
      size (string, number):
        Size of the item dot
      width (string, number):
        Sets the width for the component.
      density ('default', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      icon_color (string):
        Color of the icon.
      icon (enum):
        Apply a specific icon to the inside dot using the [v-icon](/components/icons/)
        component.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      dot_color (string):
        Color of the item dot.
      fill_dot (boolean):
        Remove outer border of item dot, making the color fill the entire dot.
      hide_dot (boolean):
        Hide the timeline item dot.
      hide_opposite (boolean):
        Hide opposite content if it exists.
      line_inset (string, number):
        Specifies the distance between the line and the dot of the item.
      side ('start', 'end'):
        Show the item either **before** or **after** the timeline. This
        will override the implicit ordering of items, but will in turn
        be overridden by the `v-timeline` **single-side** prop.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTimelineItem", children, **kwargs)
        self._attr_names += [
            "tag",
            "height",
            "size",
            "width",
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            ("icon_color", "iconColor"),
            "icon",
            ("dot_color", "dotColor"),
            ("fill_dot", "fillDot"),
            ("hide_dot", "hideDot"),
            ("hide_opposite", "hideOpposite"),
            ("line_inset", "lineInset"),
            "side",
        ]
        self._event_names += []


class VToolbar(HtmlElement):
    """
    Vuetify's VToolbar component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-toolbar>`_.

    Args:
      title (string):
        Specify a title text for the component.
      flat (boolean):
        Removes the toolbar's box-shadow.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'prominent', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Designates a specific height for the toolbar. Overrides the heights
        imposed by other props, e.g. **prominent**, **dense**, **extended**,
        etc.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      location (Anchor):
        Specifies the component's location. Can combine by using a space
        separated string. Requires the **absolute** prop.
      absolute (boolean):
        Applies position: absolute to the component.
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      image (string):
        Specifies a [v-img](/components/images) as the component's background.
      collapse (boolean):
        Puts the toolbar into a collapsed state reducing its maximum width.
      collapse_position ('end', 'start'):
        Specifies side to attach the collapsed toolbar.
      extended (boolean):
        Use this prop to increase the height of the toolbar _without_
        using the `extension` slot for adding content. May be used in
        conjunction with the **extension-height** prop. When false, will
        not show extension slot even if content is present.
      extension_height (string, number):
        Specify an explicit height for the `extension` slot.
      floating (boolean):
        Applies **display: inline-flex** to the component.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VToolbar", children, **kwargs)
        self._attr_names += [
            "title",
            "flat",
            "border",
            "density",
            "height",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "location",
            "absolute",
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "image",
            "collapse",
            ("collapse_position", "collapsePosition"),
            "extended",
            ("extension_height", "extensionHeight"),
            "floating",
        ]
        self._event_names += []


class VToolbarItems(HtmlElement):
    """
    Vuetify's VToolbarItems component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-toolbar-items>`_.

    Args:
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      variant ('flat', 'text', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VToolbarItems", children, **kwargs)
        self._attr_names += [
            "color",
            "variant",
        ]
        self._event_names += []


class VToolbarTitle(HtmlElement):
    """
    Vuetify's VToolbarTitle component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-toolbar-title>`_.

    Args:
      text (string):
        Specify content text for the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VToolbarTitle", children, **kwargs)
        self._attr_names += [
            "text",
            "tag",
        ]
        self._event_names += []


class VTooltip(HtmlElement):
    """
    Vuetify's VTooltip component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-tooltip>`_.

    Args:
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      width (string, number):
        Sets the width for the component.
      id (string):
        HTML id attribute of the tooltip overlay. If not set, a globally
        unique id will be used.
      theme (string):
        Specify a theme for this component and all of its children.
      text (string):
        Specify content text for the component.
      target (enum):
        For locationStrategy="connected", specify an element or array
        of x,y coordinates that the overlay should position itself relative
        to. This will be the activator element by default.

        Enum values: [
          Element, (string & {}), 'parent', 'cursor', ComponentPublicInstance,
          [number, number]
        ]
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      activator (Element, (string & {}), 'parent', ComponentPublicInstance):
        Explicitly sets the overlay's activator.
      close_on_back (boolean):
        Closes the overlay content when the browser's back button is
        pressed or `$router.back()` is called, cancelling the original
        navigation. `persistent` overlays will cancel navigation and
        animate as if they were clicked outside instead of closing.
      contained (boolean):
        Limits the size of the component and scrim to its offset parent.
        Implies `absolute` and `attach`. (Note: The parent element must
        have position: relative.).
      content_class (any):
        Applies a custom class to the detached element. This is useful
        because the content is moved to the beginning of the `v-app`
        component (unless the **attach** prop is provided) and is not
        targetable by classes passed directly on the component.
      content_props (any):
        Apply custom properties to the content.
      opacity (string, number):
        Sets the opacity of the scrim element. Only applies if `scrim` is enabled.
      no_click_animation (boolean):
        Disables the bounce effect when clicking outside of the content
        element when using the persistent prop.
      model_value (boolean):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      persistent (boolean):
        Clicking outside of the element or pressing esc key will not deactivate it.
      scrim (string, boolean):
        Accepts true/false to enable background, and string to define color.
      z_index (string, number):
        The z-index used for the component.
      activator_props (unknown):
        Apply custom properties to the activator.
      open_on_click (boolean):
        Designates whether the tooltip should open on activator click.
      open_on_hover (boolean):
        Designates whether the tooltip should open on activator hover.
      open_on_focus (boolean):
        Activate the component when the activator is focused.
      close_on_content_click (boolean):
        Closes component when you click on its content.
      close_delay (string, number):
        Delay (in ms) after which menu closes (when open-on-hover prop is set to true).
      open_delay (string, number):
        Delay (in ms) after which tooltip opens (when `open-on-hover`
        prop is set to **true**).
      location_strategy (LocationStrategyFunction):
        Sets how the overlay content is positioned. Defaults to `static`,
        which centers content in its container. Use `connected` to attach
        to an activator element, or `viewport` to position relative to
        the browser viewport.
      location (Anchor):
        Specifies the anchor point for positioning the component, using
        directional cues to align it either horizontally, vertically,
        or both..
      origin (Anchor):
        Sets the anchor point on the overlay content that aligns to the
        `location` anchor on the target. `auto` uses the opposing side
        of `location`; `overlap` uses the same anchor, causing the overlay
        to cover the target. Also sets the CSS `transform-origin` for
        enter/leave transitions.
      offset (string, number, number[]):
        Increases distance from the target. When passed as a pair of
        numbers, the second value shifts anchor along the side and away
        from the target.
      stick_to_target (boolean):
        Enables the overlay content to go off-screen when scrolling.
      viewport_margin (string, number):
        Sets custom viewport margin for the overlay content
      scroll_strategy (ScrollStrategyFunction):
        Strategy used when the component is activate and user scrolls.
      transition (enum):
        Sets the component transition. Can be one of the [built in](/styles/transitions/)
        or custom transition.

        Enum values: [
          string, boolean, (TransitionProps & { component: Component })
        ]
      attach (string, boolean, Element):
        Specifies which DOM element the overlay content should teleport
        to. Can be a direct element reference, querySelector string,
        or `true` to disable teleporting. Uses `body` by default.
      interactive (boolean):
        When true, the tooltip will respond to pointer events, allowing
        you to copy text from it.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTooltip", children, **kwargs)
        self._attr_names += [
            "disabled",
            "height",
            "width",
            "id",
            "theme",
            "text",
            "target",
            "eager",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "color",
            "activator",
            ("close_on_back", "closeOnBack"),
            "contained",
            ("content_class", "contentClass"),
            ("content_props", "contentProps"),
            "opacity",
            ("no_click_animation", "noClickAnimation"),
            ("model_value", "modelValue"),
            "persistent",
            "scrim",
            ("z_index", "zIndex"),
            ("activator_props", "activatorProps"),
            ("open_on_click", "openOnClick"),
            ("open_on_hover", "openOnHover"),
            ("open_on_focus", "openOnFocus"),
            ("close_on_content_click", "closeOnContentClick"),
            ("close_delay", "closeDelay"),
            ("open_delay", "openDelay"),
            ("location_strategy", "locationStrategy"),
            "location",
            "origin",
            "offset",
            ("stick_to_target", "stickToTarget"),
            ("viewport_margin", "viewportMargin"),
            ("scroll_strategy", "scrollStrategy"),
            "transition",
            "attach",
            "interactive",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VTreeview(HtmlElement):
    """
    Vuetify's VTreeview component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-treeview>`_.

    Args:
      search (string):
        The search model for filtering results.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      model_value (unknown):
        Allows one to control which nodes are selected. The array contains
        the values of currently selected items. It is equivalent to the
        `v-model:selected`
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Provides an alternative active style for `v-treeview` node. Only
        visible when `activatable` is `true` and should not be used in
        conjunction with the `shaped` prop.
      tile (boolean):
        Removes any applied **border-radius** from the component.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        Applies specified color to the active node - supports utility
        colors (for example `success` or `purple`) or css color (`#033`
        or `rgba(255, 0, 0, 0.5)`). Find a list of built-in classes on
        the [colors page](/styles/colors#material-colors).
      variant ('text', 'flat', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      activated (unknown):
        Array of ids of activated nodes.
      disabled (boolean):
        Disables selection for all nodes.
      active_color (string):
        Deprecated, use `color` instead.
      base_color (string):
        Sets the color of component when not focused.
      slim (boolean):
        Reduces horizontal spacing for badges, icons, tooltips, and avatars
        within slim list items to create a more compact visual representation.
      items (unknown[]):
        An array of items used to build the treeview.
      item_props (SelectItemKey):
        Props object that will be applied to each item component. `true`
        will treat the original object as raw props and pass it directly
        to the component.
      bg_color (string):
        Applies specified color to the control's background. Used on
        components that also support the **color** prop. - supports utility
        colors with or without `bg-` prefix (for example `success`, `purple`
        or `bg-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      lines (false, 'one', 'two', 'three'):
        Designates a **minimum-height** for all children `v-list-item`
        components. This prop uses [line-clamp](https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-line-clamp)
        and is not supported in all browsers.
      mandatory (boolean):
        Forces at least one item to always be selected (if available).
      open_on_click (boolean):
        When `true` will cause nodes to be opened by clicking anywhere
        on it, instead of only opening by clicking on expand icon. When
        using this prop with `activatable` you will be unable to mark
        nodes with children as active.
      active_class (string):
        The class applied to the component when it is in an active state.
      selected (unknown):
        An array containing the values of currently selected items. Can
        be two-way bound with `v-model:selected`.
      false_icon (enum):
        The icon used when inactive.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      true_icon (enum):
        The icon used when active.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      indeterminate_icon (enum):
        Icon used when node is in an indeterminate state. Only visible
        when `selectable` is `true`.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      value_comparator ((a: any, b: any) => boolean):
        Apply a custom comparison algorithm to compare **model-value**
        and values contains in the **items** prop.
      filter_mode ('every', 'some', 'union', 'intersection'):
        Controls how the results of `customFilter` and `customKeyFilter`
        are combined. All modes only apply `customFilter` to columns
        not specified in `customKeyFilter`.  - **some**: There is at
        least one match from either the custom filter or the custom key
        filter. - **every**: All columns match either the custom filter
        or the custom key filter. - **union**: There is at least one
        match from the custom filter, or all columns match the custom
        key filters. - **intersection**: There is at least one match
        from the custom filter, and all columns match the custom key
        filters.
      no_filter (boolean):
        Disables all item filtering.
      custom_filter (FilterFunction):
        Function used to filter items, called for each filterable key
        on each item in the list. The first argument is the filterable
        value from the item, the second is the search term, and the third
        is the internal item object. The function should return true
        if the item should be included in the filtered list, or the index
        of the match in the value if it should be included with the result
        highlighted.
      custom_key_filter (unknown):
        Function used on specific keys within the item object. `customFilter`
        is skipped for columns with `customKeyFilter` specified.
      filter_keys (string, string[]):
        Array of specific keys to filter on the item.
      ignore_accents (k):
        Folds accents before filtering. Use `'query'` to normalize only
        the search term, `'target'` to normalize only the item value,
        or `true` for both.
      hide_no_data (boolean):
        Hides the menu when there are no options to show.  Useful for
        preventing the menu from opening before results are fetched asynchronously.
         Also has the effect of opening the menu when the `items` array
        changes if not already open.
      filterable (boolean):
        **FOR INTERNAL USE ONLY** Prevents list item selection using
        [space] key and pass it back to the text input. Used internally
        for VAutocomplete and VCombobox.
      expand_icon (enum):
        Icon used to indicate that a node can be expanded.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      collapse_icon (enum):
        Icon to display when the list item is expanded.

        Enum values: [
          string, (string, [string, number])[], js_fn, FunctionalComponent
        ]
      prepend_gap (string, number):
        Sets the horizontal spacing between prepend slot and the main
        content within list item. Also affects indent to ensure expected
        alignment of group children.
      indent (string, number):
        Overrides the indent size for nested groups.
      navigation_strategy ('focus', 'track'):
        Determines keyboard navigation behavior. **focus** (default)
        moves DOM focus to items, suitable for traditional lists. **track**
        provides visual keyboard focus without moving DOM focus, ideal
        for command palettes and autocomplete where an external element
        retains focus. When track mode is active, items automatically
        receive `tabindex="-1"`, proper `aria-activedescendant` is set
        on the list container, and keyboard-focused items display focus-visible
        styling with auto-scrolling.
      navigation_index (number):
        Specifies the currently selected navigation index when using
        `navigationStrategy="track"`. Can be used with `v-model:navigationIndex`
        for two-way binding. Items at this index receive visual keyboard
        focus styling and automatic scrolling. Note: Only works with
        the `items` prop, not with slotted items.
      activatable (boolean):
        Allows user to mark a node as active by clicking on it.
      selectable (boolean):
        Will render a checkbox next to each node allowing them to be
        selected. Additionally, the **[openOnClick](/api/v-treeview/#props-open-on-click)**
        property will be applied internally.
      opened (unknown):
        An array containing the values of currently opened groups. Can
        be two-way bound with `v-model:opened`.
      items_registration ('props', 'render'):
        When set to 'props', skips rendering collapsed items/nodes (for
        significant performance gains).
      active_strategy (ActiveStrategy):
        Affects how items with children behave when activated. If not
        specified, the **single-independent** strategy will be used.
        - **leaf:** Only leaf nodes (items without children) can be activated.
        - **single-leaf:** Similar as **leaf**, but only a single item
        can be activated at a time. - **independent:** All nodes can
        be activated whether they have children or not. - **single-independent:**
        Similar as **independent**, but only a single item can be activated
        at a time.
      select_strategy (SelectStrategy):
        Affects how items with children behave when selected. - **leaf:**
        Only leaf nodes (items without children) can be selected. - **independent:**
        All nodes can be selected whether they have children or not.
        - **classic:** Selecting a parent node will cause all children
        to be selected, parent nodes will be displayed as selected if
        all their descendants are selected. Only leaf nodes will be added
        to the model. - **trunk**: Same as classic but if all of a node's
        children are selected then only that node will be added to the
        model. - **branch**: Same as classic but if any of a node's children
        are selected then that node will also be added to the model.
      item_title (SelectItemKey):
        Property on supplied `items` that contains its title.
      item_value (SelectItemKey):
        Property on supplied `items` that contains its value.
      item_children (SelectItemKey):
        Property on supplied `items` that contains its children.
      item_type (SelectItemKey):
        Designates the key on the supplied items that is used for determining
        the nodes type.
      return_object (boolean):
        When `true` will make `v-model`, `v-model:selected, `v-model:activated`
        and `v-model:opened` return the complete object instead of just
        the key.
      no_data_text (string):
        Text shown when no items are provided to the component.
      hide_actions (boolean):
        Hide the expand icon and loading indicator next to each item title.
      open_all (boolean):
        When `true` will cause all branch nodes to be opened when component is mounted.
      indent_lines_color (string):
        Sets color of indent lines
      indent_lines_opacity (string, number):
        Sets opacity of indent lines
      fluid (boolean):
        Removes indentation from nested items.
      loading_icon (string):
        Icon used when node is in a loading state.
      selected_color (string):
        The color of the selection checkbox.
      separate_roots (boolean):
        Applies to `default` variant of `indent-lines`. Prevents showing
        lines between root-level nodes.
      indent_lines (boolean, 'default', 'simple'):
        Controls visibility and variant of the indent lines.
      load_children ((item: unknown) => Promise<void>):
        A function used when dynamically loading children. If this prop
        is set, then the supplied function will be run if expanding an
        item that has a `item-children` property that is an empty array.
        Supports returning a Promise.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      click_open (event):
        Emits the item when it is clicked to open.
      click_select (event):
        Emits the item when it is clicked to select.
      update_opened (event):
        Emits the array of open items when this value changes.
      update_selected (event):
        Emits the array of selected items when this value changes.
      update_activated (event):
        Emits the array of active items when this value changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTreeview", children, **kwargs)
        self._attr_names += [
            "search",
            "border",
            ("model_value", "modelValue"),
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "tag",
            "theme",
            "color",
            "variant",
            "activated",
            "disabled",
            ("active_color", "activeColor"),
            ("base_color", "baseColor"),
            "slim",
            "items",
            ("item_props", "itemProps"),
            ("bg_color", "bgColor"),
            "lines",
            "mandatory",
            ("open_on_click", "openOnClick"),
            ("active_class", "activeClass"),
            "selected",
            ("false_icon", "falseIcon"),
            ("true_icon", "trueIcon"),
            ("indeterminate_icon", "indeterminateIcon"),
            ("value_comparator", "valueComparator"),
            ("filter_mode", "filterMode"),
            ("no_filter", "noFilter"),
            ("custom_filter", "customFilter"),
            ("custom_key_filter", "customKeyFilter"),
            ("filter_keys", "filterKeys"),
            ("ignore_accents", "ignoreAccents"),
            ("hide_no_data", "hideNoData"),
            "filterable",
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            ("prepend_gap", "prependGap"),
            "indent",
            ("navigation_strategy", "navigationStrategy"),
            ("navigation_index", "navigationIndex"),
            "activatable",
            "selectable",
            "opened",
            ("items_registration", "itemsRegistration"),
            ("active_strategy", "activeStrategy"),
            ("select_strategy", "selectStrategy"),
            ("item_title", "itemTitle"),
            ("item_value", "itemValue"),
            ("item_children", "itemChildren"),
            ("item_type", "itemType"),
            ("return_object", "returnObject"),
            ("no_data_text", "noDataText"),
            ("hide_actions", "hideActions"),
            ("open_all", "openAll"),
            ("indent_lines_color", "indentLinesColor"),
            ("indent_lines_opacity", "indentLinesOpacity"),
            "fluid",
            ("loading_icon", "loadingIcon"),
            ("selected_color", "selectedColor"),
            ("separate_roots", "separateRoots"),
            ("indent_lines", "indentLines"),
            ("load_children", "loadChildren"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("click_open", "click:open"),
            ("click_select", "click:select"),
            ("update_opened", "update:opened"),
            ("update_selected", "update:selected"),
            ("update_activated", "update:activated"),
        ]


class VTreeviewGroup(HtmlElement):
    """
    Vuetify's VTreeviewGroup component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-treeview-group>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      title (string):
        Specify a title text for the component.
      disabled (boolean):
        Puts all children inputs into a disabled state.
      value (any):
        Expands / Collapse the list-group.
      base_color (string):
        Sets the color of component when not focused.
      active_color (string):
        Deprecated, use `color` instead.
      expand_icon (enum):
        Icon to display when the list item is collapsed.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      collapse_icon (enum):
        Icon to display when the list item is expanded.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      color (string):
        Applies specified color to the control - supports utility colors
        with or without `text-` prefix (for example `success`, `purple`
        or `text-purple`) or CSS color (`#033` or `rgba(255, 0, 0, 0.5)`).
        Find a list of built-in classes on the [colors page](/styles/colors#material-colors).
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      prepend_icon (enum):
        Prepends an icon to the component, uses the same syntax as `v-icon`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      fluid (boolean):
        Removes indentation from nested items.
      raw_id (string, number):
        Defines the root element's id attribute in the component. If
        it is provided, the id attribute will be dynamically generated
        in the format: "v-list-group--id-[rawId]".
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTreeviewGroup", children, **kwargs)
        self._attr_names += [
            "tag",
            "title",
            "disabled",
            "value",
            ("base_color", "baseColor"),
            ("active_color", "activeColor"),
            ("expand_icon", "expandIcon"),
            ("collapse_icon", "collapseIcon"),
            "color",
            ("append_icon", "appendIcon"),
            ("prepend_icon", "prependIcon"),
            "fluid",
            ("raw_id", "rawId"),
        ]
        self._event_names += []


class VTreeviewItem(HtmlElement):
    """
    Vuetify's VTreeviewItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-treeview-item>`_.

    Args:
      replace (boolean):
        Setting **replace** prop will call `router.replace()` instead
        of `router.push()` when clicked, so the navigation will not leave
        a history record. You can find more information about the [replace](https://router.vuejs.org/api/#replace)
        prop on the vue-router documentation.
      link (boolean):
        Designates that the component is a link. This is automatic when
        using the href or to prop.
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      nav (boolean):
        Reduces the width of v-list-item takes and adds a border radius.
      title (string, number, boolean):
        Generates a `v-list-item-title` component with the supplied value.
        Note that this overrides the native [`title`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/title)
        attribute, that must be set with `v-bind:title.attr` instead.
      disabled (boolean):
        Removes the ability to click or target the component.
      height (string, number):
        Sets the height for the component.
      value (any):
        The value used for selection. Obtained from [`v-list`](/api/v-list)'s
        `v-model:selected` when the item is selected.
      width (string, number):
        Sets the width for the component.
      theme (string):
        Specify a theme for this component and all of its children.
      exact (boolean):
        Exactly match the link. Without this, '/' will match every route.
        You can find more information about the [**exact** prop](https://router.vuejs.org/api/#exact)
        on the vue-router documentation.
      subtitle (string, number, boolean):
        Specify a subtitle text for the component.
      base_color (string):
        Sets the color of component when not focused.
      active_color (string):
        Deprecated, use `color` instead.
      active_class (string):
        The class applied to the component when it matches the current
        route. Find more information about the [active-class prop](https://router.vuejs.org/api/#active-class)
        on the [vue-router](https://router.vuejs.org/) documentation.
      lines (false, 'one', 'two', 'three'):
        The line declaration specifies the minimum height of the item
        and can also be controlled from v-list with the same prop.
      slim (boolean):
        Reduces the vertical padding or height of the v-treeview-item,
        making it more compact.
      prepend_gap (string, number):
        Sets the horizontal spacing between prepend slot and the main
        content. Also affects indent to ensure expected alignment of
        group children.
      border (string, number, boolean):
        Applies utility border classes to the component. To use it, you
        need to omit the `border-` prefix, (for example use `border-sm`
        as `border="sm"`).  Find a list of the built-in border classes
        on the [borders page](/styles/borders).
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean):
        Designates the **border-radius** applied to the component. You
        can use the predefined sizes **0**, **xs**, **sm**, **md**, **lg**,
        **xl**, **pill**, **circle**, and **shaped**, pass `true` for
        the component default. Since v4.1 you can also provide any valid
        CSS value (e.g. `8px`, `50%`, `1em`) or number (converted to
        `px`). Find more information on available border radius classes
        on the [Border Radius page](/styles/border-radius).
      tile (boolean):
        Removes any applied **border-radius** from the component.
      color (string):
        Applies specified color to the control when in an **active**
        state or **input-value** is **true** - supports utility colors
        (for example `success` or `purple`) or css color (`#033` or `rgba(255,
        0, 0, 0.5)`). Find a list of built-in classes on the [colors
        page](/styles/colors#material-colors),
      variant ('flat', 'text', 'elevated', 'tonal', 'outlined', 'plain'):
        Applies a distinct style to the component.
      append_icon (enum):
        Creates a [v-icon](/api/v-icon/) component after default content
        in the **append** slot.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      prepend_icon (enum):
        Creates a [v-icon](/api/v-icon/) component in the **prepend**
        slot before default content.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      active (boolean):
        Controls the **active** state of the item. This is typically
        used to highlight the component.
      loading (boolean):
        Places the v-treeview-item into a loading state.
      hide_actions (boolean):
        Hide the expand icon and loading indicator next to each item title.
      index (number):
        The index of the item within the treeview list.
      prepend_avatar (string):
        Prepends a [v-avatar](/components/avatars/) component in the
        **prepend** slot before default content.
      append_avatar (string):
        Appends a [v-avatar](/components/avatars/) component after default
        content in the **append** slot.
      to (enum):
        Denotes the target route of the link. You can find more information
        about the [**to** prop](https://router.vuejs.org/api/#to) on
        the vue-router documentation.

        Enum values: [
          string, RouteLocationAsRelativeGeneric, RouteLocationAsPathGeneric
        ]
      href (string):
        Designates the component as anchor and applies the **href** attribute.
      ripple (boolean, { class: string; keys: string[] }):
        Applies the [v-ripple](/directives/ripple) directive.
      has_custom_prepend (boolean):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VTreeviewItem.json))
      toggle_icon (enum):
        Allows customization of the icon used to toggle the expansion
        and collapse of treeview branches.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      tabindex (string, number):
        Controls the tabindex of the list item. When set, overrides the
        default tabindex behavior. Automatically set to -1 by VList when
        using `navigationStrategy="track"` to prevent Tab key navigation
        into items.
      indent_lines (('leaf', 'none', 'line', 'last-leaf', 'leaf-link')[]):
        Array of indent lines to render next to the item.
      toggleExpand (event):
        Emitted when the item is toggled to expand or collapse.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VTreeviewItem", children, **kwargs)
        self._attr_names += [
            "replace",
            "link",
            "tag",
            "nav",
            "title",
            "disabled",
            "height",
            "value",
            "width",
            "theme",
            "exact",
            "subtitle",
            ("base_color", "baseColor"),
            ("active_color", "activeColor"),
            ("active_class", "activeClass"),
            "lines",
            "slim",
            ("prepend_gap", "prependGap"),
            "border",
            "density",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "tile",
            "color",
            "variant",
            ("append_icon", "appendIcon"),
            ("prepend_icon", "prependIcon"),
            "active",
            "loading",
            ("hide_actions", "hideActions"),
            "index",
            ("prepend_avatar", "prependAvatar"),
            ("append_avatar", "appendAvatar"),
            "to",
            "href",
            "ripple",
            ("has_custom_prepend", "hasCustomPrepend"),
            ("toggle_icon", "toggleIcon"),
            "tabindex",
            ("indent_lines", "indentLines"),
        ]
        self._event_names += [
            "click",
            "toggleExpand",
        ]


class VValidation(HtmlElement):
    """
    Vuetify's VValidation component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-validation>`_.

    Args:
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      error (boolean):
        Puts the input in a manual error state.
      name (string):
        Sets the component's name attribute.
      disabled (boolean):
        Removes the ability to click or target the component.
      readonly (boolean):
        Puts input in readonly state.
      label (string):
        Sets the text of the [v-label](/api/v-label/) or [v-field-label](/api/v-field-label/)
        component.
      error_messages (string, string[]):
        Puts the input in an error state and passes through custom error
        messages. Will be combined with any validations that occur from
        the **rules** prop. This field will not trigger validation.
      max_errors (string, number):
        Control the maximum number of shown errors from validation.
      rules (enum):
        Accepts a mixed array of types `function`, `boolean` and `string`.
        Functions pass an input value as an argument and must return
        either `true` / `false` or a `string` containing an error message.
        The input field will enter an error state if a function returns
        (or any value in the array contains) `false` or is a `string`.

        Enum values: [
          (, string, boolean, PromiseLike<ValidationResult>, js_fn, false,
          true), js_fn, [string, any, string])[]
        ]
      validate_on (enum):
        Change what type of event triggers validation to run.

        Enum values: [
          'eager', 'lazy', 'blur', 'input', 'submit', 'invalid-input',
          'blur lazy', 'input lazy', 'submit lazy', 'invalid-input lazy',
          'blur eager', 'input eager', 'submit eager', 'invalid-input eager',
          'lazy blur', 'lazy input', 'lazy submit', 'lazy invalid-input',
          'eager blur', 'eager input', 'eager submit', 'eager invalid-input'
        ]
      validation_value (any):
        The value used when applying validation rules.
      focused (boolean):
        Forces a focused state styling on the component.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
      update_focused (event):
        Event that is emitted when the component's focus state changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VValidation", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "error",
            "name",
            "disabled",
            "readonly",
            "label",
            ("error_messages", "errorMessages"),
            ("max_errors", "maxErrors"),
            "rules",
            ("validate_on", "validateOn"),
            ("validation_value", "validationValue"),
            "focused",
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            ("update_focused", "update:focused"),
        ]


class VVideo(HtmlElement):
    """
    Vuetify's VVideo component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-video>`_.

    Args:
      type (string):
        Media file type (optional)
      error (boolean, MediaError):
        Puts the component in the manual error state.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      height (string, number):
        Sets the height for the component.
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      rounded (string, number, boolean, (string, number, false, true)[]):
        Applies a border radius to the video container and the controls.
        Accepts array of two values to customize elements separately.
      theme (string):
        Specify a theme for this component and all of its children.
      color (string):
        General color applied to icons and sliders.
      variant ('background', 'player'):
        Applies a distinct style to the component.
      src (string):
        Media file URL
      image (string):
        Apply a specific image as cover before the video is loaded.
      floating (boolean):
        Introduces visual spacing from the video boundaries.
      playing (boolean):
        Applies correct icon of the default play button.
      progress (number):
        Controls main slider value (0 ~ 100)
      eager (boolean):
        Silently loades the media file without waiting for user to click.
      aspect_ratio (string, number):
        Sets the aspect ratio for the playback, calculated as width/height.
      hide_overlay (boolean):
        Hide center play icon.
      track_color (string):
        Passed to the main slider `color` prop.
      autoplay (boolean):
        Starts loading the media file without waiting for user to click.
        Playback begins once enough data is loaded.
      muted (boolean):
        Hides volume control and disables the playback sound.
      no_fullscreen (boolean):
        Disable fullscreen and hide the default fullscreen button.
      start_at (string, number):
        Moves progress to the specified time (in seconds) once the media file is loaded.
      controls_transition (string, boolean, (TransitionProps & { component: any })):
        The reveal transition applied to the VVideoControls component
        once the media file is loaded.
      controls_variant ('default', 'hidden', 'tube', 'mini'):
        Variant passed to the VVideoControls component.
      controls_props (unknown):
        Pass props through to the `v-video-controls` component. Accepts
        an object with anything from [v-video-controls](/api/v-video-controls/#props)
        props, camelCase keys are recommended.
      background_color (string):
        Container background color.
      hide_play (boolean):
        Hides default play button.
      hide_volume (boolean):
        Hides default volume control.
      hide_fullscreen (boolean):
        Hides default fullscreen button.
      hide_progress_bar (boolean):
        Hides default progress bar.
      split_time (boolean):
        Splits time into elapsed and remaining on each side of the main slider.
      pills (boolean):
        Makes the container transparent and shows inner actions in separated boxes.
      detached (boolean):
        Moves the container below so it won't obstruct the video.
      duration (number):
        Total duration of the video used to calculate displayed time.
      volume (string, number):
        Volume value passed to the underlying control and slots.
      volume_props (Anchor):
        Props passed down to the VVideoVolume component.
      src_object (Blob, MediaStream, MediaSource):
        Sets the source of the video to a MediaStream, MediaSource, or
        Blob object. Useful for WebRTC streaming.
      error (event):
        Emits `true` when the video fails to load or `false` when user triggered retry.
      update_playing (event):
        Emitted when playing state changes.
      update_progress (event):
        Emitted when the internal playback progress changes.
      update_volume (event):
        Emitted when the volume changes.
      loaded (event):
        Emitted when the video has loaded and is ready to be played.
      update_error (event):
        MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree//packages/api-generator/src/locale/en/VVideo.json))
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VVideo", children, **kwargs)
        self._attr_names += [
            "type",
            "error",
            "density",
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "rounded",
            "theme",
            "color",
            "variant",
            "src",
            "image",
            "floating",
            "playing",
            "progress",
            "eager",
            ("aspect_ratio", "aspectRatio"),
            ("hide_overlay", "hideOverlay"),
            ("track_color", "trackColor"),
            "autoplay",
            "muted",
            ("no_fullscreen", "noFullscreen"),
            ("start_at", "startAt"),
            ("controls_transition", "controlsTransition"),
            ("controls_variant", "controlsVariant"),
            ("controls_props", "controlsProps"),
            ("background_color", "backgroundColor"),
            ("hide_play", "hidePlay"),
            ("hide_volume", "hideVolume"),
            ("hide_fullscreen", "hideFullscreen"),
            ("hide_progress_bar", "hideProgressBar"),
            ("split_time", "splitTime"),
            "pills",
            "detached",
            "duration",
            "volume",
            ("volume_props", "volumeProps"),
            ("src_object", "srcObject"),
        ]
        self._event_names += [
            "error",
            ("update_playing", "update:playing"),
            ("update_progress", "update:progress"),
            ("update_volume", "update:volume"),
            "loaded",
            ("update_error", "update:error"),
        ]


class VVideoControls(HtmlElement):
    """
    Vuetify's VVideoControls component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-video-controls>`_.

    Args:
      playing (boolean):
        Applies correct icon of the default play button.
      progress (number):
        Controls main slider value (0 ~ 100)
      theme (string):
        Specify a theme for this component and all of its children.
      density ('default', 'comfortable', 'compact'):
        Adjusts the vertical height used by the component.
      elevation (string, number):
        Designates an elevation applied to the component between 0 and
        5. You can find more information on the [elevation page](/styles/elevation).
      hover_elevation (string, number):
        Elevation level applied to the component upon hover (adds class
        with CSS `:hover` selector)
      color (string):
        General color applied to icons and sliders.
      variant ('default', 'hidden', 'tube', 'mini'):
        Applies a distinct style to the component.
      floating (boolean):
        Introduces visual spacing from the video boundaries.
      fullscreen (boolean):
        Applies correct icon on the default fullscreen button.
      track_color (string):
        Passed to the main slider `color` prop.
      background_color (string):
        Container background color.
      hide_play (boolean):
        Hides default play button.
      hide_volume (boolean):
        Hides default volume control.
      hide_fullscreen (boolean):
        Hides default fullscreen button.
      hide_progress_bar (boolean):
        Hides default progress bar.
      split_time (boolean):
        Splits time into elapsed and remaining on each side of the main slider.
      pills (boolean):
        Makes the container transparent and shows inner actions in separated boxes.
      detached (boolean):
        Moves the container below so it won't obstruct the video.
      duration (number):
        Total duration of the video used to calculate displayed time.
      volume (string, number):
        Volume value passed to the underlying control and slots.
      volume_props (    openOnClick: boolean    openOnHover: boolean    openOnFocus: boolean    closeOnContentClick: boolean    closeDelay: string | number    openDelay: string | number    locationStrategy: 'static' | 'connected' | <a href="https://github.com/vuetifyjs/vuetify/blob/master/packages/vuetify/src/components/VOverlay/locationStrategies.ts#L41-L45" target="_bla):
        Props passed down to the VVideoVolume component.
      update_playing (event):
        Emitted when the playing state changes.
      update_progress (event):
        Emitted when the playback progress changes.
      update_volume (event):
        Emitted when the volume value changes.
      skip (event):
        Emitted when a skip action is triggered.
      click_fullscreen (event):
        Emitted when the fullscreen button is clicked.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VVideoControls", children, **kwargs)
        self._attr_names += [
            "playing",
            "progress",
            "theme",
            "density",
            "elevation",
            ("hover_elevation", "hoverElevation"),
            "color",
            "variant",
            "floating",
            "fullscreen",
            ("track_color", "trackColor"),
            ("background_color", "backgroundColor"),
            ("hide_play", "hidePlay"),
            ("hide_volume", "hideVolume"),
            ("hide_fullscreen", "hideFullscreen"),
            ("hide_progress_bar", "hideProgressBar"),
            ("split_time", "splitTime"),
            "pills",
            "detached",
            "duration",
            "volume",
            ("volume_props", "volumeProps"),
        ]
        self._event_names += [
            ("update_playing", "update:playing"),
            ("update_progress", "update:progress"),
            ("update_volume", "update:volume"),
            "skip",
            ("click_fullscreen", "click:fullscreen"),
        ]


class VVideoVolume(HtmlElement):
    """
    Vuetify's VVideoVolume component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-video-volume>`_.

    Args:
      model_value (number):
        Volume value (0 ~ 100)
      inline (boolean):
        Display slider next to the icon. VMenu won't be displayed on
        click. Recomended to pair with **sliderProps** to configure slider
        width.
      label (string):
        Text to display in tooltip and passed to `aria-label`.
      direction ('vertical', 'horizontal'):
        Switch between horizontal and vertical slider.
      menu_props (unknown):
        Props passed to VMenu containing volume slider. Useful to adjust
        **location** and control menu alignment
      slider_props (enum):
        Selected props to customize volume slider.

        Enum values: [
          {  maxWidth: string, number  width: string, number  color: string
           disabled: boolean  thumbSize: string, number  trackColor: string}
        ]
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VVideoVolume", children, **kwargs)
        self._attr_names += [
            ("model_value", "modelValue"),
            "inline",
            "label",
            "direction",
            ("menu_props", "menuProps"),
            ("slider_props", "sliderProps"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
            "click",
        ]


class VVirtualScroll(HtmlElement):
    """
    Vuetify's VVirtualScroll component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-virtual-scroll>`_.

    Args:
      height (string, number):
        Height of the component as a css value/
      max_height (string, number):
        Sets the maximum height for the component.
      max_width (string, number):
        Sets the maximum width for the component.
      min_height (string, number):
        Sets the minimum height for the component.
      min_width (string, number):
        Sets the minimum width for the component.
      width (string, number):
        Sets the width for the component.
      items (unknown[]):
        The array of items to display.
      item_key (SelectItemKey):
        Should point to a property with a unique value for each item,
        if not set then item index will be used as a key which may result
        in unnecessary re-renders.
      renderless (boolean):
        Disables default component rendering functionality. The parent
        node must be [a positioned element](https://developer.mozilla.org/en-US/docs/Web/CSS/position#types_of_positioning),
        e.g. using `position: relative;`
      item_height (string, number):
        Height in pixels of each item to display.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VVirtualScroll", children, **kwargs)
        self._attr_names += [
            "height",
            ("max_height", "maxHeight"),
            ("max_width", "maxWidth"),
            ("min_height", "minHeight"),
            ("min_width", "minWidth"),
            "width",
            "items",
            ("item_key", "itemKey"),
            "renderless",
            ("item_height", "itemHeight"),
        ]
        self._event_names += []


class VWindow(HtmlElement):
    """
    Vuetify's VWindow component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-window>`_.

    Args:
      tag (string, js_fn, FunctionalComponent):
        Specify a custom tag used on the root element.
      reverse (boolean):
        Reverse the normal transition direction.
      disabled (boolean):
        Removes the ability to click or target the component.
      theme (string):
        Specify a theme for this component and all of its children.
      mandatory (boolean, 'force'):
        Forces at least one item to always be selected (if available).
      model_value (unknown):
        The v-model value of the component. If component supports the
        **multiple** prop, this defaults to an empty array.
      direction ('horizontal', 'vertical'):
        The transition direction when changing windows.
      prev_icon (enum):
        Icon used for the "prev" button if `show-arrows` is `true`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      next_icon (enum):
        Icon used for the "next" button if `show-arrows` is `true`.

        Enum values: [
          string, js_fn, FunctionalComponent, (string, [string, number])[]
        ]
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      show_arrows (string, boolean):
        Display the "next" and "prev" buttons.
      continuous (boolean):
        If `true`, window will "wrap around" from the last item to the
        first, and from the first item to the last.
      touch (TouchHandlers):
        Provide a custom **left** and **right** function when swiped left or right.
      crossfade (boolean):
        Enables crossfade transition.
      transition_duration (number):
        Overrides transition duration. Does not work in firefox, safari
        <18, or with `prefers-reduced-motion: reduce`.
      vertical_arrows (boolean, 'left', 'right'):
        Displays the navigation arrows vertically instead of horizontally.
      update_modelValue (event):
        Event that is emitted when the component's model changes.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VWindow", children, **kwargs)
        self._attr_names += [
            "tag",
            "reverse",
            "disabled",
            "theme",
            "mandatory",
            ("model_value", "modelValue"),
            "direction",
            ("prev_icon", "prevIcon"),
            ("next_icon", "nextIcon"),
            ("selected_class", "selectedClass"),
            ("show_arrows", "showArrows"),
            "continuous",
            "touch",
            "crossfade",
            ("transition_duration", "transitionDuration"),
            ("vertical_arrows", "verticalArrows"),
        ]
        self._event_names += [
            ("update_modelValue", "update:modelValue"),
        ]


class VWindowItem(HtmlElement):
    """
    Vuetify's VWindowItem component.
    See more `info and examples <https://v4.vuetifyjs.com/api/v-window-item>`_.

    Args:
      disabled (boolean):
        Prevents the item from becoming active when using the "next"
        and "prev" buttons or the `toggle` method.
      value (any):
        The value used when the component is selected in a group. If
        not provided, a unique ID will be used.
      selected_class (string):
        Configure the active CSS class applied when an item is selected.
      transition (string, boolean):
        The transition used when the component progressing through items.
        Can be one of the [built in](/styles/transitions/) or custom
        transition.
      eager (boolean):
        Forces the component's content to render when it mounts. This
        is useful if you have content that will not be rendered in the
        DOM that you want crawled for SEO.
      reverse_transition (string, boolean):
        Sets the reverse transition.
      group_selected (event):
        Event that is emitted when an item is selected within a group.
    """

    def __init__(self, children=None, **kwargs):
        super().__init__("VWindowItem", children, **kwargs)
        self._attr_names += [
            "disabled",
            "value",
            ("selected_class", "selectedClass"),
            "transition",
            "eager",
            ("reverse_transition", "reverseTransition"),
        ]
        self._event_names += [
            ("group_selected", "group:selected"),
        ]
