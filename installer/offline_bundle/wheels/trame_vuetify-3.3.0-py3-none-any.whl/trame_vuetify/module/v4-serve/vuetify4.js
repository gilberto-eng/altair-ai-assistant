/*!
* Vuetify v4.2.1
* Forged by John Leider
* Released under the MIT License.
*/
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?t(exports,require("vue")):"function"==typeof define&&define.amd?define(["exports","vue"],t):t((e="undefined"!=typeof globalThis?globalThis:e||self).Vuetify={},e.Vue)}(this,function(e,t){"use strict"
function a(e){t.warn(`Vuetify: ${e}`)}function l(e){t.warn(`Vuetify error: ${e}`)}function n(e,a){a=Array.isArray(a)?a.slice(0,-1).map(e=>`'${e}'`).join(", ")+` or '${a.at(-1)}'`:`'${a}'`,t.warn(`[Vuetify UPGRADE] '${e}' is deprecated, use ${a} instead.`)}const o=/[\u0300-\u036F]/g,r=/ς/g
function i(e){return e.toLowerCase().replace(r,"σ")}const s={ł:"l",ø:"o",đ:"d",ð:"d",þ:"th",ħ:"h",ŧ:"t",ŋ:"n",ß:"ss",æ:"ae",œ:"oe",ı:"i",Ł:"L",Ø:"O",Đ:"D",Ð:"D",Þ:"Th",Ħ:"H",Ŧ:"T",Ŋ:"N",ẞ:"Ss",Æ:"Ae",Œ:"Oe"},u=new RegExp(`[${Object.keys(s).join("")}]`,"g")
function c(e){return e.normalize("NFD").replace(o,"").replace(u,e=>s[e])}function d(e,t,a){const l=[]
let n=e.indexOf(t)
for(;-1!==n&&(l.push([n,n+t.length]),a);)n=e.indexOf(t,n+t.length)
return l}function v(e,t,a){const l=e[t]
let n=e[a]
if(a>0&&e[a]===e[a-1]){let t=a
const l=e[a]
for(;t<e.length&&e[t]===l;)t++
n=e[t]}return[l,n]}function p(e,t,a,l,n,o){const r=l?c(t):t,s=a?i(r):r
if(0===s.length)return[]
if(!n){if(!a)return d(e,s,o)
const t=i(e)
if(t.length===e.length)return d(t,s,o)}const{folded:u,map:p}=function(e,t,a){let l=""
const n=[]
let o=0
for(const r of e){const e=t?i(r):r,s=a?c(e):e
l+=s
for(let e=0;e<s.length;e++)n.push(o)
o+=r.length}return n.push(e.length),{folded:l,map:n}}(e,a,n)
return function(e,t){const a=[]
for(const[l,n]of e){const e=v(t,l,n),o=a.at(-1)
o&&o[0]===e[0]&&o[1]===e[1]||a.push(e)}return a}(d(u,s,o),p)}function m(e,t,a={}){const{ignoreCase:l=!1,ignoreAccents:n=!1,matchAll:o=!1}=a,r=!0===n||"query"===n,i=!0===n||"target"===n
if(r===i)return p(e,t,l,r,i,o)
const s=function(e,t){const a=[...e,...t].toSorted((e,t)=>e[0]-t[0]||e[1]-t[1]),l=[]
for(const e of a){const t=l.at(-1)
t&&e[0]<t[1]||l.push(e)}return l}(p(e,t,l,!1,!1,!0),p(e,t,l,r,i,!0))
return o?s:s.slice(0,1)}function f(e){return"function"==typeof e}function g(e){return"string"==typeof e}function h(e){return"number"==typeof e}function y(e){return"boolean"==typeof e}function b(e){return"object"==typeof e&&null!==e&&!Array.isArray(e)}function w(e){return Array.isArray(e)}function V(e){return"undefined"!=typeof Element&&e instanceof Element}function S(e){return null===e}function k(e){return null==e}function x(e){return void 0===e}function N(e){return"symbol"==typeof e}function C(e,t=0){return Array.from({length:e},(e,a)=>t+a)}const E="undefined"!=typeof window,I=E&&"IntersectionObserver"in window,A=E&&("ontouchstart"in window||window.navigator.maxTouchPoints>0),P=E&&"EyeDropper"in window,_=E&&"matchMedia"in window&&f(window.matchMedia),R=()=>_&&window.matchMedia("(prefers-reduced-motion: reduce)").matches,D=E&&CSS?.supports?.("-webkit-backdrop-filter","none")
function B(e,t,a){const l=t.length-1
if(l<0)return x(e)?a:e
for(let n=0;n<l;n++){if(k(e))return a
e=e[t[n]]}return k(e)||void 0===e[t[l]]?a:e[t[l]]}function T(e,t,a){return!k(e)&&t&&g(t)?x(e[t])?B(e,(t=(t=t.replace(/\[(\w+)\]/g,".$1")).replace(/^\./,"")).split("."),a):e[t]:a}function F(e,t,a){if(!0===t)return x(e)?a:e
if(k(t)||y(t))return a
if(e!==Object(e)){if(!f(t))return a
const l=t(e,a)
return void 0===l?a:l}if(g(t))return T(e,t,a)
if(Array.isArray(t))return B(e,t,a)
if(!f(t))return a
const l=t(e,a)
return void 0===l?a:l}function $(e){return g(e)&&e.endsWith("%")}function M(e,t=0){return $(e)?parseFloat(e)/100*t:parseFloat(String(e))||0}function z(e,t="px"){if(k(e)||""===e)return
const a=Number(e)
return isNaN(a)?String(e):isFinite(a)?`${a}${t}`:void 0}function L(e){let t
return!(!e||"object"!=typeof e||(t=Object.getPrototypeOf(e))!==Object.prototype&&t)}function O(e){if(e&&"$el"in e){const t=e.$el
return t?.nodeType===Node.TEXT_NODE?t.nextElementSibling:t}return e}const j=Object.freeze({enter:"Enter",tab:"Tab",delete:"Delete",esc:"Escape",space:"Space",up:"ArrowUp",down:"ArrowDown",left:"ArrowLeft",right:"ArrowRight",end:"End",home:"Home",del:"Delete",backspace:"Backspace",insert:"Insert",pageup:"PageUp",pagedown:"PageDown",shift:"Shift"})
function H(e){return Object.keys(e)}function W(e,t){return t.every(t=>e.hasOwnProperty(t))}function U(e,t){const a={}
for(const l of t)Object.prototype.hasOwnProperty.call(e,l)&&(a[l]=e[l])
return a}function Y(e,t,a){const l=Object.create(null),n=Object.create(null)
for(const a in e)t.some(e=>e instanceof RegExp?e.test(a):e===a)?l[a]=e[a]:n[a]=e[a]
return[l,n]}function G(e,t){const a={...e}
return t.forEach(e=>delete a[e]),a}const K=/^on[^a-z]/,q=e=>K.test(e),X=["onAfterscriptexecute","onAnimationcancel","onAnimationend","onAnimationiteration","onAnimationstart","onAuxclick","onBeforeinput","onBeforescriptexecute","onChange","onClick","onCompositionend","onCompositionstart","onCompositionupdate","onContextmenu","onCopy","onCut","onDblclick","onFocusin","onFocusout","onFullscreenchange","onFullscreenerror","onGesturechange","onGestureend","onGesturestart","onGotpointercapture","onInput","onKeydown","onKeypress","onKeyup","onLostpointercapture","onMousedown","onMousemove","onMouseout","onMouseover","onMouseup","onMousewheel","onPaste","onPointercancel","onPointerdown","onPointerenter","onPointerleave","onPointermove","onPointerout","onPointerover","onPointerup","onReset","onSelect","onSubmit","onTouchcancel","onTouchend","onTouchmove","onTouchstart","onTransitioncancel","onTransitionend","onTransitionrun","onTransitionstart","onWheel"],Z=["ArrowUp","ArrowDown","ArrowRight","ArrowLeft","Enter","Escape","Tab"," "]
function Q(e){return e.isComposing&&Z.includes(e.key)}function J(e){const[t,a]=Y(e,[K]),l=G(t,X),[n,o]=Y(a,["class","style","id","inert",/^data-/])
return Object.assign(n,t),Object.assign(o,l),[n,o]}function ee(e){return k(e)?[]:Array.isArray(e)?e:[e]}function te(e,a){let l=0
const n=(...n)=>{clearTimeout(l),l=setTimeout(()=>e(...n),t.unref(a))}
return n.clear=()=>{clearTimeout(l)},n.immediate=e,n}function ae(e,t=0,a=1){return Math.max(t,Math.min(a,e))}function le(e){const t=e.toString().trim()
return t.includes(".")?t.length-t.indexOf(".")-1:0}function ne(e,t,a="0"){return e+a.repeat(Math.max(0,t-e.length))}function oe(e,t,a="0"){return a.repeat(Math.max(0,t-e.length))+e}function re(e,t=1e3){if(e<t)return`${e} B`
const a=1024===t?["Ki","Mi","Gi"]:["k","M","G"]
let l=-1
for(;Math.abs(e)>=t&&l<a.length-1;)e/=t,++l
return`${e.toFixed(1)} ${a[l]}B`}function ie(e={},t={},a,l){const n={}
for(const t in e)n[t]=e[t]
for(const o in t){const r=t[o]
if(l&&!l(o,r))continue
const i=e[o]
L(i)&&L(r)?n[o]=ie(i,r,a,l):n[o]=r}return n}function se(e){return e.map(e=>e.type===t.Fragment?se(e.children):e).flat()}function ue(e=""){if(ue.cache.has(e))return ue.cache.get(e)
const t=e.replace(/[^a-z]/gi,"-").replace(/\B([A-Z])/g,"-$1").toLowerCase()
return ue.cache.set(e,t),t}function ce(e,t){if(!t||"object"!=typeof t)return[]
if(Array.isArray(t))return t.map(t=>ce(e,t)).flat(1)
if(t.suspense)return ce(e,t.ssContent)
if(Array.isArray(t.children))return t.children.map(t=>ce(e,t)).flat(1)
if(t.component){if(Object.getOwnPropertyDescriptor(t.component.provides,e))return[t.component]
if(t.component.subTree)return ce(e,t.component.subTree).flat(1)}return[]}ue.cache=new Map
class de{#e=[]
#t=0
constructor(e){this.size=e}get isFull(){return this.#e.length===this.size}push(e){this.#e[this.#t]=e,this.#t=(this.#t+1)%this.size}values(){return this.#e.slice(this.#t).concat(this.#e.slice(0,this.#t))}clear(){this.#e.length=0,this.#t=0}}function ve(e){const a=t.reactive({})
t.watchEffect(()=>{const t=e()
for(const e in t)a[e]=t[e]},{flush:"sync"})
const l={}
for(const e in a)l[e]=t.toRef(()=>a[e])
return l}function pe(e,t){return e.includes(t)}function me(e){return e[2].toLowerCase()+e.slice(3)}const fe=()=>[Function,Array]
function ge(e,a){return!!(e[a="on"+t.capitalize(a)]||e[`${a}Once`]||e[`${a}Capture`]||e[`${a}OnceCapture`]||e[`${a}CaptureOnce`])}function he(e,...t){if(Array.isArray(e))for(const a of e)a(...t)
else f(e)&&e(...t)}function ye(e,t=!0){const a=["button","[href]",'input:not([type="hidden"])',"select","textarea","details:not(:has(> summary))","details > summary","[tabindex]",'[contenteditable]:not([contenteditable="false"])',"audio[controls]","video[controls]"].map(e=>`${e}${t?':not([tabindex="-1"])':""}:not([disabled], [inert])`).join(", ")
let n
try{n=[...e.querySelectorAll(a)]}catch(e){return l(String(e)),[]}return n.filter(e=>!e.closest("[inert]")).filter(e=>!!e.offsetParent||e.getClientRects().length>0).filter(e=>!e.parentElement?.closest("details:not([open])")||"SUMMARY"===e.tagName&&"DETAILS"===e.parentElement?.tagName)}function be(){let e=document.activeElement
for(;e?.shadowRoot?.activeElement;)e=e.shadowRoot.activeElement
return e}function we(e,t,a){let l,n=e.indexOf(be())
if(n<0){const a="prev"===t?e.at(-1):e[0],l=a?.getAttribute("role")??"";["option","listbox"].includes(l)&&(n=e.findIndex(e=>"option"===e.getAttribute("role")&&"true"===e.getAttribute("aria-selected")))}const o="next"===t?1:-1
do{n+=o,l=e[n]}while((!l||!l.offsetParent||!(a?.(l)??1))&&n<e.length&&n>=0)
return l}function Ve(e,t,a){const l=ye(e)
if(k(t)){const t=be()
e!==t&&e.contains(t)||l[0]?.focus(a)}else if("first"===t)l[0]?.focus(a)
else if("last"===t)l.at(-1)?.focus(a)
else if(h(t))l[t]?.focus(a)
else{const n=we(l,t)
n?n.focus(a):Ve(e,"next"===t?"first":"last",a)}}function Se(e){return S(e)||x(e)||g(e)&&""===e.trim()}function ke(){}function xe(e,t){if(!(E&&"undefined"!=typeof CSS&&void 0!==CSS.supports&&CSS.supports(`selector(${t})`)))return null
try{return!!e&&e.matches(t)}catch(e){return null}}function Ne(e){return e.some(e=>!t.isVNode(e)||e.type!==t.Comment&&(e.type!==t.Fragment||Ne(e.children)))?e:null}function Ce(e,t,a){return e?.(t)??a?.(t)}function Ee(){const e=t.shallowRef(),a=t=>{e.value=t}
return Object.defineProperty(a,"value",{enumerable:!0,get:()=>e.value,set:t=>e.value=t}),Object.defineProperty(a,"el",{enumerable:!0,get:()=>O(e.value)}),a}function Ie(e){const t=1===e.key.length,a=!e.ctrlKey&&!e.metaKey&&!e.altKey
return t&&a}function Ae(e){return g(e)||h(e)||y(e)||"bigint"==typeof e}function Pe(e){return"\\^$*+?.()|{}[]".includes(e)?`\\${e}`:e}function _e(e){return e.replace(/−/g,"-")}function Re(e,t,a){const l=new RegExp(`[\\d\\-${Pe(a)}]`),n=_e(e).split("").filter(e=>l.test(e)).filter((e,t,l)=>0===t&&/[-]/.test(e)||e===a&&t===l.indexOf(e)||/\d/.test(e)).join("")
if(0===t)return n.split(a)[0]
const o=new RegExp(`${Pe(a)}\\d`)
if(h(t)&&o.test(n)){const e=n.split(a)
return[e[0],e[1].substring(0,t)].join(a)}return n}function De(e){const a={}
for(const l in e)a[t.camelize(l)]=e[l]
return a}function Be(e){const a=e=>Array.isArray(e)?e.map(e=>a(e)):t.isRef(e)||t.isReactive(e)||t.isProxy(e)?a(t.toRaw(e)):L(e)?Object.keys(e).reduce((t,l)=>(t[l]=a(e[l]),t),{}):e
return a(e)}const Te=["top","bottom"],Fe=["start","end","left","right"]
function $e(e,t){let[a,l]=e.split(" ")
return l||(l=pe(Te,a)?"start":pe(Fe,a)?"top":"center"),{side:Me(a,t),align:Me(l,t)}}function Me(e,t){return"start"===e?t?"right":"left":"end"===e?t?"left":"right":e}function ze(e){return{side:{center:"center",top:"bottom",bottom:"top",left:"right",right:"left"}[e.side],align:e.align}}function Le(e){return{side:e.side,align:{center:"center",top:"bottom",bottom:"top",left:"right",right:"left"}[e.align]}}function Oe(e){return{side:e.align,align:e.side}}function je(e){return pe(Te,e.side)?"y":"x"}class He{constructor(e){if(V(e)){const t=document.body.currentCSSZoom??1,a=1+(1-t)/t,{x:l,y:n,width:o,height:r}=e.getBoundingClientRect()
this.x=l*a,this.y=n*a,this.width=o*a,this.height=r*a}else this.x=e.x,this.y=e.y,this.width=e.width,this.height=e.height}get top(){return this.y}get bottom(){return this.y+this.height}get left(){return this.x}get right(){return this.x+this.width}}function We(e,t){return{x:{before:Math.max(0,t.left-e.left),after:Math.max(0,e.right-t.right)},y:{before:Math.max(0,t.top-e.top),after:Math.max(0,e.bottom-t.bottom)}}}function Ue(e){if(Array.isArray(e)){const t=document.body.currentCSSZoom??1,a=1+(1-t)/t
return new He({x:e[0]*a,y:e[1]*a,width:0*a,height:0*a})}return new He(e)}function Ye(e){if(e===document.documentElement){if(visualViewport){const e=document.body.clientWidth,t=document.body.currentCSSZoom??(e?document.documentElement.clientWidth/e:1)
return new He({x:visualViewport.scale>1||D?0:visualViewport.offsetLeft,y:visualViewport.scale>1||D?0:visualViewport.offsetTop,width:document.documentElement.clientWidth/t,height:document.documentElement.clientHeight/t})}return new He({x:0,y:0,width:document.documentElement.clientWidth,height:document.documentElement.clientHeight})}return new He(e)}function Ge(e){const t=new He(e),a=getComputedStyle(e),l=a.transform
if(l){let n,o,r,i,s
if(l.startsWith("matrix3d("))n=l.slice(9,-1).split(/, /),o=Number(n[0]),r=Number(n[5]),i=Number(n[12]),s=Number(n[13])
else{if(!l.startsWith("matrix("))return new He(t)
n=l.slice(7,-1).split(/, /),o=Number(n[0]),r=Number(n[3]),i=Number(n[4]),s=Number(n[5])}const u=a.transformOrigin,c=t.x-i-(1-o)*parseFloat(u),d=t.y-s-(1-r)*parseFloat(u.slice(u.indexOf(" ")+1)),v=o?t.width/o:e.offsetWidth+1,p=r?t.height/r:e.offsetHeight+1
return new He({x:c,y:d,width:v,height:p})}return new He(t)}function Ke(e,t,a){if(void 0===e.animate)return{finished:Promise.resolve()}
let l
try{l=e.animate(t,a)}catch(e){return{finished:Promise.resolve()}}return void 0===l.finished&&(l.finished=new Promise(e=>{l.onfinish=()=>{e(l)}})),l}const qe=new WeakMap
const Xe=2.4,Ze=.2126729,Qe=.7151522,Je=.072175,et=.03,tt=12.82051282051282,at=.06
function lt(e,t){const a=(e.r/255)**Xe,l=(e.g/255)**Xe,n=(e.b/255)**Xe,o=(t.r/255)**Xe,r=(t.g/255)**Xe,i=(t.b/255)**Xe
let s,u=a*Ze+l*Qe+n*Je,c=o*Ze+r*Qe+i*Je
if(u<=et&&(u+=(et-u)**1.45),c<=et&&(c+=(et-c)**1.45),Math.abs(c-u)<5e-4)return 0
if(c>u){const e=1.25*(c**.55-u**.58)
s=e<.001?0:e<.078?e-e*tt*at:e-at}else{const e=1.25*(c**.62-u**.57)
s=e>-.001?0:e>-.078?e-e*tt*at:e+at}return 100*s}const nt=.20689655172413793,ot=e=>e>nt**3?Math.cbrt(e):e/(3*nt**2)+4/29,rt=e=>e>nt?e**3:3*nt**2*(e-4/29)
function it(e){const t=ot,a=t(e[1])
return[116*a-16,500*(t(e[0]/.95047)-a),200*(a-t(e[2]/1.08883))]}function st(e){const t=rt,a=(e[0]+16)/116
return[.95047*t(a+e[1]/500),t(a),1.08883*t(a-e[2]/200)]}const ut=[[3.2406,-1.5372,-.4986],[-.9689,1.8758,.0415],[.0557,-.204,1.057]],ct=e=>e<=.0031308?12.92*e:1.055*e**(1/2.4)-.055,dt=[[.4124,.3576,.1805],[.2126,.7152,.0722],[.0193,.1192,.9505]],vt=e=>e<=.04045?e/12.92:((e+.055)/1.055)**2.4
function pt(e){const t=Array(3),a=ct,l=ut
for(let n=0;n<3;++n)t[n]=Math.round(255*ae(a(l[n][0]*e[0]+l[n][1]*e[1]+l[n][2]*e[2])))
return{r:t[0],g:t[1],b:t[2]}}function mt({r:e,g:t,b:a}){const l=[0,0,0],n=vt,o=dt
e=n(e/255),t=n(t/255),a=n(a/255)
for(let n=0;n<3;++n)l[n]=o[n][0]*e+o[n][1]*t+o[n][2]*a
return l}function ft(e){return!!e&&/^(#|var\(--|(rgb|hsl)a?\()/.test(e)}const gt=/^(?<fn>(?:rgb|hsl)a?)\((?<values>.+)\)/,ht={rgb:(e,t,a,l)=>({r:e,g:t,b:a,a:l}),rgba:(e,t,a,l)=>({r:e,g:t,b:a,a:l}),hsl:(e,t,a,l)=>wt({h:e,s:t,l:a,a:l}),hsla:(e,t,a,l)=>wt({h:e,s:t,l:a,a:l}),hsv:(e,t,a,l)=>bt({h:e,s:t,v:a,a:l}),hsva:(e,t,a,l)=>bt({h:e,s:t,v:a,a:l})}
function yt(e){if(h(e))return(isNaN(e)||e<0||e>16777215)&&a(`'${e}' is not a valid hex color`),{r:(16711680&e)>>16,g:(65280&e)>>8,b:255&e}
if(g(e)&&gt.test(e)){const{groups:t}=e.match(gt),{fn:a,values:l}=t,n=l.split(/,\s*|\s*\/\s*|\s+/).map((e,t)=>e.endsWith("%")||t>0&&t<3&&["hsl","hsla","hsv","hsva"].includes(a)?parseFloat(e)/100:parseFloat(e))
return ht[a](...n)}if(g(e)){let t=e.startsWith("#")?e.slice(1):e;[3,4].includes(t.length)?t=t.split("").map(e=>e+e).join(""):[6,8].includes(t.length)||a(`'${e}' is not a valid hex(a) color`)
const l=parseInt(t,16)
return(isNaN(l)||l<0||l>4294967295)&&a(`'${e}' is not a valid hex(a) color`),It(t)}if(b(e)){if(W(e,["r","g","b"]))return e
if(W(e,["h","s","l"]))return bt(kt(e))
if(W(e,["h","s","v"]))return bt(e)}throw new TypeError(`Invalid color: ${k(e)?e:String(e)||e.constructor.name}\nExpected #hex, #hexa, rgb(), rgba(), hsl(), hsla(), object or number`)}function bt(e){const{h:t,s:a,v:l,a:n}=e,o=e=>{const n=(e+t/60)%6
return l-l*a*Math.max(Math.min(n,4-n,1),0)},r=[o(5),o(3),o(1)].map(e=>Math.round(255*e))
return{r:r[0],g:r[1],b:r[2],a:n}}function wt(e){return bt(kt(e))}function Vt(e){if(!e)return{h:0,s:1,v:1,a:1}
const t=e.r/255,a=e.g/255,l=e.b/255,n=Math.max(t,a,l),o=Math.min(t,a,l)
let r=0
n!==o&&(n===t?r=60*(0+(a-l)/(n-o)):n===a?r=60*(2+(l-t)/(n-o)):n===l&&(r=60*(4+(t-a)/(n-o)))),r<0&&(r+=360)
const i=[r,0===n?0:(n-o)/n,n]
return{h:i[0],s:i[1],v:i[2],a:e.a}}function St(e){const{h:t,s:a,v:l,a:n}=e,o=l-l*a/2
return{h:t,s:1===o||0===o?0:(l-o)/Math.min(o,1-o),l:o,a:n}}function kt(e){const{h:t,s:a,l,a:n}=e,o=l+a*Math.min(l,1-l)
return{h:t,s:0===o?0:2-2*l/o,v:o,a:n}}function xt({r:e,g:t,b:a,a:l}){return h(l)?`rgb(${e}, ${t}, ${a}, ${l})`:`rgb(${e}, ${t}, ${a})`}function Nt(e){return xt(bt(e))}function Ct(e){const t=Math.round(e).toString(16)
return("00".substr(0,2-t.length)+t).toUpperCase()}function Et({r:e,g:t,b:a,a:l}){return`#${[Ct(e),Ct(t),Ct(a),h(l)?Ct(Math.round(255*l)):""].join("")}`}function It(e){e=function(e){e.startsWith("#")&&(e=e.slice(1))
e=e.replace(/([^0-9a-f])/gi,"F"),(3===e.length||4===e.length)&&(e=e.split("").map(e=>e+e).join(""))
6!==e.length&&(e=ne(ne(e,6),8,"F"))
return e}(e)
let[t,a,l,n]=function(e,t=1){const a=[]
let l=0
for(;l<e.length;)a.push(e.substr(l,t)),l+=t
return a}(e,2).map(e=>parseInt(e,16))
return n=h(n)?n/255:n,{r:t,g:a,b:l,a:n}}function At(e){return Et(bt(e))}function Pt(e,t){const a=it(mt(e))
return a[0]=a[0]+10*t,pt(st(a))}function _t(e,t){const a=it(mt(e))
return a[0]=a[0]-10*t,pt(st(a))}function Rt(e){return mt(yt(e))[1]}function Dt(e,t){const a=Rt(e),l=Rt(t)
return(Math.max(a,l)+.05)/(Math.min(a,l)+.05)}function Bt(e){const t=Math.abs(lt(yt(0),yt(e)))
return Math.abs(lt(yt(16777215),yt(e)))>Math.min(t,50)}function Tt(e,t){return a=>Object.keys(e).reduce((l,n)=>{const o=b(e[n])?e[n]:{type:e[n]}
return l[n]=a&&n in a?{...o,default:a[n]}:o,t&&!l[n].source&&(l[n].source=t),l},{})}const Ft=Tt({class:[String,Array,Object],style:{type:[String,Array,Object],default:null}},"component")
function $t(e,a){const l=t.getCurrentInstance()
if(!l)throw new Error(`[Vuetify] ${e} must be called from inside a setup function`)
return l}function Mt(e="composables"){const t=$t(e).type
return ue(t?.aliasName||t?.name)}function zt(e,t=$t("injectSelf")){const{provides:a}=t
if(a&&e in a)return a[e]}const Lt=Symbol.for("vuetify:defaults"),Ot=Symbol.for("vuetify:defaults:root")
function jt(){const e=t.inject(Lt)
if(!e)throw new Error("[Vuetify] Could not find defaults instance")
return e}function Ht(e,a){const l=jt(),n=t.inject(Ot,null),o=t.ref(e),r=t.computed(()=>{if(t.unref(a?.disabled))return l.value
const e=t.unref(a?.scoped),r=t.unref(a?.reset),i=t.unref(a?.root)
if(!o.value&&!(e||r||i))return l.value
let s=ie(o.value,{prev:l.value})
if(e)return s
if(r||i){const e=Number(r||1/0),t=g(i)?s.prev?.[i]:void 0
i&&n?.value&&(s=n.value)
for(let t=0;t<=e&&(s&&"prev"in s);t++)s=s.prev
return s&&t&&(s=ie(ie(s,{prev:s}),t)),s}return s.prev?ie(s.prev,s,void 0,(e,t)=>void 0!==t):s})
return t.provide(Lt,r),r}function Wt(e){const a=$t("injectComponentDefaults")
return t.toRef(()=>zt(Lt,a)?.value?.[e])}function Ut(e){const a=$t("injectNestedDefaults"),l=jt(),n=a.props._as??a.type.name
return t.toRef(()=>l.value?.[n]?.[e])}function Yt(e={},a,l=jt()){const n=$t("useDefaults")
if(!(a=a??n.type.name??n.type.__name))throw new Error("[Vuetify] Could not determine component name")
const o=t.computed(()=>l.value?.[e._as??a]),r=new Proxy(e,{get(e,t){const a=Reflect.get(e,t)
if("class"===t||"style"===t)return[o.value?.[t],a].filter(e=>null!=e)
if(function(e,t){return e.props&&(void 0!==e.props[t]||void 0!==e.props[ue(t)])}(n.vnode,t))return a
const r=o.value?.[t]
if(void 0!==r)return r
const i=l.value?.global?.[t]
return void 0!==i?i:a}}),i=t.shallowRef()
return t.watchEffect(()=>{if(o.value){const e=Object.entries(o.value).filter(([e])=>e.startsWith(e[0].toUpperCase()))
i.value=e.length?Object.fromEntries(e):void 0}else i.value=void 0}),{props:r,provideSubDefaults:function(){const e=zt(Lt,n)
t.provide(Lt,t.computed(()=>i.value?ie(e?.value??{},i.value):e?.value))}}}function Gt(e){if(e._setup=e._setup??e.setup,!e.name)return a("The component is missing an explicit name, unable to generate default prop value"),e
if(e._setup){e.props=Tt(e.props??{},e.name)()
const t=Object.keys(e.props).filter(e=>"class"!==e&&"style"!==e)
e.filterProps=function(e){return U(e,t)},e.props._as=String,e.setup=function(t,a){const l=jt()
if(!l.value)return e._setup(t,a)
const{props:n,provideSubDefaults:o}=Yt(t,t._as??e.name,l),r=e._setup(n,a)
return o(),r}}return e}function Kt(e=!0){return a=>(e?Gt:t.defineComponent)(a)}function qt(e,a="div",l){return Kt()({name:l??t.capitalize(t.camelize(e.replace(/__/g,"-"))),props:{tag:{type:String,default:a},...Ft()},setup:(a,{slots:l})=>()=>t.h(a.tag,{class:[e,a.class],style:a.style},l.default?.())})}function Xt(e,t,a=new WeakMap){if(e===t)return!0
if(e instanceof Date&&t instanceof Date&&e.getTime()!==t.getTime())return!1
if(e!==Object(e)||t!==Object(t))return!1
const l=Object.keys(e)
if(l.length!==Object.keys(t).length)return!1
const n=function(e,t,a){if(!a||Ae(e)||Ae(t))return null
const l=a.get(e)?.get(t)
if(y(l))return l
const n=a.get(t)?.get(e)
return y(n)?n:null}(e,t,a)
return n||(function(e,t,a,l){if(!a||Ae(e)||Ae(t))return
const n=a.get(e)
if(n)n.set(t,l)
else{const n=new WeakMap
n.set(t,l),a.set(e,n)}}(e,t,a,!0),l.every(l=>Xt(e[l],t[l],a)))}function Zt(e){if(!f(e.getRootNode)){for(;e.parentNode;)e=e.parentNode
return e!==document?null:document}const t=e.getRootNode()
return t!==document&&t.getRootNode({composed:!0})!==document?null:t}const Qt="cubic-bezier(0.4, 0, 0.2, 1)",Jt="cubic-bezier(0.0, 0, 0.2, 1)",ea="cubic-bezier(0.4, 0, 1, 1)",ta={linear:e=>e,easeInQuad:e=>e**2,easeOutQuad:e=>e*(2-e),easeInOutQuad:e=>e<.5?2*e**2:(4-2*e)*e-1,easeInCubic:e=>e**3,easeOutCubic:e=>--e**3+1,easeInOutCubic:e=>e<.5?4*e**3:(e-1)*(2*e-2)*(2*e-2)+1,easeInQuart:e=>e**4,easeOutQuart:e=>1- --e**4,easeInOutQuart:e=>e<.5?8*e**4:1-8*--e**4,easeInQuint:e=>e**5,easeOutQuint:e=>1+--e**5,easeInOutQuint:e=>e<.5?16*e**5:1+16*--e**5,instant:e=>1}
function aa(e,a){const l={duration:300,transition:ta.easeInOutCubic}
let n=-1
const o=t.shallowRef(t.toValue(e))
return t.watch(()=>t.toValue(e),async e=>{cancelAnimationFrame(n)
const r={...l,...t.toValue(a)}
await function(e,t,a,l){const o=performance.now(),r=R()?ta.instant:l.transition??ta.easeInOutCubic
return new Promise(i=>{n=requestAnimationFrame(function s(u){const c=(u-o)/l.duration
e.value=t+(a-t)*r(ae(c,0,1)),c<1?n=requestAnimationFrame(s):(e.value=a,i())})})}(o,o.value,e,r)}),t.computed(()=>o.value)}function la(e,t,a){return Object.keys(e).filter(e=>q(e)&&e.endsWith(t)).reduce((l,n)=>(l[n.slice(0,-t.length)]=t=>he(e[n],t,a(t)),l),{})}function na(e,t=!1){for(;e;){if(t?ia(e):ra(e))return e
e=e.parentElement}return document.scrollingElement}function oa(e,t){const a=[]
if(t&&e&&!t.contains(e))return a
for(;e&&(ra(e)&&a.push(e),e!==t);)e=e.parentElement
return a}function ra(e){if(!e||e.nodeType!==Node.ELEMENT_NODE)return!1
const t=window.getComputedStyle(e),a="scroll"===t.overflowY||"auto"===t.overflowY&&e.scrollHeight>e.clientHeight,l="scroll"===t.overflowX||"auto"===t.overflowX&&e.scrollWidth>e.clientWidth
return a||l}function ia(e){if(!e||e.nodeType!==Node.ELEMENT_NODE)return!1
const t=window.getComputedStyle(e)
return["scroll","auto"].includes(t.overflowY)}function sa(e){$t("useRender").render=e}const ua=[String,Function,Object,Array],ca=Symbol.for("vuetify:icons"),da=Tt({icon:{type:ua},tag:{type:[String,Object,Function],required:!0}},"icon"),va=Kt()({name:"VComponentIcon",props:da(),setup:(e,{slots:a})=>()=>{const l=e.icon
return t.createVNode(e.tag,null,{default:()=>[e.icon?t.createVNode(l,null,null):a.default?.()]})}}),pa=Gt({name:"VSvgIcon",inheritAttrs:!1,props:da(),setup:(e,{attrs:a})=>()=>t.createVNode(e.tag,t.mergeProps(a,{style:null}),{default:()=>[t.createElementVNode("svg",{class:"v-icon__svg",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",role:"img","aria-hidden":"true"},[Array.isArray(e.icon)?e.icon.map(e=>Array.isArray(e)?t.createElementVNode("path",{d:e[0],"fill-opacity":e[1]},null):t.createElementVNode("path",{d:e},null)):t.createElementVNode("path",{d:e.icon},null)])]})}),ma=Gt({name:"VLigatureIcon",props:da(),setup:e=>()=>t.createVNode(e.tag,null,{default:()=>[e.icon]})}),fa=Gt({name:"VClassIcon",props:da(),setup:e=>()=>t.createVNode(e.tag,{class:t.normalizeClass(e.icon)},null)}),ga={collapse:"mdi-chevron-up",complete:"mdi-check",cancel:"mdi-close-circle",close:"mdi-close",delete:"mdi-close-circle",clear:"mdi-close-circle",success:"mdi-check-circle",info:"mdi-information",warning:"mdi-alert-circle",error:"mdi-close-circle",prev:"mdi-chevron-left",next:"mdi-chevron-right",checkboxOn:"mdi-checkbox-marked",checkboxOff:"mdi-checkbox-blank-outline",checkboxIndeterminate:"mdi-minus-box",delimiter:"mdi-circle",sortAsc:"mdi-arrow-up",sortDesc:"mdi-arrow-down",expand:"mdi-chevron-down",menu:"mdi-menu",subgroup:"mdi-menu-down",dropdown:"mdi-menu-down",radioOn:"mdi-radiobox-marked",radioOff:"mdi-radiobox-blank",edit:"mdi-pencil",ratingEmpty:"mdi-star-outline",ratingFull:"mdi-star",ratingHalf:"mdi-star-half-full",loading:"mdi-cached",first:"mdi-page-first",last:"mdi-page-last",unfold:"mdi-unfold-more-horizontal",file:"mdi-paperclip",plus:"mdi-plus",minus:"mdi-minus",calendar:"mdi-calendar",treeviewCollapse:"mdi-menu-down",treeviewExpand:"mdi-menu-right",tableGroupCollapse:"mdi-chevron-down",tableGroupExpand:"mdi-chevron-right",eyeDropper:"mdi-eyedropper",upload:"mdi-cloud-upload",color:"mdi-palette",command:"mdi-apple-keyboard-command",ctrl:"mdi-apple-keyboard-control",space:"mdi-keyboard-space",shift:"mdi-apple-keyboard-shift",alt:"mdi-apple-keyboard-option",enter:"mdi-keyboard-return",arrowup:"mdi-arrow-up",arrowdown:"mdi-arrow-down",arrowleft:"mdi-arrow-left",arrowright:"mdi-arrow-right",backspace:"mdi-backspace",play:"mdi-play",pause:"mdi-pause",fullscreen:"mdi-fullscreen",fullscreenExit:"mdi-fullscreen-exit",volumeHigh:"mdi-volume-high",volumeMedium:"mdi-volume-medium",volumeLow:"mdi-volume-low",volumeOff:"mdi-volume-variant-off",search:"mdi-magnify"},ha={component:e=>t.h(fa,{...e,class:"mdi"})},ya={defaults:{global:{rounded:"sm"},VAvatar:{rounded:"circle"},VAutocomplete:{variant:"underlined"},VBanner:{color:"primary"},VBtn:{class:"text-uppercase",color:"primary",rounded:0},VCheckbox:{color:"secondary",indentDetails:!1},VCombobox:{variant:"underlined"},VDatePicker:{color:"primary",controlHeight:44,elevation:1,rounded:0,controlVariant:"modal",VBtn:{color:"high-emphasis",rounded:"circle"}},VSelect:{variant:"underlined"},VSlider:{color:"primary",indentDetails:!1},VSwitch:{indentDetails:!1},VRadioGroup:{indentDetails:!1},VRangeSlider:{indentDetails:!1},VTabs:{color:"primary"},VTextarea:{variant:"underlined"},VTextField:{variant:"underlined"},VToolbar:{VBtn:{color:null}}},icons:{defaultSet:"mdi",sets:{mdi:ha}},theme:{themes:{light:{colors:{primary:"#3F51B5","primary-darken-1":"#303F9F","primary-lighten-1":"#C5CAE9",secondary:"#FF4081","secondary-darken-1":"#F50057","secondary-lighten-1":"#FF80AB",accent:"#009688"}}}}},ba={defaults:{VAvatar:{rounded:"circle"},VAutocomplete:{variant:"filled"},VBanner:{color:"primary"},VBtn:{class:"text-uppercase",color:"primary"},VCheckbox:{color:"secondary",indentDetails:!0},VCombobox:{variant:"filled"},VDatePicker:{color:"primary",controlHeight:56,elevation:2,rounded:"md",controlVariant:"modal",VBtn:{color:"high-emphasis",rounded:"circle"}},VRadioGroup:{indentDetails:!0},VSelect:{variant:"filled"},VSlider:{color:"primary",indentDetails:!0},VRangeSlider:{indentDetails:!0},VSwitch:{indentDetails:!0},VTabs:{color:"primary"},VTextarea:{variant:"filled"},VTextField:{variant:"filled"},VToolbar:{VBtn:{color:null}}},icons:{defaultSet:"mdi",sets:{mdi:ha}},theme:{themes:{light:{colors:{primary:"#6200EE","primary-darken-1":"#3700B3",secondary:"#03DAC6","secondary-darken-1":"#018786",error:"#B00020"}}}}},wa={defaults:{VAppBar:{flat:!0},VAutocomplete:{variant:"outlined"},VBanner:{color:"primary"},VBottomSheet:{contentClass:"rounded-t-xl overflow-hidden"},VBtn:{color:"primary",rounded:"xl"},VBtnGroup:{rounded:"xl",VBtn:{rounded:null}},VCard:{rounded:"lg"},VCheckbox:{color:"secondary",inset:!0,indentDetails:!0},VChip:{rounded:"sm"},VCombobox:{variant:"outlined"},VDateInput:{variant:"outlined"},VDatePicker:{controlHeight:48,color:"primary",divided:!0,headerColor:"",elevation:1,rounded:"xl",VBtn:{color:"high-emphasis",rounded:"circle"}},VFileInput:{variant:"outlined"},VList:{prependGap:16},VNavigationDrawer:{},VNumberInput:{variant:"outlined",VBtn:{color:void 0,rounded:void 0}},VRadioGroup:{indentDetails:!0},VSelect:{variant:"outlined"},VSlider:{color:"primary",indentDetails:!0},VRangeSlider:{indentDetails:!0},VSwitch:{indentDetails:!0},VTabs:{color:"primary"},VTextarea:{variant:"outlined"},VTextField:{variant:"outlined"},VToolbar:{VBtn:{color:null}}},icons:{defaultSet:"mdi",sets:{mdi:ha}},theme:{themes:{light:{colors:{primary:"#6750a4",secondary:"#b4b0bb",tertiary:"#7d5260",error:"#b3261e",surface:"#fffbfe"}}}}}
var Va=Object.freeze({__proto__:null,md1:ya,md2:ba,md3:wa})
function Sa(e,a="content"){const l=Ee(),n=t.ref()
if(E){const o=new ResizeObserver(t=>{if(e?.(t,o),t.length)if("content"===a)n.value=t[0].contentRect
else{const e=t[0].borderBoxSize?.[0],a=t[0].target
n.value=new He({x:0,y:0,width:e?.inlineSize??a.offsetWidth,height:e?.blockSize??a.offsetHeight})}})
t.onBeforeUnmount(()=>{o.disconnect()}),t.watch(()=>l.el,(e,t)=>{t&&(o.unobserve(t),n.value=void 0),e&&o.observe(e)},{flush:"post"})}return{resizeRef:l,contentRect:t.readonly(n)}}const ka=Symbol.for("vuetify:layout"),xa=Symbol.for("vuetify:layout-item"),Na=Tt({overlaps:{type:Array,default:()=>[]},fullHeight:Boolean},"layout"),Ca=Tt({name:{type:String},order:{type:[Number,String],default:0},absolute:Boolean},"layout-item")
function Ea(){const e=t.inject(ka)
if(!e)throw new Error("[Vuetify] Could not find injected layout")
return{getLayoutItem:e.getLayoutItem,mainRect:e.mainRect,mainStyles:e.mainStyles,layoutRect:e.layoutRect}}function Ia(e){const a=t.inject(ka)
if(!a)throw new Error("[Vuetify] Could not find injected layout")
const l=e.id??`layout-item-${t.useId()}`,n=$t("useLayoutItem")
t.provide(xa,{id:l})
const o=t.shallowRef(!1)
t.onDeactivated(()=>o.value=!0),t.onActivated(()=>o.value=!1)
const{layoutItemStyles:r,layoutItemScrimStyles:i}=a.register(n,{...e,active:t.computed(()=>!o.value&&e.active.value),id:l})
return t.onBeforeUnmount(()=>a.unregister(l)),{layoutItemStyles:r,layoutRect:a.layoutRect,layoutItemScrimStyles:i}}function Aa(e){const l=t.inject(ka,null),n=t.computed(()=>l?l.rootZIndex.value-100:1e3),o=t.ref([]),r=t.reactive(new Map),i=t.reactive(new Map),s=t.reactive(new Map),u=t.reactive(new Map),c=t.reactive(new Map),{resizeRef:d,contentRect:v}=Sa()
function p(e,t){return M(e,("left"===t||"right"===t?v.value?.width:v.value?.height)??0)}const m=t.shallowRef(!1)
let f=-1
t.watch(()=>[v.value?.width,v.value?.height],()=>{m.value=!0,window.clearTimeout(f),f=window.setTimeout(()=>m.value=!1,100)}),t.onScopeDispose(()=>window.clearTimeout(f))
const g=t.computed(()=>{const t=new Map,a=e.overlaps??[]
for(const e of a.filter(e=>e.includes(":"))){const[a,l]=e.split(":")
if(!o.value.includes(a)||!o.value.includes(l))continue
const n=r.get(a),s=r.get(l),u=i.get(a),c=i.get(l)
n&&s&&u&&c&&(t.set(l,{position:n.value,amount:p(u.value,n.value)}),t.set(a,{position:s.value,amount:-p(c.value,s.value)}))}return t}),h=t.computed(()=>{const e=[...new Set([...s.values()].map(e=>e.value))].sort((e,t)=>e-t),t=[]
for(const a of e){const e=o.value.filter(e=>s.get(e)?.value===a)
t.push(...e)}return((e,t,a,l,n)=>{let o={top:0,left:0,right:0,bottom:0}
const r=[{id:"",layer:{...o}}]
for(const i of e){const e=t.get(i),s=a.get(i),u=l.get(i)
if(!e||!s||!u)continue
const c={...o,[e.value]:o[e.value]+(u.value?n(s.value,e.value):0)}
r.push({id:i,layer:c}),o=c}return r})(t,r,i,u,p)}),y=t.computed(()=>!m.value&&!Array.from(c.values()).some(e=>e.value)),b=t.computed(()=>h.value[h.value.length-1].layer),w=t.toRef(()=>({"--v-layout-left":z(b.value.left),"--v-layout-right":z(b.value.right),"--v-layout-top":z(b.value.top),"--v-layout-bottom":z(b.value.bottom),...y.value?void 0:{transition:"none"}})),V=t.computed(()=>h.value.slice(1).map(({id:e},t)=>{const{layer:a}=h.value[t],l=i.get(e),n=r.get(e)
return{id:e,...a,size:p(l.value,n.value),position:n.value}})),S=e=>V.value.find(t=>t.id===e),k=$t("createLayout"),x=t.shallowRef(!1)
t.onMounted(()=>{x.value=!0}),t.provide(ka,{register:(e,{id:l,order:d,position:m,layoutSize:f,elementSize:b,active:w,disableTransitions:S,absolute:N})=>{s.set(l,d),r.set(l,m),i.set(l,f),u.set(l,w),S&&c.set(l,S)
const C=ce(xa,k?.vnode).indexOf(e)
C>-1?o.value.splice(C,0,l):o.value.push(l)
const E=t.computed(()=>V.value.findIndex(e=>e.id===l)),I=t.computed(()=>n.value+2*h.value.length-2*E.value)
return{layoutItemStyles:t.computed(()=>{const e="left"===m.value||"right"===m.value,t="right"===m.value,o="bottom"===m.value,r=t||o?1:-1,i=`calc(${100*r}% + ${r}px)`,s="translate"+(e?"X":"Y"),u={[m.value]:0,zIndex:I.value,transform:`${s}(${w.value?"0px":i})`,position:N.value||1e3!==n.value?"absolute":"fixed",...y.value?void 0:{transition:"none"}}
if(!x.value)return u
const c=$(b.value)&&v.value?p(b.value,m.value):b.value,d=V.value[E.value]
d||a(`[Vuetify] Could not find layout item "${l}"`)
const f=g.value.get(l)
return f&&(d[f.position]+=f.amount),{...u,height:e?`calc(100% - ${d.top}px - ${d.bottom}px)`:c?z(c):void 0,left:t?void 0:`${d.left}px`,right:t?`${d.right}px`:void 0,top:"bottom"!==m.value?`${d.top}px`:void 0,bottom:"top"!==m.value?`${d.bottom}px`:void 0,width:e?c?z(c):void 0:`calc(100% - ${d.left}px - ${d.right}px)`}}),layoutItemScrimStyles:t.computed(()=>({zIndex:I.value-1})),zIndex:I}},unregister:e=>{s.delete(e),r.delete(e),i.delete(e),u.delete(e),c.delete(e),o.value=o.value.filter(t=>t!==e)},mainRect:b,mainStyles:w,getLayoutItem:S,items:V,layoutRect:v,rootZIndex:n})
return{layoutClasses:t.toRef(()=>["v-layout",{"v-layout--full-height":e.fullHeight}]),layoutStyles:t.toRef(()=>({zIndex:l?n.value:void 0,position:l?"relative":void 0,overflow:l?"hidden":void 0})),getLayoutItem:S,items:V,layoutRect:v,layoutRef:d}}function Pa(e,a){let l
function n(){l=t.effectScope(),l.run(()=>a.length?a(()=>{l?.stop(),n()}):a())}t.watch(e,e=>{e&&!l?n():e||(l?.stop(),l=void 0)},{immediate:!0}),t.onScopeDispose(()=>{l?.stop()})}function _a(e,a,l,n=e=>e,o=e=>e){const r=$t("useProxiedModel"),i=t.ref(x(e[a])?l:e[a]),s=ue(a),u=s!==a?t.computed(()=>(e[a],!(!r.vnode.props?.hasOwnProperty(a)&&!r.vnode.props?.hasOwnProperty(s)||!r.vnode.props?.hasOwnProperty(`onUpdate:${a}`)&&!r.vnode.props?.hasOwnProperty(`onUpdate:${s}`)))):t.computed(()=>(e[a],!(!r.vnode.props?.hasOwnProperty(a)||!r.vnode.props?.hasOwnProperty(`onUpdate:${a}`))))
Pa(()=>!u.value,()=>{t.watch(()=>e[a],e=>{i.value=e})})
const c=t.computed({get(){const t=e[a]
return n(u.value?t:i.value)},set(l){const s=o(l),c=t.toRaw(u.value?e[a]:i.value)
c!==s&&n(c)!==l&&(i.value=s,r?.emit(`update:${a}`,s))}})
return Object.defineProperty(c,"externalValue",{get:()=>u.value?e[a]:i.value}),c}var Ra={badge:"Badge",open:"Open",close:"Close",dismiss:"Dismiss",confirmEdit:{ok:"OK",cancel:"Cancel"},dataIterator:{noResultsText:"No matching records found",loadingText:"Loading items..."},dataTable:{itemsPerPageText:"Rows per page:",ariaLabel:{sortDescending:"Sorted descending.",sortAscending:"Sorted ascending.",sortNone:"Not sorted.",activateNone:"Activate to remove sorting.",activateDescending:"Activate to sort descending.",activateAscending:"Activate to sort ascending.",selectRow:"Select row",selectAll:"Select all",selectGroup:"Select group"},sortBy:"Sort by"},dataFooter:{itemsPerPageText:"Items per page:",itemsPerPageAll:"All",nextPage:"Next page",prevPage:"Previous page",firstPage:"First page",lastPage:"Last page",pageText:"{0}-{1} of {2}"},dateRangeInput:{divider:"to"},monthPicker:{title:"Select month",itemsSelected:"{0} selected",header:"Enter month",range:{title:"Enter months"},ariaLabel:{previousYear:"Previous year",nextYear:"Next year",selectYear:"Select year",currentMonth:"Current month, {0}"}},datePicker:{itemsSelected:"{0} selected",range:{title:"Select dates",header:"Enter dates"},title:"Select date",header:"Enter date",input:{placeholder:"Enter date"},ariaLabel:{previousMonth:"Previous month",nextMonth:"Next month",selectYear:"Select year",previousYear:"Previous year",nextYear:"Next year",selectMonth:"Select month",selectDate:"{0}",currentDate:"Today, {0}"}},noDataText:"No data available",carousel:{prev:"Previous visual",next:"Next visual",ariaLabel:{delimiter:"Carousel slide {0} of {1}"}},calendar:{moreEvents:"{0} more",today:"Today"},heatmap:{less:"Less",more:"More"},input:{clear:"Clear {0}",prependAction:"{0} prepended action",appendAction:"{0} appended action",otp:"Enter verification code"},fileInput:{counter:"{0} files",counterSize:"{0} files ({1} in total)"},fileUpload:{title:"Drag and drop files here",divider:"or",browse:"Browse Files"},timePicker:{am:"AM",pm:"PM",title:"Select Time",hour:"Hour",minute:"Minute",second:"Second",notAllowed:"Value is not allowed"},pagination:{ariaLabel:{root:"Pagination Navigation",next:"Next page",previous:"Previous page",page:"Go to page {0}",currentPage:"Page {0}, Current page",first:"First page",last:"Last page"}},stepper:{next:"Next",prev:"Previous"},rating:{ariaLabel:{item:"Rating {0} of {1}"}},loading:"Loading...",infiniteScroll:{loadMore:"Load more",empty:"No more"},rules:{required:"This field is required",email:"Please enter a valid email",number:"This field can only contain numbers",integer:"This field can only contain integer values",capital:"This field can only contain uppercase letters",maxLength:"You must enter a maximum of {0} characters",minLength:"You must enter a minimum of {0} characters",strictLength:"The length of the entered field is invalid",exclude:"The {0} character is not allowed",notEmpty:"Please choose at least one value",pattern:"Invalid format"},command:{search:"Type a command or search..."},hotkey:{then:"then",ctrl:"Ctrl",command:"Command",space:"Space",shift:"Shift",alt:"Alt",enter:"Enter",escape:"Escape",upArrow:"Up Arrow",downArrow:"Down Arrow",leftArrow:"Left Arrow",rightArrow:"Right Arrow",backspace:"Backspace",option:"Option",plus:"plus",shortcut:"Keyboard shortcut: {0}",or:"or"},video:{play:"Play",pause:"Pause",seek:"Seek",volume:"Volume",showVolume:"Show volume control",mute:"Mute",unmute:"Unmute",enterFullscreen:"Full screen",exitFullscreen:"Exit full screen"},colorPicker:{ariaLabel:{eyedropper:"Select color with eyedropper",hueSlider:"Hue",alphaSlider:"Alpha",redInput:"Red value",greenInput:"Green value",blueInput:"Blue value",alphaInput:"Alpha value",hueInput:"Hue value",saturationInput:"Saturation value",lightnessInput:"Lightness value",hexInput:"HEX value",hexaInput:"HEX with alpha value",changeFormat:"Change color format"}}}
const Da="$vuetify.",Ba=(e,t)=>e.replace(/\{(\d+)\}/g,(e,a)=>String(t[Number(a)])),Ta=(e,t,n)=>(o,...r)=>{if(!o.startsWith(Da))return Ba(o,r)
const i=o.replace(Da,""),s=e.value&&n.value[e.value],u=t.value&&n.value[t.value]
let c=T(s,i,null)
return c||(a(`Translation key "${o}" not found in "${e.value}", trying fallback locale`),c=T(u,i,null)),c||(l(`Translation key "${o}" not found in fallback`),c=o),g(c)||(l(`Translation key "${o}" has a non-string value`),c=o),Ba(c,r)}
function Fa(e,t){return(a,l)=>new Intl.NumberFormat([e.value,t.value],l).format(a)}function $a(e,t){return Fa(e,t)(.1).includes(",")?",":"."}function Ma(e,t){return new Intl.NumberFormat([e.value,t.value],{useGrouping:!0}).formatToParts(1e4).find(e=>"group"===e.type)?.value??" "}function za(e,a,l){const n=_a(e,a,e[a]??l.value)
return n.value=e[a]??l.value,t.watch(l,t=>{null==e[a]&&(n.value=l.value)}),n}function La(e){return a=>{const l=za(a,"locale",e.current),n=za(a,"fallback",e.fallback),o=za(a,"messages",e.messages)
return{name:"vuetify",current:l,fallback:n,messages:o,decimalSeparator:t.toRef(()=>$a(l,n)),numericGroupSeparator:t.toRef(()=>Ma(l,n)),t:Ta(l,n,o),n:Fa(l,n),provide:La({current:l,fallback:n,messages:o})}}}const Oa=Symbol.for("vuetify:locale")
function ja(e){const a=e?.adapter?.name?e.adapter:function(e){const a=t.shallowRef(e?.locale??"en"),l=t.shallowRef(e?.fallback??"en"),n=t.ref({en:Ra,...e?.messages})
return{name:"vuetify",current:a,fallback:l,messages:n,decimalSeparator:t.toRef(()=>e?.decimalSeparator??$a(a,l)),numericGroupSeparator:t.toRef(()=>e?.numericGroupSeparator??Ma(a,l)),t:Ta(a,l,n),n:Fa(a,l),provide:La({current:a,fallback:l,messages:n})}}(e),l=function(e,a){const l=t.ref(a?.rtl??{af:!1,ar:!0,bg:!1,ca:!1,ckb:!0,cs:!1,de:!1,el:!1,en:!1,es:!1,et:!1,fa:!0,fi:!1,fr:!1,hr:!1,hu:!1,he:!0,id:!1,it:!1,ja:!1,km:!1,ko:!1,lv:!1,lt:!1,nl:!1,no:!1,pl:!1,pt:!1,ro:!1,ru:!1,sk:!1,sl:!1,srCyrl:!1,srLatn:!1,sv:!1,th:!1,tr:!1,az:!1,uk:!1,vi:!1,zhHans:!1,zhHant:!1}),n=t.computed(()=>l.value[e.current.value]??!1)
return{isRtl:n,rtl:l,rtlClasses:t.toRef(()=>"v-locale--is-"+(n.value?"rtl":"ltr"))}}(a,e)
return{...a,...l}}function Ha(){const e=t.inject(Oa)
if(!e)throw new Error("[Vuetify] Could not find injected locale instance")
return e}function Wa(e){const a=t.inject(Oa)
if(!a)throw new Error("[Vuetify] Could not find injected locale instance")
const l=a.provide(e),n=function(e,a,l){const n=t.computed(()=>l.rtl??a.value[e.current.value]??!1)
return{isRtl:n,rtl:a,rtlClasses:t.toRef(()=>"v-locale--is-"+(n.value?"rtl":"ltr"))}}(l,a.rtl,e),o={...l,...n}
return t.provide(Oa,o),o}function Ua(){const e=t.inject(Oa)
if(!e)throw new Error("[Vuetify] Could not find injected rtl instance")
return{isRtl:e.isRtl,rtlClasses:e.rtlClasses}}const Ya=Symbol.for("vuetify:theme"),Ga=Tt({theme:String},"theme")
function Ka(e,t,a,l){e.push(`${function(e,t){if(!t)return e
const a=`:where(${t})`
return":root"===e?a:`${a} ${e}`}(t,l)} {\n`,...a.map(e=>`  ${e};\n`),"}\n")}function qa(e,t){const a=e.dark?2:1,l=e.dark?1:2,n=[]
for(const[o,r]of Object.entries(e.colors)){const e=yt(r)
n.push(`--${t}theme-${o}: ${e.r},${e.g},${e.b}`+(h(e.a)?`,${e.a}`:"")),o.startsWith("on-")||n.push(`--${t}theme-${o}-overlay-multiplier: ${Rt(r)>.18?a:l}`)}for(const[a,l]of Object.entries(e.variables)){const e=g(l)&&l.startsWith("#")?yt(l):void 0,o=e?`${e.r}, ${e.g}, ${e.b}`+(h(e.a)?`, ${e.a}`:""):void 0
n.push(`--${t}${a}: ${o??l}`)}return n}function Xa(e,t,a){const l={}
if(a)for(const n of["lighten","darken"]){const o="lighten"===n?Pt:_t
for(const r of C(a[n],1))l[`${e}-${n}-${r}`]=Et(o(yt(t),r))}return l}function Za(e,t){if(!t)return{}
let a={}
for(const l of t.colors){const n=e[l]
n&&(a={...a,...Xa(l,n,t)})}return a}function Qa(e,t){const a={}
for(const l of Object.keys(e)){if(l.startsWith("on-")||e[`on-${l}`])continue
const n=`on-${l}`,o=yt(e[l])
a[n]=Bt(o)?t["theme-on-dark"]:t["theme-on-light"]}return a}function Ja(e,t,a){const l=function(e,t){if(!E)return null
let a=document.getElementById(e)
a||(a=document.createElement("style"),a.id=e,a.type="text/css",t&&a.setAttribute("nonce",t),document.head.appendChild(a))
return a}(e,t)
l&&(l.innerHTML=a)}function el(e){const l=function(e={defaultTheme:"system",prefix:"v-",variations:{colors:[],lighten:0,darken:0},themes:{light:{dark:!1,colors:{background:"#FFFFFF",surface:"#FFFFFF","surface-bright":"#FFFFFF","surface-light":"#EEEEEE","surface-variant":"#424242","on-surface-variant":"#EEEEEE",primary:"#1867C0","primary-darken-1":"#1F5592",secondary:"#48A9A6","secondary-darken-1":"#018786",error:"#B00020",info:"#2196F3",success:"#4CAF50",warning:"#FB8C00"},variables:{"border-color":"#000000","border-opacity":.12,"shadow-color":"#000000","high-emphasis-opacity":.87,"medium-emphasis-opacity":.6,"disabled-opacity":.38,"idle-opacity":.04,"hover-opacity":.04,"focus-opacity":.12,"selected-opacity":.08,"activated-opacity":.12,"pressed-opacity":.12,"dragged-opacity":.08,"theme-kbd":"#EEEEEE","theme-on-kbd":"#000000","theme-code":"#F5F5F5","theme-on-code":"#000000","theme-on-dark":"#FFF","theme-on-light":"#000","elevation-overlay-color":"black","elevation-overlay-opacity-step":"2%","highlight-opacity":"8%"}},dark:{dark:!0,colors:{background:"#121212",surface:"#212121","surface-bright":"#ccbfd6","surface-light":"#424242","surface-variant":"#c8c8c8","on-surface-variant":"#000000",primary:"#2196F3","primary-darken-1":"#277CC1",secondary:"#54B6B2","secondary-darken-1":"#48A9A6",error:"#CF6679",info:"#2196F3",success:"#4CAF50",warning:"#FB8C00"},variables:{"border-color":"#FFFFFF","border-opacity":.12,"shadow-color":"#000000","high-emphasis-opacity":1,"medium-emphasis-opacity":.7,"disabled-opacity":.5,"idle-opacity":.1,"hover-opacity":.04,"focus-opacity":.12,"selected-opacity":.08,"activated-opacity":.12,"pressed-opacity":.16,"dragged-opacity":.08,"theme-kbd":"#424242","theme-on-kbd":"#FFFFFF","theme-code":"#343434","theme-on-code":"#CCCCCC","theme-on-dark":"#FFF","theme-on-light":"#000","elevation-overlay-color":"white","elevation-overlay-opacity-step":"2%","highlight-opacity":"20%"}}},stylesheetId:"vuetify-theme-stylesheet",scoped:!1,utilities:!0,transition:!1}){const t={defaultTheme:"system",prefix:"v-",variations:{colors:[],lighten:0,darken:0},themes:{light:{dark:!1,colors:{background:"#FFFFFF",surface:"#FFFFFF","surface-bright":"#FFFFFF","surface-light":"#EEEEEE","surface-variant":"#424242","on-surface-variant":"#EEEEEE",primary:"#1867C0","primary-darken-1":"#1F5592",secondary:"#48A9A6","secondary-darken-1":"#018786",error:"#B00020",info:"#2196F3",success:"#4CAF50",warning:"#FB8C00"},variables:{"border-color":"#000000","border-opacity":.12,"shadow-color":"#000000","high-emphasis-opacity":.87,"medium-emphasis-opacity":.6,"disabled-opacity":.38,"idle-opacity":.04,"hover-opacity":.04,"focus-opacity":.12,"selected-opacity":.08,"activated-opacity":.12,"pressed-opacity":.12,"dragged-opacity":.08,"theme-kbd":"#EEEEEE","theme-on-kbd":"#000000","theme-code":"#F5F5F5","theme-on-code":"#000000","theme-on-dark":"#FFF","theme-on-light":"#000","elevation-overlay-color":"black","elevation-overlay-opacity-step":"2%","highlight-opacity":"8%"}},dark:{dark:!0,colors:{background:"#121212",surface:"#212121","surface-bright":"#ccbfd6","surface-light":"#424242","surface-variant":"#c8c8c8","on-surface-variant":"#000000",primary:"#2196F3","primary-darken-1":"#277CC1",secondary:"#54B6B2","secondary-darken-1":"#48A9A6",error:"#CF6679",info:"#2196F3",success:"#4CAF50",warning:"#FB8C00"},variables:{"border-color":"#FFFFFF","border-opacity":.12,"shadow-color":"#000000","high-emphasis-opacity":1,"medium-emphasis-opacity":.7,"disabled-opacity":.5,"idle-opacity":.1,"hover-opacity":.04,"focus-opacity":.12,"selected-opacity":.08,"activated-opacity":.12,"pressed-opacity":.16,"dragged-opacity":.08,"theme-kbd":"#424242","theme-on-kbd":"#FFFFFF","theme-code":"#343434","theme-on-code":"#CCCCCC","theme-on-dark":"#FFF","theme-on-light":"#000","elevation-overlay-color":"white","elevation-overlay-opacity-step":"2%","highlight-opacity":"20%"}}},stylesheetId:"vuetify-theme-stylesheet",scoped:!1,utilities:!0,transition:!1}
return e?ie(t,e):{...t,isDisabled:!0}}(e),o=t.shallowRef(l.defaultTheme),r=t.ref(l.themes),i=t.shallowRef("light"),s=t.computed({get:()=>"system"===o.value?i.value:o.value,set(e){o.value=e}}),u=t.computed(()=>{const e={}
for(const[t,a]of Object.entries(r.value)){const n=ie(a.dark||"dark"===t?r.value.dark:r.value.light,a),o={...n.colors,...Za(n.colors,l.variations)}
e[t]={...n,colors:{...o,...Qa(o,n.variables)}}}return e}),c=t.toRef(()=>u.value[s.value]),d=t.toRef(()=>"system"===o.value),v=t.computed(()=>{const e=[],t=l.scoped?l.prefix:""
e.push("@layer theme-base {\n"),Ka(e,":root",["color-scheme: "+(c.value?.dark?"dark":"light")],l.scope),Ka(e,":root",qa(c.value,l.prefix),l.scope)
for(const[t,a]of Object.entries(u.value))Ka(e,`.${l.prefix}theme--${t}`,["color-scheme: "+(a.dark?"dark":"light"),...qa(a,l.prefix)],l.scope)
if(e.push("}\n"),l.utilities){const a=[],n=[],o=new Set(Object.values(u.value).flatMap(e=>Object.keys(e.colors)))
for(const e of o)e.startsWith("on-")?Ka(n,`.${e}`,[`color: rgb(var(--${l.prefix}theme-${e}))`],l.scope):(Ka(a,`.${t}bg-${e}`,[`--${l.prefix}theme-overlay-multiplier: var(--${l.prefix}theme-${e}-overlay-multiplier)`,`background-color: rgb(var(--${l.prefix}theme-${e}))`,`color: rgb(var(--${l.prefix}theme-on-${e}))`],l.scope),Ka(n,`.${t}text-${e}`,[`color: rgb(var(--${l.prefix}theme-${e}))`],l.scope),Ka(n,`.${t}border-${e}`,[`--${l.prefix}border-color: var(--${l.prefix}theme-${e})`],l.scope))
e.push("@layer theme-background {\n",...a.map(e=>`  ${e}`),"}\n","@layer theme-foreground {\n",...n.map(e=>`  ${e}`),"}\n")}return"@layer vuetify-utilities {\n"+e.map(e=>`  ${e}`).join("")+"\n}"}),p=t.toRef(()=>l.isDisabled?void 0:`${l.prefix}theme--${s.value}`),m=t.toRef(()=>Object.keys(u.value))
if(_){const w=window.matchMedia("(prefers-color-scheme: dark)")
function S(){i.value=w.matches?"dark":"light"}S(),w.addEventListener("change",S,{passive:!0}),t.getCurrentScope()&&t.onScopeDispose(()=>{w.removeEventListener("change",S)})}let f
function g(e,t){if("system"!==e&&!m.value.includes(e))return a(`Theme "${e}" not found on the Vuetify theme instance`),Promise.resolve()
const n=()=>{s.value=e},o=function(e){if(!(e??l.transition)&&!f)return!1
const t=b(l.transition)?l.transition:{},a=b(e)?e:{}
return{origin:a.origin??f??t.origin,duration:a.duration??t.duration}}(t)
return o?function(e,t){if(!E||!document.startViewTransition||R())return e(),Promise.resolve()
const a=t.origin??"50% 0%",l=t.duration??"500ms",n=document.createElement("style")
n.textContent=`html:active-view-transition-type(vuetify-theme)::view-transition-old(root) { animation: none; }html:active-view-transition-type(vuetify-theme)::view-transition-new(root) { animation: v-circle-in ${l} ease-in-out; }@keyframes v-circle-in {  from { clip-path: circle(0% at ${a}); }  to { clip-path: circle(150% at ${a}); }}`,document.head.appendChild(n)
const o=document.startViewTransition({update:()=>e(),types:["vuetify-theme"]})
return o.finished.then(()=>{f=null,n.remove()}),o.updateCallbackDone}(n,o):(n(),Promise.resolve())}function h(e=m.value,t){const a=e.indexOf(s.value)
return g(e[-1===a?0:(a+1)%e.length],t)}const y=new Proxy(s,{get:(e,t)=>Reflect.get(e,t),set:(e,t,a)=>("value"===t&&n(`theme.global.name.value = ${a}`,`theme.change('${a}')`),Reflect.set(e,t,a))})
return{install:function(e){if(l.isDisabled)return
const a=e._context.provides.usehead
if(a){function n(){return{style:[{textContent:v.value,id:l.stylesheetId,nonce:l.cspNonce||!1,tagPosition:"bodyOpen"}]}}if(a.push){const o=a.push(n)
E&&t.watch(v,()=>{o.patch(n)})}else E?(a.addHeadObjs(t.toRef(n)),t.watchEffect(()=>a.updateDOM())):a.addHeadObjs(n())}else{function r(){Ja(l.stylesheetId,l.cspNonce,v.value)}E?t.watch(v,r,{immediate:!0}):r()}},change:g,cycle:h,toggle:function(e=["light","dark"],t){return h(e,t)},setTransitionOrigin:function(e){if(!e)return void(f=null)
let t,a
if(V(e)){const l=new He(e)
t=l.left+l.width/2,a=l.top+l.height/2}else t=e.clientX,a=e.clientY
const l=Math.min(98.9,100*t/window.innerWidth),n=100*a/window.innerHeight
f=`${l.toFixed(2)}% ${n.toFixed(2)}%`},isDisabled:l.isDisabled,isSystem:d,name:s,themes:r,current:c,computedThemes:u,prefix:l.prefix,themeClasses:p,styles:v,global:{name:y,current:c}}}function tl(e){$t("provideTheme")
const a=t.inject(Ya,null)
if(!a)throw new Error("Could not find Vuetify theme injection")
const l=t.toRef(()=>e.theme??a.name.value),n=t.toRef(()=>a.computedThemes.value[l.value]),o=t.toRef(()=>a.isDisabled?void 0:`${a.prefix}theme--${l.value}`),r={...a,name:l,current:n,themeClasses:o}
return t.provide(Ya,r),r}function al(){$t("useTheme")
const e=t.inject(Ya,null)
if(!e)throw new Error("Could not find Vuetify theme injection")
return e}const ll=Tt({...Ft(),...G(Na(),["fullHeight"]),...Ga()},"VApp"),nl=Kt()({name:"VApp",props:ll(),setup(e,{slots:a}){const l=tl(e),{layoutClasses:n,getLayoutItem:o,items:r,layoutRef:i}=Aa({...e,fullHeight:!0}),{rtlClasses:s}=Ua()
return sa(()=>t.createElementVNode("div",{ref:i,class:t.normalizeClass(["v-application",l.themeClasses.value,n.value,s.value,e.class]),style:t.normalizeStyle([e.style])},[t.createElementVNode("div",{class:"v-application__wrap"},[a.default?.()])])),{getLayoutItem:o,items:r,theme:l}}}),ol=Tt({tag:{type:[String,Object,Function],default:"div"}},"tag"),rl=Tt({text:String,...Ft(),...ol()},"VToolbarTitle"),il=Kt()({name:"VToolbarTitle",props:rl(),setup:(e,{slots:a})=>(sa(()=>{const l=!!(a.default||a.text||e.text)
return t.createVNode(e.tag,{class:t.normalizeClass(["v-toolbar-title",e.class]),style:t.normalizeStyle(e.style)},{default:()=>[l&&t.createElementVNode("div",{class:"v-toolbar-title__placeholder"},[a.text?a.text():e.text,a.default?.()])]})}),{})}),sl=Tt({disabled:Boolean,group:Boolean,hideOnLeave:Boolean,leaveAbsolute:Boolean,mode:String,origin:String},"transition")
function ul(e,a,l){return Kt()({name:e,props:sl({mode:l,origin:a}),setup(a,{slots:l}){const n={onBeforeEnter(e){a.origin&&(e.style.transformOrigin=a.origin)},onLeave(e){if(a.leaveAbsolute){const{offsetTop:t,offsetLeft:a,offsetWidth:l,offsetHeight:n}=e
e._transitionInitialStyles={position:e.style.position,top:e.style.top,left:e.style.left,width:e.style.width,height:e.style.height},e.style.position="absolute",e.style.top=`${t}px`,e.style.left=`${a}px`,e.style.width=`${l}px`,e.style.height=`${n}px`}a.hideOnLeave&&e.style.setProperty("display","none","important")},onAfterLeave(e){if(a.leaveAbsolute&&e?._transitionInitialStyles){const{position:t,top:a,left:l,width:n,height:o}=e._transitionInitialStyles
delete e._transitionInitialStyles,e.style.position=t||"",e.style.top=a||"",e.style.left=l||"",e.style.width=n||"",e.style.height=o||""}}}
return()=>{const o=a.group?t.TransitionGroup:t.Transition
return t.h(o,{name:a.disabled?"":e,css:!a.disabled,...a.group?void 0:{mode:a.mode},...a.disabled?{}:n},l.default)}}})}function cl(e,a,l="in-out"){return Kt()({name:e,props:{mode:{type:String,default:l},disabled:{type:Boolean,default:R()},group:Boolean,hideOnLeave:Boolean},setup(l,{slots:n}){const o=l.group?t.TransitionGroup:t.Transition
return()=>t.h(o,{name:l.disabled?"":e,css:!l.disabled,...l.disabled?{}:{...a,onLeave:e=>{l.hideOnLeave?e.style.setProperty("display","none","important"):a.onLeave?.(e)}}},n.default)}})}function dl(e="",t="y"){return{onBeforeEnter(e){e._parent=e.parentNode,e._initialStyle={transition:e.style.transition,overflow:e.style.overflow,width:e.style.width,height:e.style.height}},onEnter(a){const l=a._initialStyle
if(!l)return
a.style.setProperty("transition","none","important"),a.style.overflow="hidden"
const n=`${a.offsetWidth}px`,o=`${a.offsetHeight}px`;["x","both"].includes(t)&&(a.style.width="0"),["y","both"].includes(t)&&(a.style.height="0"),a.offsetHeight,a.style.transition=l.transition,e&&a._parent&&a._parent.classList.add(e),requestAnimationFrame(()=>{["x","both"].includes(t)&&(a.style.width=n),["y","both"].includes(t)&&(a.style.height=o)})},onAfterEnter:l,onEnterCancelled:l,onLeave(e){e._initialStyle={transition:"",overflow:e.style.overflow,width:e.style.width,height:e.style.height},e.style.overflow="hidden",["x","both"].includes(t)&&(e.style.width=`${e.offsetWidth}px`),["y","both"].includes(t)&&(e.style.height=`${e.offsetHeight}px`),e.offsetHeight,requestAnimationFrame(()=>{["x","both"].includes(t)&&(e.style.width="0"),["y","both"].includes(t)&&(e.style.height="0")})},onAfterLeave:a,onLeaveCancelled:a}
function a(t){e&&t._parent&&t._parent.classList.remove(e),l(t)}function l(e){if(!e._initialStyle)return
const{width:a,height:l}=e._initialStyle
e.style.overflow=e._initialStyle.overflow,null!=a&&["x","both"].includes(t)&&(e.style.width=a),null!=l&&["y","both"].includes(t)&&(e.style.height=l),delete e._initialStyle}}const vl=Tt({target:[Object,Array]},"v-dialog-transition"),pl=new WeakMap,ml=Kt()({name:"VDialogTransition",props:vl(),setup(e,{slots:a}){const l={onBeforeEnter(e){e.style.pointerEvents="none",e.style.visibility="hidden"},async onEnter(t,a){await new Promise(e=>requestAnimationFrame(e)),await new Promise(e=>requestAnimationFrame(e)),t.style.visibility=""
const l=gl(e.target,t),{x:n,y:o,sx:r,sy:i,speed:s}=l
if(pl.set(t,l),R())Ke(t,[{opacity:0},{}],{duration:125*s,easing:Jt}).finished.then(()=>a())
else{const e=Ke(t,[{transform:`translate(${n}px, ${o}px) scale(${r}, ${i})`,opacity:0},{}],{duration:225*s,easing:Jt})
fl(t)?.forEach(e=>{Ke(e,[{opacity:0},{opacity:0,offset:.33},{}],{duration:450*s,easing:Qt})}),e.finished.then(()=>a())}},onAfterEnter(e){e.style.removeProperty("pointer-events")},onBeforeLeave(e){e.style.pointerEvents="none"},async onLeave(t,a){let l
await new Promise(e=>requestAnimationFrame(e)),l=!pl.has(t)||Array.isArray(e.target)||e.target.offsetParent||e.target.getClientRects().length?gl(e.target,t):pl.get(t)
const{x:n,y:o,sx:r,sy:i,speed:s}=l
if(R())Ke(t,[{},{opacity:0}],{duration:85*s,easing:ea}).finished.then(()=>a())
else{Ke(t,[{},{transform:`translate(${n}px, ${o}px) scale(${r}, ${i})`,opacity:0}],{duration:125*s,easing:ea}).finished.then(()=>a()),fl(t)?.forEach(e=>{Ke(e,[{},{opacity:0,offset:.2},{opacity:0}],{duration:250*s,easing:Qt})})}},onAfterLeave(e){e.style.removeProperty("pointer-events")}}
return()=>e.target?t.createVNode(t.Transition,t.mergeProps({name:"dialog-transition"},l,{css:!1}),a):t.createVNode(t.Transition,{name:"dialog-transition"},a)}})
function fl(e){const t=e.querySelector(":scope > .v-card, :scope > .v-sheet, :scope > .v-list")?.children
return t&&[...t]}function gl(e,t){const a=Ue(e),l=Ge(t),[n,o]=getComputedStyle(t).transformOrigin.split(" ").map(e=>parseFloat(e)),[r,i]=getComputedStyle(t).getPropertyValue("--v-overlay-anchor-origin").split(" ")
let s=a.left+a.width/2
"left"===r||"left"===i?s-=a.width/2:"right"!==r&&"right"!==i||(s+=a.width/2)
let u=a.top+a.height/2
"top"===r||"top"===i?u-=a.height/2:"bottom"!==r&&"bottom"!==i||(u+=a.height/2)
const c=a.width/l.width,d=a.height/l.height,v=Math.max(1,c,d),p=c/v||0,m=d/v||0,f=l.width*l.height/(window.innerWidth*window.innerHeight),g=f>.12?Math.min(1.5,10*(f-.12)+1):1
return{x:s-(n+l.left),y:u-(o+l.top),sx:p,sy:m,speed:g}}const hl=ul("fab-transition","center center","out-in"),yl=ul("dialog-bottom-transition"),bl=ul("dialog-top-transition"),wl=ul("fade-transition"),Vl=ul("scale-transition"),Sl=ul("scroll-x-transition"),kl=ul("scroll-x-reverse-transition"),xl=ul("scroll-y-transition"),Nl=ul("scroll-y-reverse-transition"),Cl=ul("slide-x-transition"),El=ul("slide-x-reverse-transition"),Il=ul("slide-y-transition"),Al=ul("slide-y-reverse-transition"),Pl=cl("expand-transition",dl()),_l=cl("expand-x-transition",dl("","x")),Rl=cl("expand-both-transition",dl("","both")),Dl=Tt({defaults:Object,disabled:Boolean,reset:[Number,String],root:[Boolean,String],scoped:Boolean},"VDefaultsProvider"),Bl=Kt(!1)({name:"VDefaultsProvider",props:Dl(),setup(e,{slots:a}){const{defaults:l,disabled:n,reset:o,root:r,scoped:i}=t.toRefs(e)
return Ht(l,{reset:o,root:r,scoped:i,disabled:n}),()=>a.default?.()}}),Tl=Tt({height:[Number,String],maxHeight:[Number,String],maxWidth:[Number,String],minHeight:[Number,String],minWidth:[Number,String],width:[Number,String]},"dimension")
function Fl(e){return{dimensionStyles:t.computed(()=>{const t={},a=z(e.height),l=z(e.maxHeight),n=z(e.maxWidth),o=z(e.minHeight),r=z(e.minWidth),i=z(e.width)
return a&&(t.height=a),l&&(t.maxHeight=l),n&&(t.maxWidth=n),o&&(t.minHeight=o),r&&(t.minWidth=r),i&&(t.width=i),t})}}const $l=Tt({aspectRatio:[String,Number],contentClass:null,inline:Boolean,...Ft(),...Tl()},"VResponsive"),Ml=Kt()({name:"VResponsive",props:$l(),setup(e,{slots:a}){const{aspectStyles:l}=function(e){return{aspectStyles:t.computed(()=>{const t=Number(e.aspectRatio)
return t?{paddingBottom:String(1/t*100)+"%"}:void 0})}}(e),{dimensionStyles:n}=Fl(e)
return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-responsive",{"v-responsive--inline":e.inline},e.class]),style:t.normalizeStyle([n.value,e.style])},[t.createElementVNode("div",{class:"v-responsive__sizer",style:t.normalizeStyle(l.value)},null),a.additional?.(),a.default&&t.createElementVNode("div",{class:t.normalizeClass(["v-responsive__content",e.contentClass])},[a.default()])])),{}}})
function zl(e){return ve(()=>{const{class:t,style:a}=jl(e)
return{colorClasses:t,colorStyles:a}})}function Ll(e){const{colorClasses:a,colorStyles:l}=zl(()=>({text:t.toValue(e)}))
return{textColorClasses:a,textColorStyles:l}}function Ol(e){const{colorClasses:a,colorStyles:l}=zl(()=>({background:t.toValue(e)}))
return{backgroundColorClasses:a,backgroundColorStyles:l}}function jl(e){const a=function(e){return{text:g(e.text)?e.text.replace(/^text-/,""):e.text,background:g(e.background)?e.background.replace(/^bg-/,""):e.background}}(t.toValue(e)),l=[],n={}
if(a.background)if(ft(a.background)){if(n.backgroundColor=a.background,!a.text&&(ft(o=a.background)&&!/^((rgb|hsl)a?\()?var\(--/.test(o))){const e=yt(a.background)
h(e.a)&&1!==e.a||l.push(Bt(e)?"v-theme-on-dark":"v-theme-on-light")}}else l.push(`bg-${a.background}`)
var o
return a.text&&(ft(a.text)?(n.color=a.text,n.caretColor=a.text):l.push(`text-${a.text}`)),{class:l,style:n}}const Hl=/^-?\d*\.?\d+([a-z%]{0,4})$/i
function Wl(e){return String(e).trim().split(/\s+/)}function Ul(e){return!1===e.toLowerCase().match(Hl)?.at(1)?.startsWith("x")}function Yl(e){return"string"==typeof e&&!!e&&(e.includes("(")||Wl(e).every(Ul))}const Gl=Tt({rounded:{type:[Boolean,Number,String],default:void 0},tile:Boolean},"rounded")
function Kl(e,a=Mt()){return{roundedClasses:t.computed(()=>{const l=t.isRef(e)?e.value:e.rounded,n=[]
if(!t.isRef(e)&&e.tile||!1===l||"0"===String(l))n.push("rounded-0")
else if(!0===l||""===l)n.push(`${a}--rounded`)
else if(g(l)&&!Yl(l))for(const e of Wl(l))n.push(`rounded-${e}`)
return n}),roundedStyles:t.computed(()=>{const a=t.isRef(e)?e.value:e.rounded
return Yl(a)&&"0"!==String(a)||"number"==typeof a&&0!==a?{borderRadius:z(a)}:{}})}}const ql=Tt({transition:{type:null,default:"fade-transition",validator:e=>!0!==e}},"transition"),Xl=(e,{slots:a})=>{const{transition:l,disabled:n,group:o,target:r,...i}=e,{component:s=(o?t.TransitionGroup:t.Transition),...u}=b(l)?l:{}
let c
return c=b(l)?t.mergeProps(u,function(e){const t=["checked","disabled"]
return Object.fromEntries(Object.entries(e).filter(([e,a])=>t.includes(e)?!!a:!x(a)))}({disabled:n,group:o,target:r}),i):t.mergeProps({name:n||!l?"":l},i),t.h(s,c,a)}
function Zl(e,t){if(!I)return
const a=t.modifiers||{},l=t.value,n=f(l)||!b(l)?l:l.handler,o=f(l)||!b(l)?{}:l.options,r=new IntersectionObserver((l=[],o)=>{const r=e._observe?.[t.instance.$.uid]
if(!r)return
const i=l.some(e=>e.isIntersecting)
!n||a.quiet&&!r.init||a.once&&!i&&!r.init||n(i,l,o),i&&a.once?Ql(e,t):r.init=!0},o)
e._observe=Object(e._observe),e._observe[t.instance.$.uid]={init:!1,observer:r},r.observe(e)}function Ql(e,t){const a=e._observe?.[t.instance.$.uid]
a&&(a.observer.unobserve(e),delete e._observe[t.instance.$.uid])}const Jl={mounted:Zl,unmounted:Ql,updated:(e,t)=>{e._observe?.[t.instance.$.uid]&&(Ql(e,t),Zl(e,t))}},en=Tt({absolute:Boolean,alt:String,cover:Boolean,color:String,draggable:{type:[Boolean,String],default:void 0},eager:Boolean,gradient:String,imageClass:null,lazySrc:String,options:{type:Object,default:()=>({root:void 0,rootMargin:void 0,threshold:void 0})},sizes:String,src:{type:[String,Object],default:""},crossorigin:String,referrerpolicy:String,srcset:String,position:String,...$l(),...Ft(),...Gl(),...ql()},"VImg"),tn=Kt()({name:"VImg",directives:{vIntersect:Jl},inheritAttrs:!1,props:en(),emits:{loadstart:e=>!0,load:e=>!0,error:e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{backgroundColorClasses:o,backgroundColorStyles:r}=Ol(()=>e.color),{roundedClasses:i,roundedStyles:s}=Kl(e),u=$t("VImg"),c=t.shallowRef(""),d=t.ref(),v=t.shallowRef(e.eager?"loading":"idle"),p=t.shallowRef(),m=t.shallowRef()
let f=!1
const g=t.computed(()=>b(e.src)?{src:e.src.src,srcset:e.srcset||e.src.srcset,lazySrc:e.lazySrc||e.src.lazySrc,aspect:Number(e.aspectRatio||e.src.aspect||0)}:{src:e.src,srcset:e.srcset,lazySrc:e.lazySrc,aspect:Number(e.aspectRatio||0)}),h=t.computed(()=>g.value.aspect||p.value/m.value||0)
function y(a){if((!e.eager||!a)&&(!I||a||e.eager)){if(v.value="loading",g.value.lazySrc){const e=new Image
e.src=g.value.lazySrc,x(e,null)}g.value.src&&t.nextTick(()=>{l("loadstart",d.value?.currentSrc||g.value.src),setTimeout(()=>{if(!u.isUnmounted)if(d.value?.complete){if(d.value.naturalWidth||V(),"error"===v.value)return
h.value||x(d.value,null),"loading"===v.value&&w()}else d.value&&(h.value||x(d.value),S(d.value))})})}}function w(){u.isUnmounted||(d.value?(S(d.value),x(d.value),l("load",d.value.currentSrc||g.value.src)):f=!0,v.value="loaded")}function V(){u.isUnmounted||(v.value="error",l("error",d.value?.currentSrc||g.value.src))}function S(e){c.value=e.currentSrc||e.src}t.watch(()=>e.src,()=>{y("idle"!==v.value)}),t.watch(h,(e,t)=>{!e&&t&&d.value&&x(d.value)}),t.watch(d,e=>{e&&"idle"!==v.value&&(h.value||x(e),S(e),f&&(f=!1,l("load",e.currentSrc||g.value.src)))}),t.onBeforeMount(()=>y())
let k=-1
function x(e,t=100){const a=()=>{if(clearTimeout(k),u.isUnmounted)return
const{naturalHeight:l,naturalWidth:n}=e
l||n?(p.value=n,m.value=l):e.complete||"loading"!==v.value||null==t?(e.currentSrc.endsWith(".svg")||e.currentSrc.startsWith("data:image/svg+xml"))&&(p.value=1,m.value=1):k=window.setTimeout(a,t)}
a()}t.onBeforeUnmount(()=>{clearTimeout(k)})
const N=t.toRef(()=>({"v-img__img--cover":e.cover,"v-img__img--contain":!e.cover})),C=()=>{if(!g.value.src||"idle"===v.value)return null
const a=t.createElementVNode("img",{class:t.normalizeClass(["v-img__img",N.value,e.imageClass]),style:{objectPosition:e.position},crossorigin:e.crossorigin,src:g.value.src,srcset:g.value.srcset,alt:e.alt,referrerpolicy:e.referrerpolicy,draggable:e.draggable,sizes:e.sizes,ref:d,onLoad:w,onError:V},null),l=n.sources?.()
return t.createVNode(Xl,{transition:e.transition,appear:!0},{default:()=>[t.withDirectives(l?t.createElementVNode("picture",{class:"v-img__picture"},[l,a]):a,[[t.vShow,"loaded"===v.value]])]})},E=()=>t.createVNode(Xl,{transition:e.transition},{default:()=>[g.value.lazySrc&&"loaded"!==v.value&&t.createElementVNode("img",{class:t.normalizeClass(["v-img__img","v-img__img--preload",N.value]),style:{objectPosition:e.position},crossorigin:e.crossorigin,src:g.value.lazySrc,alt:e.alt,referrerpolicy:e.referrerpolicy,draggable:e.draggable},null)]}),A=()=>n.placeholder?t.createVNode(Xl,{transition:e.transition,appear:!0},{default:()=>[("loading"===v.value||"error"===v.value&&!n.error)&&t.createElementVNode("div",{class:"v-img__placeholder"},[n.placeholder()])]}):null,P=()=>n.error?t.createVNode(Xl,{transition:e.transition,appear:!0},{default:()=>["error"===v.value&&t.createElementVNode("div",{class:"v-img__error"},[n.error()])]}):null,_=()=>e.gradient?t.createElementVNode("div",{class:"v-img__gradient",style:{backgroundImage:`linear-gradient(${e.gradient})`}},null):null,R=t.shallowRef(!1)
{const e=t.watch(h,t=>{t&&(requestAnimationFrame(()=>{requestAnimationFrame(()=>{R.value=!0})}),e())})}return sa(()=>{const l=Ml.filterProps(e),[u,c]=J(a)
return t.withDirectives(t.createVNode(Ml,t.mergeProps({class:["v-img",{"v-img--absolute":e.absolute,"v-img--booting":!R.value,"v-img--fit-content":"fit-content"===e.width},o.value,i.value,e.class],style:[{width:z("auto"===e.width?p.value:e.width)},r.value,s.value,e.style]},l,u,{aspectRatio:h.value,"aria-label":e.alt||void 0,role:e.alt?"img":void 0}),{additional:()=>t.createElementVNode(t.Fragment,null,[t.createVNode(C,c,null),t.createVNode(E,null,null),t.createVNode(_,null,null),t.createVNode(A,null,null),t.createVNode(P,null,null)]),default:n.default}),[[Jl,{handler:y,options:e.options},null,{once:!0}]])}),{currentSrc:c,image:d,state:v,naturalWidth:p,naturalHeight:m}}}),an=Tt({border:[Boolean,Number,String]},"border")
function ln(e,a=Mt()){return{borderClasses:t.computed(()=>{const t=e.border
return!0===t||""===t?`${a}--border`:g(t)||0===t?String(t).split(" ").map(e=>`border-${e}`):[]})}}const nn=Tt({elevation:{type:[Number,String],validator:e=>parseInt(e)>=0},hoverElevation:{type:[Number,String],validator:e=>parseInt(e)>=0}},"elevation")
function on(e){return{elevationClasses:t.toRef(()=>{const a=t.isRef(e)?e.value:e.elevation,l=t.isRef(e)?null:e.hoverElevation
return[...k(a)?[]:[`elevation-${parseInt(a)}`],...k(l)?[]:[`hover-elevation-${parseInt(l)}`]]})}}const rn={center:"center",top:"bottom",bottom:"top",left:"right",right:"left"},sn=Tt({location:String},"location")
function un(e,a=!1,l){const{isRtl:n}=Ua(),o=t.computed(()=>{if(!e.location)return{}
const{side:t,align:o}=$e(e.location.split(" ").length>1?e.location:`${e.location} center`,n.value)
function r(e){return l?l(e):0}const i={}
return"center"!==t&&(a?i[rn[t]]=`calc(100% - ${r(t)}px)`:i[t]=0),"center"!==o?a?i[rn[o]]=`calc(100% - ${r(o)}px)`:i[o]=0:("center"===t?i.top=i.left="50%":i[{top:"left",bottom:"left",left:"top",right:"top"}[t]]="50%",i.transform={top:"translateX(-50%)",bottom:"translateX(-50%)",left:"translateY(-50%)",right:"translateY(-50%)",center:"translate(-50%, -50%)"}[t]),i})
return{locationStyles:o}}const cn=[null,"prominent","default","comfortable","compact"],dn=Tt({absolute:Boolean,collapse:Boolean,collapsePosition:{type:String,default:"start"},color:String,density:{type:String,default:"default",validator:e=>cn.includes(e)},extended:{type:Boolean,default:null},extensionHeight:{type:[Number,String],default:48},flat:Boolean,floating:Boolean,height:{type:[Number,String],default:64},image:String,title:String,...an(),...Ft(),...nn(),...sn(),...Gl(),...ol({tag:"header"}),...Ga()},"VToolbar"),vn=Kt()({name:"VToolbar",props:dn(),setup(e,{slots:a}){const{backgroundColorClasses:l,backgroundColorStyles:n}=Ol(()=>e.color),{borderClasses:o}=ln(e),{elevationClasses:r}=on(e),{locationStyles:i}=un(e),{roundedClasses:s,roundedStyles:u}=Kl(e),{themeClasses:c}=tl(e),{rtlClasses:d}=Ua(),v=t.shallowRef(null===e.extended?!!a.extension?.():e.extended),p=t.computed(()=>parseInt(Number(e.height)+("prominent"===e.density?Number(e.height):0)-("comfortable"===e.density?8:0)-("compact"===e.density?16:0),10)),m=t.computed(()=>v.value?parseInt(Number(e.extensionHeight)+("prominent"===e.density?Number(e.extensionHeight):0)-("comfortable"===e.density?4:0)-("compact"===e.density?8:0),10):0)
return Ht({VBtn:{variant:"text"}}),sa(()=>{const f=!(!e.title&&!a.title),g=!(!a.image&&!e.image),h=a.extension?.()
return v.value=null===e.extended?!!h:e.extended,t.createVNode(e.tag,{class:t.normalizeClass(["v-toolbar",`v-toolbar--collapse-${e.collapsePosition}`,{"v-toolbar--absolute":e.absolute,"v-toolbar--collapse":e.collapse,"v-toolbar--flat":e.flat,"v-toolbar--floating":e.floating,[`v-toolbar--density-${e.density}`]:!0},l.value,o.value,r.value,s.value,c.value,d.value,e.class]),style:t.normalizeStyle([n.value,i.value,u.value,e.style])},{default:()=>[g&&t.createElementVNode("div",{key:"image",class:"v-toolbar__image"},[a.image?t.createVNode(Bl,{key:"image-defaults",disabled:!e.image,defaults:{VImg:{cover:!0,src:e.image}}},a.image):t.createVNode(tn,{key:"image-img",cover:!0,src:e.image},null)]),t.createVNode(Bl,{defaults:{VTabs:{height:z(p.value)}}},{default:()=>[t.createElementVNode("div",{class:"v-toolbar__content",style:{height:z(p.value)}},[a.prepend&&t.createElementVNode("div",{class:"v-toolbar__prepend"},[a.prepend?.()]),f&&t.createVNode(il,{key:"title",text:e.title},{text:a.title}),a.default?.(),a.append&&t.createElementVNode("div",{class:"v-toolbar__append"},[a.append?.()])])]}),t.createVNode(Bl,{defaults:{VTabs:{height:z(m.value)}}},{default:()=>[t.createVNode(Pl,null,{default:()=>[v.value&&t.createElementVNode("div",{class:"v-toolbar__extension",style:{height:z(m.value)}},[h])]})]})]})}),{contentHeight:p,extensionHeight:m}}}),pn=Tt({scrollTarget:{type:String},scrollThreshold:{type:[String,Number],default:300}},"scroll")
function mn(){const e=t.shallowRef(!1)
t.onMounted(()=>{window.requestAnimationFrame(()=>{e.value=!0})})
return{ssrBootStyles:t.toRef(()=>e.value?void 0:{transition:"none !important"}),isBooted:t.readonly(e)}}const fn=Tt({scrollBehavior:String,modelValue:{type:Boolean,default:!0},location:{type:String,default:"top",validator:e=>["top","bottom"].includes(e)},...G(dn(),["location"]),...Ca(),...pn(),height:{type:[Number,String],default:64}},"VAppBar"),gn=Kt()({name:"VAppBar",props:fn(),emits:{"update:modelValue":e=>!0},setup(e,{slots:l}){const n=t.ref(),o=_a(e,"modelValue"),r=t.computed(()=>{const t=new Set(e.scrollBehavior?.split(" ")??[])
return{hide:t.has("hide"),fullyHide:t.has("fully-hide"),inverted:t.has("inverted"),collapse:t.has("collapse"),elevate:t.has("elevate"),fadeImage:t.has("fade-image")}}),i=t.computed(()=>{const e=r.value
return e.hide||e.fullyHide||e.inverted||e.collapse||e.elevate||e.fadeImage||!o.value}),s=t.computed(()=>(n.value?.contentHeight??0)+(n.value?.extensionHeight??0)),{currentScroll:u,scrollThreshold:c,isScrollingUp:d,scrollRatio:v,isAtBottom:p,reachedBottomWhileScrollingDown:m,hasEnoughScrollableSpace:f}=function(e,l={}){const{canScroll:n,layoutSize:o}=l
let r=0,i=0
const s=t.ref(null),u=t.shallowRef(0),c=t.shallowRef(0),d=t.shallowRef(0),v=t.shallowRef(!1),p=t.shallowRef(!1),m=t.shallowRef(!1),f=t.shallowRef(!1),g=t.shallowRef(!0),h=t.computed(()=>Number(e.scrollThreshold)),y=t.computed(()=>ae((h.value-u.value)/h.value||0))
function b(e){return{clientHeight:"window"in e?window.innerHeight:e.clientHeight,scrollHeight:"window"in e?document.documentElement.scrollHeight:e.scrollHeight}}function w(){const e=s.value
if(!e)return
const{clientHeight:t,scrollHeight:a}=b(e),l=a-t,n=o?.value||0,r=h.value+n
g.value=l>r}function V(){w()}function S(){const e=s.value
if(!e||n&&!n.value)return
r=u.value,u.value="window"in e?e.pageYOffset:e.scrollTop
const t=e instanceof Window?document.documentElement.scrollHeight:e.scrollHeight
i!==t&&(t>i&&w(),i=t),p.value=u.value<r,d.value=Math.abs(u.value-h.value)
const{clientHeight:a,scrollHeight:l}=b(e),o=u.value+a>=l-5
!p.value&&o&&u.value>=h.value&&g.value&&(f.value=!0)
const c=Math.abs(u.value-r)>100,v=u.value<=5;(p.value&&r-u.value>1&&!o||c&&u.value<h.value||v)&&(f.value=!1),m.value=o}return t.watch(p,()=>{c.value=c.value||u.value}),t.watch(v,()=>{c.value=0}),t.onMounted(()=>{t.watch(()=>e.scrollTarget,e=>{const t=e?document.querySelector(e):window
t?t!==s.value&&(s.value?.removeEventListener("scroll",S),s.value=t,s.value.addEventListener("scroll",S,{passive:!0}),Promise.resolve().then(()=>{w()})):a(`Unable to locate element with identifier ${e}`)},{immediate:!0}),window.addEventListener("resize",V,{passive:!0})}),t.onBeforeUnmount(()=>{s.value?.removeEventListener("scroll",S),window.removeEventListener("resize",V)}),n&&t.watch(n,S,{immediate:!0}),{scrollThreshold:h,currentScroll:u,currentThreshold:d,isScrollActive:v,scrollRatio:y,isScrollingUp:p,savedScroll:c,isAtBottom:m,reachedBottomWhileScrollingDown:f,hasEnoughScrollableSpace:g}}(e,{canScroll:i,layoutSize:s}),g=t.toRef(()=>r.value.hide||r.value.fullyHide),h=t.computed(()=>e.collapse||r.value.collapse&&(r.value.inverted?v.value>0:0===v.value)),y=t.computed(()=>e.flat||r.value.fullyHide&&!o.value||r.value.elevate&&(r.value.inverted?u.value>0:0===u.value)),b=t.computed(()=>r.value.fadeImage?r.value.inverted?1-v.value:v.value:void 0),w=t.computed(()=>{if(r.value.hide&&r.value.inverted)return 0
const e=n.value?.contentHeight??0,t=n.value?.extensionHeight??0
return g.value?u.value<c.value||r.value.fullyHide?e+t:e:e+t})
Pa(()=>!!e.scrollBehavior,()=>{t.watchEffect(()=>{g.value?r.value.inverted?o.value=u.value>c.value:f.value?m.value?o.value=!1:o.value=d.value&&!p.value||u.value<c.value:o.value=!0:o.value=!0})})
const{ssrBootStyles:V}=mn(),{layoutItemStyles:S}=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:t.toRef(()=>e.location),layoutSize:w,elementSize:t.shallowRef(void 0),active:o,absolute:t.toRef(()=>e.absolute)})
return sa(()=>{const a=G(vn.filterProps(e),["location"])
return t.createVNode(vn,t.mergeProps({ref:n,class:["v-app-bar",{"v-app-bar--bottom":"bottom"===e.location},e.class],style:[{...S.value,"--v-toolbar-image-opacity":b.value,height:void 0,...V.value},e.style]},a,{collapse:h.value,flat:y.value}),l)}),{}}}),hn=[null,"default","comfortable","compact"],yn=Tt({density:{type:String,default:"default",validator:e=>hn.includes(e)}},"density")
function bn(e,a=Mt()){return{densityClasses:t.toRef(()=>`${a}--density-${e.density}`)}}const wn=["x-small","small","default","large","x-large"],Vn=Tt({size:{type:[String,Number],default:"default"}},"size")
function Sn(e,t=Mt()){return ve(()=>{const a=e.size
let l,n
return pe(wn,a)?l=`${t}--size-${a}`:a&&(n={width:z(a),height:z(a)}),{sizeClasses:l,sizeStyles:n}})}const kn=["elevated","flat","tonal","outlined","text","plain"]
function xn(e,a){return t.createElementVNode(t.Fragment,null,[e&&t.createElementVNode("span",{key:"overlay",class:t.normalizeClass(`${a}__overlay`)},null),t.createElementVNode("span",{key:"underlay",class:t.normalizeClass(`${a}__underlay`)},null)])}const Nn=Tt({color:String,variant:{type:String,default:"elevated",validator:e=>kn.includes(e)}},"variant")
function Cn(e,a=Mt()){const l=t.toRef(()=>{const{variant:l}=t.toValue(e)
return`${a}--variant-${l}`}),{colorClasses:n,colorStyles:o}=zl(()=>{const{variant:a,color:l}=t.toValue(e)
return{[["elevated","flat"].includes(a)?"background":"text"]:l}})
return{colorClasses:n,colorStyles:o,variantClasses:l}}const En=Tt({baseColor:String,divided:Boolean,direction:{type:String,default:"horizontal"},...an(),...Ft(),...yn(),...nn(),...Gl(),...Vn({size:void 0}),...ol(),...Ga(),...Nn()},"VBtnGroup"),In=Kt()({name:"VBtnGroup",props:En(),setup(e,{slots:a}){const{themeClasses:l}=tl(e),{densityClasses:n}=bn(e),{borderClasses:o}=ln(e),{elevationClasses:r}=on(e),{roundedClasses:i,roundedStyles:s}=Kl(e)
Ht({VBtn:{height:t.toRef(()=>"horizontal"===e.direction&&null==e.size?"auto":null),baseColor:t.toRef(()=>e.baseColor),color:t.toRef(()=>e.color),density:t.toRef(()=>e.density),flat:!0,size:t.toRef(()=>e.size),variant:t.toRef(()=>e.variant)}}),sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-btn-group",`v-btn-group--${e.direction}`,{"v-btn-group--divided":e.divided,"v-btn-group--has-size":null!=e.size},l.value,o.value,n.value,r.value,i.value,e.class]),style:t.normalizeStyle([s.value,e.style])},a))}}),An=Tt({modelValue:{type:null,default:void 0},multiple:Boolean,mandatory:[Boolean,String],max:Number,selectedClass:String,disabled:Boolean},"group"),Pn=Tt({value:null,disabled:Boolean,selectedClass:String},"group-item")
function _n(e,a,l=!0){const n=$t("useGroupItem")
if(!n)throw new Error("[Vuetify] useGroupItem composable must be used inside a component setup function")
const o=t.useId()
t.provide(Symbol.for(`${a.description}:id`),o)
const r=t.inject(a,null)
if(!r){if(!l)return r
throw new Error(`[Vuetify] Could not find useGroup injection with symbol ${a.description}`)}const i=t.toRef(()=>e.value),s=t.computed(()=>!(!r.disabled.value&&!e.disabled))
function u(){r?.register({id:o,value:i,disabled:s},n)}function c(){r?.unregister(o)}u(),t.onBeforeUnmount(()=>c())
const d=t.computed(()=>r.isSelected(o)),v=t.computed(()=>r.items.value[0].id===o),p=t.computed(()=>r.items.value[r.items.value.length-1].id===o),m=t.computed(()=>d.value&&[r.selectedClass.value,e.selectedClass])
return t.watch(d,e=>{n.emit("group:selected",{value:e})},{flush:"sync"}),{id:o,isSelected:d,isFirst:v,isLast:p,toggle:()=>r.select(o,!d.value),select:e=>r.select(o,e),selectedClass:m,value:i,disabled:s,group:r,register:u,unregister:c}}function Rn(e,l){let n=!1
const o=t.reactive([]),r=_a(e,"modelValue",[],e=>x(e)?[]:Dn(o,S(e)?[null]:ee(e)),t=>{const a=function(e,t){const a=[]
return t.forEach(t=>{const l=e.findIndex(e=>e.id===t)
if(~l){const t=e[l]
a.push(x(t.value)?l:t.value)}}),a}(o,t)
return e.multiple?a:a[0]}),i=$t("useGroup")
function s(){const t=o.find(e=>!e.disabled)
t&&"force"===e.mandatory&&!r.value.length&&(r.value=[t.id])}function u(t){if(e.multiple&&a('This method is not supported when using "multiple" prop'),r.value.length){const e=r.value[0],a=o.findIndex(t=>t.id===e)
let l=(a+t)%o.length,n=o[l]
for(;n.disabled&&l!==a;)l=(l+t)%o.length,n=o[l]
if(n.disabled)return
r.value=[o[l].id]}else{const e=o.find(e=>!e.disabled)
e&&(r.value=[e.id])}}t.onMounted(()=>{s()}),t.onBeforeUnmount(()=>{n=!0}),t.onUpdated(()=>{for(let e=0;e<o.length;e++)o[e].useIndexAsValue&&(o[e].value=e)})
const c={register:function(e,a){const n=e,r=ce(Symbol.for(`${l.description}:id`),i?.vnode).indexOf(a)
x(t.unref(n.value))&&(n.value=r,n.useIndexAsValue=!0),r>-1?o.splice(r,0,n):o.push(n)},unregister:function(e){if(n)return
s()
const t=o.findIndex(t=>t.id===e)
o.splice(t,1)},selected:r,select:function(t,a){const l=o.find(e=>e.id===t)
if(!a||!l?.disabled)if(e.multiple){const l=r.value.slice(),n=l.findIndex(e=>e===t),o=~n
if(a=a??!o,o&&e.mandatory&&l.length<=1)return
if(!o&&h(e.max)&&l.length+1>e.max)return
n<0&&a?l.push(t):n>=0&&!a&&l.splice(n,1),r.value=l}else{const l=r.value.includes(t)
if(e.mandatory&&l)return
if(!l&&!a)return
r.value=a??!l?[t]:[]}},disabled:t.toRef(()=>e.disabled),prev:()=>u(o.length-1),next:()=>u(1),isSelected:e=>r.value.includes(e),selectedClass:t.toRef(()=>e.selectedClass),items:t.toRef(()=>o),getItemIndex:e=>function(e,t){const a=Dn(e,[t])
return a.length?e.findIndex(e=>e.id===a[0]):-1}(o,e)}
return t.provide(l,c),c}function Dn(e,t){const a=[]
return t.forEach(t=>{const l=e.find(e=>Xt(t,e.value)),n=e[t]
x(l?.value)?n?.useIndexAsValue&&a.push(n.id):a.push(l.id)}),a}const Bn=Symbol.for("vuetify:v-btn-toggle"),Tn=Tt({...En(),...An()},"VBtnToggle"),Fn=Kt()({name:"VBtnToggle",props:Tn(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{isSelected:l,next:n,prev:o,select:r,selected:i}=Rn(e,Bn)
return sa(()=>{const s=In.filterProps(e)
return t.createVNode(In,t.mergeProps({class:["v-btn-toggle",{"v-btn-toggle--has-color":!!e.color},e.class]},s,{style:e.style}),{default:()=>[a.default?.({isSelected:l,next:n,prev:o,select:r,selected:i})]})}),{next:n,prev:o,select:r}}}),$n=Tt({color:String,disabled:Boolean,start:Boolean,end:Boolean,icon:ua,opacity:[String,Number],...Ft(),...Vn(),...ol({tag:"i"}),...Ga()},"VIcon"),Mn=Kt()({name:"VIcon",props:$n(),setup(e,{attrs:l,slots:n}){const o=t.shallowRef(),{themeClasses:r}=al(),{iconData:i}=(e=>{const l=t.inject(ca)
if(!l)throw new Error("Missing Vuetify Icons provide!")
return{iconData:t.computed(()=>{const n=t.toValue(e)
if(!n)return{component:va}
let o=n
if(g(o)&&(o=o.trim(),o.startsWith("$")&&(o=l.aliases?.[o.slice(1)])),o||a(`Could not find aliased icon "${n}"`),Array.isArray(o))return{component:pa,icon:o}
if(!g(o))return{component:va,icon:o}
const r=Object.keys(l.sets).find(e=>g(o)&&o.startsWith(`${e}:`)),i=r?o.slice(r.length+1):o
return{component:l.sets[r??l.defaultSet].component,icon:i}})}})(()=>o.value||e.icon),{sizeClasses:s}=Sn(e),{textColorClasses:u,textColorStyles:c}=Ll(()=>e.color)
return sa(()=>{const a=n.default?.()
a&&(o.value=se(a).filter(e=>e.type===t.Text&&e.children&&g(e.children))[0]?.children)
const d=!(!l.onClick&&!l.onClickOnce)
return t.createVNode(i.value.component,{tag:e.tag,icon:i.value.icon,class:t.normalizeClass(["v-icon","notranslate",r.value,s.value,u.value,{"v-icon--clickable":d,"v-icon--disabled":e.disabled,"v-icon--start":e.start,"v-icon--end":e.end},e.class]),style:t.normalizeStyle([{"--v-icon-opacity":e.opacity},s.value?void 0:{fontSize:z(e.size),height:z(e.size),width:z(e.size)},c.value,e.style]),role:d?"button":void 0,"aria-hidden":!d,tabindex:d?e.disabled?-1:0:void 0},{default:()=>[a]})}),{}}})
function zn(e,a){const l=t.ref(),n=t.shallowRef(!1)
if(I){const e=new IntersectionObserver(e=>{n.value=!!e.find(e=>e.isIntersecting)},a)
t.onScopeDispose(()=>{e.disconnect()}),t.watch(l,(t,a)=>{a&&(e.unobserve(a),n.value=!1),t&&e.observe(t)},{flush:"post"})}return{intersectionRef:l,isIntersecting:n}}const Ln=Tt({reveal:{type:[Boolean,Object],default:!1}},"reveal")
function On(e){const a=t.toRef(()=>b(e.reveal)?Math.max(0,Number(e.reveal.duration??900)):900),l=t.shallowRef(e.reveal?"initial":"disabled")
return t.onMounted(async()=>{e.reveal&&(l.value="initial",await new Promise(e=>requestAnimationFrame(e)),l.value="pending",await new Promise(e=>setTimeout(e,a.value)),l.value="done")}),{duration:a,state:l}}const jn=Tt({bgColor:String,color:String,indeterminate:[Boolean,String],rounded:Boolean,modelValue:{type:[Number,String],default:0},rotate:{type:[Number,String],default:0},transition:{type:[Boolean,Object],default:void 0},width:{type:[Number,String],default:4},...Ft(),...Ln(),...Vn(),...ol({tag:"div"}),...Ga()},"VProgressCircular"),Hn=Kt()({name:"VProgressCircular",props:jn(),setup(e,{slots:a}){const l=2*Math.PI*20,n=t.ref(),{themeClasses:o}=tl(e),{sizeClasses:r,sizeStyles:i}=Sn(e),{textColorClasses:s,textColorStyles:u}=Ll(()=>e.color),{textColorClasses:c,textColorStyles:d}=Ll(()=>e.bgColor),{intersectionRef:v,isIntersecting:p}=zn(),{resizeRef:m,contentRect:f}=Sa(),{state:g,duration:h}=On(e),y=t.toRef(()=>"initial"===g.value?0:ae(parseFloat(e.modelValue),0,100)),w=t.toRef(()=>Number(e.width)),V=t.toRef(()=>!1===e.transition?void 0:z(b(e.transition)?e.transition.duration:void 0,"ms")),S=t.toRef(()=>i.value?Number(e.size):f.value?f.value.width:Math.max(w.value,32)),k=t.toRef(()=>20/(1-w.value/S.value)*2),x=t.toRef(()=>w.value/S.value*k.value),N=t.toRef(()=>{const t=(100-y.value)/100*l
return e.rounded&&y.value>0&&y.value<100?z(Math.min(l-.01,t+x.value)):z(t)}),C=t.computed(()=>{const t=Number(e.rotate)
return e.rounded?t+x.value/2/l*360:t})
return t.watchEffect(()=>{v.value=n.value,m.value=n.value}),sa(()=>t.createVNode(e.tag,{ref:n,class:t.normalizeClass(["v-progress-circular",{"v-progress-circular--indeterminate":!!e.indeterminate,"v-progress-circular--visible":p.value,"v-progress-circular--disable-shrink":e.indeterminate&&("disable-shrink"===e.indeterminate||R()),"v-progress-circular--revealing":["initial","pending"].includes(g.value),"v-progress-circular--no-transition":!1===e.transition},o.value,r.value,s.value,e.class]),style:t.normalizeStyle([i.value,u.value,{"--v-progress-reveal-duration":`${h.value}ms`,"--v-progress-circular-transition-duration":V.value},e.style]),role:"progressbar","aria-valuemin":"0","aria-valuemax":"100","aria-valuenow":e.indeterminate?void 0:y.value},{default:()=>[t.createElementVNode("svg",{style:{transform:`rotate(calc(-90deg + ${C.value}deg))`},xmlns:"http://www.w3.org/2000/svg",viewBox:`0 0 ${k.value} ${k.value}`},[t.createElementVNode("circle",{class:t.normalizeClass(["v-progress-circular__underlay",c.value]),style:t.normalizeStyle(d.value),fill:"transparent",cx:"50%",cy:"50%",r:20,"stroke-width":x.value,"stroke-dasharray":l,"stroke-dashoffset":0},null),t.createElementVNode("circle",{class:"v-progress-circular__overlay",fill:"transparent",cx:"50%",cy:"50%",r:20,"stroke-width":x.value,"stroke-dasharray":l,"stroke-dashoffset":N.value,"stroke-linecap":e.rounded?"round":void 0},null)]),a.default&&t.createElementVNode("div",{class:"v-progress-circular__content"},[a.default({value:y.value})])]})),{}}}),Wn=Tt({chunkCount:{type:[Number,String],default:null},chunkWidth:{type:[Number,String],default:null},chunkGap:{type:[Number,String],default:4},variant:{type:String,default:void 0,validator:e=>["split"].includes(e)}},"chunks")
const Un=Tt({absolute:Boolean,active:{type:Boolean,default:!0},bgColor:String,bgOpacity:[Number,String],bufferValue:{type:[Number,String],default:0},bufferColor:String,bufferOpacity:[Number,String],clickable:Boolean,color:String,height:{type:[Number,String],default:4},indeterminate:Boolean,max:{type:[Number,String],default:100},modelValue:{type:[Number,String],default:0},opacity:[Number,String],reverse:Boolean,stream:Boolean,striped:Boolean,roundedBar:Boolean,transition:{type:[Boolean,Object],default:void 0},...Wn(),...Ft(),...sn({location:"top"}),...Ln(),...Gl(),...ol(),...Ga()},"VProgressLinear"),Yn=Kt()({name:"VProgressLinear",props:Un(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=t.ref(),n=_a(e,"modelValue"),{isRtl:o,rtlClasses:r}=Ua(),{themeClasses:i}=tl(e),{locationStyles:s}=un(e),{textColorClasses:u,textColorStyles:c}=Ll(()=>e.color),{backgroundColorClasses:d,backgroundColorStyles:v}=Ol(()=>e.bgColor||e.color),{backgroundColorClasses:p,backgroundColorStyles:m}=Ol(()=>e.bufferColor||e.bgColor||e.color),{backgroundColorClasses:f,backgroundColorStyles:g}=Ol(()=>e.color),{roundedClasses:h,roundedStyles:y}=Kl(e),{intersectionRef:w,isIntersecting:V}=zn(),{state:S,duration:k}=On(e),x=t.computed(()=>parseFloat(e.max)),N=t.computed(()=>z(e.height)),C=t.computed(()=>ae(parseFloat(e.bufferValue)/x.value*100,0,100)),E=t.computed(()=>"initial"===S.value?0:ae(parseFloat(n.value)/x.value*100,0,100)),I=t.computed(()=>o.value!==e.reverse),A=t.computed(()=>!1===e.transition?void 0:z(b(e.transition)?e.transition.duration:void 0,"ms")),P=t.computed(()=>e.indeterminate?"fade-transition":"slide-x-transition"),_=t.shallowRef(0),{hasChunks:R,splitStyles:D,chunksMaskStyles:B,snapValueToChunk:T}=function(e,a,l,n,o){const r=t.toRef(()=>"split"===e.variant),i=t.toRef(()=>r.value?2:Number(e.chunkCount)||0),s=t.toRef(()=>!(r.value||!i.value&&!e.chunkWidth)),u=t.computed(()=>{const l=t.toValue(a)
return l?i.value?(l-Number(e.chunkGap)*(i.value-1))/i.value:Number(e.chunkWidth):0}),c=t.toRef(()=>Number(e.chunkGap)),d=t.computed(()=>{if(!s.value)return{}
const e=z(c.value),t=z(u.value)
return{maskRepeat:"repeat-x",maskImage:`linear-gradient(90deg, #000, #000 ${t}, transparent ${t}, transparent)`,maskSize:`calc(${t} + ${e}) 100%`}}),v=t.computed(()=>{if(!r.value)return
const e=z(c.value/2),a=t.toValue(o)?"right":"left",i=t.toValue(l)
if(i<=0||i>=100)return
const s=t.toValue(n),u=z(i,"%"),d=s>i&&s<100,v=z(s,"%")
return{bar:{width:`calc(${u} - ${e})`},buffer:d?{[a]:`calc(${u} + ${e})`,width:`calc(${v} - ${u} - ${z(c.value)})`}:void 0,background:{[a]:`calc(${d?v:u} + ${e})`,width:`calc(100% - ${d?v:u} - ${e})`}}})
return{hasChunks:t.toRef(()=>s.value||r.value),isSplit:r,chunkCount:i,chunksMaskStyles:d,splitStyles:v,snapValueToChunk:function(e){if(r.value)return e
const l=t.toValue(a)
if(!l)return e
const n=100*c.value/l,o=100*(u.value+c.value)/l
return ae(Math.floor((e+n)/o+1e-9)*o-n/2,0,100)}}}(e,_,E,C,I)
Pa(R,()=>{const{resizeRef:e}=Sa(e=>_.value=e[0].contentRect.width)
t.watchEffect(()=>e.value=l.value)})
const F=t.computed(()=>R.value?T(C.value):C.value),$=t.computed(()=>R.value?T(E.value):E.value)
function M(e){if(!w.value)return
const{left:t,right:a,width:l}=w.value.getBoundingClientRect(),o=I.value?l-e.clientX+(a-l):e.clientX-t
n.value=Math.round(o/l*x.value)}function L(){return t.createElementVNode("div",{class:t.normalizeClass(["v-progress-linear__background",d.value]),style:t.normalizeStyle([v.value,{opacity:null!=e.bgOpacity?parseFloat(e.bgOpacity):void 0,width:e.stream?0:void 0},e.indeterminate?{}:D.value?.background])},null)}return t.watchEffect(()=>{w.value=l.value}),sa(()=>t.createVNode(e.tag,{ref:l,class:t.normalizeClass(["v-progress-linear",{"v-progress-linear--absolute":e.absolute,"v-progress-linear--active":e.active&&V.value,"v-progress-linear--reverse":I.value,"v-progress-linear--rounded":e.rounded,"v-progress-linear--rounded-bar":e.roundedBar,"v-progress-linear--striped":e.striped,"v-progress-linear--clickable":e.clickable,"v-progress-linear--no-transition":!1===e.transition,"v-progress-linear--revealing":["initial","pending"].includes(S.value),"v-progress-linear--variant-split":"split"===e.variant},h.value,i.value,r.value,e.class]),style:t.normalizeStyle([{bottom:"bottom"===e.location?0:void 0,top:"top"===e.location?0:void 0,height:e.active?N.value:0,"--v-progress-linear-height":N.value,"--v-progress-linear-transition-duration":A.value,"--v-progress-reveal-duration":`${k.value}ms`,"--v-progress-chunk-gap":z(e.chunkGap),...e.absolute?s.value:{}},B.value,y.value,e.style]),role:"progressbar","aria-hidden":e.active?"false":"true","aria-valuemin":"0","aria-valuemax":e.max,"aria-valuenow":e.indeterminate?void 0:Math.min(parseFloat(n.value),x.value),onClick:e.clickable&&M},{default:()=>[e.stream&&t.createElementVNode("div",{key:"stream",class:t.normalizeClass(["v-progress-linear__stream",u.value]),style:{...c.value,[I.value?"left":"right"]:`calc(${N.value} * -1)`,borderTop:`calc(${N.value} / 2) dotted`,opacity:null!=e.bufferOpacity?parseFloat(e.bufferOpacity):void 0,top:`calc(50% - ${N.value} / 4)`,width:z(100-C.value,"%"),"--v-progress-linear-stream-to":`calc(${N.value} * ${I.value?1:-1})`}},null),("split"!==e.variant||!e.indeterminate)&&L(),t.createElementVNode("div",{class:t.normalizeClass(["v-progress-linear__buffer",p.value]),style:t.normalizeStyle([m.value,{opacity:null!=e.bufferOpacity?parseFloat(e.bufferOpacity):void 0,width:z(F.value,"%")},D.value?.buffer])},null),t.createVNode(t.Transition,{name:P.value},{default:()=>[e.indeterminate?t.createElementVNode("div",{class:"v-progress-linear__indeterminate"},["split"===e.variant&&t.createElementVNode(t.Fragment,null,[L(),L(),L()]),["long","short"].map(e=>t.createElementVNode("div",{key:e,class:t.normalizeClass(["v-progress-linear__indeterminate",e,f.value]),style:t.normalizeStyle(g.value)},null))]):t.createElementVNode("div",{class:t.normalizeClass(["v-progress-linear__determinate",f.value]),style:t.normalizeStyle([g.value,{width:z($.value,"%")},D.value?.bar])},null)]}),a.default&&t.createElementVNode("div",{class:"v-progress-linear__content"},[a.default({value:E.value,buffer:C.value})])]})),{}}}),Gn=Tt({loading:[Boolean,String]},"loader")
function Kn(e,a=Mt()){return{loaderClasses:t.toRef(()=>({[`${a}--loading`]:e.loading}))}}function qn(e,{slots:a}){return t.createElementVNode("div",{class:t.normalizeClass(`${e.name}__loader`)},[a.default?.({color:e.color,isActive:e.active})||t.createVNode(Yn,{absolute:e.absolute,active:e.active,color:e.color,height:"2",indeterminate:!0},null)])}const Xn=["static","relative","fixed","absolute","sticky"],Zn=Tt({position:{type:String,validator:e=>Xn.includes(e)}},"position")
function Qn(e,a=Mt()){return{positionClasses:t.toRef(()=>e.position?`${a}--${e.position}`:void 0)}}function Jn(){return $t("useRouter")?.proxy?.$router}function eo(e,a){const l=t.resolveDynamicComponent("RouterLink"),n=t.toRef(()=>!(!e.href&&!e.to)),o=t.computed(()=>n?.value||ge(a,"click")||ge(e,"click"))
if(g(l)||!("useLink"in l)){const a=t.toRef(()=>e.href)
return{isLink:n,isRouterLink:t.toRef(()=>!1),isClickable:o,href:a,linkProps:t.reactive({href:a}),route:t.toRef(()=>{}),navigate:t.toRef(()=>{})}}const r=l.useLink({to:t.toRef(()=>e.to||""),replace:t.toRef(()=>e.replace)}),i=t.computed(()=>e.to?r:void 0),s=function(){const e=$t("useRoute")
return t.computed(()=>e?.proxy?.$route)}(),u=t.computed(()=>!!i.value&&(s.value&&0===s.value.matched.length&&null==s.value.name?i.value.isExactActive?.value??!1:e.exact?s.value?i.value.isExactActive?.value&&Xt(i.value.route.value.query,s.value.query):i.value.isExactActive?.value??!1:i.value.isActive?.value??!1)),c=t.computed(()=>e.to?i.value?.route.value.href:e.href),d=t.toRef(()=>!!e.to)
return{isLink:n,isRouterLink:d,isClickable:o,isActive:u,route:t.toRef(()=>i.value?.route.value),navigate:t.toRef(()=>i.value?.navigate),href:c,linkProps:t.reactive({href:c,"aria-current":t.toRef(()=>u.value?"page":void 0),"aria-disabled":t.toRef(()=>e.disabled&&n.value?"true":void 0),tabindex:t.toRef(()=>e.disabled&&n.value?"-1":void 0)})}}const to=Tt({href:String,replace:Boolean,to:[String,Object],exact:Boolean},"router")
let ao=!1
const lo=Symbol("rippleStop")
function no(e,t){e.style.transform=t,e.style.webkitTransform=t}function oo(e){return"TouchEvent"===e.constructor.name}function ro(e){return"KeyboardEvent"===e.constructor.name}const io={show(e,t,a={}){if(!t?._ripple?.enabled)return
const l=document.createElement("span"),n=document.createElement("span")
l.appendChild(n),l.className="v-ripple__container",a.class&&(l.className+=` ${a.class}`)
const{radius:o,scale:r,x:i,y:s,centerX:u,centerY:c}=((e,t,a={})=>{let l=0,n=0
if(!ro(e)){const a=new He(t),o=oo(e)?e.touches[e.touches.length-1]:e,r=Ue([o.clientX,o.clientY])
l=r.x-a.left,n=r.y-a.top}let o=0,r=.3
t._ripple?.circle?(r=.15,o=t.clientWidth/2,o=a.center?o:o+Math.sqrt((l-o)**2+(n-o)**2)/4):o=Math.sqrt(t.clientWidth**2+t.clientHeight**2)/2
const i=(t.clientWidth-2*o)/2+"px",s=(t.clientHeight-2*o)/2+"px"
return{radius:o,scale:r,x:a.center?i:l-o+"px",y:a.center?s:n-o+"px",centerX:i,centerY:s}})(e,t,a),d=2*o+"px"
n.className="v-ripple__animation",n.style.width=d,n.style.height=d,t.appendChild(l)
const v=window.getComputedStyle(t)
v&&"static"===v.position&&(t.style.position="relative",t.dataset.previousPosition="static"),n.classList.add("v-ripple__animation--enter"),n.classList.add("v-ripple__animation--visible"),no(n,`translate(${i}, ${s}) scale3d(${r},${r},${r})`),n.dataset.activated=String(performance.now()),requestAnimationFrame(()=>{requestAnimationFrame(()=>{n.classList.remove("v-ripple__animation--enter"),n.classList.add("v-ripple__animation--in"),no(n,`translate(${u}, ${c}) scale3d(1,1,1)`)})})},hide(e){if(!e?._ripple?.enabled)return
const t=e.getElementsByClassName("v-ripple__animation")
if(0===t.length)return
const a=Array.from(t).findLast(e=>!e.dataset.isHiding)
if(!a)return
a.dataset.isHiding="true"
const l=performance.now()-Number(a.dataset.activated),n=Math.max(250-l,0)
setTimeout(()=>{a.classList.remove("v-ripple__animation--in"),a.classList.add("v-ripple__animation--out"),setTimeout(()=>{1===e.getElementsByClassName("v-ripple__animation").length&&e.dataset.previousPosition&&(e.style.position=e.dataset.previousPosition,delete e.dataset.previousPosition),a.parentNode?.parentNode===e&&e.removeChild(a.parentNode)},300)},n)}}
function so(e){return void 0===e||!!e}function uo(e){const t={},a=e.currentTarget
if(a?._ripple&&!a._ripple.touched&&!e[lo]){if(e[lo]=!0,oo(e))a._ripple.touched=!0,a._ripple.isTouch=!0
else if(a._ripple.isTouch)return
if(t.center=a._ripple.centered||ro(e),a._ripple.class&&(t.class=a._ripple.class),oo(e)){if(a._ripple.showTimerCommit)return
a._ripple.showTimerCommit=()=>{io.show(e,a,t)},a._ripple.showTimer=window.setTimeout(()=>{a?._ripple?.showTimerCommit&&(a._ripple.showTimerCommit(),a._ripple.showTimerCommit=null)},80)}else io.show(e,a,t)}}function co(e){e[lo]=!0}function vo(e){const t=e.currentTarget
if(t?._ripple){if(window.clearTimeout(t._ripple.showTimer),"touchend"===e.type&&t._ripple.showTimerCommit)return t._ripple.showTimerCommit(),t._ripple.showTimerCommit=null,void(t._ripple.showTimer=window.setTimeout(()=>{vo(e)}))
window.setTimeout(()=>{t._ripple&&(t._ripple.touched=!1)}),io.hide(t)}}function po(e){const t=e.currentTarget
t?._ripple&&(t._ripple.showTimerCommit&&(t._ripple.showTimerCommit=null),window.clearTimeout(t._ripple.showTimer))}let mo=!1
function fo(e){mo=!1,vo(e)}function go(e){mo&&(mo=!1,vo(e))}function ho(e,t,a){const{value:l,modifiers:n}=t,o=so(l)
o||io.hide(e),e._ripple=e._ripple??{},e._ripple.enabled=o,e._ripple.centered=n.center,e._ripple.circle=n.circle
const r=b(l)?l:{}
r.class&&(e._ripple.class=r.class)
const i=r.keys??["Enter","Space"]
if(e._ripple.keyDownHandler=e=>function(e,t){!mo&&t.includes(e.key)&&(mo=!0,uo(e))}(e,i),o&&!a){if(n.stop)return e.addEventListener("touchstart",co,{passive:!0}),void e.addEventListener("mousedown",co)
e.addEventListener("touchstart",uo,{passive:!0}),e.addEventListener("touchend",vo,{passive:!0}),e.addEventListener("touchmove",po,{passive:!0}),e.addEventListener("touchcancel",vo),e.addEventListener("mousedown",uo),e.addEventListener("mouseup",vo),e.addEventListener("mouseleave",vo),e.addEventListener("keydown",e._ripple.keyDownHandler),e.addEventListener("keyup",fo),e.addEventListener("blur",go),e.addEventListener("dragstart",vo,{passive:!0})}else!o&&a&&yo(e)}function yo(e){e.removeEventListener("touchstart",co),e.removeEventListener("mousedown",co),e.removeEventListener("touchstart",uo),e.removeEventListener("touchend",vo),e.removeEventListener("touchmove",po),e.removeEventListener("touchcancel",vo),e.removeEventListener("mousedown",uo),e.removeEventListener("mouseup",vo),e.removeEventListener("mouseleave",vo),e._ripple?.keyDownHandler&&e.removeEventListener("keydown",e._ripple.keyDownHandler),e.removeEventListener("keyup",fo),e.removeEventListener("blur",go),e.removeEventListener("dragstart",vo)}const bo={mounted:function(e,t){ho(e,t,!1)},unmounted:function(e){yo(e),delete e._ripple},updated:function(e,t){if(t.value===t.oldValue)return
ho(e,t,so(t.oldValue))}},wo=Tt({active:{type:Boolean,default:void 0},activeColor:String,baseColor:String,symbol:{type:null,default:Bn},flat:Boolean,icon:[Boolean,String,Function,Object],prependIcon:ua,appendIcon:ua,block:Boolean,readonly:Boolean,slim:Boolean,stacked:Boolean,spaced:String,ripple:{type:[Boolean,Object],default:!0},text:{type:[String,Number,Boolean],default:void 0},...an(),...Ft(),...yn(),...Tl(),...nn(),...Pn(),...Gn(),...sn(),...Zn(),...Gl(),...to(),...Vn(),...ol({tag:"button"}),...Ga(),...Nn({variant:"elevated"})},"VBtn"),Vo=Kt()({name:"VBtn",props:wo(),emits:{"group:selected":e=>!0},setup(e,{attrs:a,slots:l}){const{themeClasses:n}=tl(e),{borderClasses:o}=ln(e),{densityClasses:r}=bn(e),{dimensionStyles:i}=Fl(e),{elevationClasses:s}=on(e),{loaderClasses:u}=Kn(e),{locationStyles:c}=un(e),{positionClasses:d}=Qn(e),{roundedClasses:v,roundedStyles:p}=Kl(e),{sizeClasses:m,sizeStyles:f}=Sn(e),g=_n(e,e.symbol,!1),h=eo(e,a),b=t.computed(()=>void 0!==e.active?e.active:h.isRouterLink.value?h.isActive?.value:g?.isSelected.value),w=t.toRef(()=>b.value?e.activeColor??e.color:e.color),V=t.computed(()=>({color:g?.isSelected.value&&(!h.isLink.value||h.isActive?.value)||!g||h.isActive?.value?w.value??e.baseColor:e.baseColor,variant:e.variant})),{colorClasses:S,colorStyles:k,variantClasses:x}=Cn(V),N=t.computed(()=>g?.disabled.value||e.disabled),C=t.toRef(()=>"elevated"===e.variant&&!(e.disabled||e.flat||e.border)),E=t.computed(()=>{if(void 0!==e.value&&"symbol"!=typeof e.value)return Object(e.value)===e.value?JSON.stringify(e.value,null,0):e.value})
function I(e){N.value||h.isLink.value&&(e.metaKey||e.ctrlKey||e.shiftKey||0!==e.button||"_blank"===a.target)||(h.isRouterLink.value?h.navigate.value?.(e):g?.toggle())}return function(e,a){t.watch(()=>e.isActive?.value,l=>{e.isLink.value&&y(l)&&a&&t.nextTick(()=>{a(l)})},{immediate:!0})}(h,g?.select),sa(()=>{const a=h.isLink.value?"a":e.tag,w=!(!e.prependIcon&&!l.prepend),V=!(!e.appendIcon&&!l.append),A=!(!e.icon||!0===e.icon)
return t.withDirectives(t.createVNode(a,t.mergeProps(h.linkProps,{type:"a"===a?void 0:"button",class:["v-btn",g?.selectedClass.value,{"v-btn--active":b.value,"v-btn--block":e.block,"v-btn--disabled":N.value,"v-btn--elevated":C.value,"v-btn--flat":e.flat,"v-btn--icon":!!e.icon,"v-btn--loading":e.loading,"v-btn--readonly":e.readonly,"v-btn--slim":e.slim,"v-btn--stacked":e.stacked},e.spaced?["v-btn--spaced",`v-btn--spaced-${e.spaced}`]:[],n.value,o.value,S.value,r.value,s.value,u.value,d.value,v.value,m.value,x.value,e.class],style:[k.value,i.value,c.value,f.value,p.value,e.style],"aria-busy":!!e.loading||void 0,disabled:N.value&&"a"!==a||void 0,tabindex:e.loading||e.readonly?-1:void 0,onClick:I,value:"a"!==a?E.value:void 0}),{default:()=>[xn(!0,"v-btn"),!e.icon&&w&&t.createElementVNode("span",{key:"prepend",class:"v-btn__prepend"},[l.prepend?t.createVNode(Bl,{key:"prepend-defaults",disabled:!e.prependIcon,defaults:{VIcon:{icon:e.prependIcon}}},l.prepend):t.createVNode(Mn,{key:"prepend-icon",icon:e.prependIcon},null)]),t.createElementVNode("span",{class:"v-btn__content","data-no-activator":""},[!l.default&&A?t.createVNode(Mn,{key:"content-icon",icon:e.icon},null):t.createVNode(Bl,{key:"content-defaults",disabled:!A,defaults:{VIcon:{icon:e.icon}}},{default:()=>[l.default?.()??t.toDisplayString(e.text)]})]),!e.icon&&V&&t.createElementVNode("span",{key:"append",class:"v-btn__append"},[l.append?t.createVNode(Bl,{key:"append-defaults",disabled:!e.appendIcon,defaults:{VIcon:{icon:e.appendIcon}}},l.append):t.createVNode(Mn,{key:"append-icon",icon:e.appendIcon},null)]),!!e.loading&&t.createElementVNode("span",{key:"loader",class:"v-btn__loader"},[l.loader?.()??t.createVNode(Hn,{color:y(e.loading)?void 0:e.loading,indeterminate:!0,width:"2"},null)])]}),[[bo,!N.value&&e.ripple,"",{center:!!e.icon}]])}),{group:g}}}),So=Tt({...G(wo({icon:"$menu",variant:"text"}),["spaced"])},"VAppBarNavIcon"),ko=Kt()({name:"VAppBarNavIcon",props:So(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(Vo,t.mergeProps(e,{class:["v-app-bar-nav-icon"]}),a)),{})}),xo=Kt()({name:"VAppBarTitle",props:rl(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(il,t.mergeProps(e,{class:"v-app-bar-title"}),a)),{})}),No=qt("v-alert-title"),Co=Tt({iconSize:[Number,String],iconSizes:{type:Array,default:()=>[["x-small",10],["small",16],["default",24],["large",28],["x-large",32]]}},"iconSize")
function Eo(e,a){return{iconSize:t.computed(()=>{const t=new Map(e.iconSizes),l=e.iconSize??a()??"default"
return t.has(l)?t.get(l):l})}}const Io=["success","info","warning","error"],Ao=Tt({border:{type:[Boolean,String],validator:e=>y(e)||["top","end","bottom","start"].includes(e)},borderColor:String,closable:Boolean,closeIcon:{type:ua,default:"$close"},closeLabel:{type:String,default:"$vuetify.close"},icon:{type:[Boolean,String,Function,Object],default:null},modelValue:{type:Boolean,default:!0},prominent:Boolean,title:String,text:String,type:{type:String,validator:e=>Io.includes(e)},...Ft(),...yn(),...Tl(),...nn(),...Co(),...sn(),...Zn(),...Gl(),...ol(),...Ga(),...Nn({variant:"flat"})},"VAlert"),Po=Kt()({name:"VAlert",props:Ao(),emits:{"click:close":e=>!0,"update:modelValue":e=>!0},setup(e,{emit:a,slots:l}){const n=_a(e,"modelValue"),o=t.toRef(()=>{if(!1!==e.icon)return e.type?e.icon??`$${e.type}`:e.icon}),{iconSize:r}=Eo(e,()=>e.prominent?44:void 0),{themeClasses:i}=tl(e),{colorClasses:s,colorStyles:u,variantClasses:c}=Cn(()=>({color:e.color??e.type,variant:e.variant})),{densityClasses:d}=bn(e),{dimensionStyles:v}=Fl(e),{elevationClasses:p}=on(e),{locationStyles:m}=un(e),{positionClasses:f}=Qn(e),{roundedClasses:g,roundedStyles:h}=Kl(e),{textColorClasses:y,textColorStyles:b}=Ll(()=>e.borderColor),{t:w}=Ha(),V=t.toRef(()=>({"aria-label":w(e.closeLabel),onClick(e){n.value=!1,a("click:close",e)}}))
return()=>{const a=!(!l.prepend&&!o.value),w=!(!l.title&&!e.title),S=!(!l.close&&!e.closable),k={density:e.density,icon:o.value,size:e.iconSize||e.prominent?r.value:void 0}
return n.value&&t.createVNode(e.tag,{class:t.normalizeClass(["v-alert",e.border&&{"v-alert--border":!!e.border,[`v-alert--border-${!0===e.border?"start":e.border}`]:!0},{"v-alert--prominent":e.prominent},i.value,s.value,d.value,p.value,f.value,g.value,c.value,e.class]),style:t.normalizeStyle([u.value,v.value,m.value,h.value,e.style]),role:"alert"},{default:()=>[xn(!1,"v-alert"),e.border&&t.createElementVNode("div",{key:"border",class:t.normalizeClass(["v-alert__border",y.value]),style:t.normalizeStyle(b.value)},null),a&&t.createElementVNode("div",{key:"prepend",class:"v-alert__prepend"},[l.prepend?t.createVNode(Bl,{key:"prepend-defaults",disabled:!o.value,defaults:{VIcon:{...k}}},l.prepend):t.createVNode(Mn,t.mergeProps({key:"prepend-icon"},k),null)]),t.createElementVNode("div",{class:"v-alert__content"},[w&&t.createVNode(No,{key:"title"},{default:()=>[l.title?.()??e.title]}),l.text?.()??e.text,l.default?.()]),l.append&&t.createElementVNode("div",{key:"append",class:"v-alert__append"},[l.append()]),S&&t.createElementVNode("div",{key:"close",class:"v-alert__close"},[l.close?t.createVNode(Bl,{key:"close-defaults",defaults:{VBtn:{icon:e.closeIcon,size:"x-small",variant:"text"}}},{default:()=>[l.close?.({props:V.value})]}):t.createVNode(Vo,t.mergeProps({key:"close-btn",icon:e.closeIcon,size:"x-small",variant:"text"},V.value),null)])]})}}}),_o=Tt({bordered:Boolean,color:String,content:[Number,String],dot:Boolean,dotSize:[Number,String],floating:Boolean,icon:ua,inline:Boolean,label:{type:String,default:"$vuetify.badge"},max:[Number,String],modelValue:{type:Boolean,default:!0},offsetX:[Number,String],offsetY:[Number,String],textColor:String,...Ft(),...sn({location:"top end"}),...Gl(),...ol(),...Ga(),...ql({transition:"scale-rotate-transition"}),...Tl()},"VBadge"),Ro=Kt()({name:"VBadge",inheritAttrs:!1,props:_o(),setup(e,a){const{backgroundColorClasses:l,backgroundColorStyles:n}=Ol(()=>e.color),{roundedClasses:o,roundedStyles:r}=Kl(e),{t:i}=Ha(),{textColorClasses:s,textColorStyles:u}=Ll(()=>e.textColor),{themeClasses:c}=al(),{locationStyles:d}=un(e,!0,t=>(e.floating?e.dot?2:4:e.dot?Number(e.dotSize??8):12)+(["top","bottom"].includes(t)?Number(e.offsetY??0):["left","right"].includes(t)?Number(e.offsetX??0):0)),{dimensionStyles:v}=Fl(e)
return sa(()=>{const p=Number(e.content),m=!e.max||isNaN(p)?e.content:p<=Number(e.max)?p:`${e.max}+`,[f,g]=Y(a.attrs,["aria-atomic","aria-label","aria-live","role","title"])
return t.createVNode(e.tag,t.mergeProps({class:["v-badge",{"v-badge--bordered":e.bordered,"v-badge--dot":e.dot,"v-badge--floating":e.floating,"v-badge--inline":e.inline},e.class]},g,{style:e.style}),{default:()=>[t.createElementVNode("div",{class:"v-badge__wrapper"},[a.slots.default?.(),t.createVNode(Xl,{transition:e.transition},{default:()=>[t.withDirectives(t.createElementVNode("span",t.mergeProps({class:["v-badge__badge",c.value,l.value,o.value,s.value],style:[n.value,u.value,v.value,e.inline?{}:d.value,e.dot&&e.dotSize?{width:z(e.dotSize),height:z(e.dotSize)}:{},r.value],"aria-atomic":"true","aria-label":i(e.label,p),"aria-live":"polite",role:"status"},f),[e.dot?void 0:a.slots.badge?a.slots.badge?.():e.icon?t.createVNode(Mn,{icon:e.icon},null):m]),[[t.vShow,e.modelValue]])]})])]})}),{}}}),Do=Tt({badge:{type:[Boolean,Object],default:!1},start:Boolean,end:Boolean,icon:ua,image:String,text:String,...an(),...Ft(),...yn(),...Gl(),...Vn(),...ol(),...Ga(),...Nn({variant:"flat"})},"VAvatar"),Bo=Kt()({name:"VAvatar",props:Do(),setup(e,{slots:a}){const{themeClasses:l}=tl(e),{borderClasses:n}=ln(e),{colorClasses:o,colorStyles:r,variantClasses:i}=Cn(e),{densityClasses:s}=bn(e),{roundedClasses:u,roundedStyles:c}=Kl(e),{sizeClasses:d,sizeStyles:v}=Sn(e),p=t.computed(()=>{switch(e.size){case"x-small":return 8
case"small":return 10
case"large":return 14
case"x-large":return 16
default:return 12}}),m=t.computed(()=>{const{floating:t}=b(e.badge)?e.badge:{}
return(t?p.value/2:0)-1.5}),f=t.computed(()=>({bordered:!0,dot:!a.badge,dotSize:p.value,offsetX:m.value,offsetY:m.value,color:g(e.badge)?e.badge:"primary",...b(e.badge)?e.badge:{}}))
return sa(()=>{const p=t.createVNode(e.tag,{class:t.normalizeClass(["v-avatar",{"v-avatar--start":e.start,"v-avatar--end":e.end},l.value,n.value,o.value,s.value,u.value,d.value,i.value,e.class]),style:t.normalizeStyle([r.value,v.value,c.value,e.style])},{default:()=>[a.default?t.createVNode(Bl,{key:"content-defaults",defaults:{VImg:{cover:!0,src:e.image},VIcon:{icon:e.icon}}},{default:()=>[a.default()]}):e.image?t.createVNode(tn,{key:"image",src:e.image,alt:"",cover:!0},null):e.icon?t.createVNode(Mn,{key:"icon",icon:e.icon},null):e.text,xn(!1,"v-avatar")]})
return e.badge?t.createVNode(Ro,f.value,{default:()=>p,badge:a.badge}):p}),{}}}),To=Tt({text:String,onClick:fe(),...Ft(),...Ga()},"VLabel"),Fo=Kt()({name:"VLabel",props:To(),setup:(e,{slots:a})=>(sa(()=>t.createElementVNode("label",{class:t.normalizeClass(["v-label",{"v-label--clickable":!!e.onClick},e.class]),style:t.normalizeStyle(e.style),onClick:e.onClick},[e.text,a.default?.()])),{})}),$o=Symbol.for("vuetify:selection-control-group"),Mo=Tt({color:String,disabled:{type:Boolean,default:null},defaultsTarget:String,error:Boolean,id:String,inline:Boolean,falseIcon:ua,trueIcon:ua,indeterminateIcon:ua,ripple:{type:[Boolean,Object],default:!0},multiple:{type:Boolean,default:null},name:String,readonly:{type:Boolean,default:null},modelValue:null,type:String,valueComparator:{type:Function,default:Xt},...Ft(),...yn(),...Ga()},"SelectionControlGroup"),zo=Tt({...Mo({defaultsTarget:"VSelectionControl"})},"VSelectionControlGroup"),Lo=Kt()({name:"VSelectionControlGroup",props:zo(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),n=t.useId(),o=t.toRef(()=>e.id||`v-selection-control-group-${n}`),r=t.toRef(()=>e.name||o.value),i=new Set
return t.provide($o,{modelValue:l,forceUpdate:()=>{i.forEach(e=>e())},onForceUpdate:e=>{i.add(e),t.onScopeDispose(()=>{i.delete(e)})}}),Ht({[e.defaultsTarget]:{color:t.toRef(()=>e.color),disabled:t.toRef(()=>e.disabled),density:t.toRef(()=>e.density),error:t.toRef(()=>e.error),inline:t.toRef(()=>e.inline),modelValue:l,multiple:t.toRef(()=>!!e.multiple||null==e.multiple&&Array.isArray(l.value)),name:r,falseIcon:t.toRef(()=>e.falseIcon),trueIcon:t.toRef(()=>e.trueIcon),readonly:t.toRef(()=>e.readonly),ripple:t.toRef(()=>e.ripple),type:t.toRef(()=>e.type),valueComparator:t.toRef(()=>e.valueComparator)}}),sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-selection-control-group",{"v-selection-control-group--inline":e.inline},e.class]),style:t.normalizeStyle(e.style),role:"radio"===e.type?"radiogroup":void 0},[a.default?.()])),{}}}),Oo=Tt({indeterminate:Boolean,label:String,baseColor:String,trueValue:null,falseValue:null,value:null,...Ft(),...Mo()},"VSelectionControl")
const jo=Kt()({name:"VSelectionControl",directives:{vRipple:bo},inheritAttrs:!1,props:Oo(),emits:{"update:modelValue":e=>!0},setup(e,{attrs:a,slots:l}){const{group:n,densityClasses:o,icon:r,model:i,textColorClasses:s,textColorStyles:u,backgroundColorClasses:c,backgroundColorStyles:d,trueValue:v}=function(e){const a=t.inject($o,void 0),{densityClasses:l}=bn(e),n=_a(e,"modelValue"),o=t.computed(()=>void 0!==e.trueValue?e.trueValue:void 0===e.value||e.value),r=t.computed(()=>void 0!==e.falseValue&&e.falseValue),i=t.computed(()=>!!e.multiple||null==e.multiple&&Array.isArray(n.value)),s=t.computed({get(){const t=a?a.modelValue.value:n.value
return i.value?ee(t).some(t=>e.valueComparator(t,o.value)):e.valueComparator(t,o.value)},set(t){if(e.readonly)return
const l=t?o.value:r.value
let s=l
i.value&&(s=t?[...ee(n.value),l]:ee(n.value).filter(t=>!e.valueComparator(t,o.value))),a?a.modelValue.value=s:n.value=s}}),u=t.computed(()=>s.value||e.indeterminate),{textColorClasses:c,textColorStyles:d}=Ll(()=>{if(!e.error&&!e.disabled)return u.value?e.color:e.baseColor}),{backgroundColorClasses:v,backgroundColorStyles:p}=Ol(()=>!u.value||e.error||e.disabled?e.baseColor:e.color),m=t.computed(()=>e.indeterminate?e.indeterminateIcon:s.value?e.trueIcon:e.falseIcon)
return{group:a,densityClasses:l,trueValue:o,falseValue:r,model:s,textColorClasses:c,textColorStyles:d,backgroundColorClasses:v,backgroundColorStyles:p,icon:m}}(e),p=t.useId(),m=t.shallowRef(!1),f=t.shallowRef(!1),g=t.ref(),h=t.toRef(()=>e.id||`input-${p}`),y=t.toRef(()=>!e.disabled&&!e.readonly)
function b(t){e.disabled||(m.value=!0,!1!==xe(t.target,":focus-visible")&&(f.value=!0))}function w(){m.value=!1,f.value=!1}function V(e){e.stopPropagation()}function S(a){y.value?(e.readonly&&n&&t.nextTick(()=>n.forceUpdate()),i.value=a.target.checked):g.value&&(g.value.checked=i.value)}return n?.onForceUpdate(()=>{g.value&&(g.value.checked=i.value)}),sa(()=>{const n=l.label?l.label({label:e.label,props:{for:h.value}}):e.label,[p,y]=J(a),k=t.createElementVNode("input",t.mergeProps({ref:g,checked:i.value,disabled:!!e.disabled,id:h.value,onBlur:w,onFocus:b,onInput:S,"aria-disabled":!!e.disabled,"aria-label":e.label,type:e.type,value:v.value,name:e.name,"aria-checked":"checkbox"===e.type?i.value:void 0},y),null)
return t.createElementVNode("div",t.mergeProps({class:["v-selection-control",{"v-selection-control--dirty":i.value,"v-selection-control--indeterminate":e.indeterminate,"v-selection-control--disabled":e.disabled,"v-selection-control--error":e.error,"v-selection-control--focused":m.value,"v-selection-control--focus-visible":f.value,"v-selection-control--inline":e.inline},o.value,e.class]},p,{style:e.style}),[t.createElementVNode("div",{class:t.normalizeClass(["v-selection-control__wrapper",s.value]),style:t.normalizeStyle(u.value)},[l.default?.({backgroundColorClasses:c,backgroundColorStyles:d}),t.withDirectives(t.createElementVNode("div",{class:t.normalizeClass(["v-selection-control__input"])},[l.input?.({model:i,textColorClasses:s,textColorStyles:u,backgroundColorClasses:c,backgroundColorStyles:d,inputNode:k,icon:r.value,props:{onFocus:b,onBlur:w,id:h.value}})??t.createElementVNode(t.Fragment,null,[r.value&&t.createVNode(Mn,{key:"icon",icon:r.value},null),k])]),[[bo,!e.disabled&&!e.readonly&&e.ripple,null,{center:!0,circle:!0}]])]),n&&t.createVNode(Fo,{for:h.value,onClick:V},{default:()=>[n]})])}),{isFocused:m,input:g}}}),Ho=Tt({...Oo({falseIcon:"$checkboxOff",trueIcon:"$checkboxOn",indeterminateIcon:"$checkboxIndeterminate"})},"VCheckboxBtn"),Wo=Kt()({name:"VCheckboxBtn",props:Ho(),emits:{"update:modelValue":e=>!0,"update:indeterminate":e=>!0},setup(e,{slots:a}){const l=_a(e,"indeterminate"),n=_a(e,"modelValue")
function o(e){l.value&&(l.value=!1)}return sa(()=>{const r=G(jo.filterProps(e),["modelValue"])
return t.createVNode(jo,t.mergeProps(r,{modelValue:n.value,"onUpdate:modelValue":[e=>n.value=e,o],class:["v-checkbox-btn",e.class],style:e.style,type:"checkbox","aria-checked":l.value?"mixed":void 0}),a)}),{}}})
function Uo(e){const{t:a}=Ha()
return{InputIcon:function({name:l,color:n,...o}){const r={prepend:"prependAction",prependInner:"prependAction",append:"appendAction",appendInner:"appendAction",clear:"clear"}[l],i=e[`onClick:${l}`],s=i&&r?a(`$vuetify.input.${r}`,e.label??""):void 0
return t.createVNode(Mn,t.mergeProps({icon:e[`${l}Icon`],"aria-label":s,onClick:i,onKeydown:function(e){"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),e.stopPropagation(),he(i,new PointerEvent("click",e)))},color:n},o),null)}}}const Yo=Tt({active:Boolean,color:String,messages:{type:[Array,String],default:()=>[]},...Ft(),...ql({transition:{component:Il,leaveAbsolute:!0,group:!0}})},"VMessages"),Go=Kt()({name:"VMessages",props:Yo(),setup(e,{slots:a}){const l=t.computed(()=>ee(e.messages)),{textColorClasses:n,textColorStyles:o}=Ll(()=>e.color)
return sa(()=>t.createVNode(Xl,{transition:e.transition,tag:"div",class:t.normalizeClass(["v-messages",n.value,e.class]),style:t.normalizeStyle([o.value,e.style])},{default:()=>[e.active&&l.value.map((e,n)=>t.createElementVNode("div",{class:"v-messages__message",key:`${n}-${l.value}`},[a.message?a.message({message:e}):e]))]})),{}}}),Ko=Tt({focused:Boolean,"onUpdate:focused":fe()},"focus")
function qo(e,a=Mt()){const l=_a(e,"focused")
return{focusClasses:t.toRef(()=>({[`${a}--focused`]:l.value})),isFocused:l,focus:function(){l.value=!0},blur:function(){l.value=!1}}}const Xo=Symbol.for("vuetify:form"),Zo=Tt({disabled:Boolean,fastFail:Boolean,readonly:Boolean,modelValue:{type:Boolean,default:null},validateOn:{type:String,default:"input"}},"form")
function Qo(e){const a=t.inject(Xo,null)
return{...a,isReadonly:t.computed(()=>!!(e?.readonly??a?.isReadonly.value)),isDisabled:t.computed(()=>!!(e?.disabled??a?.isDisabled.value))}}const Jo=Symbol.for("vuetify:rules")
function er(e){const a=t.inject(Jo,null)
if(!e){if(!a)throw new Error("Could not find Vuetify rules injection")
return a.aliases}return a?.resolve(e)??t.toRef(e)}const tr=Tt({disabled:{type:Boolean,default:null},error:Boolean,errorMessages:{type:[Array,String],default:()=>[]},maxErrors:{type:[Number,String],default:1},name:String,label:String,readonly:{type:Boolean,default:null},rules:{type:Array,default:()=>[]},modelValue:null,validateOn:String,validationValue:null,...Ko()},"validation")
function ar(e,a=Mt(),l=t.useId()){const n=_a(e,"modelValue"),o=t.computed(()=>x(e.validationValue)?n.value:e.validationValue),r=Qo(e),i=er(()=>e.rules),s=t.ref([]),u=t.shallowRef(!0),c=t.computed(()=>!(!ee(""===n.value?null:n.value).length&&!ee(""===o.value?null:o.value).length)),d=t.computed(()=>e.errorMessages?.length?ee(e.errorMessages).concat(s.value).slice(0,Math.max(0,Number(e.maxErrors))):s.value),v=t.computed(()=>{let t=(e.validateOn??r.validateOn?.value)||"input"
"lazy"===t&&(t="input lazy"),"eager"===t&&(t="input eager")
const a=new Set(t?.split(" ")??[])
return{input:a.has("input"),blur:a.has("blur")||a.has("input")||a.has("invalid-input"),invalidInput:a.has("invalid-input"),lazy:a.has("lazy"),eager:a.has("eager")}}),p=t.computed(()=>!e.error&&!e.errorMessages?.length&&(!e.rules.length||(u.value?!s.value.length&&!v.value.lazy||null:!s.value.length))),m=t.shallowRef(!1)
let h=!1
const y=t.computed(()=>({[`${a}--error`]:!1===p.value,[`${a}--dirty`]:c.value,[`${a}--disabled`]:r.isDisabled.value,[`${a}--readonly`]:r.isReadonly.value})),b=$t("validation"),w=t.computed(()=>e.name??t.unref(l))
async function V(){h=!0,n.value=null,await t.nextTick(),h=!1,await S()}async function S(){u.value=!0,v.value.lazy?s.value=[]:await k(!v.value.eager)}async function k(t=!1){const a=[]
m.value=!0
for(const t of i.value){if(a.length>=Number(e.maxErrors??1))break
const l=f(t)?t:()=>t,n=await l(o.value)
!0!==n&&(!1===n||g(n)?a.push(n||""):console.warn(`${n} is not a valid value. Rule functions must return boolean true or a string.`))}return s.value=a,m.value=!1,u.value=t,s.value}return t.onBeforeMount(()=>{r.register?.({id:w.value,vm:b,validate:k,reset:V,resetValidation:S})}),t.onBeforeUnmount(()=>{r.unregister?.(w.value)}),t.onMounted(async()=>{v.value.lazy||await k(!v.value.eager),r.update?.(w.value,p.value,d.value)}),Pa(()=>v.value.input||v.value.invalidInput&&!1===p.value,()=>{t.watch(o,()=>{h||k()})}),Pa(()=>v.value.blur,()=>{t.watch(()=>e.focused,e=>{e||k()})}),t.watch([p,d],()=>{r.update?.(w.value,p.value,d.value)}),{errorMessages:d,isDirty:c,isDisabled:r.isDisabled,isReadonly:r.isReadonly,isPristine:u,isValid:p,isValidating:m,reset:V,resetValidation:S,validate:k,validationClasses:y}}const lr=Tt({id:String,appendIcon:ua,baseColor:String,centerAffix:{type:Boolean,default:!0},color:String,glow:Boolean,iconColor:[Boolean,String],prependIcon:ua,detailsActive:{type:Boolean,default:null},hideDetails:[Boolean,String],hideSpinButtons:Boolean,hint:String,indentDetails:{type:Boolean,default:null},persistentHint:Boolean,messages:{type:[Array,String],default:()=>[]},direction:{type:String,default:"horizontal",validator:e=>["horizontal","vertical"].includes(e)},"onClick:prepend":fe(),"onClick:append":fe(),...Ft(),...yn(),...U(Tl(),["maxWidth","minWidth","width"]),...Ga(),...tr()},"VInput"),nr=Kt()({name:"VInput",props:{...lr()},emits:{"update:modelValue":e=>!0},setup(e,{attrs:a,slots:l,emit:n}){const{densityClasses:o}=bn(e),{dimensionStyles:r}=Fl(e),{themeClasses:i}=tl(e),{rtlClasses:s}=Ua(),{InputIcon:u}=Uo(e),c=t.useId(),d=t.computed(()=>e.id||`input-${c}`),{errorMessages:v,isDirty:p,isDisabled:m,isReadonly:f,isPristine:g,isValid:h,isValidating:y,reset:b,resetValidation:w,validate:V,validationClasses:S}=ar(e,"v-input",d),k=t.computed(()=>e.errorMessages?.length||!g.value&&v.value.length?v.value:e.hint&&(e.persistentHint||e.focused)?e.hint:e.messages),x=t.toRef(()=>k.value.length>0),N=t.toRef(()=>!e.hideDetails||"auto"===e.hideDetails&&(x.value||(e.detailsActive??!!l.details))),C=t.computed(()=>N.value?`${d.value}-messages`:void 0),E=t.computed(()=>({id:d,messagesId:C,isDirty:p,isDisabled:m,isReadonly:f,isPristine:g,isValid:h,isValidating:y,hasDetails:N,reset:b,resetValidation:w,validate:V})),I=t.toRef(()=>e.error||e.disabled?void 0:e.focused?e.color:e.baseColor),A=t.toRef(()=>{if(e.iconColor)return!0===e.iconColor?I.value:e.iconColor})
return sa(()=>{const a=!(!l.prepend&&!e.prependIcon),n=!(!l.append&&!e.appendIcon)
return t.createElementVNode("div",{class:t.normalizeClass(["v-input",`v-input--${e.direction}`,{"v-input--center-affix":e.centerAffix,"v-input--focused":e.focused,"v-input--glow":e.glow,"v-input--hide-spin-buttons":e.hideSpinButtons,"v-input--indent-details":e.indentDetails},o.value,i.value,s.value,S.value,e.class]),style:t.normalizeStyle([r.value,e.style])},[a&&t.createElementVNode("div",{key:"prepend",class:"v-input__prepend"},[l.prepend?l.prepend(E.value):e.prependIcon&&t.createVNode(u,{key:"prepend-icon",name:"prepend",color:A.value},null)]),l.default&&t.createElementVNode("div",{class:"v-input__control"},[l.default?.(E.value)]),n&&t.createElementVNode("div",{key:"append",class:"v-input__append"},[l.append?l.append(E.value):e.appendIcon&&t.createVNode(u,{key:"append-icon",name:"append",color:A.value},null)]),!0!==e.hideDetails&&t.createElementVNode("div",{id:C.value,class:t.normalizeClass(["v-input__details",{"v-input__details--hidden":!N.value}]),role:"alert","aria-live":"polite"},[t.createVNode(Go,{active:x.value,messages:k.value},{message:l.message}),l.details?.(E.value)])])}),{reset:b,resetValidation:w,validate:V,isValid:h,errorMessages:v}}}),or=Symbol("Forwarded refs")
function rr(e,t){let a=e
for(;a;){const e=Reflect.getOwnPropertyDescriptor(a,t)
if(e)return e
a=Object.getPrototypeOf(a)}}function ir(e,...t){return e[or]=t,new Proxy(e,{get(e,a){if(Reflect.has(e,a))return Reflect.get(e,a)
if(!(N(a)||a.startsWith("$")||a.startsWith("__")))for(const e of t)if(e.value&&Reflect.has(e.value,a)){const t=Reflect.get(e.value,a)
return f(t)?t.bind(e.value):t}},has(e,a){if(Reflect.has(e,a))return!0
if(N(a)||a.startsWith("$")||a.startsWith("__"))return!1
for(const e of t)if(e.value&&Reflect.has(e.value,a))return!0
return!1},set(e,a,l){if(Reflect.has(e,a))return Reflect.set(e,a,l)
if(N(a)||a.startsWith("$")||a.startsWith("__"))return!1
for(const e of t)if(e.value&&Reflect.has(e.value,a))return Reflect.set(e.value,a,l)
return!1},getOwnPropertyDescriptor(e,a){const l=Reflect.getOwnPropertyDescriptor(e,a)
if(l)return l
if(!(N(a)||a.startsWith("$")||a.startsWith("__"))){for(const e of t){if(!e.value)continue
const t=rr(e.value,a)??("_"in e.value?rr(e.value._?.setupState,a):void 0)
if(t)return t}for(const e of t){const t=e.value&&e.value[or]
if(!t)continue
const l=t.slice()
for(;l.length;){const e=l.shift(),t=rr(e.value,a)
if(t)return t
const n=e.value&&e.value[or]
n&&l.push(...n)}}}}})}const sr=Tt({...G(lr(),["direction","glow"]),...G(Ho(),["inline"])},"VCheckbox"),ur=Kt()({name:"VCheckbox",inheritAttrs:!1,props:sr(),emits:{"update:modelValue":e=>!0,"update:focused":e=>!0},setup(e,{attrs:a,slots:l}){const n=_a(e,"modelValue"),{isFocused:o,focus:r,blur:i}=qo(e),s=t.ref(),u=t.useId()
return sa(()=>{const[c,d]=J(a),v=nr.filterProps(e),p=Wo.filterProps(e)
return t.createVNode(nr,t.mergeProps({ref:s,class:["v-checkbox",e.class]},c,v,{modelValue:n.value,"onUpdate:modelValue":e=>n.value=e,id:e.id||`checkbox-${u}`,focused:o.value,style:e.style}),{...l,default:({id:e,messagesId:a,isDisabled:o,isReadonly:s,isValid:u})=>t.createVNode(Wo,t.mergeProps(p,{id:e.value,"aria-describedby":a.value,disabled:o.value,readonly:s.value},d,{error:!1===u.value,modelValue:n.value,"onUpdate:modelValue":e=>n.value=e,onFocus:r,onBlur:i}),l)})}),ir({},s)}}),cr=["sm","md","lg","xl","xxl"],dr=Symbol.for("vuetify:display"),vr={mobileBreakpoint:"lg",thresholds:{xs:0,sm:600,md:840,lg:1145,xl:1545,xxl:2138}}
function pr(e){return E&&!e?window.innerWidth:b(e)&&e.clientWidth||0}function mr(e){return E&&!e?window.innerHeight:b(e)&&e.clientHeight||0}function fr(e){const t=E&&!e?window.navigator.userAgent:"ssr"
function a(e){return Boolean(t.match(e))}return{android:a(/android/i),ios:a(/iphone|ipad|ipod/i),cordova:a(/cordova/i),electron:a(/electron/i),chrome:a(/chrome/i),edge:a(/edge/i),firefox:a(/firefox/i),opera:a(/opera/i),win:a(/win/i),mac:a(/mac/i),linux:a(/linux/i),touch:A,ssr:"ssr"===t}}function gr(e,a){const{thresholds:l,mobileBreakpoint:n}=((e=vr)=>ie(vr,e))(e),o=t.shallowRef(mr(a)),r=t.shallowRef(fr(a)),i=t.reactive({}),s=t.shallowRef(pr(a))
function u(){o.value=mr(),s.value=pr()}return t.watchEffect(()=>{const e=s.value<l.sm,t=s.value<l.md&&!e,a=s.value<l.lg&&!(t||e),u=s.value<l.xl&&!(a||t||e),c=s.value<l.xxl&&!(u||a||t||e),d=s.value>=l.xxl,v=e?"xs":t?"sm":a?"md":u?"lg":c?"xl":"xxl",p=h(n)?n:l[n],m=s.value<p
i.xs=e,i.sm=t,i.md=a,i.lg=u,i.xl=c,i.xxl=d,i.smAndUp=!e,i.mdAndUp=!(e||t),i.lgAndUp=!(e||t||a),i.xlAndUp=!(e||t||a||u),i.smAndDown=!(a||u||c||d),i.mdAndDown=!(u||c||d),i.lgAndDown=!(c||d),i.xlAndDown=!d,i.name=v,i.height=o.value,i.width=s.value,i.mobile=m,i.mobileBreakpoint=n,i.platform=r.value,i.thresholds=l}),E&&(window.addEventListener("resize",u,{passive:!0}),t.onScopeDispose(()=>{window.removeEventListener("resize",u)},!0)),{...t.toRefs(i),update:function(){u(),r.value=fr()},ssr:!!a}}const hr=Tt({mobile:{type:Boolean,default:!1},mobileBreakpoint:[Number,String]},"display")
function yr(e={mobile:null},a=Mt()){const l=t.inject(dr)
if(!l)throw new Error("Could not find Vuetify display injection")
const n=t.computed(()=>!!e.mobile||(h(e.mobileBreakpoint)?l.width.value<e.mobileBreakpoint:e.mobileBreakpoint?l.width.value<l.thresholds.value[e.mobileBreakpoint]:!!S(e.mobile)&&l.mobile.value)),o=t.toRef(()=>a?{[`${a}--mobile`]:n.value}:{})
return{...l,displayClasses:o,mobile:n}}const br=Symbol.for("vuetify:goto")
function wr(){return{container:void 0,duration:300,layout:!1,offset:0,easing:"easeInOutCubic",patterns:ta}}function Vr(e){return g(e)?document.querySelector(e):O(e)}function Sr(e,t,a){if(h(e))return t&&a?-e:e
let l=Vr(e),n=0
for(;l;)n+=t?l.offsetLeft:l.offsetTop,l=l.offsetParent
return n}async function kr(e,t,l,n){const o=l?"scrollLeft":"scrollTop",r=ie(n?.options??wr(),t),i=n?.rtl.value,s=(h(e)?e:Vr(e))??0,u="parent"===r.container&&s instanceof HTMLElement?s.parentElement:Vr(r.container)??(document.scrollingElement||document.body)
const c=R()?r.patterns.instant:f(r.easing)?r.easing:r.patterns[r.easing]
if(!c)throw new TypeError(`Easing function "${r.easing}" not found.`)
let d
if(h(s))d=Sr(s,l,i)
else if(d=Sr(s,l,i)-Sr(u,l,i),r.layout){const e=window.getComputedStyle(s).getPropertyValue("--v-layout-top")
e&&(d-=parseInt(e,10))}d+=r.offset,d=function(e,t,a,l){const{scrollWidth:n,scrollHeight:o}=e,[r,i]=e===document.scrollingElement?[window.innerWidth,window.innerHeight]:[e.offsetWidth,e.offsetHeight]
let s,u
l?a?(s=-(n-r),u=0):(s=0,u=n-r):(s=0,u=o+-i)
return ae(t,s,u)}(u,d,!!i,!!l)
const v=u[o]??0
if(d===v)return Promise.resolve(d)
const p=performance.now()
return new Promise(e=>requestAnimationFrame(function t(l){const n=(l-p)/r.duration,i=Math.floor(v+(d-v)*c(ae(n,0,1)))
return u[o]=i,n>=1&&Math.abs(i-u[o])<10?e(d):n>2?(a("Scroll target is not reachable"),e(u[o])):void requestAnimationFrame(t)}))}function xr(e={}){const a=t.inject(br),{isRtl:l}=Ua()
if(!a)throw new Error("[Vuetify] Could not find injected goto instance")
const n={...a,rtl:t.toRef(()=>a.rtl.value||l.value)}
async function o(t,a){return kr(t,ie(e,a),!1,n)}return o.horizontal=async(t,a)=>kr(t,ie(e,a),!0,n),o}function Nr(e,t){const a=e?"scrollWidth":"scrollHeight"
return t?.[a]||0}function Cr(e,t,a){if(!a)return 0
const{scrollLeft:l,offsetWidth:n,scrollWidth:o}=a
return e?t?o-n+l:l:a.scrollTop}function Er(e,t){const a=e?"offsetWidth":"offsetHeight"
return t?.[a]||0}function Ir(e,t){const a=e?"offsetLeft":"offsetTop"
return t?.[a]||0}const Ar=Symbol.for("vuetify:v-slide-group"),Pr=Tt({centerActive:Boolean,scrollDistance:{type:[String,Number],default:"100%",validator:e=>/^-?\d*\.?\d+(px|%)?$/.test(String(e).trim())},scrollSnap:{type:String,validator:e=>["start","center","end"].includes(e)},scrollToActive:{type:Boolean,default:!0},contentClass:null,direction:{type:String,default:"horizontal"},symbol:{type:null,default:Ar},nextIcon:{type:ua,default:"$next"},prevIcon:{type:ua,default:"$prev"},showArrows:{type:[Boolean,String],validator:e=>y(e)||["always","desktop","mobile","never"].includes(e)},...Ft(),...hr({mobile:null}),...ol(),...An({selectedClass:"v-slide-group-item--active"})},"VSlideGroup"),_r=Kt()({name:"VSlideGroup",props:Pr(),emits:{"update:modelValue":e=>!0,edge:e=>!0},setup(e,{emit:a,slots:l}){const{isRtl:n}=Ua(),{displayClasses:o,mobile:r}=yr(e),i=Rn(e,e.symbol),s=t.shallowRef(!1),u=t.shallowRef(0),c=t.shallowRef(0),d=t.shallowRef(0),v=t.computed(()=>"horizontal"===e.direction),{resizeRef:p,contentRect:m}=Sa(),{resizeRef:f,contentRect:h}=Sa(),y=xr(),w=t.computed(()=>({container:p.el,duration:200,easing:"easeOutQuart"})),V=t.computed(()=>i.selected.value.length?i.items.value.findIndex(e=>e.id===i.selected.value[0]):-1),S=t.computed(()=>i.selected.value.length?i.items.value.findIndex(e=>e.id===i.selected.value[i.selected.value.length-1]):-1)
if(E){let a=-1
t.watch(()=>[i.selected.value,m.value,h.value,v.value],()=>{cancelAnimationFrame(a),a=requestAnimationFrame(()=>{if(m.value&&h.value){const e=v.value?"width":"height"
c.value=m.value[e],d.value=h.value[e],s.value=c.value+1<d.value}if(e.scrollToActive&&V.value>=0&&f.el){x(f.el.children[S.value],e.centerActive)}})})}const k=t.shallowRef(!1)
function x(t,a){if(e.scrollSnap)return C(function(e,t){const a=M(e),l=t?(a.start+a.end-c.value)/2:$()
return O().filter(j(a)).reduce(function(e){return(t,a)=>Math.abs(a-e)<Math.abs(t-e)?a:t}(l),L(a))}(t,a))
let l=0
l=a?function({selectedElement:e,containerElement:t,isHorizontal:a}){const l=Er(a,t)
return Ir(a,e)-l/2+Er(a,e)/2}({containerElement:p.el,isHorizontal:v.value,selectedElement:t}):function({selectedElement:e,containerElement:t,isRtl:a,isHorizontal:l}){const n=Er(l,t),o=Cr(l,a,t),r=Er(l,e),i=Ir(l,e),s=.4*r
return o>i?i-s:o+n<i+r?i-n+r+s:o}({containerElement:p.el,isHorizontal:v.value,isRtl:n.value,selectedElement:t}),C(F(l))}let N=0
function C(t){if(!E||!p.el)return
const a=Er(v.value,p.el),l=Nr(v.value,p.el)
if(l<=a)return
if(t=ae(t,0,l-a),Math.abs(t-$())<=1)return
const n=v.value?y.horizontal(t,w.value):y(t,w.value)
if(e.scrollSnap){const e=p.el
e.style.scrollSnapType="none",N++,n.finally(()=>--N||(e.style.scrollSnapType=""))}}function I(e){if(k.value=!0,s.value&&f.el&&!1!==xe(e.target,":focus-visible"))for(const t of e.composedPath())for(const e of f.el.children)if(e===t)return void x(e)}function A(e){k.value=!1}let P=!1
function _(e){P||k.value||e.relatedTarget&&f.el?.contains(e.relatedTarget)||T(),P=!1}function R(){P=!0}function D(e){function t(t){e.preventDefault(),T(t)}f.el&&(v.value?"ArrowRight"===e.key?t(n.value?"prev":"next"):"ArrowLeft"===e.key&&t(n.value?"next":"prev"):"ArrowDown"===e.key?t("next"):"ArrowUp"===e.key&&t("prev"),"Home"===e.key?t("first"):"End"===e.key&&t("last"))}function B(e,t){if(!e)return
let a=e
do{a=a?.["next"===t?"nextElementSibling":"previousElementSibling"]}while(a?.hasAttribute("disabled"))
return a}function T(e){if(!f.el)return
let t
if(e)if("next"===e){if(t=B(f.el.querySelector(":focus"),e),!t)return T("first")}else if("prev"===e){if(t=B(f.el.querySelector(":focus"),e),!t)return T("last")}else"first"===e?(t=f.el.firstElementChild,t?.hasAttribute("disabled")&&(t=B(t,"next"))):"last"===e&&(t=f.el.lastElementChild,t?.hasAttribute("disabled")&&(t=B(t,"prev")))
else{t=ye(f.el)[0]}t&&t.focus({preventScroll:!0})}function F(e){return v.value&&n.value?Nr(!0,p.el)-Er(!0,p.el)-e:e}function $(){return F(Cr(v.value,n.value,p.el))}function M(e){const t=Er(v.value,e),a=v.value&&n.value?Nr(!0,p.el)-e.offsetLeft-t:Ir(v.value,e)
return{start:a,end:a+t}}function z(){return f.el?Array.from(f.el.children,M):[]}function L(t){return"end"===e.scrollSnap?t.end-c.value:"center"===e.scrollSnap?(t.start+t.end-c.value)/2:t.start}function O(){return z().map(L)}function j(e){return t=>!e||t<=e.start+1&&t+c.value>=e.end-1}function H(e,t){const a=t>0,l=e+t,n=O().filter(t=>a?t>e+1:t<e-1),o=n.filter(j((r=a?l:e,z().find(e=>e.start<r-1&&e.end>r+1))))
var r
const i=o.length?o:n
return(a?i.findLast(e=>e<=l)??i[0]:i.find(e=>e>=l)??i.at(-1))??l}function W(t){if(!p.el||!c.value)return
if(b(t)&&"index"in t){const a=f.el?.children[t.index]
return void(a&&x(a,e.centerActive))}const a=$(),l=g(t)?e.scrollDistance:t.by,n=function(e,t){return g(t)&&t.endsWith("%")?e*parseFloat(t)/100:parseFloat(String(t))||e}(c.value,l)*("prev"===t?-1:1)
C(e.scrollSnap?H(a,n):a+n)}const U=t.computed(()=>({next:i.next,prev:i.prev,select:i.select,isSelected:i.isSelected})),Y=t.computed(()=>s.value||Math.abs(u.value)>0),G=t.computed(()=>{switch(e.showArrows){case"never":return!1
case"always":return!0
case"desktop":return!r.value
case!0:return Y.value
case"mobile":return r.value||Y.value
default:return!r.value&&Y.value}}),K=t.computed(()=>Math.abs(u.value)>1),q=t.computed(()=>{if(!Y.value)return!1
return d.value-c.value-Math.abs(u.value)>1})
function X(){const e=K.value,t=q.value
u.value=$(),e&&!K.value&&a("edge","start"),t&&!q.value&&a("edge","end")}return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-slide-group",{"v-slide-group--vertical":!v.value,"v-slide-group--has-affixes":G.value,"v-slide-group--is-overflowing":s.value,"v-slide-group--snap":!!e.scrollSnap},o.value,e.class]),style:t.normalizeStyle(e.style),tabindex:k.value||i.selected.value.length?-1:0,onFocus:_},{default:()=>[G.value&&t.createElementVNode("div",{key:"prev",class:t.normalizeClass(["v-slide-group__prev",{"v-slide-group__prev--disabled":!K.value}]),onMousedown:R,onClick:()=>K.value&&W("prev")},[l.prev?.(U.value)??t.createVNode(wl,null,{default:()=>[t.createVNode(Mn,{icon:n.value?e.nextIcon:e.prevIcon},null)]})]),t.createElementVNode("div",{key:"container",ref:p,class:t.normalizeClass(["v-slide-group__container",e.contentClass]),style:{"--v-slide-group-snap-align":e.scrollSnap},onScroll:X},[t.createElementVNode("div",{ref:f,class:"v-slide-group__content",onFocusin:I,onFocusout:A,onKeydown:D},[l.default?.(U.value)])]),G.value&&t.createElementVNode("div",{key:"next",class:t.normalizeClass(["v-slide-group__next",{"v-slide-group__next--disabled":!q.value}]),onMousedown:R,onClick:()=>q.value&&W("next")},[l.next?.(U.value)??t.createVNode(wl,null,{default:()=>[t.createVNode(Mn,{icon:n.value?e.prevIcon:e.nextIcon},null)]})])]})),{selected:i.selected,slide:W,scrollOffset:u,focus:T,hasPrev:K,hasNext:q,hasOverflow:s}}}),Rr=Symbol.for("vuetify:v-chip-group"),Dr=Tt({baseColor:String,column:Boolean,filter:Boolean,valueComparator:{type:Function,default:Xt},...Pr({scrollToActive:!1}),...Ft(),...An({selectedClass:"v-chip--selected"}),...ol(),...Ga(),...Nn({variant:"tonal"})},"VChipGroup"),Br=Kt()({name:"VChipGroup",props:Dr(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{themeClasses:l}=tl(e),{isSelected:n,select:o,next:r,prev:i,selected:s}=Rn(e,Rr)
return Ht({VChip:{baseColor:t.toRef(()=>e.baseColor),color:t.toRef(()=>e.color),disabled:t.toRef(()=>e.disabled),filter:t.toRef(()=>e.filter),variant:t.toRef(()=>e.variant)}}),sa(()=>{const u=_r.filterProps(e)
return t.createVNode(_r,t.mergeProps(u,{class:["v-chip-group",{"v-chip-group--column":e.column},l.value,e.class],style:e.style}),{default:()=>[a.default?.({isSelected:n,select:o,next:r,prev:i,selected:s.value})]})}),{}}}),Tr=Tt({activeClass:String,appendAvatar:String,appendIcon:ua,baseColor:String,closable:Boolean,closeIcon:{type:ua,default:"$delete"},closeLabel:{type:String,default:"$vuetify.close"},draggable:Boolean,filter:Boolean,filterIcon:{type:ua,default:"$complete"},label:Boolean,link:{type:Boolean,default:void 0},pill:Boolean,prependAvatar:String,prependIcon:ua,ripple:{type:[Boolean,Object],default:!0},text:{type:[String,Number,Boolean],default:void 0},modelValue:{type:Boolean,default:!0},onClick:fe(),onClickOnce:fe(),...an(),...Ft(),...yn(),...nn(),...Pn(),...Gl(),...to(),...Vn(),...ol({tag:"span"}),...Ga(),...Nn({variant:"tonal"})},"VChip"),Fr=Kt()({name:"VChip",directives:{vRipple:bo},props:Tr(),emits:{"click:close":e=>!0,"update:modelValue":e=>!0,"group:selected":e=>!0,click:e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{t:o}=Ha(),{borderClasses:r}=ln(e),{densityClasses:i}=bn(e),{elevationClasses:s}=on(e),{roundedClasses:u,roundedStyles:c}=Kl(e),{sizeClasses:d}=Sn(e),{themeClasses:v}=tl(e),p=_a(e,"modelValue"),m=_n(e,Rr,!1),f=_n(e,Ar,!1),g=eo(e,a),h=t.toRef(()=>!1!==e.link&&g.isLink.value),y=t.computed(()=>!e.disabled&&!1!==e.link&&(!!m||e.link||g.isClickable.value)),b=t.toRef(()=>({"aria-label":o(e.closeLabel),disabled:e.disabled,onClick(e){e.preventDefault(),e.stopPropagation(),p.value=!1,l("click:close",e)}}))
t.watch(p,e=>{e?(m?.register(),f?.register()):(m?.unregister(),f?.unregister())})
const{colorClasses:w,colorStyles:V,variantClasses:S}=Cn(()=>({color:!m||m.isSelected.value?e.color??e.baseColor:e.baseColor,variant:e.variant}))
function k(e){l("click",e),y.value&&(g.navigate.value?.(e),m?.toggle())}function x(e){"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),k(e))}return()=>{const a=g.isLink.value?"a":e.tag,l=!(!e.appendIcon&&!e.appendAvatar),o=!(!l&&!n.append),f=!(!n.close&&!e.closable),N=!(!n.filter&&!e.filter)&&m,C=!(!e.prependIcon&&!e.prependAvatar),E=!(!C&&!n.prepend)
return p.value&&t.withDirectives(t.createVNode(a,t.mergeProps(g.linkProps,{class:["v-chip",{"v-chip--disabled":e.disabled,"v-chip--label":e.label,"v-chip--link":y.value,"v-chip--filter":N,"v-chip--pill":e.pill,[`${e.activeClass}`]:e.activeClass&&g.isActive?.value},v.value,r.value,w.value,i.value,s.value,u.value,d.value,S.value,m?.selectedClass.value,e.class],style:[V.value,c.value,e.style],disabled:e.disabled||void 0,draggable:e.draggable,tabindex:y.value?0:void 0,onClick:(y.value||e.onClick||e.onClickOnce)&&k,onKeydown:y.value&&!h.value&&x}),{default:()=>[xn(y.value,"v-chip"),N&&t.createVNode(_l,{key:"filter"},{default:()=>[t.withDirectives(t.createElementVNode("div",{class:"v-chip__filter"},[n.filter?t.createVNode(Bl,{key:"filter-defaults",disabled:!e.filterIcon,defaults:{VIcon:{icon:e.filterIcon}}},n.filter):t.createVNode(Mn,{key:"filter-icon",icon:e.filterIcon},null)]),[[t.vShow,m.isSelected.value]])]}),E&&t.createElementVNode("div",{key:"prepend",class:"v-chip__prepend"},[n.prepend?t.createVNode(Bl,{key:"prepend-defaults",disabled:!C,defaults:{VAvatar:{image:e.prependAvatar,start:!0},VIcon:{icon:e.prependIcon,start:!0}}},n.prepend):t.createElementVNode(t.Fragment,null,[e.prependIcon&&t.createVNode(Mn,{key:"prepend-icon",icon:e.prependIcon,start:!0},null),e.prependAvatar&&t.createVNode(Bo,{key:"prepend-avatar",image:e.prependAvatar,start:!0},null)])]),t.createElementVNode("div",{class:"v-chip__content","data-no-activator":""},[n.default?.({isSelected:m?.isSelected.value,selectedClass:m?.selectedClass.value,select:m?.select,toggle:m?.toggle,value:m?.value.value,disabled:e.disabled})??t.toDisplayString(e.text)]),o&&t.createElementVNode("div",{key:"append",class:"v-chip__append"},[n.append?t.createVNode(Bl,{key:"append-defaults",disabled:!l,defaults:{VAvatar:{end:!0,image:e.appendAvatar},VIcon:{end:!0,icon:e.appendIcon}}},n.append):t.createElementVNode(t.Fragment,null,[e.appendIcon&&t.createVNode(Mn,{key:"append-icon",end:!0,icon:e.appendIcon},null),e.appendAvatar&&t.createVNode(Bo,{key:"append-avatar",end:!0,image:e.appendAvatar},null)])]),f&&t.createElementVNode("button",t.mergeProps({key:"close",class:"v-chip__close",type:"button","data-testid":"close-chip"},b.value),[n.close?t.createVNode(Bl,{key:"close-defaults",defaults:{VIcon:{icon:e.closeIcon,size:"x-small"}}},n.close):t.createVNode(Mn,{key:"close-icon",icon:e.closeIcon,size:"x-small"},null)])]}),[[bo,y.value&&e.ripple,null]])}}}),$r=["dotted","dashed","solid","double"],Mr=Tt({color:String,contentOffset:[Number,String,Array],gradient:Boolean,inset:Boolean,length:[Number,String],opacity:[Number,String],thickness:[Number,String],vertical:Boolean,variant:{type:String,default:"solid",validator:e=>$r.includes(e)},...Ft(),...Ga()},"VDivider"),zr=Kt()({name:"VDivider",props:Mr(),setup(e,{attrs:a,slots:l}){const{themeClasses:n}=tl(e),{textColorClasses:o,textColorStyles:r}=Ll(()=>e.color),i=t.computed(()=>{const t={}
return e.length&&(t[e.vertical?"height":"width"]=z(e.length)),e.thickness&&(t[e.vertical?"borderRightWidth":"borderTopWidth"]=z(e.thickness)),t}),s=t.toRef(()=>{const t=Array.isArray(e.contentOffset)?e.contentOffset[0]:e.contentOffset,a=Array.isArray(e.contentOffset)?e.contentOffset[1]:0
return{marginBlock:e.vertical&&t?z(t):void 0,marginInline:!e.vertical&&t?z(t):void 0,transform:a?`translate${e.vertical?"X":"Y"}(${z(a)})`:void 0}})
return sa(()=>{const u=a.role,c=!!l.default,d=t.createElementVNode("hr",{class:t.normalizeClass([{"v-divider":!0,"v-divider--gradient":e.gradient&&!l.default,"v-divider--inset":e.inset,"v-divider--vertical":e.vertical},n.value,o.value,e.class]),style:t.normalizeStyle([i.value,r.value,{"--v-border-opacity":e.opacity},{"border-style":e.variant},e.style]),"aria-orientation":c||u?void 0:e.vertical?"vertical":"horizontal",role:c?void 0:u},null)
return c?t.createElementVNode("div",{class:t.normalizeClass(["v-divider__wrapper",{"v-divider__wrapper--gradient":e.gradient,"v-divider__wrapper--inset":e.inset,"v-divider__wrapper--vertical":e.vertical}])},[d,t.createElementVNode("div",{class:"v-divider__content",style:t.normalizeStyle(s.value)},[l.default()]),d]):d}),{}}}),Lr=Symbol.for("vuetify:list")
function Or(e={filterable:!1}){const a=t.inject(Lr,{filterable:!1,hasPrepend:t.shallowRef(!1),updateHasPrepend:()=>null,trackingIndex:t.shallowRef(-1),navigationStrategy:t.shallowRef("focus"),uid:""}),{filterable:l,trackingIndex:n=a.trackingIndex,navigationStrategy:o=a.navigationStrategy,uid:r=a.uid||t.useId()}=e,i={filterable:a.filterable||l,hasPrepend:t.shallowRef(!1),updateHasPrepend:e=>{e&&(i.hasPrepend.value=e)},trackingIndex:n,navigationStrategy:o,uid:r}
return t.provide(Lr,i),a}function jr(){return t.inject(Lr,null)}const Hr=e=>{const a={activate:({id:a,value:l,activated:n})=>(a=t.toRaw(a),e&&!l&&1===n.size&&n.has(a)||(l?n.add(a):n.delete(a)),n),in:(e,t,l)=>{let n=new Set
if(!k(e))for(const o of ee(e))n=a.activate({id:o,value:!0,activated:new Set(n),children:t,parents:l})
return n},out:e=>Array.from(e)}
return a},Wr=e=>{const a=Hr(e)
return{activate:({activated:e,id:l,...n})=>{l=t.toRaw(l)
const o=e.has(l)?new Set([l]):new Set
return a.activate({...n,id:l,activated:o})},in:(e,t,l)=>{let n=new Set
if(!k(e)){const o=ee(e)
o.length&&(n=a.in(o.slice(0,1),t,l))}return n},out:(e,t,l)=>a.out(e,t,l)}},Ur={open:({id:e,value:t,opened:a,parents:l})=>{if(t){const t=new Set
t.add(e)
let a=l.get(e)
for(;!k(a);)t.add(a),a=l.get(a)
return t}return a.delete(e),a},select:()=>null},Yr={open:({id:e,value:t,opened:a,parents:l})=>{if(t){let t=l.get(e)
for(a.add(e);!k(t)&&t!==e;)a.add(t),t=l.get(t)
return a}return a.delete(e),a},select:()=>null},Gr={open:Yr.open,select:({id:e,value:t,opened:a,parents:l})=>{if(!t)return a
const n=[]
let o=l.get(e)
for(;!k(o);)n.push(o),o=l.get(o)
return new Set(n)}},Kr=e=>{const a={select:({id:a,value:l,selected:n})=>{if(a=t.toRaw(a),e&&!l){const e=Array.from(n.entries()).reduce((e,[t,a])=>("on"===a&&e.push(t),e),[])
if(1===e.length&&e[0]===a)return n}return n.set(a,l?"on":"off"),n},in:(e,t,l,n)=>{const o=new Map
for(const r of e||[])a.select({id:r,value:!0,selected:o,children:t,parents:l,disabled:n})
return o},out:e=>{const t=[]
for(const[a,l]of e.entries())"on"===l&&t.push(a)
return t}}
return a},qr=e=>{const a=Kr(e)
return{select:({selected:e,id:l,...n})=>{l=t.toRaw(l)
const o=e.has(l)?new Map([[l,e.get(l)]]):new Map
return a.select({...n,id:l,selected:o})},in:(e,t,l,n)=>e?.length?a.in(e.slice(0,1),t,l,n):new Map,out:(e,t,l)=>a.out(e,t,l)}},Xr=e=>{const a={select:({id:a,value:l,selected:n,children:o,parents:r,disabled:i})=>{a=t.toRaw(a)
const s=new Map(n),u=[a]
for(;u.length;){const e=u.shift()
i.has(e)||n.set(t.toRaw(e),l?"on":"off"),o.has(e)&&u.push(...o.get(e))}let c=t.toRaw(r.get(a))
for(;c;){let e=!0,a=!0
for(const l of o.get(c)){const o=t.toRaw(l)
if(!i.has(o)&&("on"!==n.get(o)&&(e=!1),n.has(o)&&"off"!==n.get(o)&&(a=!1),!e&&!a))break}n.set(c,e?"on":a?"off":"indeterminate"),c=t.toRaw(r.get(c))}if(e&&!l){const e=Array.from(n.entries()).reduce((e,[t,a])=>("on"===a&&e.push(t),e),[])
if(0===e.length)return s}return n},in:(e,t,l)=>{let n=new Map
for(const o of e||[])n=a.select({id:o,value:!0,selected:n,children:t,parents:l,disabled:new Set})
return n},out:(e,t)=>{const a=[]
for(const[l,n]of e.entries())"on"!==n||t.has(l)||a.push(l)
return a}}
return a},Zr=Symbol.for("vuetify:nested"),Qr={id:t.shallowRef(),root:{itemsRegistration:t.ref("render"),register:()=>null,unregister:()=>null,updateDisabled:()=>null,children:t.ref(new Map),parents:t.ref(new Map),disabled:t.ref(new Set),open:()=>null,openOnSelect:()=>null,activate:()=>null,select:()=>null,activatable:t.ref(!1),scrollToActive:t.ref(!1),selectable:t.ref(!1),opened:t.ref(new Set),activated:t.ref(new Set),selected:t.ref(new Map),selectedValues:t.ref([]),getPath:()=>[]}},Jr=Tt({activatable:Boolean,selectable:Boolean,activeStrategy:[String,Function,Object],selectStrategy:[String,Function,Object],openStrategy:[String,Object],opened:null,activated:null,selected:null,mandatory:Boolean,itemsRegistration:{type:String,default:"render"}},"nested"),ei=(e,{items:a,returnObject:n,scrollToActive:o,valueComparator:r})=>{let i=!1
const s=t.shallowRef(new Map),u=t.shallowRef(new Map),c=t.shallowRef(new Set),d=_a(e,"opened",e.opened,e=>new Set(Array.isArray(e)?e.map(e=>t.toRaw(e)):e),e=>[...e.values()])
let v=null
function p(){return v||queueMicrotask(()=>{v=null}),v??d.value}function m(e){v=e,d.value=e}const g=t.computed(()=>{if(f(e.activeStrategy))return e.activeStrategy(e.mandatory)
if(b(e.activeStrategy))return e.activeStrategy
switch(e.activeStrategy){case"leaf":return(e=>{const a=Hr(e)
return{activate:({id:e,activated:l,children:n,...o})=>(e=t.toRaw(e),n.has(e)?l:a.activate({id:e,activated:l,children:n,...o})),in:a.in,out:a.out}})(e.mandatory)
case"single-leaf":return(e=>{const a=Wr(e)
return{activate:({id:e,activated:l,children:n,...o})=>(e=t.toRaw(e),n.has(e)?l:a.activate({id:e,activated:l,children:n,...o})),in:a.in,out:a.out}})(e.mandatory)
case"independent":return Hr(e.mandatory)
default:return Wr(e.mandatory)}}),h=t.computed(()=>{if(f(e.selectStrategy))return e.selectStrategy(e.mandatory)
if(b(e.selectStrategy))return e.selectStrategy
switch(e.selectStrategy){case"single-leaf":return(e=>{const a=qr(e)
return{select:({id:e,selected:l,children:n,...o})=>(e=t.toRaw(e),n.has(e)?l:a.select({id:e,selected:l,children:n,...o})),in:a.in,out:a.out}})(e.mandatory)
case"leaf":return(e=>{const a=Kr(e)
return{select:({id:e,selected:l,children:n,...o})=>(e=t.toRaw(e),n.has(e)?l:a.select({id:e,selected:l,children:n,...o})),in:a.in,out:a.out}})(e.mandatory)
case"independent":return Kr(e.mandatory)
case"single-independent":return qr(e.mandatory)
case"trunk":return(e=>{const t=Xr(e)
return{select:t.select,in:t.in,out:(e,t,a)=>{const l=[]
for(const[t,n]of e.entries())if("on"===n){if(a.has(t)){const l=a.get(t)
if("on"===e.get(l))continue}l.push(t)}return l}}})(e.mandatory)
case"branch":return(e=>{const t={select:Xr(e).select,in:(e,a,l,n)=>{let o=new Map
for(const r of e||[])a.has(r)||(o=t.select({id:r,value:!0,selected:o,children:a,parents:l,disabled:n}))
return o},out:e=>{const t=[]
for(const[a,l]of e.entries())"on"!==l&&"indeterminate"!==l||t.push(a)
return t}}
return t})(e.mandatory)
default:return Xr(e.mandatory)}}),y=t.computed(()=>{if(b(e.openStrategy))return e.openStrategy
switch(e.openStrategy){case"list":return Gr
case"single":return Ur
default:return Yr}}),w=t.computed(()=>{const e=[],t=[...a.value]
for(;t.length;){const a=t.pop()
e.push(a),a.children&&t.push(...a.children)}return e})
function V(e){const a=t.toValue(r)
if(!a)return e
const l=t.toValue(n)
for(const n of w.value){const o=l?t.toRaw(n.raw):n.value
if(a(e,o))return o}return e}const S=_a(e,"activated",e.activated,e=>g.value.in(Array.isArray(e)?e.map(V):e,s.value,u.value),e=>g.value.out(e,s.value,u.value)),N=_a(e,"selected",e.selected,e=>h.value.in(Array.isArray(e)?e.map(V):e,s.value,u.value,c.value),e=>h.value.out(e,s.value,u.value))
function C(e){const a=[]
let l=t.toRaw(e)
for(;!x(l);)a.unshift(l),l=u.value.get(l)
return a}t.onBeforeUnmount(()=>{i=!0})
const E=$t("nested"),I=new Set,A=function(e,t,a={leading:!0,trailing:!0}){let l=0,n=0,o=!1,r=0
function i(){clearTimeout(l),o=!1,r=0}const s=(...s)=>{clearTimeout(l)
const u=Date.now()
r||(r=u)
const c=u-Math.max(r,n)
function d(){n=Date.now(),l=setTimeout(i,t),e(...s)}o?c>=t?d():a.trailing&&(l=setTimeout(d,t-c)):(o=!0,a.leading&&d())}
return s.clear=i,s.immediate=e,s}(()=>{t.nextTick(()=>{s.value=new Map(s.value),u.value=new Map(u.value)})},100)
t.watch(()=>[a.value,t.toValue(n)],()=>{"props"===e.itemsRegistration&&function(){const e=new Map,l=new Map,o=new Set,r=t.toValue(n)?e=>t.toRaw(e.raw):e=>e.value,i=[...a.value]
let d=0
for(;d<i.length;){const t=i[d++],a=r(t)
if(t.children){const n=[]
for(const l of t.children){const t=r(l)
e.set(t,a),n.push(t),i.push(l)}l.set(a,n)}t.props.disabled&&o.add(a)}s.value=l,u.value=e,c.value=o}()},{immediate:!0})
const P={id:t.shallowRef(),root:{opened:d,activatable:t.toRef(()=>e.activatable),scrollToActive:t.toRef(()=>t.toValue(o)),selectable:t.toRef(()=>e.selectable),activated:S,selected:N,selectedValues:t.computed(()=>{const e=[]
for(const[t,a]of N.value.entries())"on"===a&&e.push(t)
return e}),itemsRegistration:t.toRef(()=>e.itemsRegistration),register:(e,t,a,n)=>{if(I.has(e)){return void l(`Multiple nodes with the same ID\n\t${C(e).map(String).join(" -> ")}\n\t${C(t).concat(e).map(String).join(" -> ")}`)}I.add(e),t&&e!==t&&u.value.set(e,t),a&&c.value.add(e),n&&s.value.set(e,[]),k(t)||s.value.set(t,[...s.value.get(t)||[],e]),A()},unregister:e=>{if(i)return
I.delete(e),s.value.delete(e),c.value.delete(e)
const t=u.value.get(e)
if(t){const a=s.value.get(t)??[]
s.value.set(t,a.filter(t=>t!==e))}u.value.delete(e),A()},updateDisabled:(e,t)=>{t?c.value.add(e):c.value.delete(e)},open:(e,t,a)=>{E.emit("click:open",{id:e,value:t,path:C(e),event:a})
const l=y.value.open({id:e,value:t,opened:new Set(p()),children:s.value,parents:u.value,event:a})
l&&m(l)},openOnSelect:(e,t,a)=>{const l=y.value.select({id:e,value:t,selected:new Map(N.value),opened:new Set(p()),children:s.value,parents:u.value,event:a})
l&&m(l)},select:(e,t,a)=>{E.emit("click:select",{id:e,value:t,path:C(e),event:a})
const l=h.value.select({id:e,value:t,selected:new Map(N.value),children:s.value,parents:u.value,disabled:c.value,event:a})
l&&(N.value=l),P.root.openOnSelect(e,t,a)},activate:(t,a,l)=>{if(!e.activatable)return P.root.select(t,!0,l)
E.emit("click:activate",{id:t,value:a,path:C(t),event:l})
const n=g.value.activate({id:t,value:a,activated:new Set(S.value),children:s.value,parents:u.value,event:l})
if(n.size!==S.value.size)S.value=n
else{for(const e of n)if(!S.value.has(e))return void(S.value=n)
for(const e of S.value)if(!n.has(e))return void(S.value=n)}},children:s,parents:u,disabled:c,getPath:C}}
return t.provide(Zr,P),P.root},ti=(e,a,l)=>{const n=t.inject(Zr,Qr),o=Symbol("nested item"),r=t.computed(()=>{const a=t.toRaw(t.toValue(e))
return x(a)?o:a}),i={...n,id:r,open:(e,t)=>n.root.open(r.value,e,t),openOnSelect:(e,t)=>n.root.openOnSelect(r.value,e,t),isOpen:t.computed(()=>n.root.opened.value.has(r.value)),parent:t.computed(()=>n.root.parents.value.get(r.value)),activate:(e,t)=>n.root.activate(r.value,e,t),isActivated:t.computed(()=>n.root.activated.value.has(r.value)),scrollToActive:n.root.scrollToActive,select:(e,t)=>n.root.select(r.value,e,t),isSelected:t.computed(()=>"on"===n.root.selected.value.get(r.value)),isIndeterminate:t.computed(()=>"indeterminate"===n.root.selected.value.get(r.value)),isLeaf:t.computed(()=>!n.root.children.value.get(r.value)),isGroupActivator:n.isGroupActivator}
return t.onBeforeMount(()=>{n.isGroupActivator||"props"===n.root.itemsRegistration.value||t.nextTick(()=>{n.root.register(r.value,n.id.value,t.toValue(a),l)})}),t.onBeforeUnmount(()=>{n.isGroupActivator||"props"===n.root.itemsRegistration.value||n.root.unregister(r.value)}),t.watch(r,(e,o)=>{n.isGroupActivator||"props"===n.root.itemsRegistration.value||(n.root.unregister(o),t.nextTick(()=>{n.root.register(e,n.id.value,t.toValue(a),l)}))}),t.watch(()=>t.toValue(a),e=>{n.root.updateDisabled(r.value,e)}),l&&t.provide(Zr,i),i},ai=Gt({name:"VListGroupActivator",setup:(e,{slots:a})=>((()=>{const e=t.inject(Zr,Qr)
t.provide(Zr,{...e,isGroupActivator:!0})})(),()=>a.default?.())}),li=Tt({activeColor:String,baseColor:String,color:String,collapseIcon:{type:ua,default:"$collapse"},disabled:Boolean,expandIcon:{type:ua,default:"$expand"},rawId:[String,Number],prependIcon:ua,appendIcon:ua,fluid:Boolean,subgroup:Boolean,title:String,value:null,...Ft(),...ol()},"VListGroup"),ni=Kt()({name:"VListGroup",props:li(),setup(e,{slots:a}){const{isOpen:l,open:n,id:o}=ti(()=>e.value,()=>e.disabled,!0),r=t.computed(()=>`v-list-group--id-${String(e.rawId??o.value)}`),i=jr(),{isBooted:s}=mn(),u=t.inject(Zr),c=t.toRef(()=>"render"===u?.root?.itemsRegistration.value)
function d(e){["INPUT","TEXTAREA"].includes(e.target?.tagName)||n(!l.value,e)}const v=t.computed(()=>({onClick:d,class:"v-list-group__header",id:r.value})),p=t.computed(()=>l.value?e.collapseIcon:e.expandIcon),m=t.computed(()=>({VListItem:{activeColor:e.activeColor,baseColor:e.baseColor,color:e.color,prependIcon:e.prependIcon||e.subgroup&&p.value,appendIcon:e.appendIcon||!e.subgroup&&p.value,title:e.title,value:e.value}}))
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-list-group",{"v-list-group--prepend":i?.hasPrepend.value,"v-list-group--fluid":e.fluid,"v-list-group--subgroup":e.subgroup,"v-list-group--open":l.value},e.class]),style:t.normalizeStyle(e.style)},{default:()=>[a.activator&&t.createVNode(Bl,{defaults:m.value},{default:()=>[t.createVNode(ai,null,{default:()=>[a.activator({props:v.value,isOpen:l.value})]})]}),t.createVNode(Xl,{transition:{component:Pl},disabled:!s.value},{default:()=>[c.value?t.withDirectives(t.createElementVNode("div",{class:"v-list-group__items",role:"group","aria-labelledby":r.value,inert:!l.value},[a.default?.()]),[[t.vShow,l.value]]):l.value&&t.createElementVNode("div",{class:"v-list-group__items",role:"group","aria-labelledby":r.value},[a.default?.()])]})]})),{isOpen:l}}}),oi=Tt({opacity:[Number,String],...Ft(),...ol()},"VListItemSubtitle"),ri=Kt()({name:"VListItemSubtitle",props:oi(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-list-item-subtitle",e.class]),style:t.normalizeStyle([{"--v-list-item-subtitle-opacity":e.opacity},e.style])},a)),{})}),ii=qt("v-list-item-title"),si=Tt({active:{type:Boolean,default:void 0},activeClass:String,activeColor:String,appendAvatar:String,appendIcon:ua,baseColor:String,disabled:Boolean,lines:[Boolean,String],link:{type:Boolean,default:void 0},nav:Boolean,prependAvatar:String,prependIcon:ua,ripple:{type:[Boolean,Object],default:!0},slim:Boolean,prependGap:[Number,String],subtitle:{type:[String,Number,Boolean],default:void 0},title:{type:[String,Number,Boolean],default:void 0},value:null,index:Number,tabindex:[Number,String],onClick:fe(),onClickOnce:fe(),...an(),...Ft(),...yn(),...Tl(),...nn(),...Gl(),...to(),...ol(),...Ga(),...Nn({variant:"text"})},"VListItem"),ui=Kt()({name:"VListItem",directives:{vRipple:bo},props:si(),emits:{click:e=>!0},setup(e,{attrs:a,slots:l,emit:o}){const r=eo(e,a),i=t.ref(),s=t.computed(()=>void 0===e.value?r.href.value:e.value),{activate:u,isActivated:c,select:d,isOpen:v,isSelected:p,isIndeterminate:m,isGroupActivator:f,root:g,parent:h,openOnSelect:y,scrollToActive:b,id:w}=ti(s,()=>e.disabled,!1),V=jr(),S=t.computed(()=>!1!==e.active&&(e.active||r.isActive?.value||(g.activatable.value?c.value:p.value))),k=t.toRef(()=>!1!==e.link&&r.isLink.value),x=t.computed(()=>!!V&&(g.selectable.value||g.activatable.value||null!=e.value)),N=t.computed(()=>!e.disabled&&!1!==e.link&&(e.link||r.isClickable.value||x.value)),C=t.computed(()=>V&&"track"===V.navigationStrategy.value&&void 0!==e.index&&V.trackingIndex.value===e.index),E=t.computed(()=>V?k.value?"link":x.value?"option":"listitem":void 0),I=t.computed(()=>{if(x.value)return g.activatable.value?c.value:g.selectable.value?p.value:S.value}),A=t.toRef(()=>e.rounded||e.nav),P=t.toRef(()=>e.color??e.activeColor),_=t.toRef(()=>({color:S.value?P.value??e.baseColor:e.baseColor,variant:e.variant}))
function R(){null!=h.value&&g.open(h.value,!0),y(!0)}t.watch(()=>r.isActive?.value,e=>{e&&R()}),t.watch(c,e=>{e&&b&&i.value?.scrollIntoView({block:"nearest",behavior:"instant"})}),t.watch(C,e=>{e&&i.value?.scrollIntoView({block:"nearest",behavior:"instant"})}),t.onBeforeMount(()=>{r.isActive?.value&&t.nextTick(()=>R())})
const{themeClasses:D}=tl(e),{borderClasses:B}=ln(e),{colorClasses:T,colorStyles:F,variantClasses:$}=Cn(_),{densityClasses:M}=bn(e),{dimensionStyles:L}=Fl(e),{elevationClasses:O}=on(e),{roundedClasses:j,roundedStyles:H}=Kl(A),W=t.toRef(()=>e.lines?`v-list-item--${e.lines}-line`:void 0),U=t.toRef(()=>void 0!==e.ripple&&e.ripple&&V?.filterable?{keys:["Enter"]}:e.ripple),Y=t.computed(()=>({isActive:S.value,select:d,isOpen:v.value,isSelected:p.value,isIndeterminate:m.value,isDisabled:e.disabled}))
function G(t){o("click",t),["INPUT","TEXTAREA"].includes(t.target?.tagName)||N.value&&(r.navigate.value?.(t),f||(g.activatable.value?u(!c.value,t):g.selectable.value?d(!p.value,t):null==e.value||k.value||d(!p.value,t)))}function K(e){const t=e.target;["INPUT","TEXTAREA"].includes(t.tagName)||"treeitem"!==e.currentTarget?.getAttribute("role")&&("Enter"===e.key||" "===e.key&&!V?.filterable)&&(e.preventDefault(),e.stopPropagation(),e.target.dispatchEvent(new MouseEvent("click",e)))}return sa(()=>{const a=k.value?"a":e.tag,o=l.title||null!=e.title,s=l.subtitle||null!=e.subtitle,u=!(!!(!e.appendAvatar&&!e.appendIcon)&&!l.append),c=!(!!(!e.prependAvatar&&!e.prependIcon)&&!l.prepend)
return V?.updateHasPrepend(c),e.activeColor&&n("active-color",["color","base-color"]),t.withDirectives(t.createVNode(a,t.mergeProps(r.linkProps,{ref:i,id:void 0!==e.index&&V?`v-list-item-${V.uid}-${e.index}`:void 0,class:["v-list-item",{"v-list-item--active":S.value,"v-list-item--disabled":e.disabled,"v-list-item--link":N.value,"v-list-item--nav":e.nav,"v-list-item--prepend":!c&&V?.hasPrepend.value,"v-list-item--slim":e.slim,"v-list-item--focus-visible":C.value,[`${e.activeClass}`]:e.activeClass&&S.value},D.value,B.value,T.value,M.value,O.value,W.value,j.value,$.value,e.class],style:[{"--v-list-prepend-gap":z(e.prependGap)},F.value,L.value,H.value,e.style],tabindex:e.tabindex??(N.value?V?-2:0:void 0),"aria-selected":I.value,role:E.value,onClick:(N.value||e.onClick||e.onClickOnce)&&G,onKeydown:N.value&&!k.value&&K}),{default:()=>[xn(N.value||S.value,"v-list-item"),c&&t.createElementVNode("div",{key:"prepend",class:"v-list-item__prepend"},[l.prepend?t.createVNode(Bl,{key:"prepend-defaults",defaults:{VAvatar:{density:e.density,image:e.prependAvatar},VIcon:{density:e.density,icon:e.prependIcon},VListItemAction:{start:!0},VCheckboxBtn:{density:e.density}}},{default:()=>[l.prepend?.(Y.value)]}):t.createElementVNode(t.Fragment,null,[e.prependAvatar&&t.createVNode(Bo,{key:"prepend-avatar",density:e.density,image:e.prependAvatar},null),e.prependIcon&&t.createVNode(Mn,{key:"prepend-icon",density:e.density,icon:e.prependIcon},null)]),t.createElementVNode("div",{class:"v-list-item__spacer"},null)]),t.createElementVNode("div",{class:"v-list-item__content","data-no-activator":""},[o&&t.createVNode(ii,{key:"title"},{default:()=>[l.title?.({title:e.title})??t.toDisplayString(e.title)]}),s&&t.createVNode(ri,{key:"subtitle"},{default:()=>[l.subtitle?.({subtitle:e.subtitle})??t.toDisplayString(e.subtitle)]}),l.default?.(Y.value)]),u&&t.createElementVNode("div",{key:"append",class:"v-list-item__append"},[l.append?t.createVNode(Bl,{key:"append-defaults",defaults:{VAvatar:{density:e.density,image:e.appendAvatar},VIcon:{density:e.density,icon:e.appendIcon},VListItemAction:{end:!0},VCheckboxBtn:{density:e.density}}},{default:()=>[l.append?.(Y.value)]}):t.createElementVNode(t.Fragment,null,[e.appendIcon&&t.createVNode(Mn,{key:"append-icon",density:e.density,icon:e.appendIcon},null),e.appendAvatar&&t.createVNode(Bo,{key:"append-avatar",density:e.density,image:e.appendAvatar},null)]),t.createElementVNode("div",{class:"v-list-item__spacer"},null)])]}),[[bo,N.value&&U.value]])}),{activate:u,isActivated:c,isGroupActivator:f,isSelected:p,list:V,select:d,root:g,id:w,link:r}}}),ci=Tt({color:String,inset:Boolean,sticky:Boolean,title:String,...Ft(),...ol()},"VListSubheader"),di=Kt()({name:"VListSubheader",props:ci(),setup(e,{slots:a}){const{textColorClasses:l,textColorStyles:n}=Ll(()=>e.color)
return sa(()=>{const o=!(!a.default&&!e.title)
return t.createVNode(e.tag,{class:t.normalizeClass(["v-list-subheader",{"v-list-subheader--inset":e.inset,"v-list-subheader--sticky":e.sticky},l.value,e.class]),style:t.normalizeStyle([{textColorStyles:n},e.style])},{default:()=>[o&&t.createElementVNode("div",{class:"v-list-subheader__text"},[a.default?.()??e.title])]})}),{}}}),vi=Tt({items:Array,returnObject:Boolean},"VListChildren"),pi=Kt()({name:"VListChildren",props:vi(),setup:(e,{slots:a})=>(Or(),()=>a.default?.()??e.items?.map(({children:l,props:n,type:o,raw:r},i)=>{if("divider"===o)return a.divider?.({props:n})??t.createVNode(zr,n,null)
if("subheader"===o)return a.subheader?.({props:n})??t.createVNode(di,n,null)
const s={subtitle:a.subtitle?e=>a.subtitle?.({...e,item:r}):void 0,prepend:a.prepend?e=>a.prepend?.({...e,item:r}):void 0,append:a.append?e=>a.append?.({...e,item:r}):void 0,title:a.title?e=>a.title?.({...e,item:r}):void 0},u=ni.filterProps(n)
return l?t.createVNode(ni,t.mergeProps(u,{value:e.returnObject?r:n?.value,rawId:n?.value}),{activator:({props:l})=>{const o=t.mergeProps(n,l,{value:e.returnObject?r:n.value})
return a.header?a.header({props:o}):t.createVNode(ui,t.mergeProps(o,{index:i}),s)},default:()=>t.createVNode(pi,{items:l,returnObject:e.returnObject},a)}):a.item?a.item({props:{...n,index:i}}):t.createVNode(ui,t.mergeProps(n,{index:i,value:e.returnObject?r:n.value}),s)}))}),mi=Tt({items:{type:Array,default:()=>[]},itemTitle:{type:[String,Array,Function],default:"title"},itemValue:{type:[String,Array,Function],default:"value"},itemChildren:{type:[Boolean,String,Array,Function],default:"children"},itemProps:{type:[Boolean,String,Array,Function],default:"props"},itemType:{type:[Boolean,String,Array,Function],default:"type"},returnObject:Boolean,valueComparator:Function},"list-items"),fi=new Set(["item","divider","subheader"])
function gi(e,t){const a=F(t,e.itemTitle,t),l=F(t,e.itemValue,a),n=F(t,e.itemChildren),o=!0===e.itemProps?b(t)?"children"in t?G(t,["children"]):t:void 0:F(t,e.itemProps)
let r=F(t,e.itemType,"item")
fi.has(r)||(r="item")
const i={title:a,value:l,...o}
return{type:r,title:String(i.title??""),value:i.value,props:i,children:"item"===r&&Array.isArray(n)?hi(e,n):void 0,raw:t}}function hi(e,t){const a=U(e,gi.neededProps),l=[]
for(const e of t)l.push(gi(a,e))
return l}function yi(e){const a=t.computed(()=>hi(e,e.items)),l=t.computed(()=>a.value.some(e=>S(e.value))),n=t.shallowRef(new Map),o=t.shallowRef([])
return t.watchEffect(()=>{const e=a.value,t=new Map,l=[]
for(let a=0;a<e.length;a++){const n=e[a]
if(Ae(n.value)||S(n.value)){let e=t.get(n.value)
e||(e=[],t.set(n.value,e)),e.push(n)}else l.push(n)}n.value=t,o.value=l}),{items:a,transformIn:function(t){const r=n.value,i=a.value,s=o.value,u=l.value,c=e.returnObject,d=!!e.valueComparator,v=e.valueComparator||Xt,p=U(e,gi.neededProps),m=[]
e:for(const e of t){if(!u&&S(e))continue
if(c&&g(e)){m.push(gi(p,e))
continue}const t=r.get(e)
if(!d&&t)m.push(...t)
else{for(const t of d?i:s)if(v(e,t.value)){m.push(t)
continue e}m.push(gi(p,e))}}return m},transformOut:function(t){return e.returnObject?t.map(({raw:e})=>e):t.map(({value:e})=>e)}}}gi.neededProps=["itemTitle","itemValue","itemChildren","itemProps","itemType"]
const bi=new Set(["item","divider","subheader"])
function wi(e,t){const a=Ae(t)?t:F(t,e.itemTitle),l=Ae(t)?t:F(t,e.itemValue,void 0),n=F(t,e.itemChildren),o=!0===e.itemProps?G(t,["children"]):F(t,e.itemProps)
let r=F(t,e.itemType,"item")
bi.has(r)||(r="item")
const i={title:a,value:l,...o}
return{type:r,title:i.title,value:i.value,props:i,children:"item"===r&&n?Vi(e,n):void 0,raw:t}}function Vi(e,t){const a=[]
for(const l of t)a.push(wi(e,l))
return a}function Si(e){return{items:t.computed(()=>Vi(e,e.items))}}const ki=Tt({baseColor:String,activeColor:String,activeClass:String,bgColor:String,disabled:Boolean,filterable:Boolean,expandIcon:ua,collapseIcon:ua,lines:{type:[Boolean,String],default:"one"},slim:Boolean,prependGap:[Number,String],indent:[Number,String],nav:Boolean,navigationStrategy:{type:String,default:"focus"},navigationIndex:Number,"onClick:open":fe(),"onClick:select":fe(),"onUpdate:opened":fe(),...Jr({selectStrategy:"single-leaf",openStrategy:"list"}),...an(),...Ft(),...yn(),...Tl(),...nn(),...mi(),...Gl(),...ol(),...Ga(),...Nn({variant:"text"})},"VList"),xi=Kt()({name:"VList",props:ki(),emits:{"update:selected":e=>!0,"update:activated":e=>!0,"update:opened":e=>!0,"update:navigationIndex":e=>!0,"click:open":e=>!0,"click:activate":e=>!0,"click:select":e=>!0},setup(e,{attrs:a,slots:l,emit:n}){const{items:o}=Si(e),{themeClasses:r}=tl(e),{backgroundColorClasses:i,backgroundColorStyles:s}=Ol(()=>e.bgColor),{borderClasses:u}=ln(e),{densityClasses:c}=bn(e),{dimensionStyles:d}=Fl(e),{elevationClasses:v}=on(e),{roundedClasses:p,roundedStyles:m}=Kl(e),{children:f,open:g,parents:h,select:y,getPath:b}=ei(e,{items:o,returnObject:t.toRef(()=>e.returnObject),scrollToActive:t.toRef(()=>"track"===e.navigationStrategy),valueComparator:t.toRef(()=>e.valueComparator)}),w=t.toRef(()=>e.lines?`v-list--${e.lines}-line`:void 0),V=t.toRef(()=>e.activeColor),S=t.toRef(()=>e.baseColor),k=t.toRef(()=>e.color),x=t.toRef(()=>e.selectable||e.activatable),N=_a(e,"navigationIndex",-1,e=>e??-1),C=t.useId()
Or({filterable:e.filterable,trackingIndex:N,navigationStrategy:t.toRef(()=>e.navigationStrategy),uid:C}),t.watch(o,()=>{"track"===e.navigationStrategy&&(N.value=-1)}),Ht({VListGroup:{activeColor:V,baseColor:S,color:k,expandIcon:t.toRef(()=>e.expandIcon),collapseIcon:t.toRef(()=>e.collapseIcon)},VListItem:{activeClass:t.toRef(()=>e.activeClass),activeColor:V,baseColor:S,color:k,density:t.toRef(()=>e.density),disabled:t.toRef(()=>e.disabled),lines:t.toRef(()=>e.lines),nav:t.toRef(()=>e.nav),slim:t.toRef(()=>e.slim),variant:t.toRef(()=>e.variant),tabindex:t.toRef(()=>"track"===e.navigationStrategy?-1:void 0)}})
const E=t.shallowRef(!1),I=t.ref()
function A(e){E.value=!0}function P(e){E.value=!1}function _(t){"track"===e.navigationStrategy?~N.value||(N.value=D("first")):E.value||t.relatedTarget&&I.value?.contains(t.relatedTarget)||F()}function R(){"track"===e.navigationStrategy&&(N.value=-1)}function D(e){const t=o.value.length
if(0===t)return-1
let a
"first"===e?a=0:"last"===e?a=t-1:(a=N.value+("next"===e?1:-1),a<0&&(a=t-1),a>=t&&(a=0))
const l=a
let n=0
for(;n<t;){const r=o.value[a]
if(r&&"divider"!==r.type&&"subheader"!==r.type)return a
if(a+="next"===e||"first"===e?1:-1,a<0&&(a=t-1),a>=t&&(a=0),a===l)return-1
n++}return-1}function B(t){const a=t.target
if(!I.value||"INPUT"===a.tagName&&["Home","End"].includes(t.key)||"TEXTAREA"===a.tagName)return
const l=function(e){switch(e){case"ArrowDown":return"next"
case"ArrowUp":return"prev"
case"Home":return"first"
case"End":return"last"
default:return null}}(t.key)
if(null!==l)if(t.preventDefault(),"track"===e.navigationStrategy){const e=D(l);-1!==e&&(N.value=e)}else{F(l,{preventScroll:!0})
const e=be()
e&&I.value?.contains(e)&&e.scrollIntoView({block:"nearest"})}}function T(e){E.value=!0}function F(e,t){if(I.value)return Ve(I.value,e,t)}return sa(()=>{const n=e.indent??(e.prependGap?Number(e.prependGap)+24:void 0),f=x.value?a.ariaMultiselectable??!String(e.selectStrategy).startsWith("single-"):void 0
return t.createVNode(e.tag,{ref:I,class:t.normalizeClass(["v-list",{"v-list--disabled":e.disabled,"v-list--nav":e.nav,"v-list--slim":e.slim},r.value,i.value,u.value,c.value,v.value,w.value,p.value,e.class]),style:t.normalizeStyle([{"--v-list-indent":z(n),"--v-list-group-prepend":n?"0px":void 0,"--v-list-prepend-gap":z(e.prependGap)},s.value,d.value,m.value,e.style]),tabindex:e.disabled||E.value?-1:0,role:x.value?"listbox":"list","aria-activedescendant":"track"===e.navigationStrategy&&N.value>=0?`v-list-item-${C}-${N.value}`:void 0,"aria-multiselectable":f,onFocusin:A,onFocusout:P,onFocus:_,onBlur:R,onKeydown:B,onMousedown:T},{default:()=>[t.createVNode(pi,{items:o.value,returnObject:e.returnObject},l)]})}),{open:g,select:y,focus:F,children:f,parents:h,getPath:b,navigationIndex:N}}}),Ni=qt("v-list-img"),Ci=Tt({start:Boolean,end:Boolean,...Ft(),...ol()},"VListItemAction"),Ei=Kt()({name:"VListItemAction",props:Ci(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-list-item-action",{"v-list-item-action--start":e.start,"v-list-item-action--end":e.end},e.class]),style:t.normalizeStyle(e.style)},a)),{})}),Ii=Tt({start:Boolean,end:Boolean,...Ft(),...ol()},"VListItemMedia"),Ai=Kt()({name:"VListItemMedia",props:Ii(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-list-item-media",{"v-list-item-media--start":e.start,"v-list-item-media--end":e.end},e.class]),style:t.normalizeStyle(e.style)},a)),{})}),Pi=Symbol.for("vuetify:v-menu")
function _i(e,t){return{x:e.x+t.x,y:e.y+t.y}}function Ri(e,t){if("top"===e.side||"bottom"===e.side){const{side:a,align:l}=e
return _i({x:"left"===l?0:"center"===l?t.width/2:"right"===l?t.width:l,y:"top"===a?0:"bottom"===a?t.height:a},t)}if("left"===e.side||"right"===e.side){const{side:a,align:l}=e
return _i({x:"left"===a?0:"right"===a?t.width:a,y:"top"===l?0:"center"===l?t.height/2:"bottom"===l?t.height:l},t)}return _i({x:t.width/2,y:t.height/2},t)}const Di={static:function(e,a,l){return t.watch([()=>a.origin,e.isRtl],function(){if("auto"!==a.origin&&"overlap"!==a.origin){const{side:t,align:n}=$e(a.origin,e.isRtl.value)
l.value={transformOrigin:`${t} ${n}`}}else l.value={}},{immediate:!0}),{updateLocation:()=>{}}},connected:function(e,a,n){(Array.isArray(e.target.value)||function(e){for(;e;){if("fixed"===window.getComputedStyle(e).position)return!0
e=e.offsetParent}return!1}(e.target.value))&&Object.assign(n.value,{position:"fixed",top:0,[e.isRtl.value?"right":"left"]:0})
const{preferredAnchor:o,preferredOrigin:r}=ve(()=>{const t=$e(a.location??"bottom",e.isRtl.value),l="overlap"===a.origin?t:"auto"===a.origin?ze(t):$e(a.origin,e.isRtl.value)
return t.side===l.side&&t.align===Le(l).align?{preferredAnchor:Oe(t),preferredOrigin:Oe(l)}:{preferredAnchor:t,preferredOrigin:l}}),[i,s,u,c]=["minWidth","minHeight","maxWidth","maxHeight"].map(t=>{const l=t.endsWith("Width")
return()=>{const n=a[t]
if(null==n)return 1/0
const o=e.contentEl.value?.parentElement??document.documentElement
if(h(n)||/^-?[\d.]+(?:px)?$/.test(n.trim()))return parseFloat(n)
if(n.endsWith("%")){const e=Ye(o)
return parseFloat(n)*(l?e.width:e.height)/100}return function(e,t,a){const l=document.createElement("div")
l.style.position="absolute",l.style.visibility="hidden",l.style[a?"width":"height"]=e,t.appendChild(l)
const n=a?l.offsetWidth:l.offsetHeight
return t.removeChild(l),n>0?n:1/0}(n,o,l)}}),d=t.computed(()=>{if(Array.isArray(a.offset))return a.offset
if(g(a.offset)){const e=a.offset.split(" ").map(parseFloat)
return e.length<2&&e.push(0),e}return h(a.offset)?[a.offset,0]:[0,0]})
let v=!1,p=-1
const m=new de(4),f=new ResizeObserver(()=>{if(!v)return
if(requestAnimationFrame(e=>{e!==p&&m.clear(),requestAnimationFrame(e=>{p=e})}),m.isFull){const e=m.values()
if(Xt(e.at(-1),e.at(-3))&&!Xt(e.at(-1),e.at(-2)))return}const e=b()
e&&m.push(e.flipped)})
let y=new He({x:0,y:0,width:0,height:0})
function b(){if(v=!1,requestAnimationFrame(()=>v=!0),!e.target.value||!e.contentEl.value)return;(Array.isArray(e.target.value)||e.target.value.offsetParent||e.target.value.getClientRects().length)&&(y=Ue(e.target.value))
const t=function(e,t){const a=Ge(e),l=getComputedStyle(e)
function n(t){return e.style[t]&&parseFloat(l[t])||0}t?a.x+=n("right"):a.x-=n("left")
return a.y-=n("top"),a}(e.contentEl.value,e.isRtl.value),p=oa(e.contentEl.value),m=Number(a.viewportMargin),f=i(),g=s(),h=u(),b=c()
p.length||(p.push(document.documentElement),e.contentEl.value.style.top&&e.contentEl.value.style.left||(t.x-=parseFloat(document.documentElement.style.getPropertyValue("--v-body-scroll-x")||0),t.y-=parseFloat(document.documentElement.style.getPropertyValue("--v-body-scroll-y")||0)))
const w=p.reduce((e,t)=>{const a=Ye(t)
return e?new He({x:Math.max(e.left,a.left),y:Math.max(e.top,a.top),width:Math.min(e.right,a.right)-Math.max(e.left,a.left),height:Math.min(e.bottom,a.bottom)-Math.max(e.top,a.top)}):a},void 0)
a.stickToTarget?(w.x+=Math.min(m,y.x),w.y+=Math.min(m,y.y),w.width=Math.max(w.width-2*m,y.x+y.width-m),w.height=Math.max(w.height-2*m,y.y+y.height-m)):(w.x+=m,w.y+=m,w.width-=2*m,w.height-=2*m)
let V={anchor:o.value,origin:r.value}
function S(e){const a=new He(t),l=Ri(e.anchor,y),n=Ri(e.origin,a)
let{x:o,y:r}=(s=n,{x:(i=l).x-s.x,y:i.y-s.y})
var i,s
switch(e.anchor.side){case"top":r-=d.value[0]
break
case"bottom":r+=d.value[0]
break
case"left":o-=d.value[0]
break
case"right":o+=d.value[0]}switch(e.anchor.align){case"top":r-=d.value[1]
break
case"bottom":r+=d.value[1]
break
case"left":o-=d.value[1]
break
case"right":o+=d.value[1]}a.x+=o,a.y+=r,a.width=Math.min(a.width,h),a.height=Math.min(a.height,b)
return{overflows:We(a,w),x:o,y:r}}let k=0,x=0
const N={x:0,y:0},C={x:!1,y:!1}
let E=-1
for(;;){if(E++>10){l("Infinite loop detected in connectedLocationStrategy")
break}const{x:e,y:a,overflows:n}=S(V)
k+=e,x+=a,t.x+=e,t.y+=a
{const e=je(V.anchor),t=n.x.before||n.x.after,a=n.y.before||n.y.after
let l=!1
if(["x","y"].forEach(o=>{if("x"===o&&t&&!C.x||"y"===o&&a&&!C.y){const t={anchor:{...V.anchor},origin:{...V.origin}},a="x"===o?"y"===e?Le:ze:"y"===e?ze:Le
t.anchor=a(t.anchor),t.origin=a(t.origin)
const{overflows:r}=S(t);(r[o].before<=n[o].before&&r[o].after<=n[o].after||r[o].before+r[o].after<(n[o].before+n[o].after)/2)&&(V=t,l=C[o]=!0)}}),l)continue}n.x.before&&(k+=n.x.before,t.x+=n.x.before),n.x.after&&(k-=n.x.after,t.x-=n.x.after),n.y.before&&(x+=n.y.before,t.y+=n.y.before),n.y.after&&(x-=n.y.after,t.y-=n.y.after)
{const e=We(t,w)
N.x=w.width-e.x.before-e.x.after,N.y=w.height-e.y.before-e.y.after,k+=e.x.before,t.x+=e.x.before,x+=e.y.before,t.y+=e.y.before}break}const I=je(V.anchor),A="auto"!==a.origin&&"overlap"!==a.origin?$e(a.origin,e.isRtl.value):V.origin
return Object.assign(n.value,{"--v-overlay-anchor-origin":`${V.anchor.side} ${V.anchor.align}`,transformOrigin:`${A.side} ${A.align}`,top:z(Ti(x)),left:e.isRtl.value?void 0:z(Ti(k)),right:e.isRtl.value?z(Ti(-k)):void 0,minWidth:z("y"===I?Math.min(f,y.width):f),maxWidth:z(Fi(ae(N.x,f===1/0?0:f,h))),maxHeight:z(Fi(ae(N.y,g===1/0?0:g,b)))}),{available:N,contentBox:t,flipped:C}}return t.watch(e.target,(e,t)=>{t&&!Array.isArray(t)&&f.unobserve(t),Array.isArray(e)?Xt(e,t)||b():e&&f.observe(e)},{immediate:!0}),t.watch(e.contentEl,(e,t)=>{t&&f.unobserve(t),e&&f.observe(e)},{immediate:!0}),t.onScopeDispose(()=>{f.disconnect()}),t.watch(()=>[o.value,r.value,a.origin,a.offset,a.minWidth,a.minHeight,a.maxWidth,a.maxHeight],()=>b()),t.nextTick(()=>{const e=b()
if(!e)return
const{available:t,contentBox:a}=e
a.height>t.y&&requestAnimationFrame(()=>{b(),requestAnimationFrame(()=>{b()})})}),{updateLocation:b}}},Bi=Tt({locationStrategy:{type:[String,Function],default:"static",validator:e=>f(e)||e in Di},location:String,origin:{type:String,default:"auto"},offset:[Number,String,Array],stickToTarget:Boolean,viewportMargin:{type:[Number,String],default:12}},"VOverlay-location-strategies")
function Ti(e){return Math.round(e*devicePixelRatio)/devicePixelRatio}function Fi(e){return Math.ceil(e*devicePixelRatio)/devicePixelRatio}let $i=!0
const Mi=[]
let zi=-1
function Li(){cancelAnimationFrame(zi),zi=requestAnimationFrame(()=>{const e=Mi.shift()
e&&e(),Mi.length?Li():$i=!0})}const Oi={none:null,close:function(e){Wi(Hi(e.target.value,e.contentEl.value),function(t){e.isActive.value=!1})},block:function(e,a){const l=e.root.value?.offsetParent,n=Hi(e.target.value,e.contentEl.value),o=[...new Set([...oa(n,a.contained?l:void 0),...oa(e.contentEl.value,a.contained?l:void 0)])].filter(e=>!e.classList.contains("v-overlay-scroll-blocked")),r=window.innerWidth-document.documentElement.offsetWidth,i=(s=l||document.documentElement,ra(s)&&s)
var s
i&&e.root.value.classList.add("v-overlay--scroll-blocked")
o.forEach((e,t)=>{e.style.setProperty("--v-body-scroll-x",z(-e.scrollLeft)),e.style.setProperty("--v-body-scroll-y",z(-e.scrollTop)),e===document.documentElement&&"scroll"===getComputedStyle(e).overflowY||e.style.setProperty("--v-scrollbar-offset",z(r)),e.classList.add("v-overlay-scroll-blocked")}),t.onScopeDispose(()=>{o.forEach((e,t)=>{const a=parseFloat(e.style.getPropertyValue("--v-body-scroll-x")),l=parseFloat(e.style.getPropertyValue("--v-body-scroll-y")),n=e.style.scrollBehavior
e.style.scrollBehavior="auto",e.style.removeProperty("--v-body-scroll-x"),e.style.removeProperty("--v-body-scroll-y"),e.style.removeProperty("--v-scrollbar-offset"),e.classList.remove("v-overlay-scroll-blocked"),e.scrollLeft=-a,e.scrollTop=-l,e.style.scrollBehavior=n}),i&&e.root.value.classList.remove("v-overlay--scroll-blocked")})},reposition:function(e,a,l){let n=!1,o=-1,r=-1
function i(t){var a
a=()=>{const a=performance.now()
e.updateLocation.value?.(t)
const l=performance.now()-a
n=l/(1e3/60)>2},!$i||Mi.length?(Mi.push(a),Li()):($i=!1,a(),Li())}r=("undefined"==typeof requestIdleCallback?e=>e():requestIdleCallback)(()=>{l.run(()=>{Wi(Hi(e.target.value,e.contentEl.value),e=>{n?(cancelAnimationFrame(o),o=requestAnimationFrame(()=>{o=requestAnimationFrame(()=>{i(e)})})):i(e)})})}),t.onScopeDispose(()=>{"undefined"!=typeof cancelIdleCallback&&cancelIdleCallback(r),cancelAnimationFrame(o)})}},ji=Tt({scrollStrategy:{type:[String,Function],default:"block",validator:e=>f(e)||e in Oi}},"VOverlay-scroll-strategies")
function Hi(e,t){return Array.isArray(e)?document.elementsFromPoint(...e).find(e=>!t?.contains(e)):e??t}function Wi(e,a){const l=[document,...oa(e)]
l.forEach(e=>{e.addEventListener("scroll",a,{passive:!0})}),t.onScopeDispose(()=>{l.forEach(e=>{e.removeEventListener("scroll",a)})})}const Ui=Tt({closeDelay:[Number,String],openDelay:[Number,String]},"delay")
function Yi(e,t){let a=()=>{}
function l(l,n){a?.()
const o=l?e.openDelay:e.closeDelay,r=Math.max(n?.minDelay??0,Number(o??0))
return new Promise(e=>{a=function(e,t){if(!E||0===e)return t(),()=>{}
const a=window.setTimeout(t,e)
return()=>window.clearTimeout(a)}(r,()=>{t?.(l),e(l)})})}return{clearDelay:a,runOpenDelay:function(){return l(!0)},runCloseDelay:function(e){return l(!1,e)}}}const Gi=Tt({target:[String,Object],activator:[String,Object],activatorProps:{type:Object,default:()=>({})},openOnClick:{type:Boolean,default:void 0},openOnHover:Boolean,openOnFocus:{type:Boolean,default:void 0},closeOnContentClick:Boolean,...Ui()},"VOverlay-activator")
function Ki(e,{isActive:a,isTop:l,contentEl:n,isSubmenu:o=!1}){const r=$t("useActivator"),i=t.ref(),s=t.inject(Pi,null)
let u=!1,c=!1,d=!0
const v=t.ref(!1)
let p=!1
const m=()=>!o||(s?.rootOpenedByHover?.()??v.value),f=t.computed(()=>e.openOnFocus||null==e.openOnFocus&&e.openOnHover),g=t.computed(()=>e.openOnClick||null==e.openOnClick&&!e.openOnHover&&!f.value),{runOpenDelay:h,runCloseDelay:y}=Yi(e,t=>{t!==(e.openOnHover&&u||f.value&&c)||e.openOnHover&&a.value&&!l.value||(a.value!==t&&(d=!0,t&&(p=!0,v.value=u&&e.openOnHover)),a.value=t)})
let b=!1
t.watch(a,e=>{if(!e)return b=!0,setTimeout(()=>b=!1,50),v.value=!1,void(p=!1)
p||(v.value=!1),p=!1})
const w=t.ref(),V=e=>{b&&!a.value||(e.stopPropagation(),i.value=e.currentTarget||e.target,a.value||(w.value=[e.clientX,e.clientY]),a.value=!a.value)},S=t=>{u=!0,i.value=t.currentTarget||t.target,"cursor"===e.target&&(w.value=[t.clientX,t.clientY]),h()},x=e=>{w.value=[e.clientX,e.clientY]},N=t=>{u=!1,"cursor"===e.target&&(c=!1),m()&&y()},C=e=>{b||!1!==xe(e.target,":focus-visible")&&(c=!0,e.stopPropagation(),i.value=e.currentTarget||e.target,h())},I=e=>{const t=e.relatedTarget
t&&!n.value?.contains(t)&&(c=!1,e.stopPropagation(),y({minDelay:1}))},A=t.computed(()=>{const t={}
return g.value&&(t.onClick=V),e.openOnHover&&(t.onMouseenter=S,t.onMouseleave=N,"cursor"!==e.target||g.value||(t.onMousemove=x)),f.value&&(t.onFocus=C,t.onBlur=I),t}),P=t.computed(()=>{const l={}
if(e.openOnHover&&(l.onMouseenter=()=>{u=!0,h()},l.onMouseleave=()=>{u=!1,m()&&y()}),f.value&&(l.onFocusin=e=>{e.target.matches(":focus-visible")&&(c=!0,h())},l.onFocusout=e=>{const t=e.relatedTarget
t&&!n.value?.contains(t)&&(c=!1,y({minDelay:1}))}),e.closeOnContentClick){const e=t.inject(Pi,null)
l.onClick=()=>{a.value=!1,e?.closeParents()}}return l}),_=t.computed(()=>{const t={}
return e.openOnHover&&(t.onMouseenter=()=>{d&&(u=!0,d=!1,h())},t.onMouseleave=()=>{u=!1,m()&&y()}),t})
t.watch(l,t=>{!t||!m()||(!e.openOnHover||u||f.value&&c)&&(!f.value||c||e.openOnHover&&u)||n.value?.contains(be())||y()}),t.watch(a,e=>{e||setTimeout(()=>{w.value=void 0})},{flush:"post"})
const R=Ee()
t.watchEffect(()=>{R.value&&t.nextTick(()=>{i.value=R.el})})
const D=Ee(),B=t.computed(()=>"cursor"===e.target&&w.value?w.value:D.value?D.el:qi(e.target,r)||i.value),T=t.computed(()=>Array.isArray(B.value)?void 0:B.value)
let F
return t.watch(()=>!!e.activator,a=>{a&&E?(F=t.effectScope(),F.run(()=>{!function(e,a,{activatorEl:l,activatorEvents:n}){function o(a=i(),l=e.activatorProps){a&&function(e,t){Object.keys(t).forEach(a=>{if(q(a)){const l=me(a),n=qe.get(e)
if(k(t[a]))n?.forEach(t=>{const[a,o]=t
a===l&&(e.removeEventListener(l,o),n.delete(t))})
else if(!n||![...n]?.some(e=>e[0]===l&&e[1]===t[a])){e.addEventListener(l,t[a])
const o=n||new Set
o.add([l,t[a]]),qe.has(e)||qe.set(e,o)}}else k(t[a])?e.removeAttribute(a):e.setAttribute(a,t[a])})}(a,t.mergeProps(n.value,l))}function r(a=i(),l=e.activatorProps){a&&function(e,t){Object.keys(t).forEach(t=>{if(q(t)){const a=me(t),l=qe.get(e)
l?.forEach(t=>{const[n,o]=t
n===a&&(e.removeEventListener(a,o),l.delete(t))})}else e.removeAttribute(t)})}(a,t.mergeProps(n.value,l))}function i(t=e.activator){const n=qi(t,a)
return l.value=n?.nodeType===Node.ELEMENT_NODE?n:void 0,l.value}t.watch(()=>e.activator,(e,a)=>{if(a&&e!==a){const e=i(a)
e&&r(e)}e&&t.nextTick(()=>o())},{immediate:!0}),t.watch(()=>e.activatorProps,()=>{o()}),t.onScopeDispose(()=>{r()})}(e,r,{activatorEl:i,activatorEvents:A})})):F&&F.stop()},{flush:"post",immediate:!0}),t.onScopeDispose(()=>{F?.stop()}),{activatorEl:i,activatorRef:R,target:B,targetEl:T,targetRef:D,activatorEvents:A,contentEvents:P,scrimEvents:_,openedByHover:v}}function qi(e,t){if(!e)return
let a
if("parent"===e){let e=t?.proxy?.$el?.parentNode
for(;e?.hasAttribute("data-no-activator");)e=e.parentNode
a=e}else a=g(e)?document.querySelector(e):"$el"in e?e.$el:e
return a}const Xi=Tt({retainFocus:Boolean,captureFocus:Boolean,disableInitialFocus:Boolean},"focusTrap"),Zi=new Map
let Qi=0
function Ji(e){const t=be()
if("Tab"!==e.key||!t)return
const a=Array.from(Zi.values()).filter(({isActive:e,contentEl:a})=>e.value&&a.value?.contains(t)).map(e=>e.contentEl.value)
let l,n=t
for(;n;){if(a.includes(n)){l=n
break}n=n.parentElement}if(!l){const t=function(){let e
for(const{isActive:t,contentEl:a}of Zi.values())t.value&&a.value&&(e=a.value)
return e}()
if(!t)return
const a=ye(t).filter(e=>e.tabIndex>=0)
return e.preventDefault(),void(a.length?e.shiftKey?a[a.length-1].focus():a[0].focus():t.focus({preventScroll:!0}))}const o=ye(l).filter(e=>e.tabIndex>=0)
if(!o.length)return
if(1===o.length&&o[0].classList.contains("v-list")&&o[0].contains(t))return void e.preventDefault()
const r=o[0],i=o[o.length-1],s=t===r||t===l||r.classList.contains("v-list")&&r.contains(t),u=t===i||i.classList.contains("v-list")&&i.contains(t)
e.shiftKey&&s&&(e.preventDefault(),i.focus()),!e.shiftKey&&u&&(e.preventDefault(),r.focus())}function es(e,{isActive:a,localTop:l,contentEl:n}){const o=Symbol("trap")
let r=!1,i=-1
async function s(){r=!0,i=window.setTimeout(()=>{r=!1},100)}async function u(e){const o=e.relatedTarget,i=e.target
if(document.removeEventListener("pointerdown",s),document.removeEventListener("keydown",c),await new Promise(e=>requestAnimationFrame(e)),a.value&&!r&&o!==i&&n.value&&t.toValue(l)&&![document,n.value].includes(i)&&!n.value.contains(i)){const e=ye(n.value)
e[0]?.focus()}}function c(e){if("Tab"===e.key&&(document.removeEventListener("keydown",c),a.value&&n.value&&e.target&&!n.value.contains(e.target))){const t=ye(document.documentElement)
if(e.shiftKey&&e.target===t.at(0)||!e.shiftKey&&e.target===t.at(-1)){const t=ye(n.value)
t.length>0&&(e.preventDefault(),t[0].focus())}}}const d=t.toRef(()=>a.value&&e.captureFocus&&!e.disableInitialFocus)
E&&(t.watch(()=>e.retainFocus,e=>{e?Zi.set(o,{isActive:a,contentEl:n}):Zi.delete(o)},{immediate:!0}),t.watch(d,e=>{e?(document.addEventListener("pointerdown",s),document.addEventListener("focusin",u,{once:!0}),document.addEventListener("keydown",c)):(document.removeEventListener("pointerdown",s),document.removeEventListener("focusin",u),document.removeEventListener("keydown",c))},{immediate:!0}),Qi++<1&&document.addEventListener("keydown",Ji)),t.onScopeDispose(()=>{Zi.delete(o),E&&(clearTimeout(i),document.removeEventListener("pointerdown",s),document.removeEventListener("focusin",u),document.removeEventListener("keydown",c),--Qi<1&&document.removeEventListener("keydown",Ji))})}function ts(){if(!E)return t.shallowRef(!1)
const{ssr:e}=yr()
if(e){const e=t.shallowRef(!1)
return t.onMounted(()=>{e.value=!0}),e}return t.shallowRef(!0)}const as=Tt({eager:Boolean},"lazy")
function ls(e,a){const l=t.shallowRef(!1),n=t.toRef(()=>l.value||e.eager||a.value)
return t.watch(a,()=>l.value=!0),{isBooted:l,hasContent:n,onAfterLeave:function(){e.eager||(l.value=!1)}}}function ns(){const e=$t("useScopeId").vnode.scopeId
return{scopeId:e?{[e]:""}:void 0}}const os=Symbol.for("vuetify:stack"),rs=t.reactive([])
function is(){return!0}function ss(e,t,a,l=!1){if(!e||!l&&!1===us(e,a))return!1
const n=Zt(t)
if("undefined"!=typeof ShadowRoot&&n instanceof ShadowRoot&&n.host===e.target)return!1
const o=a.value,r=((f(o)?void 0:o.include)||(()=>[]))()
return r.push(t),!r.some(t=>t?.contains(e.target))}function us(e,t){const a=t.value
return((f(a)?void 0:a.closeConditional)||is)(e)}function cs(e,t){const a=Zt(e)
t(document),"undefined"!=typeof ShadowRoot&&a instanceof ShadowRoot&&t(a)}const ds={mounted(e,t){const a=a=>function(e,t,a){const l=f(a.value)?a.value:a.value.handler
e.shadowTarget=e.target,t._clickOutside.lastMousedownWasOutside&&ss(e,t,a)&&setTimeout(()=>{us(e,a)&&l&&l(e)},0)}(a,e,t),l=a=>{e._clickOutside.lastMousedownWasOutside=ss(a,e,t,!0)}
cs(e,e=>{e.addEventListener("click",a,!0),e.addEventListener("mousedown",l,!0)}),e._clickOutside||(e._clickOutside={lastMousedownWasOutside:!1}),e._clickOutside[t.instance.$.uid]={onClick:a,onMousedown:l}},beforeUnmount(e,t){e._clickOutside&&(cs(e,a=>{if(!a||!e._clickOutside?.[t.instance.$.uid])return
const{onClick:l,onMousedown:n}=e._clickOutside[t.instance.$.uid]
a.removeEventListener("click",l,!0),a.removeEventListener("mousedown",n,!0)}),delete e._clickOutside[t.instance.$.uid])}},vs=new WeakMap
function ps(e){const{modelValue:a,color:l,...n}=e
return t.createVNode(t.Transition,{name:"fade-transition",appear:!0},{default:()=>[e.modelValue&&t.createElementVNode("div",t.mergeProps({class:["v-overlay__scrim",e.color.backgroundColorClasses.value],style:e.color.backgroundColorStyles.value},n),null)]})}const ms=Tt({absolute:Boolean,attach:[Boolean,String,Object],closeOnBack:{type:Boolean,default:!0},contained:Boolean,contentClass:null,contentProps:null,disabled:Boolean,opacity:[Number,String],noClickAnimation:Boolean,modelValue:Boolean,persistent:Boolean,scrim:{type:[Boolean,String],default:!0},zIndex:{type:[Number,String],default:2e3},...Gi(),...Ft(),...Tl(),...as(),...Bi(),...ji(),...Xi(),...Ga(),...ql()},"VOverlay"),fs=Kt()({name:"VOverlay",directives:{vClickOutside:ds},inheritAttrs:!1,props:{_disableGlobalStack:Boolean,_submenu:Boolean,...G(ms(),["disableInitialFocus"])},emits:{"click:outside":e=>!0,"update:modelValue":e=>!0,keydown:e=>!0,afterEnter:()=>!0,afterLeave:()=>!0},setup(e,{slots:a,attrs:l,emit:n}){const o=$t("VOverlay"),r=t.ref(),i=t.ref(),s=t.ref(),u=_a(e,"modelValue"),c=t.computed({get:()=>u.value,set:t=>{t&&e.disabled||(u.value=t)}}),{themeClasses:d}=tl(e),{rtlClasses:v,isRtl:p}=Ua(),{hasContent:m,onAfterLeave:h}=ls(e,c),y=Ol(()=>g(e.scrim)?e.scrim:null),{globalTop:b,localTop:w,stackStyles:V}=function(e,a,l){const n=$t("useStack"),o=!l,r=t.inject(os,void 0),i=t.reactive({activeChildren:new Set})
t.provide(os,i)
const s=t.shallowRef(Number(t.toValue(a)))
Pa(e,()=>{const e=rs.at(-1)?.[1]
s.value=e?e+10:Number(t.toValue(a)),o&&rs.push([n.uid,s.value]),r?.activeChildren.add(n.uid),t.onScopeDispose(()=>{if(o){const e=t.toRaw(rs).findIndex(e=>e[0]===n.uid)
rs.splice(e,1)}r?.activeChildren.delete(n.uid)})})
const u=t.shallowRef(!0)
o&&t.watchEffect(()=>{const e=rs.at(-1)?.[0]===n.uid
setTimeout(()=>u.value=e)})
const c=t.toRef(()=>!i.activeChildren.size)
return{globalTop:t.readonly(u),localTop:c,stackStyles:t.toRef(()=>({zIndex:s.value}))}}(c,()=>e.zIndex,e._disableGlobalStack),{activatorEl:S,activatorRef:k,target:x,targetEl:N,targetRef:C,activatorEvents:I,contentEvents:A,scrimEvents:P,openedByHover:_}=Ki(e,{isActive:c,isTop:w,contentEl:s,isSubmenu:e._submenu}),{teleportTarget:R}=function(e){return{teleportTarget:t.computed(()=>{const a=e()
if(!0===a||!E)return
const l=!1===a?document.body:g(a)?document.querySelector(a):a
if(!l)return void t.warn(`Unable to locate target ${a}`)
let n=[...l.children].find(e=>e.matches(".v-overlay-container"))
return n||(n=document.createElement("div"),n.className="v-overlay-container",l.appendChild(n)),n})}}(()=>{const t=e.attach||e.contained
if(t)return t
const a=S?.value?.getRootNode()||o.proxy?.$el?.getRootNode()
return a instanceof ShadowRoot&&a}),{dimensionStyles:D}=Fl(e),B=ts(),T=t.computed(()=>"static"===e.locationStrategy?function(e){if(!e)return
const t=e.includes(" ")?e:`${e} center`
let a="center",l="center"
const n={left:"start",start:"start",right:"end",end:"end"},o={top:"start",bottom:"end"}
for(const e of t.split(" "))e in n?a=n[e]:e in o&&(l=o[e])
return{[`v-overlay--justify-${a}`]:!0,[`v-overlay--align-${l}`]:!0}}(e.location):void 0),{scopeId:F}=ns()
t.watch(()=>e.disabled,e=>{e&&(c.value=!1)})
const{contentStyles:$,updateLocation:M}=function(e,a){const l=t.ref({}),n=t.ref()
function o(e){n.value?.(e)}function r(e){n.value?.(e)}function i(e){n.value?.(e)}return E&&Pa(()=>!(!a.isActive.value||!e.locationStrategy),s=>{t.watch(()=>e.locationStrategy,s),t.onScopeDispose(()=>{window.removeEventListener("resize",o),visualViewport?.removeEventListener("resize",r),visualViewport?.removeEventListener("scroll",i),n.value=void 0,a.isActive.value&&(l.value={})}),window.addEventListener("resize",o,{passive:!0}),visualViewport?.addEventListener("resize",r,{passive:!0}),visualViewport?.addEventListener("scroll",i,{passive:!0}),f(e.locationStrategy)?n.value=e.locationStrategy(a,e,l)?.updateLocation:n.value=Di[e.locationStrategy](a,e,l)?.updateLocation}),{contentStyles:l,updateLocation:n}}(e,{isRtl:p,contentEl:s,target:x,isActive:c})
!function(e,a){if(!E)return
let l
t.watchEffect(async()=>{l?.stop(),a.isActive.value&&e.scrollStrategy&&(l=t.effectScope(),await new Promise(e=>setTimeout(e)),l.active&&l.run(()=>{f(e.scrollStrategy)?e.scrollStrategy(a,e,l):Oi[e.scrollStrategy]?.(a,e,l)}))}),t.onScopeDispose(()=>{l?.stop()})}(e,{root:r,contentEl:s,targetEl:N,target:x,isActive:c,updateLocation:M})
const L=t.inject(Pi,null)
function O(t){n("click:outside",t),e.persistent?q():c.value=!1,e.scrim||L?.closeParents(t)}function j(t){return c.value&&w.value&&(!e.scrim||t.target===i.value||t instanceof MouseEvent&&t.shadowTarget===i.value)}"VMenu"!==o.parent?.type?.name&&t.provide(Pi,null),es(e,{isActive:c,localTop:w,contentEl:s})
let H=!1
function W(e){let t=e
const a=new Set
for(;t;){const e=t.closest(".v-overlay__content")
if(!e||a.has(e))return!1
if(e===s.value)return!0
a.add(e),t=vs.get(e)??null}return!1}function U(t){"Escape"===t.key&&b.value&&(s.value?.contains(be())||n("keydown",t),e.persistent?q():(c.value=!1,s.value?.contains(be())&&S.value?.focus()))}function Y(e){("Escape"!==e.key||b.value)&&n("keydown",e)}t.watchEffect(()=>{s.value&&(S.value?vs.set(s.value,S.value):vs.delete(s.value))}),t.watch(c,e=>{if(e){const e=be(),t=S.value
H=!!t&&(e===t||t.contains(e)),s.value&&(s.value.inert=!1),s.value?._clickOutside&&(s.value._clickOutside.lastMousedownWasOutside=!1)}else s.value&&(s.value.inert=!0),function(){const e=S.value
if(!e||!e.isConnected)return
if(e.closest(".v-overlay__content"))return
if(s.value?._clickOutside?.lastMousedownWasOutside)return
const t=be()
if((t&&t!==document.body||!H)&&t!==e&&!e.contains(t)&&!W(t))return
const a=e.parentElement
let l
if((a?ye(a):[]).includes(e))l=e
else{const t=ye(e)
l=t.find(e=>"INPUT"===e.tagName||"TEXTAREA"===e.tagName)??t[0]}l?.focus({preventScroll:!0})}()},{flush:"post"}),E&&t.watch(c,e=>{e?window.addEventListener("keydown",U):window.removeEventListener("keydown",U)},{immediate:!0}),t.onBeforeUnmount(()=>{E&&window.removeEventListener("keydown",U)})
const G=Jn()
Pa(()=>e.closeOnBack,()=>{!function(e,a){let l,n,o=!1
function r(e){e.state?.replaced||(o=!0,setTimeout(()=>o=!1))}E&&e?.beforeEach&&(t.nextTick(()=>{window.addEventListener("popstate",r),l=e.beforeEach(()=>ao?o?a():void 0:(ao=!0,new Promise(e=>{setTimeout(()=>e(o?a():void 0))}))),n=e?.afterEach(()=>{ao=!1})}),t.onScopeDispose(()=>{window.removeEventListener("popstate",r),l?.(),n?.()}))}(G,()=>{if(b.value&&c.value)return e.persistent?q():c.value=!1,!1})})
const K=t.ref()
function q(){e.noClickAnimation||s.value&&Ke(s.value,[{transformOrigin:"center"},{transform:"scale(1.03)"},{transformOrigin:"center"}],{duration:150,easing:Qt})}function X(){n("afterEnter")}function Z(){h(),n("afterLeave")}return t.watch(()=>c.value&&(e.absolute||e.contained)&&null==R.value,e=>{if(e){const e=na(r.value)
e&&e!==document.scrollingElement&&(K.value=e.scrollTop)}}),sa(()=>t.createElementVNode(t.Fragment,null,[a.activator?.({isActive:c.value,targetRef:C,props:t.mergeProps({ref:k},I.value,e.activatorProps)}),B.value&&m.value&&t.createVNode(t.Teleport,{disabled:!R.value,to:R.value},{default:()=>[t.createElementVNode("div",t.mergeProps({class:["v-overlay",{"v-overlay--absolute":e.absolute||e.contained,"v-overlay--active":c.value,"v-overlay--contained":e.contained},T.value,d.value,v.value,e.class],style:[V.value,{"--v-overlay-opacity":e.opacity,top:z(K.value)},e.style],ref:r,onKeydown:Y},F,l),[t.createVNode(ps,t.mergeProps({color:y,modelValue:c.value&&!!e.scrim,ref:i},P.value),null),t.createVNode(Xl,{appear:!0,persisted:!0,transition:e.transition,target:x.value,onAfterEnter:X,onAfterLeave:Z},{default:()=>[t.withDirectives(t.createElementVNode("div",t.mergeProps({ref:s,class:["v-overlay__content",e.contentClass],style:[D.value,$.value]},A.value,e.contentProps),[a.default?.({isActive:c})]),[[t.vShow,c.value],[ds,{handler:O,closeConditional:j,include:()=>c.value?[S.value,...Array.from(document.querySelectorAll(".v-overlay__content")).filter(W)]:[]}]])]})])]})])),{activatorEl:S,scrimEl:i,target:x,animateClick:q,contentEl:s,rootEl:r,globalTop:b,localTop:w,updateLocation:M,openedByHover:_}}}),gs=Tt({_disableKeys:Boolean,id:String,submenu:Boolean,openOnArrow:{type:Boolean,default:!0},...G(ms({captureFocus:!0,closeDelay:250,closeOnContentClick:!0,locationStrategy:"connected",location:void 0,openDelay:300,scrim:!1,scrollStrategy:"reposition",transition:{component:ml}}),["absolute"])},"VMenu"),hs=Kt()({name:"VMenu",props:gs(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),{scopeId:n}=ns(),{isRtl:o}=Ua(),r=t.useId(),i=t.toRef(()=>e.id||`v-menu-${r}`),s=t.ref(),u=t.inject(Pi,null),c=t.shallowRef(new Map)
function d(t){if(!e.disabled)if("Tab"===t.key){if(e.submenu&&!e.retainFocus)return t.preventDefault(),l.value=!1,void s.value?.activatorEl?.focus()
we(ye(s.value?.contentEl,!1),t.shiftKey?"prev":"next",e=>e.tabIndex>=0)||e.retainFocus||(l.value=!1)}else e.submenu&&t.key===(o.value?"ArrowRight":"ArrowLeft")&&(l.value=!1,s.value?.activatorEl?.focus())}function v(t){if(e.disabled||e._disableKeys||t.isComposing)return
const a=s.value?.contentEl
if(a&&l.value)if("ArrowDown"===t.key||"ArrowUp"===t.key){if(!e.openOnArrow)return
t.preventDefault(),t.stopImmediatePropagation(),Ve(a,"ArrowDown"===t.key?"next":"prev")}else e.submenu&&(t.key===(o.value?"ArrowRight":"ArrowLeft")?(l.value=!1,s.value?.activatorEl?.focus()):t.key===(o.value?"ArrowLeft":"ArrowRight")&&(t.preventDefault(),Ve(a,"first")))
else(e.submenu?t.key===(o.value?"ArrowLeft":"ArrowRight"):e.openOnArrow&&["ArrowDown","ArrowUp"].includes(t.key))&&(l.value=!0,t.preventDefault(),p(t))}function p(e,t=1){if(!l.value)return
const a=s.value?.contentEl
a?.contains(be())||a&&ye(a).length&&(["ArrowUp","ArrowDown"].includes(e.key)?function(e){const t=s.value?.contentEl
if(!t||!l.value)return
if(!["ArrowUp","ArrowDown"].includes(e.key))return
const a=ye(t),n="ArrowUp"===e.key?a.at(-1):a[0],o=n?.getAttribute("role")??"",r=["option","listbox"].includes(o)&&a.find(e=>"option"===e.getAttribute("role")&&"true"===e.getAttribute("aria-selected")&&null!=e.offsetParent)
r?r.focus():Ve(t,"ArrowDown"===e.key?"next":"prev")}(e):v(e),a.contains(be()))||t<=10&&requestAnimationFrame(()=>p(e,t+1))}t.provide(Pi,{register(e,t){for(const[t,a]of[...c.value])t!==e&&a()
c.value.set(e,t)},unregister(e){c.value.delete(e)},closeParents(t){const a=!t||s.value?.contentEl?._clickOutside?.lastMousedownWasOutside
setTimeout(()=>{c.value.size||e.persistent||!a||(l.value=!1,u?.closeParents(t))},40)},rootOpenedByHover:e.submenu&&u?u.rootOpenedByHover:()=>s.value?.openedByHover??!1}),t.onBeforeUnmount(()=>u?.unregister(r)),t.onDeactivated(()=>l.value=!1),t.watch(l,e=>{if(e)u?.register(r,()=>{l.value=!1})
else{u?.unregister(r)
for(const[,e]of[...c.value])e()}},{immediate:!0})
const m=t.computed(()=>t.mergeProps({"aria-haspopup":"menu","aria-expanded":String(l.value),"aria-controls":i.value,"aria-owns":i.value,onKeydown:v},e.activatorProps))
return sa(()=>{const o=fs.filterProps(e)
return t.createVNode(fs,t.mergeProps({ref:s,id:i.value,class:["v-menu",e.class],style:e.style},o,{modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,absolute:!0,_submenu:e.submenu,activatorProps:m.value,location:e.location??(e.submenu?"end":"bottom"),onKeydown:d},n),{activator:a.activator,default:(...e)=>t.createVNode(Bl,{root:"VMenu"},{default:()=>[a.default?.(...e)]})})}),ir({id:i,ΨopenChildren:c},s)}}),ys=Tt({color:String,...an(),...Ft(),...Tl(),...nn(),...sn(),...Zn(),...Gl(),...ol(),...Ga()},"VSheet"),bs=Kt()({name:"VSheet",props:ys(),setup(e,{slots:a}){const{themeClasses:l}=tl(e),{backgroundColorClasses:n,backgroundColorStyles:o}=Ol(()=>e.color),{borderClasses:r}=ln(e),{dimensionStyles:i}=Fl(e),{elevationClasses:s}=on(e),{locationStyles:u}=un(e),{positionClasses:c}=Qn(e),{roundedClasses:d,roundedStyles:v}=Kl(e)
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-sheet",l.value,n.value,r.value,s.value,c.value,d.value,e.class]),style:t.normalizeStyle([o.value,i.value,u.value,v.value,e.style])},a)),{}}}),ws=Tt({active:Boolean,disabled:Boolean,max:[Number,String],value:{type:[Number,String],default:0},...Ft(),...ql({transition:{component:Il}})},"VCounter"),Vs=Kt()({name:"VCounter",functional:!0,props:ws(),setup(e,{slots:a}){const l=t.shallowRef(e.max)
t.watch(()=>e.max,e=>null!=e&&(l.value=e))
const n=t.toRef(()=>e.active?e.max:l.value),o=t.toRef(()=>n.value?`${e.value} / ${n.value}`:String(e.value))
return sa(()=>t.createVNode(Xl,{transition:e.transition,appear:!0},{default:()=>[t.withDirectives(t.createElementVNode("div",{class:t.normalizeClass(["v-counter",{"text-error":n.value&&!e.disabled&&parseFloat(e.value)>parseFloat(n.value)},e.class]),style:t.normalizeStyle(e.style)},[a.default?a.default({counter:o.value,max:n.value,value:e.value}):o.value]),[[t.vShow,e.active]])]})),{}}}),Ss=Tt({floating:Boolean,...Ft()},"VFieldLabel"),ks=Kt()({name:"VFieldLabel",props:Ss(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(Fo,{class:t.normalizeClass(["v-field-label",{"v-field-label--floating":e.floating},e.class]),style:t.normalizeStyle(e.style)},a)),{})}),xs=["underlined","outlined","filled","solo","solo-inverted","solo-filled","plain"],Ns=Tt({appendInnerIcon:ua,bgColor:String,clearable:Boolean,clearIcon:{type:ua,default:"$clear"},active:Boolean,centerAffix:{type:Boolean,default:void 0},color:String,baseColor:String,dirty:Boolean,disabled:{type:Boolean,default:null},glow:Boolean,error:Boolean,flat:Boolean,iconColor:[Boolean,String],label:String,persistentClear:Boolean,prependInnerIcon:ua,reverse:Boolean,singleLine:Boolean,variant:{type:String,default:"filled",validator:e=>xs.includes(e)},"onClick:clear":fe(),"onClick:appendInner":fe(),"onClick:prependInner":fe(),...Ft(),...Gn(),...Gl(),...Ga()},"VField"),Cs=Kt()({name:"VField",inheritAttrs:!1,props:{id:String,details:Boolean,labelId:String,...Ko(),...Ns()},emits:{"update:focused":e=>!0,"update:modelValue":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{themeClasses:o}=tl(e),{loaderClasses:r}=Kn(e),{focusClasses:i,isFocused:s,focus:u,blur:c}=qo(e),{InputIcon:d}=Uo(e),{roundedClasses:v,roundedStyles:p}=Kl(e),{rtlClasses:m}=Ua(),f=t.toRef(()=>e.dirty||e.active),h=t.toRef(()=>!(!e.label&&!n.label)),y=t.toRef(()=>!e.singleLine&&h.value),b=t.useId(),w=t.computed(()=>e.id||`input-${b}`),V=t.toRef(()=>e.details?`${w.value}-messages`:void 0),S=t.ref(),k=t.ref(),x=t.ref(),N=t.computed(()=>["plain","underlined"].includes(e.variant)),C=t.computed(()=>e.error||e.disabled?void 0:f.value&&s.value?e.color:e.baseColor),E=t.computed(()=>!0===e.iconColor||!e.iconColor&&e.glow&&s.value?C.value:!e.iconColor||e.glow&&!s.value?void 0:e.iconColor),{backgroundColorClasses:I,backgroundColorStyles:A}=Ol(()=>e.bgColor),{textColorClasses:P,textColorStyles:_}=Ll(C)
t.watch(f,e=>{if(y.value&&!R()){const t=S.value.$el,a=k.value.$el
requestAnimationFrame(()=>{const l=Ge(t),n=new He(a),o=n.x-l.x,r=n.y-l.y-(l.height/2-n.height/2),i=n.width/.75,s=Math.abs(i-l.width)>1?{maxWidth:z(i)}:void 0,u=getComputedStyle(t),c=getComputedStyle(a),d=1e3*parseFloat(u.transitionDuration)||150,v=parseFloat(c.getPropertyValue("--v-field-label-scale")),p=c.getPropertyValue("color")
t.style.visibility="visible",a.style.visibility="hidden",Ke(t,{transform:`translate(${o}px, ${r}px) scale(${v})`,color:p,...s},{duration:d,easing:Qt,direction:e?"normal":"reverse"}).finished.then(()=>{t.style.removeProperty("visibility"),a.style.removeProperty("visibility")})})}},{flush:"post"})
const D=t.computed(()=>({isActive:f,isFocused:s,controlRef:x,iconColor:E,blur:c,focus:u})),B=t.toRef(()=>{const e=!f.value
return{"aria-hidden":e,for:e?void 0:w.value}}),T=t.toRef(()=>{const e=y.value&&f.value
return{"aria-hidden":e,for:e?void 0:w.value}})
function F(e){e.target!==be()&&e.preventDefault()}return sa(()=>{const l="outlined"===e.variant,s=!(!n["prepend-inner"]&&!e.prependInnerIcon),b=!(!e.clearable&&!n.clear||e.disabled),x=!!(n["append-inner"]||e.appendInnerIcon||b),C=()=>n.label?n.label({...D.value,label:e.label,props:{for:w.value}}):e.label
return t.createElementVNode("div",t.mergeProps({class:["v-field",{"v-field--active":f.value,"v-field--appended":x,"v-field--center-affix":e.centerAffix??!N.value,"v-field--disabled":e.disabled,"v-field--dirty":e.dirty,"v-field--error":e.error,"v-field--glow":e.glow,"v-field--flat":e.flat,"v-field--has-background":!!e.bgColor,"v-field--persistent-clear":e.persistentClear,"v-field--prepended":s,"v-field--reverse":e.reverse,"v-field--single-line":e.singleLine,"v-field--no-label":!C(),[`v-field--variant-${e.variant}`]:!0},o.value,I.value,i.value,r.value,v.value,m.value,e.class],style:[A.value,p.value,e.style],onClick:F},a),[t.createElementVNode("div",{class:"v-field__overlay"},null),t.createVNode(qn,{name:"v-field",active:!!e.loading,color:e.error?"error":g(e.loading)?e.loading:e.color},{default:n.loader}),s&&t.createElementVNode("div",{key:"prepend",class:"v-field__prepend-inner"},[n["prepend-inner"]?n["prepend-inner"](D.value):e.prependInnerIcon&&t.createVNode(d,{key:"prepend-icon",name:"prependInner",color:E.value},null)]),t.createElementVNode("div",{class:"v-field__field","data-no-activator":""},[["filled","solo","solo-inverted","solo-filled"].includes(e.variant)&&y.value&&t.createVNode(ks,t.mergeProps({key:"floating-label",ref:k,class:[P.value],floating:!0},B.value,{style:_.value}),{default:()=>[C()]}),h.value&&t.createVNode(ks,t.mergeProps({key:"label",ref:S,id:e.labelId},T.value),{default:()=>[C()]}),n.default?.({...D.value,props:{id:w.value,class:"v-field__input","aria-describedby":V.value},focus:u,blur:c})??t.createElementVNode("div",{id:w.value,class:"v-field__input","aria-describedby":V.value},null)]),b&&t.createVNode(_l,{key:"clear"},{default:()=>[t.withDirectives(t.createElementVNode("div",{class:"v-field__clearable",onMousedown:e=>{e.preventDefault(),e.stopPropagation()}},[t.createVNode(Bl,{defaults:{VIcon:{icon:e.clearIcon}}},{default:()=>[n.clear?n.clear({...D.value,props:{onFocus:u,onBlur:c,onClick:e["onClick:clear"],tabindex:-1}}):t.createVNode(d,{name:"clear",onFocus:u,onBlur:c,tabindex:-1},null)]})]),[[t.vShow,e.dirty]])]}),x&&t.createElementVNode("div",{key:"append",class:"v-field__append-inner"},[n["append-inner"]?n["append-inner"](D.value):e.appendInnerIcon&&t.createVNode(d,{key:"append-icon",name:"appendInner",color:E.value},null)]),t.createElementVNode("div",{class:t.normalizeClass(["v-field__outline",P.value]),style:t.normalizeStyle(_.value)},[l&&t.createElementVNode(t.Fragment,null,[t.createElementVNode("div",{class:"v-field__outline__start"},null),y.value&&t.createElementVNode("div",{class:"v-field__outline__notch"},[t.createVNode(ks,t.mergeProps({ref:k,floating:!0},B.value),{default:()=>[C()]})]),t.createElementVNode("div",{class:"v-field__outline__end"},null)]),N.value&&y.value&&t.createVNode(ks,t.mergeProps({ref:k,floating:!0},B.value),{default:()=>[C()]})])])}),{controlRef:x,fieldIconColor:E}}}),Es=Tt({autocomplete:String},"autocomplete")
function Is(e){const a=t.useId(),l=t.shallowRef(0),n=t.toRef(()=>"suppress"===e.autocomplete),o=t.toRef(()=>{if(e.name)return n.value?`${e.name}-${a}-${l.value}`:e.name}),r=t.toRef(()=>n.value?"off":e.autocomplete)
return{isSuppressing:n,fieldAutocomplete:r,fieldName:o,update:()=>l.value=(new Date).getTime()}}function As(e){return{onIntersect:function(t,a){if(!e.autofocus||!t)return
const l=a[0].target,n=l.matches("input,textarea")?l:l.querySelector("input,textarea")
setTimeout(()=>n?.focus(),50)}}}const Ps=["color","file","time","date","datetime-local","week","month"],_s=Tt({autofocus:Boolean,counter:{type:[Boolean,Number,String],default:void 0},counterValue:[Number,Function],prefix:String,placeholder:String,persistentPlaceholder:Boolean,persistentCounter:Boolean,suffix:String,role:String,type:{type:String,default:"text"},modelModifiers:Object,...Es(),...G(lr(),["direction"]),...Ns()},"VTextField"),Rs=Kt()({name:"VTextField",directives:{vIntersect:Jl},inheritAttrs:!1,props:_s(),emits:{"click:control":e=>!0,"mousedown:control":e=>!0,"update:focused":e=>!0,"update:modelValue":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const o=_a(e,"modelValue",void 0,e=>Object.is(e,-0)?"-0":e),{isFocused:r,focus:i,blur:s}=qo(e),{onIntersect:u}=As(e),c=t.computed(()=>f(e.counterValue)?e.counterValue(o.value):h(e.counterValue)?e.counterValue:(o.value??"").toString().length),d=t.computed(()=>a.maxlength?a.maxlength:e.counter&&(h(e.counter)||g(e.counter))?e.counter:void 0),v=t.computed(()=>["plain","underlined"].includes(e.variant)),p=t.ref(),m=t.ref(),y=t.ref()
t.watch(()=>e.type,()=>{y.value},{flush:"post"})
const b=Is(e),w=t.computed(()=>Ps.includes(e.type)||e.persistentPlaceholder||r.value||e.active)
function V(){b.isSuppressing.value&&b.update(),r.value||i(),t.nextTick(()=>{y.value!==be()&&y.value?.focus()})}function S(e){l("mousedown:control",e),e.target!==y.value&&(V(),e.preventDefault())}function k(e){l("click:control",e)}function x(a){const l=a.target
if(!e.modelModifiers?.trim||!["text","search","password","tel","url"].includes(e.type))return void(o.value=l.value)
const n=l.value,r=l.selectionStart,i=l.selectionEnd
o.value=n,t.nextTick(()=>{let e=0
n.trimStart().length===l.value.length&&(e=n.length-l.value.length),null!=r&&(l.selectionStart=r-e),null!=i&&(l.selectionEnd=i-e)})}return sa(()=>{const l=!(!n.counter&&void 0===e.counter),f=!1!==e.counter&&null!==e.counter&&(e.persistentCounter||r.value),g=!0!==e.hideDetails&&!(!n.details&&!l),h=!!(n.details||l&&f),[N,C]=J(a),{modelValue:E,...I}=nr.filterProps(e),A=Cs.filterProps(e)
return t.createVNode(nr,t.mergeProps({ref:p,modelValue:o.value,"onUpdate:modelValue":e=>o.value=e,class:["v-text-field",{"v-text-field--prefixed":e.prefix,"v-text-field--suffixed":e.suffix,"v-input--plain-underlined":v.value},e.class],style:e.style},N,I,{centerAffix:!v.value,focused:r.value,detailsActive:h,indentDetails:e.indentDetails??!v.value}),{...n,default:({id:a,isDisabled:l,isDirty:c,isReadonly:d,isValid:v,hasDetails:p,reset:f})=>t.createVNode(Cs,t.mergeProps({ref:m,onMousedown:S,onClick:k,"onClick:clear":a=>function(a,l){a.stopPropagation(),V(),t.nextTick(()=>{l(),he(e["onClick:clear"],a)})}(a,f),role:e.role},G(A,["onClick:clear"]),{id:a.value,labelId:`${a.value}-label`,active:w.value||c.value,dirty:c.value||e.dirty,disabled:l.value,focused:r.value,details:p.value,error:!1===v.value}),{...n,default:({props:{class:r,...c},controlRef:v})=>{const p=t.createElementVNode("input",t.mergeProps({ref:e=>y.value=v.value=e,value:o.value,onInput:x,autofocus:e.autofocus,readonly:d.value,disabled:l.value,name:b.fieldName.value,autocomplete:b.fieldAutocomplete.value,placeholder:e.placeholder,size:1,role:e.role,type:e.type,onFocus:i,onBlur:s,"aria-labelledby":`${a.value}-label`},c,C),null)
return t.createElementVNode(t.Fragment,null,[e.prefix&&t.createElementVNode("span",{class:"v-text-field__prefix"},[t.createElementVNode("span",{class:"v-text-field__prefix__text"},[e.prefix])]),t.withDirectives(n.default?t.createElementVNode("div",{class:t.normalizeClass(r),"data-no-activator":""},[n.default({id:a}),p]):t.cloneVNode(p,{class:r}),[[Jl,u,null,{once:!0}]]),e.suffix&&t.createElementVNode("span",{class:"v-text-field__suffix"},[t.createElementVNode("span",{class:"v-text-field__suffix__text"},[e.suffix])])])}}),details:g?a=>t.createElementVNode(t.Fragment,null,[n.details?.(a),l&&t.createElementVNode(t.Fragment,null,[t.createElementVNode("span",null,null),t.createVNode(Vs,{active:f,value:c.value,max:d.value,disabled:e.disabled},n.counter)])]):void 0})}),ir({},p,m,y)}}),Ds=Tt({renderless:Boolean,...Ft()},"VVirtualScrollItem"),Bs=Kt()({name:"VVirtualScrollItem",inheritAttrs:!1,props:Ds(),emits:{"update:height":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{resizeRef:o,contentRect:r}=Sa(void 0,"border")
t.watch(()=>r.value?.height,e=>{null!=e&&l("update:height",e)}),sa(()=>e.renderless?t.createElementVNode(t.Fragment,null,[n.default?.({itemRef:o})]):t.createElementVNode("div",t.mergeProps({ref:o,class:["v-virtual-scroll__item",e.class],style:e.style},a),[n.default?.()]))}}),Ts=100,Fs=Tt({itemHeight:{type:[Number,String],default:null},itemKey:{type:[String,Array,Function],default:null},height:[Number,String]},"virtual")
function $s(e,a){const l=yr(),n=t.shallowRef(0)
t.watchEffect(()=>{n.value=parseFloat(e.itemHeight||0)})
const o=t.shallowRef(0),r=t.shallowRef(Math.ceil((parseInt(e.height)||l.height.value)/(n.value||16))||1),i=t.shallowRef(0),s=t.shallowRef(0),u=t.ref(),c=t.ref()
let d=0
const{resizeRef:v,contentRect:p}=Sa()
t.watchEffect(()=>{v.value=u.value})
const m=t.computed(()=>u.value===document.documentElement?l.height.value:p.value?.height||parseInt(e.height)||0),f=t.computed(()=>!!(u.value&&c.value&&m.value&&n.value))
let g=Array.from({length:a.value.length}),h=Array.from({length:a.value.length}),y=new Map
const b=t.shallowRef(0)
let w=-1,V="start",S=0
function k(e){return g[e]||n.value}const x=te(()=>{const e=performance.now()
h[0]=0
const t=a.value.length
for(let e=1;e<=t;e++)h[e]=(h[e-1]||0)+k(e-1)
b.value=Math.max(b.value,performance.now()-e),T()},b),N=t.watch(f,e=>{e&&(N(),d=c.value.offsetTop,x.immediate(),T(),~w&&t.nextTick(()=>{E&&window.requestAnimationFrame(()=>{~w&&M(w,V)})}))})
function C(e){e=ae(e,0,a.value.length)
const t=Math.floor(e),l=e%1,n=t+1,o=h[t]||0
return o+((h[n]||o)-o)*l}function I(e){return function(e,t){let a=e.length-1,l=0,n=0,o=null,r=-1
if(e[a]<t)return a
for(;l<=a;)if(n=l+a>>1,o=e[n],o>t)a=n-1
else{if(!(o<t))return o===t?n:l
r=n,l=n+1}return r}(h,e)}t.onScopeDispose(()=>{x.clear()})
let A=0,P=0,_=0
t.watch(m,(e,t)=>{T(),e<t&&requestAnimationFrame(()=>{P=0,T()})})
let R=-1
function D(){u.value&&c.value&&(P=0,_=0,window.clearTimeout(R),T())}let B=-1
function T(){cancelAnimationFrame(B),B=requestAnimationFrame($)}function $(){if(!u.value||!m.value||!n.value)return
const e=A-d,t=Math.sign(P),l=ae(I(Math.max(0,e-Ts)),0,a.value.length),c=ae(I(e+m.value+Ts)+1,l+1,a.value.length)
if((-1!==t||l<o.value)&&(1!==t||c>r.value)){const e=C(o.value)-C(l),t=C(c)-C(r.value)
Math.max(e,t)>Ts?(o.value=l,r.value=c):(l<=0&&(o.value=l),c>=a.value.length&&(r.value=c,o.value=l))}i.value=C(o.value),s.value=C(a.value.length)-C(r.value)}function M(e,l="start"){w!==e&&(S=0)
const c=C(e)
if(!u.value||e&&!c)return w=e,void(V=l)
const v=n.value||16,p=Math.ceil(Ts/v),f=Math.max(1,Math.ceil((m.value||0)/v)),g="center"===l?Math.ceil(f/2):"end"===l?f:0
o.value=ae(e-g-p,0,Math.max(0,a.value.length-1)),r.value=ae(e-g+f+p,o.value+1,a.value.length),i.value=C(o.value),s.value=C(a.value.length)-C(r.value),P=0,_=0,w=e,V=l,t.nextTick(()=>{const t=u.value
if(!t||!~w||w!==e)return
const a=function(e,t){const a=C(e)
if("center"===t)return Math.max(0,a-m.value/2+k(e)/2)
if("end"===t){const t=u.value?.clientHeight||m.value
return Math.max(0,a+d-t+k(e))}return a}(e,l)
t.scrollTop=a,A=t.scrollTop,e&&t.scrollTop<a-1&&t.scrollHeight>S?(S=t.scrollHeight,E&&requestAnimationFrame(()=>{w===e&&M(e,l)})):(w=-1,V="start",T())})}const z=t.computed(()=>a.value.slice(o.value,r.value).map((t,a)=>{const l=a+o.value
return{raw:t,index:l,key:F(t,e.itemKey,l)}}))
return t.watch(a,()=>{g=Array.from({length:a.value.length}),h=Array.from({length:a.value.length}),y=new Map,x.immediate(),T()},{deep:1}),{calculateVisibleItems:T,containerRef:u,markerRef:c,computedItems:z,paddingTop:i,paddingBottom:s,scrollToIndex:M,handleScroll:function(){if(!u.value||!c.value)return
const e=u.value.scrollTop,t=performance.now()
t-_>500?(P=Math.sign(e-A),d=c.value.offsetTop):P=e-A,A=e,_=t,window.clearTimeout(R),R=window.setTimeout(D,500),T()},handleScrollend:D,handleItemResize:function(e,t){const a=g[e],l=n.value
if(t>0){if(a){const e=y.get(a)-1
e?y.set(a,e):y.delete(a)}y.set(t,(y.get(t)??0)+1),n.value=function(){let e=0
for(const t of y.values())e+=t
let t=0
for(const a of[...y.keys()].sort((e,t)=>e-t))if(t+=y.get(a),2*t>=e)return a
return n.value}()}a===t&&l===n.value||(g[e]=t,x())}}}const Ms=Tt({items:{type:Array,default:()=>[]},renderless:Boolean,...Fs(),...Ft(),...Tl()},"VVirtualScroll"),zs=Kt()({name:"VVirtualScroll",props:Ms(),setup(e,{slots:a}){const l=$t("VVirtualScroll"),{dimensionStyles:n}=Fl(e),{calculateVisibleItems:o,containerRef:r,markerRef:i,handleScroll:s,handleScrollend:u,handleItemResize:c,scrollToIndex:d,paddingTop:v,paddingBottom:p,computedItems:m}=$s(e,t.toRef(()=>e.items))
return Pa(()=>e.renderless,()=>{function e(e=!1){const t=e?"addEventListener":"removeEventListener"
E&&(r.value===document.documentElement?(document[t]("scroll",s,{passive:!0}),document[t]("scrollend",u)):(r.value?.[t]("scroll",s,{passive:!0}),r.value?.[t]("scrollend",u)))}t.onMounted(()=>{r.value=na(l.vnode.el,!0),e(!0)}),t.onScopeDispose(e)}),sa(()=>{const l=m.value.map(l=>t.createVNode(Bs,{key:l.key,renderless:e.renderless,"onUpdate:height":e=>c(l.index,e)},{default:e=>a.default?.({item:l.raw,index:l.index,...e})}))
return e.renderless?t.createElementVNode(t.Fragment,null,[t.createElementVNode("div",{ref:i,class:"v-virtual-scroll__spacer",style:{paddingTop:z(v.value)}},null),l,t.createElementVNode("div",{class:"v-virtual-scroll__spacer",style:{paddingBottom:z(p.value)}},null)]):t.createElementVNode("div",{ref:r,class:t.normalizeClass(["v-virtual-scroll",e.class]),onScrollPassive:s,onScrollend:u,style:t.normalizeStyle([n.value,e.style])},[t.createElementVNode("div",{ref:i,class:"v-virtual-scroll__container",style:{paddingTop:z(v.value),paddingBottom:z(p.value)}},[l])])}),{calculateVisibleItems:o,scrollToIndex:d}}})
function Ls(e){return k(e)?[]:w(e)?e:[e]}function Os(e){const t=e.filter(e=>e[0]<e[1]).toSorted((e,t)=>e[0]-t[0]),a=[]
for(const e of t){const t=a.at(-1)
t&&e[0]<=t[1]?t[1]=Math.max(t[1],e[1]):a.push([e[0],e[1]])}return a}function js(e,t){const a=[]
let l=0
for(const[n,o]of t)l<n&&a.push({text:e.slice(l,n),match:!1}),a.push({text:e.slice(n,o),match:!0}),l=o
return l<e.length&&a.push({text:e.slice(l),match:!1}),a}function Hs(e,a,l={}){const n=t.toValue(e),o=t.toValue(a),r=t.toValue(l.matches),i=t.toValue(l.matchAll)??!1,s=t.toValue(l.ignoreCase)??!1,u=t.toValue(l.ignoreAccents)??!1
if(r?.length)return js(n,Os(r))
if(o){const e=function(e,t,a){const l=[]
for(const n of Ls(t).filter(Boolean))l.push(...m(e,n,a))
return Os(l)}(n,o,{matchAll:i,ignoreCase:s,ignoreAccents:u})
return e.length>0?js(n,e):[{text:n,match:!1}]}return[{text:n,match:!1}]}const Ws=Gt({name:"VHighlight",props:Tt({text:{type:String,default:""},query:[String,Array],matches:Array,matchAll:Boolean,ignoreCase:Boolean,ignoreAccents:[Boolean,String],color:String,opacity:[String,Number],markClass:String,...ol({tag:"span"})},"VHighlight")(),setup(e){const a=t.computed(()=>Hs(()=>e.text,()=>e.query,{matches:()=>e.matches,matchAll:()=>e.matchAll,ignoreCase:()=>e.ignoreCase,ignoreAccents:()=>e.ignoreAccents??!1})),{textColorClasses:l,textColorStyles:n}=Ll(()=>e.color)
return()=>t.createVNode(e.tag,{class:"v-highlight"},{default:()=>[a.value.map((a,o)=>a.match?t.createElementVNode("mark",{key:o,class:t.normalizeClass(["v-highlight__mark",l.value,e.markClass]),style:t.normalizeStyle([n.value,{"--v-highlight-opacity":e.opacity}])},[a.text]):t.createElementVNode("span",{key:o},[a.text]))]})}})
function Us(e,t,a){return function(l){return!(l.relatedTarget||document.activeElement!==document.body||!e.value)&&(requestAnimationFrame(()=>{if(!e.value)return
const l=t(),n=(l&&ye(l)[0])??a()
n?.focus({preventScroll:!0})}),!0)}}function Ys(e){return!!e&&"divider"!==e.type&&"subheader"!==e.type&&!e.props?.disabled}function Gs(e,t,a){const l=e.length
for(let n=0;n<l;n++){const o=((t+n*a)%l+l)%l
if(Ys(e[o]))return o}return-1}function Ks(e,a,l,n,o={}){const r=t.shallowRef(!1)
let i,s=0,u=null
function c(){return e.value?.$el}function d(e){return c()?.querySelector(`[aria-posinset="${e+1}"]`)??null}async function v(e,t=!0,a="center"){if(e<0)return!1
if(!t){const t=d(e)
return t?.focus({preventScroll:!0}),!!t}const n=++s,o=c()
o?.contains(be())&&o.focus({preventScroll:!0}),l.value?.scrollToIndex(e,a)
let r=d(e)
const i=performance.now()+500
for(;!r&&performance.now()<i;){if(await new Promise(e=>requestAnimationFrame(e)),n!==s)return!0
r=d(e)}return r?.focus({preventScroll:!0}),r&&o&&function(e,t,a){const l=e.getBoundingClientRect().top+e.clientTop,n=e.clientHeight,{top:o,height:r}=t.getBoundingClientRect(),i="start"===a?o-l:"end"===a?o+r-(l+n):o+r/2-(l+n/2)
Math.abs(i)>1&&(e.scrollTop+=i)}(o,r,a),!!r}async function p(){const a=Gs(t.toValue(n),0,1)
await v(a)||e.value?.focus("first")}async function m(){const a=t.toValue(n),l=Gs(a,a.length-1,-1)
await v(l)||e.value?.focus("last")}async function f(e,a=!1){if(!t.toValue(o.noAutoScroll)){const l=o.selectedIndex?.()??-1
if(l>=0){const o=a?l:Gs(t.toValue(n),l+e,e)
return await v(o,!1)||v(o)}}if(1===e){const e=o.headerEl?.(),t=e&&ye(e)[0]
if(t)return t.focus()}if(Gs(t.toValue(n),0,1)<0){const t=o.menuContentEl?.(),a=t?ye(t):[],l=1===e?a[0]:a.at(-1)
return l?.focus()}return 1===e?p():m()}function g(e){u=e}return{listEvents:{onScrollPassive:function(e){cancelAnimationFrame(i),r.value=!0,i=requestAnimationFrame(()=>{i=requestAnimationFrame(()=>{r.value=!1})})},onKeydownCapture:function(e){if("ArrowUp"!==e.key&&"ArrowDown"!==e.key)return
const a=c(),l=be()
if(!a||!l||!a.contains(l))return
const o=l.closest("[aria-posinset]")
if(!o||!a.contains(o))return
const r=a.querySelectorAll("[aria-posinset]")
if(!(o===("ArrowUp"===e.key?r[0]:r[r.length-1])))return
const i=Number(o.getAttribute("aria-posinset"))
if(!i)return
const s="ArrowUp"===e.key?-1:1,u=Gs(t.toValue(n),i-1+s,s)
u<0||u===i-1||(e.preventDefault(),e.stopImmediatePropagation(),v(u,!0,1===s?"end":"start"))},onKeydown:async function(e){if("Tab"===e.key)return void a.value?.focus()
if("Home"===e.key||"End"===e.key)return e.preventDefault(),e.stopImmediatePropagation(),void await("Home"===e.key?p():m())
if("PageDown"!==e.key&&"PageUp"!==e.key)return
const l=c()
if(!l)return
await async function(){await new Promise(e=>requestAnimationFrame(e)),await new Promise(e=>requestAnimationFrame(e)),await new Promise(e=>requestAnimationFrame(e)),await new Promise(e=>{if(r.value){const a=t.watch(r,()=>{a(),e()})}else e()})}()
const n=l.querySelectorAll(":scope > :not(.v-virtual-scroll__spacer)")
if("PageDown"===e.key){const e=l.getBoundingClientRect().top
for(const t of n)if(t.getBoundingClientRect().top>=e){t.focus()
break}}else{const e=l.getBoundingClientRect().bottom
for(const t of[...n].reverse())if(t.getBoundingClientRect().bottom<=e){t.focus()
break}}}},focusItem:v,focusFirstItem:p,focusLastItem:m,focusFromActivator:f,onActivatorKeydown:function(e,t){const a="ArrowDown"===e.key?1:"ArrowUp"===e.key?-1:null
if(!a)return!1
const l=t.value
return t.value=!0,!c()?.contains(be())&&(l?(e.stopImmediatePropagation(),f(a),!0):(g(a),!1))},setPendingFocus:g,flushPendingFocus:function(){if(!u)return!1
const e=u
return u=null,f(e,!0),!0}}}function qs(e,...t){requestAnimationFrame(()=>{const a=be()
a&&a!==document.body&&(t.some(e=>e?.contains(a))||(e.value=!1))})}function Xs(e,a,l){let n=!1
t.watch(e,e=>{e||(n=!0,t.nextTick(()=>n=!1))}),t.watch(a,a=>{!a||n?n=!1:t.toValue(l)&&(e.value=!0)})}function Zs(e,a){const l=_a(e,"menu"),n=t.computed({get:()=>l.value,set:n=>{l.value&&!n&&a.vMenuRef.value?.ΨopenChildren.size||!n&&e.menuProps?.persistent||n&&t.toValue(a.menuDisabled)||(l.value=n)}})
return Xs(n,a.isFocused,()=>e.openOnFocus),{menu:n,closeOnSelect:function(){e.multiple||!1===e.menuProps?.closeOnContentClick||(n.value=!1)}}}function Qs({groups:e,onLeave:a}){function l(e){const t=function(e){return"list"===e.type?e.contentRef.value?.$el:e.contentRef.value}(e)
return t?ye(t):[]}return{onTabKeydown:function(n){const o=n.target,r=n.shiftKey?"backward":"forward",i=e.map(l),s=e.map(e=>"list"===e.type?e.contentRef.value?.$el:e.contentRef.value).findIndex(e=>e?.contains(o)),u=function(a,l,n,o){const r=e[l],i=a[l]
if("list"!==r.type){if(!("forward"===n?i.at(-1)===o:i.at(0)===o))return null}const s="forward"===n?1:-1
for(let n=l+s;n>=0&&n<e.length;n+=s){const l=e[n]
if(a[n].length>0||"list"===l.type&&t.toValue(l.displayItemsCount)>0)return n}return null}(i,s,r,o)
if(S(u)){const t=e[s],l=i[s]
if("list"===t.type||("forward"===r?l.at(-1)===n.target:l.at(0)===n.target)){a()
const e=be()
if(e){const t=new KeyboardEvent("keydown",{key:"Tab",shiftKey:n.shiftKey,bubbles:!0,cancelable:!0})
e.dispatchEvent(t),t.defaultPrevented&&n.preventDefault()}}}else{n.preventDefault(),n.stopImmediatePropagation()
const a=e[u]
if("list"===a.type&&t.toValue(a.displayItemsCount)>0)a.contentRef.value?.focus(0)
else{const e="forward"===r
i[u].at(e?0:-1).focus()}}}}}function Js(e,t){if(!k(e)&&!y(e)&&-1!==e)return h(e)?[[e,e+t.length]]:Array.isArray(e[0])?e:[e]}const eu=Tt({customFilter:Function,customKeyFilter:Object,filterKeys:[Array,String],filterMode:{type:String,default:"intersection"},ignoreAccents:[Boolean,String],noFilter:Boolean},"filter")
function tu(e,t,a){const l=[],n=a?.default??(o=a?.ignoreAccents,(e,t)=>{if(k(e)||k(t))return-1
if(!t.length)return 0
const a=m(e.toString(),t.toString(),{ignoreCase:!0,ignoreAccents:o,matchAll:!0})
return a.length?a:-1})
var o
const r=!!a?.filterKeys&&ee(a.filterKeys),i=Object.keys(a?.customKeyFilter??{}).length
if(!e?.length)return l
let s=[]
e:for(let o=0;o<e.length;o++){const[u,c=u]=ee(e[o]),d={},v={}
let p=-1
if((t||i>0)&&!a?.noFilter){let e=!1
if(b(u)){if("divider"===u.type||"subheader"===u.type){"divider"===s.at(-1)?.type&&"subheader"===u.type||(s=[]),s.push({index:o,matches:{},type:u.type})
continue}const l=r||Object.keys(c)
e=l.length===i
for(const e of l){const l=F(c,e),o=a?.customKeyFilter?.[e]
if(p=o?o(l,t,u):n(l,t,u),-1!==p&&!1!==p)o?d[e]=Js(p,t):v[e]=Js(p,t)
else if("every"===a?.filterMode)continue e}}else p=n(u,t,u),-1!==p&&!1!==p&&(v.title=Js(p,t))
const l=Object.keys(v).length,m=Object.keys(d).length
if(!l&&!m)continue
if("union"===a?.filterMode&&m!==i&&!l)continue
if("intersection"===a?.filterMode&&(m!==i||!l&&i>0&&!e))continue}s.length&&(l.push(...s),s=[]),l.push({index:o,matches:{...v,...d}})}return l}function au(e,a,l,n){const o=t.shallowRef([]),r=t.shallowRef(new Map),i=t.computed(()=>n?.transform?t.unref(a).map(e=>[e,n.transform(e)]):t.unref(a))
return t.watchEffect(()=>{const s=f(l)?l():t.unref(l),u=g(s)||h(s)?String(s):"",c=tu(i.value,u,{customKeyFilter:{...e.customKeyFilter,...t.unref(n?.customKeyFilter)},default:e.customFilter,filterKeys:e.filterKeys,filterMode:e.filterMode,ignoreAccents:e.ignoreAccents,noFilter:e.noFilter}),d=t.unref(a),v=[],p=new Map
c.forEach(({index:e,matches:t})=>{const a=d[e]
v.push(a),x(a.value)||p.set(a.value,t)}),o.value=v,r.value=p}),{filteredItems:o,filteredMatches:r,getMatches:function(e){return r.value.get(e.value)}}}const lu=Tt({closeText:{type:String,default:"$vuetify.close"},openText:{type:String,default:"$vuetify.open"}},"autocomplete")
function nu(e,a){const l=t.useId(),n=t.computed(()=>`menu-${l}`),o=t.toRef(()=>t.toValue(a)),r=t.toRef(()=>n.value)
return{menuId:n,ariaExpanded:o,ariaControls:r}}const ou=Tt({chips:Boolean,closableChips:Boolean,eager:Boolean,form:String,hideNoData:Boolean,hideSelected:Boolean,listProps:{type:Object},menu:Boolean,menuElevation:[Number,String],menuIcon:{type:ua,default:"$dropdown"},menuProps:{type:Object},multiple:Boolean,noDataText:{type:String,default:"$vuetify.noDataText"},openOnClear:Boolean,openOnFocus:Boolean,itemColor:String,noAutoScroll:Boolean,...lu(),...mi({itemChildren:!1})},"Select"),ru=Tt({search:String,...eu({filterKeys:["title"]}),...ou(),...G(_s({modelValue:null,role:"combobox"}),["validationValue","dirty"]),...ql({transition:{component:ml}})},"VSelect"),iu=Kt()({name:"VSelect",props:ru(),emits:{"update:focused":e=>!0,"update:modelValue":e=>!0,"update:menu":e=>!0,"update:search":e=>!0,"item:added":e=>!0,"item:removed":e=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),o=t.ref(),r=t.ref(),i=t.ref(),s=t.ref(),u=t.ref(),c=t.ref(),{items:d,transformIn:v,transformOut:p}=yi(e),m=_a(e,"search",""),{filteredItems:g,getMatches:y}=au(e,d,()=>m.value),b=_a(e,"modelValue",[],e=>v(null===e?[null]:ee(e)),t=>{const a=p(t)
return e.multiple?a:a[0]??null}),w=t.computed(()=>f(e.counterValue)?e.counterValue(b.value):h(e.counterValue)?e.counterValue:b.value.length),V=Qo(e),S=t.computed(()=>b.value.map(e=>e.value)),k=t.shallowRef(!1),x=t.toRef(()=>e.closableChips&&!V.isReadonly.value&&!V.isDisabled.value),N=Ut("VChip"),{InputIcon:C}=Uo(e)
let I,A="",P=0,_=!1
const R=t.computed(()=>{const t=m.value?g.value:d.value
return e.hideSelected?t.filter(t=>!b.value.some(a=>(e.valueComparator||Xt)(a,t))):t}),D=t.computed(()=>e.hideNoData&&!R.value.length||V.isReadonly.value||V.isDisabled.value),{menu:B,closeOnSelect:T}=Zs(e,{vMenuRef:r,menuDisabled:D,isFocused:k}),{menuId:F,ariaExpanded:$,ariaControls:M}=nu(0,B),z=t.computed(()=>({...e.menuProps,activatorProps:{...e.menuProps?.activatorProps||{},"aria-haspopup":"listbox"}})),{listEvents:L,focusItem:O,focusFirstItem:j,focusLastItem:H,onActivatorKeydown:W,setPendingFocus:U,flushPendingFocus:Y}=Ks(i,o,c,R,{selectedIndex:ne,menuContentEl:()=>r.value?.contentEl,noAutoScroll:()=>e.noAutoScroll}),G=Us(B,()=>r.value?.contentEl,()=>o.value?.controlRef),{onTabKeydown:K}=Qs({groups:[{type:"element",contentRef:s},{type:"list",contentRef:i,displayItemsCount:()=>R.value.length},{type:"element",contentRef:u}],onLeave:()=>{B.value=!1,o.value?.focus()}})
function q(t){e.openOnClear&&(B.value=!0)}function X(){D.value||(_=!1,U(null),B.value=!B.value)}function Z(e){"Tab"===e.key&&K(e),i.value?.$el.contains(e.target)&&Ie(e)&&Q(e)}function Q(t){if(!t.key||V.isReadonly.value)return
switch(t.key){case"Escape":case"Tab":B.value=!1
break
case"Enter":case" ":t.preventDefault(),_=!0,B.value=!0
break
case"ArrowDown":case"ArrowUp":if(t.preventDefault(),_=!0,W(t,B))return
break
case"Home":t.preventDefault(),B.value&&j()
break
case"End":t.preventDefault(),B.value&&H()
break
case"Backspace":if(!e.clearable)break
t.preventDefault()
for(const e of b.value)a("item:removed",e)
return b.value=[],void q()}if(!Ie(t))return
const l=performance.now()
l-I>1e3&&(A="",P=0),A+=t.key.toLowerCase(),I=l
const n=R.value
function o(){for(let e=P;e<n.length;e++){const t=n[e]
if(t.title.toLowerCase().startsWith(A))return[t,e]}}const r=function(){let e=o()
return e||(A.at(-1)===A.at(-2)&&(A=A.slice(0,-1),P++,e=o(),e)?e:(P=0,e=o(),e||(A=t.key.toLowerCase(),o())))}()
if(!r)return
const[i,s]=r
P=s,B.value?(e.multiple||J(i,!0,!1),O(s)):e.multiple||J(i,!0)}function J(l,n=!0,o=!0){if(l.props.disabled)return
const r=e.valueComparator||Xt
if(e.multiple){const e=b.value.findIndex(e=>r(e.value,l.value)),t=null==n?!~e:n
if(~e){const n=t?[...b.value,l]:[...b.value],[o]=n.splice(e,1)
t||a("item:removed",o),b.value=n}else t&&(a("item:added",l),b.value=[...b.value,l])}else{const e=!1!==n,i=b.value[0]
e?(i&&!r(i.value,l.value)?(a("item:removed",i),a("item:added",l)):i||a("item:added",l),b.value=[l]):(i&&a("item:removed",i),b.value=[]),o&&t.nextTick(()=>T())}}let te=0
function ae(){te=performance.now()}function le(e){const t=e.target
o.value?.$el.contains(t)||(B.value=!1)
const a=e.relatedTarget;(r.value?.contentEl?.contains(a)||!a&&performance.now()-te<10)&&(k.value=!0)}function ne(){return R.value.findIndex(t=>b.value.some(a=>(e.valueComparator||Xt)(a.value,t.value)))}async function oe(){if(e.eager&&c.value?.calculateVisibleItems(),!i.value||!k.value)return
if(Y())return
if(i.value.$el?.contains(be()))return
const t=ne()
t>=0&&await O(t,!e.noAutoScroll)||_&&j()}function re(){m.value="",k.value&&(r.value?.contentEl?._clickOutside?.lastMousedownWasOutside?k.value=!1:o.value?.focus())}function ie(e){k.value=!0}function se(e){if(!o.value?.$el.contains(e.relatedTarget)&&!e.currentTarget.contains(e.relatedTarget)){if(G(e))return
k.value=!1}}function ue(e){if(null==e){for(const e of b.value)a("item:removed",e)
b.value=[]}else if(xe(o.value,":autofill")||xe(o.value,":-webkit-autofill")){const t=d.value.find(t=>t.title===e)
t&&J(t)}else o.value&&(o.value.value="")}return t.watch(B,t=>{if(t||(_=!1,U(null)),!e.hideSelected&&B.value&&b.value.length){const t=ne()
E&&!e.noAutoScroll&&window.requestAnimationFrame(()=>{t>=0&&c.value?.scrollToIndex(t,"center")})}}),t.watch(d,(t,a)=>{B.value||k.value&&e.hideNoData&&!a.length&&t.length&&(B.value=!0)}),sa(()=>{const a=!(!e.chips&&!l.chip),d=!!(!e.hideNoData||R.value.length||l["prepend-item"]||l["append-item"]||l["no-data"]),v=b.value.length>0,p=Rs.filterProps(e),f=v||!k.value&&e.label&&!e.persistentPlaceholder?void 0:e.placeholder,h={search:m,filteredItems:g.value}
return t.createVNode(Rs,t.mergeProps({ref:o},p,{modelValue:b.value.map(e=>e.props.title).join(", "),name:void 0,"onUpdate:modelValue":ue,focused:k.value,"onUpdate:focused":e=>k.value=e,validationValue:b.externalValue,counterValue:w.value,dirty:v,class:["v-select",{"v-select--active-menu":B.value,"v-select--chips":!!e.chips,["v-select--"+(e.multiple?"multiple":"single")]:!0,"v-select--selected":b.value.length,"v-select--selection-slot":!!l.selection},e.class],style:e.style,inputmode:"none",placeholder:f,"onClick:clear":q,"onMousedown:control":X,onBlur:le,onKeydown:Q,"aria-expanded":$.value,"aria-controls":M.value}),{...l,default:({id:o})=>t.createElementVNode(t.Fragment,null,[S.value.map((a,l)=>t.createElementVNode("input",{key:l,type:"hidden",name:e.name,value:a,form:e.form},null)),t.createVNode(hs,t.mergeProps({id:F.value,ref:r,modelValue:B.value,"onUpdate:modelValue":e=>B.value=e,activator:"parent",captureFocus:!1,openOnArrow:!1,disabled:D.value,_disableKeys:!0,eager:e.eager,maxHeight:310,openOnClick:!1,closeOnContentClick:!1,transition:e.transition,onAfterEnter:oe,onAfterLeave:re},z.value,{contentClass:["v-select__content",z.value.contentClass]}),{default:()=>[t.createVNode(bs,{elevation:e.menuElevation,onFocusin:ie,onFocusout:se,onKeydown:Z,onMousedown:ae},{default:()=>[l["menu-header"]&&t.createElementVNode("header",{ref:s},[l["menu-header"](h)]),d&&t.createVNode(xi,t.mergeProps({key:"select-list",ref:i,class:"v-list--navigable",selected:S.value,selectStrategy:e.multiple?"independent":"single-independent",tabindex:"-1",selectable:!!R.value.length,"aria-live":"polite","aria-labelledby":`${o.value}-label`,"aria-multiselectable":e.multiple,color:e.itemColor??e.color},L,e.listProps),{default:()=>[l["prepend-item"]?.(),!R.value.length&&!e.hideNoData&&(l["no-data"]?.()??t.createVNode(ui,{key:"no-data",title:n(e.noDataText)},null)),t.createVNode(zs,{ref:c,renderless:!0,items:R.value,itemKey:"value"},{default:({item:a,index:n,itemRef:o})=>{const r=De(a.props),i=t.mergeProps(a.props,{ref:o,key:a.value,onClick:()=>J(a,null),"aria-posinset":n+1,"aria-setsize":R.value.length})
return"divider"===a.type?l.divider?.({props:a.raw,index:n})??t.createVNode(zr,t.mergeProps(a.props,{ref:o,key:`divider-${n}`}),null):"subheader"===a.type?l.subheader?.({props:a.raw,index:n})??t.createVNode(di,t.mergeProps(a.props,{ref:o,key:`subheader-${n}`}),null):l.item?.({item:a.raw,internalItem:a,index:n,props:i})??t.createVNode(ui,t.mergeProps(i,{role:"option"}),{prepend:({isSelected:l})=>t.createElementVNode(t.Fragment,null,[e.multiple&&!e.hideSelected?t.createVNode(Wo,{key:a.value,modelValue:l,ripple:!1,tabindex:"-1","aria-hidden":!0,onClick:e=>e.preventDefault()},null):void 0,r.prependAvatar&&t.createVNode(Bo,{image:r.prependAvatar},null),r.prependIcon&&t.createVNode(Mn,{icon:r.prependIcon},null)]),title:()=>m.value?t.createVNode(Ws,{text:a.title,matches:y(a)?.title,markClass:"v-select__mask",matchAll:!0,ignoreCase:!0},null):a.title})}}),l["append-item"]?.()]}),l["menu-footer"]&&t.createElementVNode("footer",{ref:u},[l["menu-footer"](h)])]})]}),b.value.map((n,o)=>{function r(e){e.stopPropagation(),e.preventDefault(),J(n,!1)}const i=t.mergeProps(Fr.filterProps(n.props),{"onClick:close":r,onKeydown(e){"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),e.stopPropagation(),r(e))},onMousedown(e){e.preventDefault(),e.stopPropagation()},modelValue:!0,"onUpdate:modelValue":void 0}),s=a?!!l.chip:!!l.selection,u=s?Ne(a?l.chip({item:n.raw,internalItem:n,index:o,props:i}):l.selection({item:n.raw,internalItem:n,index:o})):void 0
if(!s||u)return t.createElementVNode("div",{key:n.value,class:"v-select__selection"},[a?l.chip?t.createVNode(Bl,{key:"chip-defaults",defaults:{VChip:{closable:x.value,size:N.value?.size??"small",text:n.title}}},{default:()=>[u]}):t.createVNode(Fr,t.mergeProps({key:"chip",closable:x.value,size:N.value?.size??"small",text:n.title,disabled:n.props.disabled},i),null):u??t.createElementVNode("span",{class:"v-select__selection-text"},[n.title,e.multiple&&o<b.value.length-1&&t.createElementVNode("span",{class:"v-select__selection-comma"},[t.createTextVNode(",")])])])})]),"append-inner":(...a)=>t.createElementVNode(t.Fragment,null,[l["append-inner"]?.(...a),e.menuIcon?t.createVNode(Mn,{class:"v-select__menu-icon",color:o.value?.fieldIconColor,icon:e.menuIcon,"aria-hidden":!0},null):void 0,e.appendInnerIcon&&t.createVNode(C,{key:"append-icon",name:"appendInner",color:a[0].iconColor.value},null)])})}),ir({isFocused:k,menu:B,search:m,filteredItems:g,select:J},o)}}),su=Tt({autoSelectFirst:{type:[Boolean,String]},clearOnSelect:Boolean,search:String,closeOnInputClick:Boolean,...eu({filterKeys:["title"]}),...ou(),...G(_s({modelValue:null,role:"combobox"}),["validationValue","dirty"])},"VAutocomplete"),uu=Kt()({name:"VAutocomplete",props:su(),emits:{"update:focused":e=>!0,"update:search":e=>!0,"update:modelValue":e=>!0,"update:menu":e=>!0,"item:added":e=>!0,"item:removed":e=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),o=t.ref(),r=t.ref(),i=t.ref(),s=t.ref(),u=t.ref(),c=t.ref(),d=t.shallowRef(!1),v=t.shallowRef(!0),p=t.shallowRef(!1),m=t.shallowRef(-1),g=t.shallowRef(null),{items:y,transformIn:b,transformOut:w}=yi(e),{textColorClasses:V,textColorStyles:S}=Ll(()=>o.value?.color),{InputIcon:k}=Uo(e),x=_a(e,"search",""),N=_a(e,"modelValue",[],e=>b(null===e?[null]:ee(e)),t=>{const a=w(t)
return e.multiple?a:a[0]??null}),C=t.computed(()=>f(e.counterValue)?e.counterValue(N.value):h(e.counterValue)?e.counterValue:N.value.length),I=Qo(e),{filteredItems:A,getMatches:P}=au(e,y,()=>g.value??(v.value?"":x.value)),_=t.computed(()=>e.hideSelected&&null===g.value?A.value.filter(e=>!N.value.some(t=>t.value===e.value)):A.value),R=t.toRef(()=>e.closableChips&&!I.isReadonly.value&&!I.isDisabled.value),D=Ut("VChip"),B=t.computed(()=>!(!e.chips&&!l.chip)),T=t.computed(()=>B.value||!!l.selection),F=t.computed(()=>e.multiple||T.value?"":String(N.value.at(-1)?.props.title??"")),$=t.computed(()=>N.value.map(e=>e.props.value)),M=t.computed(()=>_.value.find(e=>"item"===e.type&&!e.props.disabled)),z=t.computed(()=>(!0===e.autoSelectFirst||"exact"===e.autoSelectFirst&&x.value===M.value?.title)&&_.value.length>0&&!v.value&&!p.value),L=t.computed(()=>e.hideNoData&&!_.value.length||I.isReadonly.value||I.isDisabled.value),{menu:O,closeOnSelect:j}=Zs(e,{vMenuRef:r,menuDisabled:L,isFocused:d}),{menuId:H,ariaExpanded:W,ariaControls:U}=nu(0,O),{listEvents:Y,onActivatorKeydown:G,setPendingFocus:K,flushPendingFocus:q}=Ks(i,o,c,_,{selectedIndex:()=>v.value?ie():-1,headerEl:()=>s.value,menuContentEl:()=>r.value?.contentEl,noAutoScroll:()=>e.noAutoScroll}),X=Us(O,()=>r.value?.contentEl,()=>o.value?.controlRef),{onTabKeydown:Z}=Qs({groups:[{type:"element",contentRef:s},{type:"list",contentRef:i,displayItemsCount:()=>_.value.length},{type:"element",contentRef:u}],onLeave:()=>{O.value=!1,o.value?.focus()}})
function J(t){e.openOnClear&&(O.value=!0),x.value=""}function te(){L.value||(O.value=!e.closeOnInputClick||!O.value)}function ae(e){L.value||(d.value&&(e.preventDefault(),e.stopPropagation()),O.value=!O.value)}function le(e){"Tab"===e.key&&Z(e),i.value?.$el.contains(e.target)&&(Ie(e)||"Backspace"===e.key)&&o.value?.focus()}function ne(t){if(!Q(t)&&!I.isReadonly.value)switch(t.key){case"Escape":O.value=!1
break
case"ArrowDown":case"ArrowUp":if(t.preventDefault(),G(t,O))break
"ArrowDown"===t.key&&z.value&&i.value?.focus("next")
break
case"Enter":t.preventDefault(),O.value=!0,oe()
break
case"Tab":oe(),O.value=!1
break
default:!function(t){const a=N.value.length
if(["Backspace","Delete"].includes(t.key)){if(!e.multiple&&T.value&&a>0&&!x.value)return void ge(N.value[0],!1)
if(~m.value){t.preventDefault()
const e=m.value
ge(N.value[m.value],!1),m.value=e>=a-1?a-2:e}else"Backspace"!==t.key||x.value||(m.value=a-1)
return}if(!e.multiple)return
if("ArrowLeft"===t.key){if(m.value<0&&(o.value?.selectionStart??0)>0)return
const e=m.value>-1?m.value-1:a-1
if(N.value[e])m.value=e
else{const e=x.value?.length??null
m.value=-1,o.value?.setSelectionRange(e,e)}}else if("ArrowRight"===t.key){if(m.value<0)return
const e=m.value+1
N.value[e]?m.value=e:(m.value=-1,o.value?.setSelectionRange(0,0))}else~m.value&&Ie(t)&&(m.value=-1)}(t)}}function oe(){const e=M.value
z.value&&e&&(N.value.some(({value:t})=>t===e.value)||ge(e))}function re(e){if(xe(o.value,":autofill")||xe(o.value,":-webkit-autofill")){const t=y.value.find(t=>t.title===e.target.value)
t&&ge(t)}}function ie(){return _.value.findIndex(t=>N.value.some(a=>(e.valueComparator||Xt)(a.value,t.value)))}function se(){e.eager&&c.value?.calculateVisibleItems(),q()}function ue(){d.value&&(r.value?.contentEl?._clickOutside?.lastMousedownWasOutside?d.value=!1:(v.value=!0,o.value?.focus())),g.value=null}function ce(e){d.value=!0,setTimeout(()=>{p.value=!0})}function de(e){if(p.value=!1,!o.value?.$el.contains(e.relatedTarget)){if(X(e))return
d.value=!1}}function ve(t){if(null==t||""===t&&!e.multiple&&!T.value){for(const e of N.value)a("item:removed",e)
N.value=[]}}let pe=0
function me(){pe=performance.now()}function fe(e){const t=e.relatedTarget,a=r.value?.contentEl;(a?.contains(t)||!t&&performance.now()-pe<10)&&(d.value=!0)}function ge(l,n=!0){if(!l||l.props.disabled)return
const o=e.valueComparator||Xt
if(e.multiple){const t=N.value.findIndex(e=>o(e.value,l.value)),r=null==n?!~t:n
if(~t){const e=r?[...N.value,l]:[...N.value],[n]=e.splice(t,1)
r||a("item:removed",n),N.value=e}else r&&(a("item:added",l),N.value=[...N.value,l])
e.clearOnSelect&&(x.value="")}else{const e=!1!==n,r=N.value[0]
e?(r&&!o(r.value,l.value)?(a("item:removed",r),a("item:added",l)):r||a("item:added",l),N.value=[l]):(r&&a("item:removed",r),N.value=[]),g.value=v.value?"":x.value??"",x.value=e&&!T.value?l.title:"",t.nextTick(()=>{j(),v.value=!0})}}return t.watch(d,(t,l)=>{if(t!==l)if(t)v.value=!0
else{if(!e.multiple&&null==x.value){for(const e of N.value)a("item:removed",e)
N.value=[]}O.value=!1,!v.value&&x.value&&(g.value=x.value),x.value=F.value,v.value=!0,m.value=-1}}),t.watch(F,e=>{d.value||(x.value=e)},{immediate:!0}),t.watch(x,e=>{d.value&&(e&&(O.value=!0),v.value=!e,O.value&&t.nextTick(()=>{c.value?.scrollToIndex(0),i.value?.$el?.contains(be())&&o.value?.focus()}))}),t.watch(O,t=>{if(t||K(null),!e.hideSelected&&t&&N.value.length&&v.value){const t=ie()
E&&!e.noAutoScroll&&window.requestAnimationFrame(()=>{t>=0&&c.value?.scrollToIndex(t,"center")})}t&&(g.value=null)}),t.watch(y,(e,t)=>{O.value||d.value&&!t.length&&e.length&&(O.value=!0)}),sa(()=>{const a=!!(!e.hideNoData||_.value.length||l["prepend-item"]||l["append-item"]||l["no-data"]),p=N.value.length>0,f=Rs.filterProps(e),g={search:x,filteredItems:A.value}
return t.createVNode(Rs,t.mergeProps({ref:o},f,{form:"",modelValue:x.value,"onUpdate:modelValue":[e=>x.value=e,ve],focused:d.value,"onUpdate:focused":e=>d.value=e,validationValue:N.externalValue,counterValue:C.value,dirty:p,onChange:re,class:["v-autocomplete","v-autocomplete--"+(e.multiple?"multiple":"single"),{"v-autocomplete--active-menu":O.value,"v-autocomplete--chips":!!e.chips,"v-autocomplete--selection-slot":!!T.value,"v-autocomplete--selecting-index":m.value>-1},e.class],style:e.style,readonly:I.isReadonly.value,placeholder:p?void 0:e.placeholder,"onClick:clear":J,"onMousedown:control":te,onKeydown:ne,onBlur:fe,"aria-expanded":W.value,"aria-controls":U.value}),{...l,default:({id:o})=>t.createElementVNode(t.Fragment,null,[$.value.map((a,l)=>t.createElementVNode("input",{key:l,type:"hidden",name:e.name,value:a,form:e.form},null)),t.createVNode(hs,t.mergeProps({id:H.value,ref:r,modelValue:O.value,"onUpdate:modelValue":e=>O.value=e,activator:"parent",captureFocus:!1,openOnArrow:!1,disabled:L.value,_disableKeys:!0,eager:e.eager,maxHeight:310,openOnClick:!1,closeOnContentClick:!1,onAfterEnter:se,onAfterLeave:ue},e.menuProps,{contentClass:["v-autocomplete__content",e.menuProps?.contentClass]}),{default:()=>[t.createVNode(bs,{elevation:e.menuElevation,onFocusin:ce,onKeydown:le,onMousedown:me},{default:()=>[l["menu-header"]&&t.createElementVNode("header",{ref:s},[l["menu-header"](g)]),a&&t.createVNode(xi,t.mergeProps({key:"autocomplete-list",ref:i,class:"v-list--navigable",filterable:!0,selected:$.value,selectStrategy:e.multiple?"independent":"single-independent",onMousedown:e=>e.preventDefault(),onFocusout:de,tabindex:"-1",selectable:!!_.value.length,"aria-live":"polite","aria-labelledby":`${o.value}-label`,"aria-multiselectable":e.multiple,color:e.itemColor??e.color},Y,e.listProps),{default:()=>[l["prepend-item"]?.(),!_.value.length&&!e.hideNoData&&(l["no-data"]?.()??t.createVNode(ui,{key:"no-data",title:n(e.noDataText)},null)),t.createVNode(zs,{ref:c,renderless:!0,items:_.value,itemKey:"value"},{default:({item:a,index:n,itemRef:o})=>{const r=De(a.props),i=t.mergeProps(a.props,{ref:o,key:a.value,active:!(!z.value||a!==M.value)||void 0,onClick:()=>ge(a,null),"aria-posinset":n+1,"aria-setsize":_.value.length})
return"divider"===a.type?l.divider?.({props:a.raw,index:n})??t.createVNode(zr,t.mergeProps(a.props,{ref:o,key:`divider-${n}`}),null):"subheader"===a.type?l.subheader?.({props:a.raw,index:n})??t.createVNode(di,t.mergeProps(a.props,{ref:o,key:`subheader-${n}`}),null):l.item?.({item:a.raw,internalItem:a,index:n,props:i})??t.createVNode(ui,t.mergeProps(i,{role:"option"}),{prepend:({isSelected:l})=>t.createElementVNode(t.Fragment,null,[e.multiple&&!e.hideSelected?t.createVNode(Wo,{key:a.value,modelValue:l,ripple:!1,tabindex:"-1","aria-hidden":!0,onClick:e=>e.preventDefault()},null):void 0,r.prependAvatar&&t.createVNode(Bo,{image:r.prependAvatar},null),r.prependIcon&&t.createVNode(Mn,{icon:r.prependIcon},null)]),title:()=>v.value?a.title:t.createVNode(Ws,{text:a.title,matches:P(a)?.title,markClass:"v-autocomplete__mask",matchAll:!0,ignoreCase:!0},null)})}}),l["append-item"]?.()]}),l["menu-footer"]&&t.createElementVNode("footer",{ref:u},[l["menu-footer"](g)])]})]}),N.value.map((a,n)=>{function o(e){e.stopPropagation(),e.preventDefault(),ge(a,!1)}const r=t.mergeProps(Fr.filterProps(a.props),{"onClick:close":o,onKeydown(e){"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),e.stopPropagation(),o(e))},onMousedown(e){e.preventDefault(),e.stopPropagation()},modelValue:!0,"onUpdate:modelValue":void 0}),i=B.value?!!l.chip:!!l.selection,s=i?Ne(B.value?l.chip({item:a.raw,internalItem:a,index:n,props:r}):l.selection({item:a.raw,internalItem:a,index:n})):void 0
if(!i||s)return t.createElementVNode("div",{key:a.value,class:t.normalizeClass(["v-autocomplete__selection",n===m.value&&["v-autocomplete__selection--selected",V.value]]),style:t.normalizeStyle(n===m.value?S.value:{})},[B.value?l.chip?t.createVNode(Bl,{key:"chip-defaults",defaults:{VChip:{closable:R.value,size:D.value?.size??"small",text:a.title}}},{default:()=>[s]}):t.createVNode(Fr,t.mergeProps({key:"chip",closable:R.value,size:D.value?.size??"small",text:a.title,disabled:a.props.disabled},r),null):s??t.createElementVNode("span",{class:"v-autocomplete__selection-text"},[a.title,e.multiple&&n<N.value.length-1&&t.createElementVNode("span",{class:"v-autocomplete__selection-comma"},[t.createTextVNode(",")])])])})]),"append-inner":(...a)=>t.createElementVNode(t.Fragment,null,[l["append-inner"]?.(...a),e.menuIcon?t.createVNode(Mn,{class:"v-autocomplete__menu-icon",color:o.value?.fieldIconColor,icon:e.menuIcon,onMousedown:ae,onClick:ke,"aria-hidden":!0,tabindex:"-1"},null):void 0,e.appendInnerIcon&&t.createVNode(k,{key:"append-icon",name:"appendInner",color:a[0].iconColor.value},null)])})}),ir({isFocused:d,isPristine:v,menu:O,search:x,filteredItems:A,select:ge},o)}}),cu=Tt({color:String,density:String,...Ft()},"VBannerActions"),du=Kt()({name:"VBannerActions",props:cu(),setup:(e,{slots:a})=>(Ht({VBtn:{color:e.color,density:e.density,slim:!0,variant:"text"}}),sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-banner-actions",e.class]),style:t.normalizeStyle(e.style)},[a.default?.()])),{})}),vu=qt("v-banner-text"),pu=Tt({avatar:String,bgColor:String,color:String,icon:ua,lines:String,stacked:Boolean,sticky:Boolean,text:String,...an(),...Ft(),...yn(),...Tl(),...hr({mobile:null}),...nn(),...sn(),...Zn(),...Gl(),...ol(),...Ga()},"VBanner"),mu=Kt()({name:"VBanner",props:pu(),setup(e,{slots:a}){const{backgroundColorClasses:l,backgroundColorStyles:n}=Ol(()=>e.bgColor),{borderClasses:o}=ln(e),{densityClasses:r}=bn(e),{displayClasses:i,mobile:s}=yr(e),{dimensionStyles:u}=Fl(e),{elevationClasses:c}=on(e),{locationStyles:d}=un(e),{positionClasses:v}=Qn(e),{roundedClasses:p,roundedStyles:m}=Kl(e),{themeClasses:f}=tl(e),g=t.toRef(()=>e.color),h=t.toRef(()=>e.density)
Ht({VBannerActions:{color:g,density:h}}),sa(()=>{const y=!(!e.text&&!a.text),b=!(!e.avatar&&!e.icon),w=!(!b&&!a.prepend)
return t.createVNode(e.tag,{class:t.normalizeClass(["v-banner",{"v-banner--stacked":e.stacked||s.value,"v-banner--sticky":e.sticky,[`v-banner--${e.lines}-line`]:!!e.lines},f.value,l.value,o.value,r.value,i.value,c.value,v.value,p.value,e.class]),style:t.normalizeStyle([n.value,u.value,d.value,m.value,e.style]),role:"banner"},{default:()=>[w&&t.createElementVNode("div",{key:"prepend",class:"v-banner__prepend"},[a.prepend?t.createVNode(Bl,{key:"prepend-defaults",disabled:!b,defaults:{VAvatar:{color:g.value,density:h.value,icon:e.icon,image:e.avatar}}},a.prepend):t.createVNode(Bo,{key:"prepend-avatar",color:g.value,density:h.value,icon:e.icon,image:e.avatar},null)]),t.createElementVNode("div",{class:"v-banner__content"},[y&&t.createVNode(vu,{key:"text"},{default:()=>[a.text?.()??e.text]}),a.default?.()]),a.actions&&t.createVNode(du,{key:"actions"},a.actions)]})})}}),fu=Tt({baseColor:String,bgColor:String,color:String,grow:Boolean,mode:{type:String,validator:e=>!e||["horizontal","shift"].includes(e)},height:{type:[Number,String],default:56},active:{type:Boolean,default:!0},...an(),...Ft(),...yn(),...nn(),...Gl(),...Ca({name:"bottom-navigation"}),...ol({tag:"header"}),...An({selectedClass:"v-btn--selected"}),...Ga()},"VBottomNavigation"),gu=Kt()({name:"VBottomNavigation",props:fu(),emits:{"update:active":e=>!0,"update:modelValue":e=>!0},setup(e,{slots:a}){const{themeClasses:l}=al(),{borderClasses:n}=ln(e),{backgroundColorClasses:o,backgroundColorStyles:r}=Ol(()=>e.bgColor),{densityClasses:i}=bn(e),{elevationClasses:s}=on(e),{roundedClasses:u,roundedStyles:c}=Kl(e),{ssrBootStyles:d}=mn(),v=t.computed(()=>$(e.height)?e.height:Number(e.height)-("comfortable"===e.density?8:0)-("compact"===e.density?16:0)),p=_a(e,"active",e.active),{layoutItemStyles:m}=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:t.toRef(()=>"bottom"),layoutSize:t.toRef(()=>p.value?v.value:0),elementSize:v,active:p,absolute:t.toRef(()=>e.absolute)})
return Rn(e,Bn),Ht({VBtn:{baseColor:t.toRef(()=>e.baseColor),color:t.toRef(()=>e.color),density:t.toRef(()=>e.density),stacked:t.toRef(()=>"horizontal"!==e.mode),variant:"text"}},{scoped:!0}),sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-bottom-navigation",{"v-bottom-navigation--active":p.value,"v-bottom-navigation--grow":e.grow,"v-bottom-navigation--shift":"shift"===e.mode},l.value,o.value,n.value,i.value,s.value,u.value,e.class]),style:t.normalizeStyle([r.value,m.value,{height:z(v.value)},d.value,c.value,e.style])},{default:()=>[a.default&&t.createElementVNode("div",{class:"v-bottom-navigation__content"},[a.default()])]})),{}}}),hu=Tt({fullscreen:Boolean,scrollable:Boolean,...G(ms({captureFocus:!0,location:"center center",origin:"center center",scrollStrategy:"block",transition:{component:ml},zIndex:2400,retainFocus:!0}),["disableInitialFocus"])},"VDialog"),yu=Kt()({name:"VDialog",props:hu(),emits:{"update:modelValue":e=>!0,afterEnter:()=>!0,afterLeave:()=>!0},setup(e,{emit:a,slots:l}){const n=_a(e,"modelValue"),{scopeId:o}=ns(),r=t.ref()
function i(){a("afterEnter"),(e.scrim||e.retainFocus)&&r.value?.contentEl&&!r.value.contentEl.contains(be())&&r.value.contentEl.focus({preventScroll:!0})}function s(){a("afterLeave")}return t.watch(n,async e=>{e||(await t.nextTick(),r.value?.activatorEl?.focus({preventScroll:!0}))}),sa(()=>{const a=fs.filterProps(e),u=t.mergeProps({"aria-haspopup":"dialog"},e.activatorProps),c=t.mergeProps({tabindex:-1},e.contentProps),d=e.fullscreen?ke:e.locationStrategy
return t.createVNode(fs,t.mergeProps({ref:r,class:["v-dialog",{"v-dialog--fullscreen":e.fullscreen,"v-dialog--scrollable":e.scrollable},e.class],style:e.style},a,{modelValue:n.value,"onUpdate:modelValue":e=>n.value=e,"aria-modal":"true",activatorProps:u,contentProps:c,height:e.fullscreen?void 0:e.height,width:e.fullscreen?void 0:e.width,maxHeight:e.fullscreen?void 0:e.maxHeight,maxWidth:e.fullscreen?void 0:e.maxWidth,locationStrategy:d,role:"dialog",onAfterEnter:i,onAfterLeave:s},o),{activator:l.activator,default:(...e)=>t.createVNode(Bl,{root:"VDialog"},{default:()=>[l.default?.(...e)]})})}),ir({},r)}}),bu=Tt({inset:Boolean,...hu({transition:"bottom-sheet-transition",location:"bottom center",origin:"bottom center",viewportMargin:0})},"VBottomSheet"),wu=Kt()({name:"VBottomSheet",props:bu(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue")
return sa(()=>{const n=yu.filterProps(e)
return t.createVNode(yu,t.mergeProps(n,{contentClass:["v-bottom-sheet__content",e.contentClass],modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,class:["v-bottom-sheet",{"v-bottom-sheet--inset":e.inset},e.class],style:e.style}),a)}),{}}}),Vu=Tt({divider:[Number,String],...Ft()},"VBreadcrumbsDivider"),Su=Kt()({name:"VBreadcrumbsDivider",props:Vu(),setup:(e,{slots:a})=>(sa(()=>t.createElementVNode("li",{"aria-hidden":"true",class:t.normalizeClass(["v-breadcrumbs-divider",e.class]),style:t.normalizeStyle(e.style)},[a?.default?.()??e.divider])),{})}),ku=Tt({active:Boolean,activeClass:String,activeColor:String,color:String,disabled:Boolean,title:String,...Ft(),...U(Tl(),["width","maxWidth"]),...to(),...ol({tag:"li"})},"VBreadcrumbsItem"),xu=Kt()({name:"VBreadcrumbsItem",props:ku(),setup(e,{slots:a,attrs:l}){const n=eo(e,l),o=t.computed(()=>e.active||n.isActive?.value),{dimensionStyles:r}=Fl(e),{textColorClasses:i,textColorStyles:s}=Ll(()=>o.value?e.activeColor:e.color)
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-breadcrumbs-item",{"v-breadcrumbs-item--active":o.value,"v-breadcrumbs-item--disabled":e.disabled,[`${e.activeClass}`]:o.value&&e.activeClass},i.value,e.class]),style:t.normalizeStyle([s.value,r.value,e.style]),"aria-current":o.value?"page":void 0},{default:()=>[n.isLink.value?t.createElementVNode("a",t.mergeProps({class:"v-breadcrumbs-item--link",onClick:n.navigate.value},n.linkProps),[a.default?.()??e.title]):a.default?.()??e.title]})),{}}}),Nu=Tt({activeClass:String,activeColor:String,bgColor:String,color:String,disabled:Boolean,divider:{type:String,default:"/"},icon:ua,items:{type:Array,default:()=>[]},...Ft(),...yn(),...Gl(),...ol({tag:"ul"})},"VBreadcrumbs"),Cu=Kt()({name:"VBreadcrumbs",props:Nu(),setup(e,{slots:a}){const{backgroundColorClasses:l,backgroundColorStyles:n}=Ol(()=>e.bgColor),{densityClasses:o}=bn(e),{roundedClasses:r,roundedStyles:i}=Kl(e)
Ht({VBreadcrumbsDivider:{divider:t.toRef(()=>e.divider)},VBreadcrumbsItem:{activeClass:t.toRef(()=>e.activeClass),activeColor:t.toRef(()=>e.activeColor),color:t.toRef(()=>e.color),disabled:t.toRef(()=>e.disabled)}})
const s=t.computed(()=>e.items.map(e=>g(e)?{item:{title:e},raw:e}:{item:e,raw:e}))
return sa(()=>{const u=!(!a.prepend&&!e.icon)
return t.createVNode(e.tag,{class:t.normalizeClass(["v-breadcrumbs",l.value,o.value,r.value,e.class]),style:t.normalizeStyle([n.value,i.value,e.style])},{default:()=>[u&&t.createElementVNode("li",{key:"prepend",class:"v-breadcrumbs__prepend"},[a.prepend?t.createVNode(Bl,{key:"prepend-defaults",disabled:!e.icon,defaults:{VIcon:{icon:e.icon,start:!0}}},a.prepend):t.createVNode(Mn,{key:"prepend-icon",start:!0,icon:e.icon},null)]),s.value.map(({item:e,raw:l},n,o)=>t.createElementVNode(t.Fragment,null,[a.item?.({item:e,index:n})??t.createVNode(xu,t.mergeProps({key:n,disabled:n>=o.length-1},g(e)?{title:e}:e),{default:a.title?()=>a.title?.({item:e,index:n}):void 0}),n<o.length-1&&t.createVNode(Su,null,{default:a.divider?()=>a.divider?.({item:l,index:n}):void 0})])),a.default?.()]})}),{}}}),Eu=Tt({active:{type:Boolean,default:void 0},activeColor:String,activeIcon:[String,Function,Object],activeVariant:String,baseVariant:{type:String,default:"tonal"},disabled:Boolean,height:[Number,String],width:[Number,String],hideOverlay:Boolean,icon:[String,Function,Object],iconColor:String,loading:Boolean,opacity:[Number,String],readonly:Boolean,rotate:[Number,String],size:{type:[Number,String],default:"default"},sizes:{type:Array,default:()=>[["x-small",16],["small",24],["default",40],["large",48],["x-large",56]]},text:{type:[String,Number,Boolean],default:void 0},...an(),...Ft(),...nn(),...Co(),...Gl(),...ol({tag:"button"}),...Ga(),...Nn({variant:"flat"})},"VIconBtn"),Iu=Kt()({name:"VIconBtn",props:Eu(),emits:{"update:active":e=>!0},setup(e,{attrs:a,slots:l}){const n=_a(e,"active"),{themeClasses:o}=tl(e),{borderClasses:r}=ln(e),{elevationClasses:i}=on(e),{roundedClasses:s,roundedStyles:u}=Kl(e),{colorClasses:c,colorStyles:d,variantClasses:v}=Cn(()=>({color:(()=>{if(!e.disabled)return n.value?e.activeColor??e.color??"surface-variant":e.color})(),variant:void 0===n.value?e.variant:n.value?e.activeVariant??e.variant:e.baseVariant??e.variant})),p=new Map(e.sizes)
function m(){e.disabled||e.readonly||void 0===n.value||"a"===e.tag&&a.href||(n.value=!n.value)}return sa(()=>{const a=n.value?e.activeIcon??e.icon:e.icon,f=e.size,g=p.has(f)?p.get(f):f,h=e.height??g,b=e.width??g,{iconSize:w}=Eo(e,()=>new Map(e.iconSizes).get(f)),V={icon:a,size:w.value,color:e.iconColor,opacity:e.opacity}
return t.createVNode(e.tag,{type:"button"===e.tag?"button":void 0,class:t.normalizeClass([{"v-icon-btn":!0,"v-icon-btn--active":n.value,"v-icon-btn--disabled":e.disabled,"v-icon-btn--loading":e.loading,"v-icon-btn--readonly":e.readonly,[`v-icon-btn--${e.size}`]:!0},o.value,c.value,r.value,i.value,s.value,v.value,e.class]),style:t.normalizeStyle([{"--v-icon-btn-rotate":z(e.rotate,"deg"),"--v-icon-btn-height":z(h),"--v-icon-btn-width":z(b)},d.value,u.value,e.style]),tabindex:e.disabled||e.readonly?-1:0,onClick:m},{default:()=>[xn(!e.hideOverlay,"v-icon-btn"),t.createElementVNode("div",{class:"v-icon-btn__content","data-no-activator":""},[!l.default&&a?t.createVNode(Mn,t.mergeProps({key:"content-icon"},V),null):t.createVNode(Bl,{key:"content-defaults",disabled:!a,defaults:{VIcon:{...V}}},{default:()=>l.default?.()??t.toDisplayString(e.text)})]),!!e.loading&&t.createElementVNode("span",{key:"loader",class:"v-icon-btn__loader"},[l.loader?.()??t.createVNode(Hn,{color:y(e.loading)?void 0:e.loading,indeterminate:"disable-shrink",width:"2",size:w.value},null)])]})}),{}}})
const Au=/^(\d{4})-(\d{1,2})(-(\d{1,2}))?([^\d]+(\d{1,2}))?(:(\d{1,2}))?(:(\d{1,2}))?$/,Pu=/(\d\d?)(:(\d\d?)|)(:(\d\d?)|)/,_u=[0,31,28,31,30,31,30,31,31,30,31,30,31],Ru=[0,31,29,31,30,31,30,31,31,30,31,30,31]
function Du(e){const t=Xu(e)
return t.day=1,Gu(t),Ku(t),t}function Bu(e){const t=Xu(e)
return t.day=qu(t.year,t.month),Gu(t),Ku(t),t}function Tu(e){return isFinite(parseInt(e))}function Fu(e){if(h(e))return e
if(g(e)){const t=Pu.exec(e)
return!!t&&60*parseInt(t[1])+parseInt(t[3]||0)}return!!b(e)&&(!(!h(e.hour)||!h(e.minute))&&60*e.hour+e.minute)}function $u(e){return h(e)&&isFinite(e)||g(e)&&!!Au.exec(e)||e instanceof Date}function Mu(e,t=!1,a){if(h(e)&&isFinite(e)&&(e=new Date(e)),e instanceof Date){return zu(e)}if(!g(e)){if(t)throw new Error(`${e} is not a valid timestamp. It must be a Date, number of milliseconds since Epoch, or a string in the format of YYYY-MM-DD or YYYY-MM-DD hh:mm. Zero-padding is optional and seconds are ignored.`)
return null}const l=Au.exec(e)
if(!l){if(t)throw new Error(`${e} is not a valid timestamp. It must be a Date, number of milliseconds since Epoch, or a string in the format of YYYY-MM-DD or YYYY-MM-DD hh:mm. Zero-padding is optional and seconds are ignored.`)
return null}const n={date:e,time:"",year:parseInt(l[1]),month:parseInt(l[2]),day:parseInt(l[4])||1,hour:parseInt(l[6])||0,minute:parseInt(l[8])||0,weekday:0,hasDay:!!l[4],hasTime:!(!l[6]||!l[8]),past:!1,present:!1,future:!1}
return Gu(n),Ku(n),n}function zu(e){return Ku({date:"",time:"",year:e.getFullYear(),month:e.getMonth()+1,day:e.getDate(),weekday:e.getDay(),hour:e.getHours(),minute:e.getMinutes(),hasDay:!0,hasTime:!0,past:!1,present:!0,future:!1})}function Lu(e){return 1e4*e.year+100*e.month+e.day}function Ou(e){return 100*e.hour+e.minute}function ju(e){return 1e4*Lu(e)+Ou(e)}function Hu(e,t,a=!1){let l=Lu(t),n=Lu(e),o=l===n
return e.hasTime&&a&&o&&(l=Ou(t),n=Ou(e),o=l===n),e.past=n<l,e.present=o,e.future=n>l,e}function Wu(e){return e instanceof Date||h(e)&&isFinite(e)}function Uu(e,t,a){return e.hasTime!==t&&(e.hasTime=t,t||(e.hour=23,e.minute=59,e.time=Qu(e))),e}function Yu(e,t,a){return e.hasTime=!0,e.hour=0,e.minute=0,Ju(e,t),Ku(e),a&&Hu(e,a,!0),e}function Gu(e){return e.weekday=function(e){if(e.hasDay){const t=Math.floor,a=e.day,l=(e.month+9)%12+1,n=t(e.year/100),o=e.year%100-(e.month<=2?1:0)
return((a+t(2.6*l-.2)-2*n+o+t(o/4)+t(n/4))%7+7)%7}return e.weekday}(e),e}function Ku(e){return e.time=Qu(e),e.date=function(e){let t=`${Zu(e.year,4)}-${Zu(e.month,2)}`
e.hasDay&&(t+=`-${Zu(e.day,2)}`)
return t}(e),e}function qu(e,t){return function(e){return e%4==0&&e%100!=0||e%400==0}(e)?Ru[t]:_u[t]}function Xu(e){if(null==e)return null
const{date:t,time:a,year:l,month:n,day:o,weekday:r,hour:i,minute:s,hasDay:u,hasTime:c,past:d,present:v,future:p}=e
return{date:t,time:a,year:l,month:n,day:o,weekday:r,hour:i,minute:s,hasDay:u,hasTime:c,past:d,present:v,future:p}}function Zu(e,t){let a=String(e)
for(;a.length<t;)a="0"+a
return a}function Qu(e){return e.hasTime?`${Zu(e.hour,2)}:${Zu(e.minute,2)}`:""}function Ju(e,t){for(e.minute+=t;e.minute>=60;)e.minute-=60,e.hour++,e.hour>=24&&(ec(e),e.hour=0)
return e}function ec(e){return e.day++,e.weekday=(e.weekday+1)%7,e.day>28&&e.day>qu(e.year,e.month)&&(e.day=1,e.month++,e.month>12&&(e.month=1,e.year++)),e}function tc(e){return e.day--,e.weekday=(e.weekday+6)%7,e.day<1&&(e.month--,e.month<1&&(e.year--,e.month=12),e.day=qu(e.year,e.month)),e}function ac(e,t=ec,a=1){for(;--a>=0;)t(e)
return e}function lc(e,t,a=ec,l=6){for(;e.weekday!==t&&--l>=0;)a(e)
return e}function nc(e){const t=`${Zu(e.hour,2)}:${Zu(e.minute,2)}`,a=e.date
return new Date(`${a}T${t}:00+00:00`)}function oc(e,t,a,l,n=42,o=0){const r=Lu(t),i=[]
let s=Xu(e),u=0,c=u===r
if(r<Lu(e))throw new Error("End date is earlier than start date.")
for(;(!c||i.length<o)&&i.length<n;){if(u=Lu(s),c=c||u===r,0===l[s.weekday]){s=ec(s)
continue}const e=Xu(s)
Ku(e),Hu(e,a),i.push(e),s=ac(s,ec,l[s.weekday])}if(!i.length)throw new Error("No dates found using specified start date, end date, and weekdays.")
return i}function rc(e,t){const a=(e,t)=>""
return"undefined"==typeof Intl||void 0===Intl.DateTimeFormat?a:(a,l)=>{try{return new Intl.DateTimeFormat(e||void 0,t(a,l)).format(nc(a))}catch(e){return""}}}function ic(e){const t=e.slice(-2).toUpperCase()
switch(!0){case"GB-alt-variant"===e:return{firstDay:0,firstWeekSize:4}
case"001"===e:return{firstDay:1,firstWeekSize:1}
case"AG AS BD BR BS BT BW BZ CA CO DM DO ET GT GU HK HN ID IL IN JM JP KE\n    KH KR LA MH MM MO MT MX MZ NI NP PA PE PH PK PR PY SA SG SV TH TT TW UM US\n    VE VI WS YE ZA ZW".includes(t):return{firstDay:0,firstWeekSize:1}
case"AI AL AM AR AU AZ BA BM BN BY CL CM CN CR CY EC GE HR KG KZ LB LK LV\n    MD ME MK MN MY NZ RO RS SI TJ TM TR UA UY UZ VN XK".includes(t):return{firstDay:1,firstWeekSize:1}
case"AD AN AT AX BE BG CH CZ DE DK EE ES FI FJ FO FR GB GF GP GR HU IE IS\n    IT LI LT LU MC MQ NL NO PL RE RU SE SK SM VA".includes(t):return{firstDay:1,firstWeekSize:4}
case"AE AF BH DJ DZ EG IQ IR JO KW LY OM QA SD SY".includes(t):return{firstDay:6,firstWeekSize:1}
case"MV"===t:return{firstDay:5,firstWeekSize:1}
case"PT"===t:return{firstDay:0,firstWeekSize:4}
default:return null}}function sc(e,t,l){let n=(l??ic(t)?.firstDay??0)%7;[0,1,2,3,4,5,6].includes(n)||(a("Invalid firstDayOfWeek, expected discrete number in range [0-6]"),n=0)
const o=new Date(e)
for(;o.getDay()!==n;)o.setDate(o.getDate()-1)
return o}function uc(e){return new Date(e.getFullYear(),e.getMonth(),1)}function cc(e){return new Date(e.getFullYear(),e.getMonth()+1,0)}const dc=/^([12]\d{3}-([1-9]|0[1-9]|1[0-2])-([1-9]|0[1-9]|[12]\d|3[01]))$/
function vc(e){if(null==e)return new Date
if(e instanceof Date)return e
if("string"==typeof e){let t
if(dc.test(e))return function(e){const t=e.split("-").map(Number)
return new Date(t[0],t[1]-1,t[2])}(e)
if(t=Date.parse(e),!isNaN(t))return new Date(t)}return null}const pc=new Date(2e3,0,2)
function mc(e,t,a,l){const n=vc(e)??new Date,o=l?.[t]
if("function"==typeof o)return o(n,t,a)
let r={}
switch(t){case"fullDate":r={year:"numeric",month:"short",day:"numeric"}
break
case"fullDateWithWeekday":r={weekday:"long",year:"numeric",month:"long",day:"numeric"}
break
case"normalDate":return`${n.getDate()} ${new Intl.DateTimeFormat(a,{month:"long"}).format(n)}`
case"normalDateWithWeekday":r={weekday:"short",day:"numeric",month:"short"}
break
case"shortDate":r={month:"short",day:"numeric"}
break
case"year":r={year:"numeric"}
break
case"month":r={month:"long"}
break
case"monthShort":r={month:"short"}
break
case"monthAndYear":r={month:"long",year:"numeric"}
break
case"monthAndDate":r={month:"long",day:"numeric"}
break
case"weekday":r={weekday:"long"}
break
case"weekdayShort":r={weekday:"short"}
break
case"dayOfMonth":return new Intl.NumberFormat(a).format(n.getDate())
case"hours12h":r={hour:"numeric",hour12:!0}
break
case"hours24h":r={hour:"numeric",hour12:!1}
break
case"minutes":r={minute:"numeric"}
break
case"seconds":r={second:"numeric"}
break
case"fullTime":r={hour:"numeric",minute:"numeric"}
break
case"fullTime12h":r={hour:"numeric",minute:"numeric",hour12:!0}
break
case"fullTime24h":r={hour:"numeric",minute:"numeric",hour12:!1}
break
case"fullDateTime":r={year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"numeric"}
break
case"fullDateTime12h":r={year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"numeric",hour12:!0}
break
case"fullDateTime24h":r={year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"numeric",hour12:!1}
break
case"keyboardDate":r={year:"numeric",month:"2-digit",day:"2-digit"}
break
case"keyboardDateTime":return r={year:"numeric",month:"2-digit",day:"2-digit",hour:"numeric",minute:"numeric"},new Intl.DateTimeFormat(a,r).format(n).replace(/, /g," ")
case"keyboardDateTime12h":return r={year:"numeric",month:"2-digit",day:"2-digit",hour:"numeric",minute:"numeric",hour12:!0},new Intl.DateTimeFormat(a,r).format(n).replace(/, /g," ")
case"keyboardDateTime24h":return r={year:"numeric",month:"2-digit",day:"2-digit",hour:"numeric",minute:"numeric",hour12:!1},new Intl.DateTimeFormat(a,r).format(n).replace(/, /g," ")
default:r=o??{timeZone:"UTC",timeZoneName:"short"}}return new Intl.DateTimeFormat(a,r).format(n)}function fc(e,t){const a=new Date(e)
return a.setDate(a.getDate()+t),a}function gc(e){return e.getFullYear()}function hc(e,t,a,l){const n=ic(t),o=a??n?.firstDay??0,r=n?.firstWeekSize??1
return void 0!==l?function(e,t,a,l){const n=(7+l-a)%7,o=sc(e,t,a),r=fc(o,6)
function i(e){return(7+new Date(e,0,1).getDay()-a)%7}let s=gc(o)
s<gc(r)&&i(s+1)<=n&&s++
const u=new Date(s,0,1),c=i(s),d=fc(u,c<=n?-c:7-c)
return 1+wc(Sc(o),Vc(d),"weeks")}(e,t,o,l):function(e,t,a,l){const n=sc(e,t,a),o=fc(sc(e,t,a),6)
function r(e){const l=new Date(e,0,1)
return 7-wc(l,sc(l,t,a),"days")}let i=gc(n)
i<gc(o)&&r(i+1)>=l&&i++
const s=new Date(i,0,1),u=r(i),c=fc(s,u>=l?u-7:u)
return 1+wc(Sc(n),Vc(c),"weeks")}(e,t,o,r)}function yc(e,t){return e.getTime()>t.getTime()}function bc(e,t){return e.getTime()===t.getTime()}function wc(e,t,a){const l=new Date(e),n=new Date(t)
switch(a){case"years":return l.getFullYear()-n.getFullYear()
case"quarters":return Math.floor((l.getMonth()-n.getMonth()+12*(l.getFullYear()-n.getFullYear()))/4)
case"months":return l.getMonth()-n.getMonth()+12*(l.getFullYear()-n.getFullYear())
case"weeks":return Math.floor((l.getTime()-n.getTime())/6048e5)
case"days":return Math.floor((l.getTime()-n.getTime())/864e5)
case"hours":return Math.floor((l.getTime()-n.getTime())/36e5)
case"minutes":return Math.floor((l.getTime()-n.getTime())/6e4)
case"seconds":return Math.floor((l.getTime()-n.getTime())/1e3)
default:return l.getTime()-n.getTime()}}function Vc(e){return new Date(e.getFullYear(),e.getMonth(),e.getDate(),0,0,0,0)}function Sc(e){return new Date(e.getFullYear(),e.getMonth(),e.getDate(),23,59,59,999)}class kc{constructor(e){this.locale=e.locale,this.formats=e.formats}date(e){return vc(e)}toJsDate(e){return e}toISO(e){return function(e,t){const a=e.toJsDate(t)
return`${a.getFullYear()}-${oe(String(a.getMonth()+1),2,"0")}-${oe(String(a.getDate()),2,"0")}`}(this,e)}parseISO(e){return function(e){const[t,a,l]=e.split("-").map(Number)
return new Date(t,a-1,l)}(e)}addMinutes(e,t){return function(e,t){const a=new Date(e)
return a.setMinutes(a.getMinutes()+t),a}(e,t)}addHours(e,t){return function(e,t){const a=new Date(e)
return a.setHours(a.getHours()+t),a}(e,t)}addDays(e,t){return fc(e,t)}addWeeks(e,t){return function(e,t){const a=new Date(e)
return a.setDate(a.getDate()+7*t),a}(e,t)}addMonths(e,t){return function(e,t){const a=new Date(e)
return a.setDate(1),a.setMonth(a.getMonth()+t),a}(e,t)}getWeekArray(e,t){const a=void 0!==t?Number(t):void 0
return function(e,t,a){const l=[]
let n=[]
const o=uc(e),r=cc(e),i=a??ic(t)?.firstDay??0,s=(o.getDay()-i+7)%7,u=(r.getDay()-i+7)%7
for(let e=0;e<s;e++){const t=new Date(o)
t.setDate(t.getDate()-(s-e)),n.push(t)}for(let t=1;t<=r.getDate();t++){const a=new Date(e.getFullYear(),e.getMonth(),t)
n.push(a),7===n.length&&(l.push(n),n=[])}for(let e=1;e<7-u;e++){const t=new Date(r)
t.setDate(t.getDate()+e),n.push(t)}return n.length>0&&l.push(n),l}(e,this.locale,a)}startOfWeek(e,t){const a=void 0!==t?Number(t):void 0
return sc(e,this.locale,a)}endOfWeek(e){return function(e,t){const a=new Date(e),l=((ic(t)?.firstDay??0)+6)%7
for(;a.getDay()!==l;)a.setDate(a.getDate()+1)
return a}(e,this.locale)}startOfMonth(e){return uc(e)}endOfMonth(e){return cc(e)}format(e,t){return mc(e,t,this.locale,this.formats)}isEqual(e,t){return bc(e,t)}isValid(e){return function(e){const t=new Date(e)
return t instanceof Date&&!isNaN(t.getTime())}(e)}isWithinRange(e,t){return function(e,t){return bc(e,t[0])||bc(e,t[1])||yc(e,t[0])&&function(e,t){return e.getTime()<t.getTime()}(e,t[1])}(e,t)}isAfter(e,t){return yc(e,t)}isAfterDay(e,t){return function(e,t){return yc(Vc(e),Vc(t))}(e,t)}isBefore(e,t){return!yc(e,t)&&!bc(e,t)}isSameDay(e,t){return function(e,t){return e.getDate()===t.getDate()&&e.getMonth()===t.getMonth()&&e.getFullYear()===t.getFullYear()}(e,t)}isSameMonth(e,t){return function(e,t){return e.getMonth()===t.getMonth()&&e.getFullYear()===t.getFullYear()}(e,t)}isSameYear(e,t){return function(e,t){return e.getFullYear()===t.getFullYear()}(e,t)}setMinutes(e,t){return function(e,t){const a=new Date(e)
return a.setMinutes(t),a}(e,t)}setHours(e,t){return function(e,t){const a=new Date(e)
return a.setHours(t),a}(e,t)}setMonth(e,t){return function(e,t){const a=new Date(e)
return a.setMonth(t),a}(e,t)}setDate(e,t){return function(e,t){const a=new Date(e)
return a.setDate(t),a}(e,t)}setYear(e,t){return function(e,t){const a=new Date(e)
return a.setFullYear(t),a}(e,t)}getDiff(e,t,a){return wc(e,t,a)}getWeekdays(e,t){const a=void 0!==e?Number(e):void 0
return function(e,t,a){const l=t??ic(e)?.firstDay??0
return C(7).map(t=>{const n=new Date(pc)
return n.setDate(pc.getDate()+l+t),new Intl.DateTimeFormat(e,{weekday:a??"narrow"}).format(n)})}(this.locale,a,t)}getYear(e){return gc(e)}getMonth(e){return function(e){return e.getMonth()}(e)}getWeek(e,t,a){const l=void 0!==t?Number(t):void 0,n=void 0!==a?Number(a):void 0
return hc(e,this.locale,l,n)}getDate(e){return function(e){return e.getDate()}(e)}getNextMonth(e){return function(e){return new Date(e.getFullYear(),e.getMonth()+1,1)}(e)}getPreviousMonth(e){return function(e){return new Date(e.getFullYear(),e.getMonth()-1,1)}(e)}getHours(e){return function(e){return e.getHours()}(e)}getMinutes(e){return function(e){return e.getMinutes()}(e)}startOfDay(e){return Vc(e)}endOfDay(e){return Sc(e)}startOfYear(e){return function(e){return new Date(e.getFullYear(),0,1)}(e)}endOfYear(e){return function(e){return new Date(e.getFullYear(),11,31)}(e)}}const xc=Symbol.for("vuetify:date-options"),Nc=Symbol.for("vuetify:date-adapter")
function Cc(e,a){const l=t.reactive(f(e.adapter)?new e.adapter({locale:e.locale[a.current.value]??a.current.value,formats:e.formats}):e.adapter)
return t.watch(a.current,t=>{l.locale=e.locale[t]??t??l.locale}),l}function Ec(){const e=t.inject(xc)
if(!e)throw new Error("[Vuetify] Could not find injected date options")
return Cc(e,Ha())}const Ic=Tt({start:{type:[String,Number,Date],validate:$u,default:()=>zu(new Date).date},end:{type:[String,Number,Date],validate:$u},weekdays:{type:[Array,String],default:()=>[0,1,2,3,4,5,6],validate:function(e){if(g(e)&&(e=e.split(",")),Array.isArray(e)){const t=e.map(e=>parseInt(e))
if(t.length>7||0===t.length)return!1
const a={}
let l=!1
for(let e=0;e<t.length;e++){const n=t[e]
if(!isFinite(n)||n<0||n>=7)return!1
if(e>0){const a=n-t[e-1]
if(a<0){if(l)return!1
l=!0}else if(0===a)return!1}if(a[n])return!1
a[n]=!0}return!0}return!1}},firstDayOfWeek:[Number,String],firstDayOfYear:[Number,String],weekdayFormat:{type:Function,default:null},dayFormat:{type:Function,default:null},format:String,locale:String,now:{type:String,validator:$u},type:{type:String,default:"month"}},"VCalendar-base")
function Ac(e){const{times:a,updateTimes:l}=function(e){const a=t.reactive({now:Mu("0000-00-00 00:00",!0),today:Mu("0000-00-00",!0)}),l=t.computed(()=>e.now&&$u(e.now)?Mu(e.now,!0):null)
function n(){a.now.present=a.today.present=!0,a.now.past=a.today.past=!1,a.now.future=a.today.future=!1}function o(){return zu(new Date)}function r(e,t){e.date!==t.date&&(t.year=e.year,t.month=e.month,t.day=e.day,t.weekday=e.weekday,t.date=e.date)}function i(e,t){e.time!==t.time&&(t.hour=e.hour,t.minute=e.minute,t.time=e.time)}function s(){const e=l.value||o()
r(e,a.now),i(e,a.now),r(e,a.today)}return t.watch(l,s),s(),n(),{times:a,parsedNow:l,updateTimes:s,setPresent:n,getNow:o,updateDay:r,updateTime:i}}({now:e.now}),n=Wa(e),o=Ec(),r=t.computed(()=>"month"===e.type?Du(Mu(e.start,!0)):Mu(e.start,!0)),i=t.computed(()=>{const t=r.value,a=e.end&&Mu(e.end)||t,l=ju(a)<ju(t)?t:a
return"month"===e.type?Bu(l):l}),s=t.computed(()=>$u(e.modelValue)?Mu(e.modelValue,!0):r.value||a.today),u=t.computed(()=>{const t=Array.isArray(e.weekdays)?e.weekdays:(e.weekdays||"").split(",").map(e=>parseInt(e,10)),a=o.toJsDate(o.startOfWeek(o.date(),e.firstDayOfWeek)).getDay()
return[...t.toSorted().filter(e=>e>=a),...t.toSorted().filter(e=>e<a)]}),c=t.computed(()=>{const t=s.value,a=parseInt(String(e.categoryDays))||1
switch(e.type){case"day":return[t.weekday]
case"4day":return[t.weekday,(t.weekday+1)%7,(t.weekday+2)%7,(t.weekday+3)%7]
case"category":return Array.from({length:a},(e,a)=>(t.weekday+a)%7)
default:return u.value}}),d=t.computed(()=>function(e){const t=[1,1,1,1,1,1,1],a=[0,0,0,0,0,0,0]
for(let t=0;t<e.length;t++)a[e[t]]=1
for(let e=0;e<7;e++){let l=1
for(let t=1;t<7&&!a[(e+t)%7];t++)l++
t[e]=a[e]*l}return t}(u.value)),v=t.computed(()=>oc(r.value,i.value,a.today,d.value)),p=t.computed(()=>e.dayFormat?e.dayFormat:rc(n.current.value,()=>({timeZone:"UTC",day:"numeric"}))),m=t.computed(()=>e.weekdayFormat?e.weekdayFormat:rc(n.current.value,(e,t)=>({timeZone:"UTC",weekday:t?"short":"long"})))
return{times:a,locale:n,parsedValue:s,parsedWeekdays:u,effectiveWeekdays:c,weekdaySkips:d,parsedStart:r,parsedEnd:i,days:v,dayFormatter:p,weekdayFormatter:m,getColorProps:function(e){return jl(e)},getRelativeClasses:function(e,t=!1){return{"v-present":e.present,"v-past":e.past,"v-future":e.future,"v-outside":t}},getWeekNumber:function(t){return o.getWeek(o.date(t.date),e.firstDayOfWeek,e.firstDayOfYear)},getStartOfWeek:function(e){return function(e,t,a){const l=Xu(e)
return lc(l,t[0],tc),Ku(l),a&&Hu(l,a,l.hasTime),l}(e,u.value,a.today)},getEndOfWeek:function(e){return function(e,t,a){const l=Xu(e)
return lc(l,t[t.length-1]),Ku(l),a&&Hu(l,a,l.hasTime),l}(e,u.value,a.today)},getFormatter:function(e){return rc(n.current.value,()=>e)},updateTimes:l}}const Pc=Tt({maxDays:{type:Number,default:7},intervalHeight:{type:[Number,String],default:48,validate:Tu},intervalWidth:{type:[Number,String],default:60,validate:Tu},intervalMinutes:{type:[Number,String],default:60,validate:Tu},firstInterval:{type:[Number,String],default:0,validate:Tu},firstTime:{type:[Number,String,Object],validate:function(e){return h(e)&&isFinite(e)||!!Pu.exec(e)||b(e)&&isFinite(e.hour)&&isFinite(e.minute)}},intervalCount:{type:[Number,String],default:24,validate:Tu},intervalFormat:{type:Function,default:null},intervalStyle:{type:Function,default:null},showIntervalLabel:{type:Function,default:null}},"VCalendar-intervals")
function _c(e){const a=Ac(e),l=t.shallowRef(),n=t.computed(()=>parseInt(String(e.firstInterval||0))),o=t.computed(()=>parseInt(String(e.intervalMinutes||60))),r=t.computed(()=>parseInt(String(e.intervalCount||24))),i=t.computed(()=>parseFloat(String(e.intervalHeight||48))),s=t.computed(()=>Fu(e.firstTime)),u=t.computed(()=>{const e=s.value
return!1!==e&&e>=0&&e<=1440?e:n.value*o.value}),c=t.computed(()=>{const e=Math.ceil((1440-u.value)/o.value)
return ae(r.value,0,e)}),d=t.computed(()=>c.value*i.value),v=t.computed(()=>oc(a.parsedStart.value,a.parsedEnd.value,a.times.today,a.weekdaySkips.value,e.maxDays)),p=t.computed(()=>{const e=v.value,t=u.value,l=o.value,n=c.value,r=a.times.now
return e.map(e=>function(e,t,a,l,n){const o=[]
for(let r=0;r<l;r++){const l=t+r*a,i=Xu(e)
o.push(Yu(i,l,n))}return o}(e,t,l,n,r))}),m=t.computed(()=>{if(e.intervalFormat)return e.intervalFormat
const t="ampm"===e.format||"24hr"!==e.format&&void 0,l="24hr"===e.format?"2-digit":"numeric"
return rc(a.locale.current.value,(e,a)=>a?0===e.minute?{timeZone:"UTC",hour:l,hour12:t}:{timeZone:"UTC",hour:l,minute:"2-digit",hour12:t}:{timeZone:"UTC",hour:"2-digit",minute:"2-digit",hour12:t})})
function f(e){const t=new He(e.currentTarget),a=e,l=e,n=a.changedTouches||a.touches,o=n&&n[0]?n[0]:l
return(Ue([o.clientX,o.clientY]).y-t.top)/i.value}function g(e){return e/o.value*i.value}function h(e,t=!1){const a=!1!==t
let l=w(e,y(t)?void 0:t)
return!1===l||(l*=d.value,a?l<0?l=0:l>d.value&&(l=d.value):l<0?l+=d.value:l>d.value&&(l-=d.value)),l}function w(e,t){let a=Fu(e)
if(!1===a)return!1
const l=c.value*o.value
if(t&&b(e)&&"day"in e){a+=(Lu(e)-Lu(t))*l}return(a-u.value)/l}return{...a,scrollAreaRef:l,parsedFirstInterval:n,parsedIntervalMinutes:o,parsedIntervalCount:r,parsedIntervalHeight:i,parsedFirstTime:s,firstMinute:u,bodyHeight:d,days:v,intervals:p,intervalFormatter:m,showIntervalLabelDefault:function(e){const t=p.value[0][0]
return!(t.hour===e.hour&&t.minute===e.minute)},intervalStyleDefault:function(e){},getIntervalAtEvent:f,getTimestampAtEvent:function(e,t){const l=Xu(t),n=Math.floor(f(e)*o.value)
return Yu(l,u.value+n,a.times.now)},getSlotScope:function(e){const t=Xu(e)
return t.timeToY=h,t.timeDelta=w,t.minutesToPixels=g,t.week=v.value,t.intervalRange=[u.value,u.value+c.value*o.value],t},scrollToTime:function(e){const t=h(e),a=l.value
return!(!1===t||!a)&&(a.scrollTop=t,!0)},minutesToPixels:g,timeToY:h,timeDelta:w}}const Rc=Tt({intervalHighlight:{type:[Boolean,String],default:!1}},"interval-highlight")
function Dc(e,a){const l=t.shallowRef(null),{textColorClasses:n,textColorStyles:o}=Ll(()=>g(e.intervalHighlight)&&e.intervalHighlight?e.intervalHighlight:"surface-variant")
return{hoveredTime:l,onMousemove:function(t){e.intervalHighlight&&(l.value=function(e){const t=Math.floor(a.getIntervalAtEvent(e)),l=a.intervals.value[0]
return!l||t<0||t>=l.length?null:l[t].time}(t))},onMouseleave:function(){e.intervalHighlight&&(l.value=null)},isHighlighted:function(t){return!!e.intervalHighlight&&l.value===t.time},genUnderlay:function(){if(e.intervalHighlight)return t.createElementVNode("div",{class:t.normalizeClass(["v-calendar-daily__day-interval__underlay",n.value]),style:t.normalizeStyle(o.value)},null)}}}const Bc={mounted:function(e,t){const a=t.value,l={passive:!t.modifiers?.active}
window.addEventListener("resize",a,l),e._onResize=Object(e._onResize),e._onResize[t.instance.$.uid]={handler:a,options:l},t.modifiers?.quiet||a()},unmounted:function(e,t){if(!e._onResize?.[t.instance.$.uid])return
const{handler:a,options:l}=e._onResize[t.instance.$.uid]
window.removeEventListener("resize",a,l),delete e._onResize[t.instance.$.uid]}},Tc=Gt({name:"VCalendarDaily",directives:{vResize:Bc},props:{color:String,shortWeekdays:{type:Boolean,default:!0},shortIntervals:{type:Boolean,default:!0},hideHeader:Boolean,...Rc(),...Ic(),...Pc()},setup(e,{slots:a,attrs:l}){const n=t.ref(0),o=t.ref(),r=_c(e),i=Dc(e,r)
function s(){t.nextTick(u)}function u(){n.value=c()}function c(){return r.scrollAreaRef.value&&o.value?r.scrollAreaRef.value.offsetWidth-o.value.offsetWidth:0}function d(){const l=z(e.intervalWidth)
return t.createElementVNode("div",{class:"v-calendar-daily__intervals-head",style:{width:l}},[a["interval-header"]?.()])}function v(e,a){const n=la(l,":day",t=>({nativeEvent:t,...r.getSlotScope(e)}))
return t.createElementVNode("div",t.mergeProps({key:e.date,class:["v-calendar-daily_head-day",r.getRelativeClasses(e)]},n),[m(e),f(e),p(e,a)])}function p(e,t){return a["day-header"]?.({week:r.days.value,...e,index:t})??[]}function m(a){const l=a.present?e.color:void 0
return t.createElementVNode("div",t.mergeProps(r.getColorProps({text:l}),{class:"v-calendar-daily_head-weekday"}),[r.weekdayFormatter.value(a,e.shortWeekdays)])}function f(e){return t.createElementVNode("div",{class:"v-calendar-daily_head-day-label"},[a["day-label-header"]?.(e)??g(e)])}function g(a){const n=la(l,":date",e=>({nativeEvent:e,...a}))
return t.createVNode(Iu,t.mergeProps({active:a.present,activeColor:e.color,variant:"outlined",baseVariant:"text","onUpdate:active":ke},n),{default:()=>[r.dayFormatter.value(a,!1)]})}function h(e){return a["day-body"]?.(r.getSlotScope(e))??[]}function y(e){return r.intervals.value[e].map(b)}function b(l){const n=z(e.intervalHeight),o=e.intervalStyle||r.intervalStyleDefault
return t.createElementVNode("div",{class:t.normalizeClass(["v-calendar-daily__day-interval",{"v-calendar-daily__day-interval--hover":i.isHighlighted(l)}]),key:l.time,style:t.normalizeStyle([{height:n},o(l)])},[i.genUnderlay(),a.interval?.(r.getSlotScope(l))])}function w(){const a=z(e.intervalWidth),n=la(l,":interval",e=>({nativeEvent:e,...r.getTimestampAtEvent(e,r.parsedStart.value)}))
return t.createElementVNode("div",t.mergeProps({class:"v-calendar-daily__intervals-body",style:{width:a}},n),[V()])}function V(){return r.intervals.value.length?r.intervals.value[0].map(S):null}function S(a){const l=z(e.intervalHeight),n=e.shortIntervals,o=(e.showIntervalLabel||r.showIntervalLabelDefault)(a)?r.intervalFormatter.value(a,n):void 0
return t.createElementVNode("div",{key:a.time,class:"v-calendar-daily__interval",style:{height:l}},[t.createElementVNode("div",{class:"v-calendar-daily__interval-text"},[o])])}return t.onMounted(s),sa(()=>t.withDirectives(t.createElementVNode("div",{class:t.normalizeClass(["v-calendar-daily",l.class]),onDragstart:e=>e.preventDefault()},[e.hideHeader?void 0:t.createElementVNode("div",{class:"v-calendar-daily__head",style:{marginRight:n.value+"px"}},[d(),r.days.value.map(v)]),t.createElementVNode("div",{class:"v-calendar-daily__body"},[t.createElementVNode("div",{ref:r.scrollAreaRef,class:"v-calendar-daily__scroll-area"},[t.createElementVNode("div",{ref:o,class:"v-calendar-daily__pane",style:{height:z(r.bodyHeight.value)}},[t.createElementVNode("div",{class:"v-calendar-daily__day-container"},[w(),a.days?.()??r.days.value.map((e,a)=>{const n=la(l,":time",t=>({nativeEvent:t,...r.getSlotScope(r.getTimestampAtEvent(t,e))}))
return t.createElementVNode("div",t.mergeProps({key:e.date,class:["v-calendar-daily__day",r.getRelativeClasses(e)]},n,{onMousemove:i.onMousemove,onMouseleave:i.onMouseleave}),[y(a),h(e)])})])])])])]),[[Bc,u,void 0,{quiet:!0}]])),{...r,scrollPush:n,pane:o,init:s,onResize:u,getScrollPush:c}}})
function Fc(e,t){return g(e)?e.split(/\s*,\s/):Array.isArray(e)?e.map(e=>{if(g(e))return e
const a=g(e.categoryName)?e.categoryName:function(e,t){return f(t)?t(e):g(t)&&b(e)?e[t]:g(e)?e:""}(e,t)
return{...e,categoryName:a}}):[]}const $c=Gt({name:"VCalendarCategory",props:{categories:{type:[Array,String],default:""},categoryText:[String,Function],categoryForInvalid:{type:String,default:""},...Rc(),...Ic(),...Pc()},setup(e,{slots:a,attrs:l}){const n=_c(e),o=Dc(e,n),r=t.computed(()=>Fc(e.categories,e.categoryText))
function i(t,a){return{...t,category:b(a)&&a.categoryName===e.categoryForInvalid?null:a}}function s(e){return t.createElementVNode("div",{class:"v-calendar-category__columns"},[r.value.map(o=>function(e,o){const r=b(o.category)?o.category.categoryName:o.category,s=la(l,":dayCategory",()=>i(n.getSlotScope(e)||e,o.category))
return t.createElementVNode("div",t.mergeProps({class:"v-calendar-category__column-header"},s),[a.category?.(o)??u(r),a["day-header"]?.(o)])}(e,i(e,o)))])}function u(a){return t.createElementVNode("div",{class:"v-calendar-category__category"},[null===a?e.categoryForInvalid:a])}function c(){const e=[]
return n.days.value.forEach((a,i)=>{const s=new Array(r.value.length||1)
s.fill(a),e.push(...s.map((e,a)=>function(e,a,i){const s=r.value[i],u=la(l,":time",t=>n.getSlotScope(n.getTimestampAtEvent(t,e)))
return t.createElementVNode("div",t.mergeProps({key:e.date+"-"+i,class:["v-calendar-daily__day",n.getRelativeClasses(e)]},u,{onMousemove:o.onMousemove,onMouseleave:o.onMouseleave}),[d(a,s),v(e,s)])}(e,i,a)))}),e}function d(l,r){return n.intervals.value[l].map(l=>function(l,r){const s=z(e.intervalHeight),u=e.intervalStyle||n.intervalStyleDefault
return t.createElementVNode("div",{key:l.time,class:t.normalizeClass(["v-calendar-daily__day-interval",{"v-calendar-daily__day-interval--hover":o.isHighlighted(l)}]),style:t.normalizeStyle([{height:s},u({...l,category:r})])},[o.genUnderlay(),a.interval?.(i(n.getSlotScope(l),r))])}(l,r))}function v(e,a){return t.createElementVNode("div",{class:"v-calendar-category__columns"},[p(e,a)])}function p(e,o){const r=la(l,":timeCategory",t=>i(n.getSlotScope(n.getTimestampAtEvent(t,e)),o))
return t.createElementVNode("div",t.mergeProps({class:"v-calendar-category__column"},r),[a["day-body"]?.(i(n.getSlotScope(e),o))])}return sa(()=>t.createVNode(Tc,t.mergeProps({class:["v-calendar-daily","v-calendar-category"]},e),{...a,days:c,"day-header":s})),{...n,parsedCategories:r}}}),Mc={control:"ctrl",command:"cmd",option:"alt",up:"arrowup",down:"arrowdown",left:"arrowleft",right:"arrowright",esc:"escape",spacebar:" ",space:" ",return:"enter",del:"delete",plus:"+",slash:"/",underscore:"_",minus:"-",hyphen:"-"}
class zc extends Error{}function Lc(e){let t=0
try{const e=function(){const e=[r()]
for(;"-"===l();)n(),e.push(r())
return 1===e.length?e[0]:{type:"sequence",parts:e}}()
if(!o())throw new zc(`Unexpected character '${l()}' at position ${t}`)
return e}catch(l){if(l instanceof zc)return a(`Invalid hotkey combination: ${l.message}\n  ${e}\n  ${" ".repeat(t)}^`),""
throw l}function l(a=0){return t+a<e.length?e[t+a]:null}function n(){if(t>=e.length)throw new zc("Unexpected end of input")
return e[t++]}function o(){return t>=e.length}function r(){const e=[i()]
for(;"/"===l();)n(),e.push(i())
return 1===e.length?e[0]:{type:"alternate",parts:e}}function i(){const e=[s()]
for(;pe(["+","_"],l());)n(),e.push(s())
return 1===e.length?e[0]:{type:"combo",parts:e}}function s(){const e=l()
if(!g(e))throw new zc("Unexpected end of input")
const a=l(1)
if(Oc(e)&&g(a)&&!Oc(a))throw new zc(`Unexpected separator '${e}' at position ${t}`)
const r=n()
if(Oc(r))return r
const i=[r]
for(;!o()&&!Oc(l())&&" "!==l();)i.push(n())
return function(e){const t=e.toLowerCase()
return Mc[t]||t}(i.join(""))}}function Oc(e){return pe(["-","/","+","_"],e)}const jc=["ctrl","shift","alt","meta","cmd"],Hc=new Set(jc)
function Wc(e){return Hc.has(e)}const Uc=Object.fromEntries(jc.map(e=>[e,!1]))
function Yc(e,t,a){if(!g(t)&&"alternate"===t.type)return t.parts.some(t=>Yc(e,t,a))
const{modifiers:l,actualKey:n}=function(e){const t=g(e)?[e]:e.parts,a={...Uc}
let l
for(const e of t)Wc(e)?a[e]=!0:l=e
return{modifiers:a,actualKey:l}}(t),o=l.ctrl||!a&&(l.cmd||l.meta),r=a&&(l.cmd||l.meta)
return e.ctrlKey===o&&e.metaKey===r&&e.shiftKey===l.shift&&e.altKey===l.alt&&e.key.toLowerCase()===n?.toLowerCase()}const Gc={"credit-card":"#### - #### - #### - ####",date:"##/##/####","date-time":"##/##/#### ##:##","iso-date":"####-##-##","iso-date-time":"####-##-## ##:##",phone:"(###) ### - ####",social:"###-##-####",time:"##:##","time-with-seconds":"##:##:##"},Kc={"#":{pattern:/[0-9]/},A:{pattern:/[A-Z]/i,convert:e=>e.toUpperCase()},a:{pattern:/[a-z]/i,convert:e=>e.toLowerCase()},N:{pattern:/[0-9A-Z]/i,convert:e=>e.toUpperCase()},n:{pattern:/[0-9a-z]/i,convert:e=>e.toLowerCase()},X:{pattern:/[-!$%^&*()_+|~=`{}[\]:";'<>?,./\\ ]/}}
const qc=Gt({name:"VCalendarWeekly",props:{minWeeks:{validate:Tu,default:1},monthFormat:Function,showWeek:Boolean,color:String,shortWeekdays:{type:Boolean,default:!0},showMonthOnFirst:{type:Boolean,default:!0},shortMonths:{type:Boolean,default:!0},hideHeader:Boolean,...Ic()},setup(e,{slots:a,attrs:l}){const n=Ac(e),o=al(),r=t.computed(()=>parseInt(String(e.minWeeks))),i=t.computed(()=>{const e=r.value*n.parsedWeekdays.value.length
return oc(n.getStartOfWeek(n.parsedStart.value),n.getEndOfWeek(n.parsedEnd.value),n.times.today,n.weekdaySkips.value,Number.MAX_SAFE_INTEGER,e)}),s=t.computed(()=>{const e=n.times.today
return oc(n.getStartOfWeek(e),n.getEndOfWeek(e),e,n.weekdaySkips.value,n.parsedWeekdays.value.length,n.parsedWeekdays.value.length)}),u=t.computed(()=>e.monthFormat?e.monthFormat:rc(n.locale.current.value,(e,t)=>({timeZone:"UTC",month:t?"short":"long"})))
function c(e){const t=Lu(e)
return t<Lu(n.parsedStart.value)||t>Lu(n.parsedEnd.value)}function d(){const a=s.value.map(v)
return e.showWeek&&a.unshift(t.createElementVNode("div",{class:"v-calendar-weekly__head-weeknumber"},null)),a}function v(a,l){const o=c(i.value[l]),r=a.present?e.color:void 0
return t.createElementVNode("div",t.mergeProps(n.getColorProps({text:r}),{key:a.date,class:["v-calendar-weekly__head-weekday",n.getRelativeClasses(a,o)],role:"columnheader"}),[n.weekdayFormatter.value(a,e.shortWeekdays)])}function p(){const e=i.value,t=n.parsedWeekdays.value.length,a=[]
for(let l=0;l<e.length;l+=t)a.push(m(e.slice(l,l+t),f(e[l])))
return a}function m(o,r){const i=o.map((e,r)=>function(e,o,r){const i=c(e),s=la(l,":day",t=>({nativeEvent:t,...e}))
return t.createElementVNode("div",t.mergeProps({key:e.date,class:["v-calendar-weekly__day",n.getRelativeClasses(e,i)],role:"cell"},s),[g(e),a.day?.({outside:i,index:o,week:r,...e})])}(e,r,o))
return e.showWeek&&i.unshift(function(e){return t.createElementVNode("div",{class:"v-calendar-weekly__weeknumber"},[t.createElementVNode("small",null,[String(e)])])}(r)),t.createElementVNode("div",{key:o[0].date,class:"v-calendar-weekly__week",role:"row"},[i])}function f(e){return n.getWeekNumber(e)}function g(e){return t.createElementVNode("div",{class:"v-calendar-weekly__day-label"},[a["day-label"]?.(e)??h(e)])}function h(a){const o=1===a.day&&e.showMonthOnFirst,r=la(l,":date",e=>({nativeEvent:e,...a}))
return t.createVNode(Iu,t.mergeProps({active:a.present,activeColor:e.color,variant:"outlined",baseVariant:"text","onUpdate:active":ke},r),{default:()=>[o?u.value(a,e.shortMonths)+" "+n.dayFormatter.value(a,!1):n.dayFormatter.value(a,!1)]})}return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-calendar-weekly",o.themeClasses.value]),onDragstart:e=>e.preventDefault()},[e.hideHeader?void 0:t.createElementVNode("div",{class:"v-calendar-weekly__head",role:"row"},[d()]),p()])),{...n,days:i,todayWeek:s,monthFormatter:u,isOutside:c}}})
function Xc(e,t=0){const a=e.map(e=>({event:e,columnCount:0,column:0,left:0,width:100}))
return a.sort((e,a)=>Math.max(t,e.event.startTimestampIdentifier)-Math.max(t,a.event.startTimestampIdentifier)||a.event.endTimestampIdentifier-e.event.endTimestampIdentifier),a}function Zc(e,t,a,l,n=!0){return n?!(e>=l||t<=a):!(e>l||t<a)}function Qc(e){e.forEach(t=>{t.visuals.forEach(t=>{t.columnCount=e.length})})}function Jc(e){return[e.startTimestampIdentifier,e.endTimestampIdentifier]}function ed(e){return[e.startIdentifier,e.endIdentifier]}function td(e,t){return[Math.max(t,e.startTimestampIdentifier),Math.min(t+864e5,e.endTimestampIdentifier)]}function ad(e){const t={groups:[],min:-1,max:-1,reset:()=>{t.groups=[],t.min=t.max=-1},getVisuals:(a,l,n,o=!1)=>{(a.weekday===e||o)&&t.reset()
const r=Xc(l,ju(a))
return r.forEach(e=>{const[a,l]=n?Jc(e.event):ed(e.event)
t.groups.length>0&&!Zc(a,l,t.min,t.max,n)&&(Qc(t.groups),t.reset())
let o=function(e,t,a,l){for(let n=0;n<e.length;n++){const o=e[n]
let r=!1
if(Zc(t,a,o.start,o.end,l))for(let e=0;e<o.visuals.length;e++){const n=o.visuals[e],[i,s]=l?Jc(n.event):ed(n.event)
if(Zc(t,a,i,s,l)){r=!0
break}}if(!r)return n}return-1}(t.groups,a,l,n);-1===o&&(o=t.groups.length,t.groups.push({start:a,end:l,visuals:[]}))
const r=t.groups[o]
r.visuals.push(e),r.start=Math.min(r.start,a),r.end=Math.max(r.end,l),e.column=o,-1===t.min?(t.min=a,t.max=l):(t.min=Math.min(t.min,a),t.max=Math.max(t.max,l))}),Qc(t.groups),n&&t.reset(),r}}
return t}const ld=100
function nd(e,t){for(const a of e){const{visual:l,parent:n}=a,o=dd(a)+1,r=n?n.visual.left:0,i=ld-r,s=Math.min(5,ld/o),u=od(a,e),c=i/(o-a.index+1),d=i/(o-a.index+(a.sibling?1:0))*u
n&&(l.left=a.sibling?r+c:r+s),l.width=ud(a,e,t)?ld-l.left:Math.min(ld-l.left,1.7*d)}}function od(e,t){if(!e.children.length)return 1
const a=e.index+t.length
return e.children.reduce((e,t)=>Math.min(e,t.index),a)-e.index}function rd(e,t){const a=function(e,t){const a=[]
for(const l of t)Zc(e.start,e.end,l.start,l.end)&&a.push(l.index)
return a}(e,t)
a.sort()
for(let e=0;e<a.length;e++)if(e<a[e])return e
return!1}function id(e,t,a,l,n=!1){const o=[]
for(const n of t)n.index>=a&&n.index<=l&&Zc(e.start,e.end,n.start,n.end)&&o.push(n)
if(n&&o.length>0){const e=o.reduce((e,t)=>Math.min(e,t.index),o[0].index)
return o.filter(t=>t.index===e)}return o}function sd(e,t){let a=null
for(const l of t)Zc(e.start,e.end,l.start,l.end)&&(null===a||l.index>a.index)&&(a=l)
return a}function ud(e,t,a){for(const l of t)if(l!==e&&l.index>e.index&&Zc(e.start,vd(e.start,a),l.start,l.end))return!1
return!0}function cd(e,t){const[a,l]=td(e.event,t)
return{parent:null,sibling:!0,index:0,visual:e,start:a,end:l,children:[]}}function dd(e){let t=e.index
for(const a of e.children){const e=dd(a)
e>t&&(t=e)}return t}function vd(e,t){const a=e%100,l=a+t
return e-a+100*Math.floor(l/60)+l%60}const pd={stack:(e,t,a)=>{const l=ad(t)
return(e,t,n,o)=>{if(!n)return l.getVisuals(e,t,n,o)
const r=ju(e),i=Xc(t,r),s=function(e,t){const a=[]
for(const l of e){const[e,n]=td(l.event,t)
let o=!1
for(const t of a)if(Zc(e,n,t.start,t.end)){t.visuals.push(l),t.end=Math.max(t.end,n),o=!0
break}o||a.push({start:e,end:n,visuals:[l]})}return a}(i,r)
for(const e of s){const t=[]
for(const l of e.visuals){const e=cd(l,r),n=rd(e,t)
if(!1===n){const l=sd(e,t)
l&&(e.parent=l,e.sibling=Zc(e.start,e.end,l.start,vd(l.start,a)),e.index=l.index+1,l.children.push(e))}else{const[l]=id(e,t,n-1,n-1),o=id(e,t,n+1,n+t.length,!0)
e.children=o,e.index=n,l&&(e.parent=l,e.sibling=Zc(e.start,e.end,l.start,vd(l.start,a)),l.children.push(e))
for(const t of o){t.parent===l&&(t.parent=e)
t.index-e.index<=1&&e.sibling&&Zc(e.start,vd(e.start,a),t.start,t.end)&&(t.sibling=!0)}}t.push(e)}nd(t,a)}return i.sort((e,t)=>e.left-t.left||e.event.startTimestampIdentifier-t.event.startTimestampIdentifier),i}},column:(e,t,a)=>{const l=ad(t)
return(e,t,a,n)=>{const o=l.getVisuals(e,t,a,n)
return a&&o.forEach(e=>{e.left=100*e.column/e.columnCount,e.width=100/e.columnCount}),o}}}
function md(e,t){return t>=e.startIdentifier&&t<=e.endIdentifier}function fd(e,t,a,l){return a===e.startIdentifier||l===t.weekday&&md(e,a)}const gd=Tt({events:{type:Array,default:()=>[]},eventStart:{type:String,default:"start"},eventEnd:{type:String,default:"end"},eventTimed:{type:[String,Function],default:"timed"},eventCategory:{type:[String,Function],default:"category"},eventHeight:{type:Number,default:20},eventColor:{type:[String,Function],default:"primary"},eventTextColor:{type:[String,Function]},eventName:{type:[String,Function],default:"name"},eventOverlapThreshold:{type:[String,Number],default:60},eventOverlapMode:{type:[String,Function],default:"stack",validate:e=>e in pd||f(e)},eventMore:{type:Boolean,default:!0},eventMoreText:{type:String,default:"$vuetify.calendar.moreEvents"},eventRipple:{type:[Boolean,Object],default:null},eventMarginBottom:{type:Number,default:1}},"VCalendar-events")
function hd(e,a,l){const n=Ac(e),o=t.computed(()=>!Array.isArray(e.events)||0===e.events.length),r=t.computed(()=>"category"===e.type),i=t.computed(()=>f(e.eventTimed)?e.eventTimed:t=>!!t[e.eventTimed]),s=t.computed(()=>f(e.eventCategory)?e.eventCategory:t=>t[e.eventCategory]),u=t.computed(()=>e.events?e.events.map((t,a)=>function(e,t,a,l,n=!1,o=!1){const r=e[a],i=e[l],s=Mu(r,!0),u=i?Mu(i,!0):s,c=Wu(r)?Uu(s,n):s,d=Wu(i)?Uu(u,n):u,v=Lu(c),p=ju(c),m=Lu(d),f=c.hasTime?0:2359
return{input:e,start:c,startIdentifier:v,startTimestampIdentifier:p,end:d,endIdentifier:m,endTimestampIdentifier:ju(d)+f,allDay:!c.hasTime,index:t,category:o}}(t,a,e.eventStart||"",e.eventEnd||"",i.value(t),!!r.value&&s.value(t))):[]),c=t.computed(()=>parseInt(String(e.eventOverlapThreshold||0))),d=t.computed(()=>f(e.eventTextColor)?e.eventTextColor:()=>e.eventTextColor),v=t.computed(()=>f(e.eventName)?e.eventName:(t,a)=>t.input[e.eventName]||""),p=t.computed(()=>f(e.eventOverlapMode)?e.eventOverlapMode:pd[e.eventOverlapMode]),m=t.computed(()=>n.effectiveWeekdays.value)
function h(t){return f(e.eventColor)?e.eventColor(t):t.color||e.eventColor}const y=t.ref([])
function w(){const e={},t=y.value
return t&&t.length?(t.forEach(t=>{const a=t.getAttribute("data-date")
t.parentElement&&a&&(a in e||(e[a]={parent:t.parentElement,more:null,events:[]}),t.getAttribute("data-more")?e[a].more=t:(e[a].events.push(t),t.style.display=""))}),e):e}function V({event:t},a){const l=e.eventHeight||0,n=e.eventMarginBottom||0,o=Lu(a),i=a.week,s=o===t.startIdentifier
let u=o===t.endIdentifier,c=95
if(!r.value)for(let e=a.index+1;e<i.length;e++){const a=Lu(i[e])
if(!(t.endIdentifier>=a)){u=!0
break}c+=100,u=u||a===t.endIdentifier}return k(t,{eventParsed:t,day:a,start:s,end:u,timed:!1},!1,{class:["v-event",{"v-event-start":s,"v-event-end":u}],style:{height:`${l}px`,width:`calc(${c}% + ${(c-95)/100}px)`,marginBottom:`${n}px`},"data-date":a.date})}function S({event:t,left:a,width:l},n){const o=n.timeDelta(t.start,n),r=n.timeDelta(t.end,n)
if(!1===r||!1===o||r<0||o>=1||function(e,t){return"00:00"===e.end.time&&e.end.date===t.date&&e.start.date!==t.date}(t,n))return!1
const i=Lu(n),s=t.startIdentifier>=i,u=t.endIdentifier>i,c=n.timeToY(t.start,n),d=n.timeToY(t.end,n)
return k(t,{eventParsed:t,day:n,start:s,end:u,timed:!0},!0,{class:"v-event-timed",style:{top:`${c}px`,height:`${Math.max(e.eventHeight||0,d-c)}px`,left:`${a}%`,width:`${l}%`}})}function k(o,r,i,s){const u=a.event,p=d.value(o.input),m=h(o.input),f=o.start.hour<12&&o.end.hour>=12,g=(b=o.start,525600*((w=o.end).year-b.year)+43800*(w.month-b.month)+1440*(w.day-b.day)+60*(w.hour-b.hour)+(w.minute-b.minute)<=c.value)
var b,w
const V=(t,a)=>{const l="ampm"===e.format||"24hr"!==e.format&&void 0
return n.getFormatter({timeZone:"UTC",hour:"24hr"===e.format?"2-digit":"numeric",minute:t.minute>0?"numeric":void 0,hour12:l})(t,!0)},S=()=>V(o.start)+" - "+V(o.end),k=()=>{const e=v.value(o,i)
if(o.start.hasTime){if(i){const a=S(),l=g?", ":t.createElementVNode("br",null,null)
return t.createElementVNode("span",{class:"v-event-summary"},[t.createElementVNode("strong",null,[e]),l,a])}{const a=V(o.start)
return t.createElementVNode("span",{class:"v-event-summary"},[t.createElementVNode("strong",null,[a]),t.createTextVNode(" "),e])}}return t.createElementVNode("span",{class:"v-event-summary"},[e])},N={...r,event:o.input,outside:r.day.outside,singline:g,overlapsNoon:f,formatTime:V,timeSummary:S,eventSummary:k},C=la(l,":event",e=>({...N,nativeEvent:e}))
return t.withDirectives(t.createElementVNode("div",t.mergeProps(n.getColorProps({text:p,background:m}),C,s,{ref_for:!0,ref:y}),[u?.(N)??x(k)]),[[bo,e.eventRipple??!0]])}function x(e){return t.createElementVNode("div",{class:"pl-1"},[e()])}function N(a){const l=(e.eventHeight||0)+(e.eventMarginBottom||0)
return t.createElementVNode("div",{style:{height:`${l}px`},"data-date":a.date,ref_for:!0,ref:y},null)}function C(a){const n=e.eventHeight||0,o=e.eventMarginBottom||0,r=la(l,":more",e=>({nativeEvent:e,...a}))
return t.withDirectives(t.createElementVNode("div",t.mergeProps({class:["v-event-more pl-1",{"v-outside":a.outside}],"data-date":a.date,"data-more":"1",style:{display:"none",height:`${n}px`,marginBottom:`${o}px`},ref_for:!0,ref:y},r),null),[[bo,e.eventRipple??!0]])}function E(e,t){return!r.value||b(t)&&t.categoryName&&t.categoryName===e.category||g(e.category)&&t===e.category||!g(e.category)&&null===t}function I(e){const t=Lu(e),a=m.value[0]
return u.value.filter(l=>fd(l,e,t,a))}function A(e){const t=Lu(e),a=m.value[0]
return u.value.filter(l=>l.allDay&&(r.value?md(l,t):fd(l,e,t,a))&&E(l,e.category))}function P(e){return u.value.filter(t=>!t.allDay&&function(e,t,a){if(a){const l=Ju(Xu(t),a[0]),n=Ju(Xu(t),a[1]),o=e.startTimestampIdentifier<ju(n),r=e.endTimestampIdentifier>ju(l)
return o&&r}return md(e,Lu(t))}(t,e,e.intervalRange)&&E(t,e.category))}return{...n,noEvents:o,parsedEvents:u,parsedEventOverlapThreshold:c,eventTimedFunction:i,eventCategoryFunction:s,eventTextColorFunction:d,eventNameFunction:v,eventModeFunction:p,eventWeekdays:m,categoryMode:r,eventColorFunction:h,eventsRef:y,updateEventVisibility:function(){if(o.value||!e.eventMore)return
const t=e.eventHeight||0,a=w()
for(const l in a){const{parent:o,events:r,more:i}=a[l]
if(!i)break
const s=o.getBoundingClientRect(),u=r.length-1,c=r.map(e=>({event:e,bottom:e.getBoundingClientRect().bottom})).sort((e,t)=>e.bottom-t.bottom)
let d=0
for(let e=0;e<=u;e++){const a=c[e].bottom;(e===u?a>s.bottom:a+t>s.bottom)&&(c[e].event.style.display="none",d++)}d?(i.style.display="",i.innerHTML=n.locale.t(e.eventMoreText,d)):i.style.display="none"}},getEventsMap:w,genDayEvent:V,genTimedEvent:S,genEvent:k,genName:x,genPlaceholder:N,genMore:C,getVisibleEvents:function(){const e=n.days.value,t=Lu(e[0]),a=Lu(e[e.length-1])
return u.value.filter(e=>function(e,t,a){return t<=e.endIdentifier&&a>=e.startIdentifier}(e,t,a))},isEventForCategory:E,getEventsForDay:I,getEventsForDayAll:A,getEventsForDayTimed:P,getScopedSlots:function(){if(o.value)return{...a}
const l=p.value(u.value,m.value[0],c.value),n=e=>!!e,i=(e,t,a,o)=>{const i=t(e),s=l(e,i,o,r.value)
if(o)return s.map(t=>a(t,e)).filter(n)
const u=[]
return s.forEach((t,l)=>{for(;u.length<t.column;)u.push(N(e))
const n=a(t,e)
n&&u.push(n)}),u}
return{...a,day:t=>{let l=i(t,I,V,!1)
if(l&&l.length>0&&e.eventMore&&l.push(C(t)),a.day){const e=a.day(t)
e&&(l=l?l.concat(e):e)}return l},"day-header":e=>{let t=i(e,A,V,!1)
if(a["day-header"]){const l=a["day-header"](e)
l&&(t=t?t.concat(l):l)}return t},"day-body":e=>{const l=i(e,P,S,!0)
let n=[t.createElementVNode("div",{class:"v-event-timed-container"},[l])]
if(a["day-body"]){const t=a["day-body"](e)
t&&(n=n.concat(t))}return n}}}}}const yd=Kt()({name:"VCalendar",directives:{vResize:Bc},props:{modelValue:{type:[String,Number,Date],validate:$u},categoryDays:{type:[Number,String],default:1,validate:e=>isFinite(parseInt(e))&&parseInt(e)>0},categories:{type:[Array,String],default:""},categoryText:{type:[String,Function]},categoryHideDynamic:{type:Boolean},categoryShowAll:{type:Boolean},categoryForInvalid:{type:String,default:""},...Rc(),...Ic(),...gd(),...Pc()},setup(e,{slots:a,attrs:l,emit:n}){const o=t.ref(),r=hd(e,a,l),i=t.ref(null),s=t.ref(null),u=t.computed(()=>parseInt(String(e.categoryDays))||1),c=t.computed(()=>Fc(e.categories,e.categoryText)),d=t.computed(()=>{const t=r.parsedValue.value
let a=null,l=e.maxDays,n=c.value,o=t,i=t
switch(e.type){case"month":a=qc,o=Du(t),i=Bu(t)
break
case"week":a=Tc,o=r.getStartOfWeek(t),i=r.getEndOfWeek(t),l=7
break
case"day":a=Tc,l=1
break
case"4day":a=Tc,i=ac(Xu(i),ec,3),Ku(i),l=4
break
case"custom-weekly":a=qc,o=r.parsedStart.value||t,i=r.parsedEnd.value
break
case"custom-daily":a=Tc,o=r.parsedStart.value||t,i=r.parsedEnd.value
break
case"category":const s=u.value
a=$c,i=ac(Xu(i),ec,s),Ku(i),l=s,n=S(n)
break
default:const c=e.type
throw new Error(`${c} is not a valid Calendar type`)}return{component:a,start:o,end:i,maxDays:l,categories:n}}),v=t.computed(()=>r.effectiveWeekdays.value),p=t.computed(()=>"category"===e.type),m=t.computed(()=>r.getFormatter({timeZone:"UTC",month:"long"})),f=t.computed(()=>r.getFormatter({timeZone:"UTC",month:"short"})),y=t.computed(()=>{const{start:e,end:t}=d.value,a=e.year!==t.year,l=a||e.month!==t.month
return a?f.value(e,!0)+" "+e.year+" - "+f.value(t,!0)+" "+t.year:l?f.value(e,!0)+" - "+f.value(t,!0)+" "+t.year:m.value(e,!1)+" "+e.year})
function w(){const{start:e,end:t}=d.value
i.value&&s.value&&e.date===i.value.date&&t.date===s.value.date||(i.value=e,s.value=t,n("change",{start:e,end:t}))}function V(t=1){const a=Xu(r.parsedValue.value),l=t>0,o=l?ec:tc,i=l?31:1
let s=l?t:-t
for(;--s>=0;)switch(e.type){case"month":a.day=i,o(a)
break
case"week":ac(a,o,7)
break
case"day":ac(a,o,1)
break
case"4day":ac(a,o,4)
break
case"category":ac(a,o,u.value)}Gu(a),Ku(a),Hu(a,r.times.now),e.modelValue instanceof Date?n("update:modelValue",nc(a)):h(e.modelValue)?n("update:modelValue",nc(a).getTime()):n("update:modelValue",a.date),n("moved",a)}function S(t){if(!r.noEvents.value){const a=t.reduce((e,t,a)=>(b(t)&&t.categoryName?e[t.categoryName]={index:a,count:0}:g(t)&&(e[t]={index:a,count:0}),e),{})
if(!e.categoryHideDynamic||!e.categoryShowAll){let l=t.length
r.parsedEvents.value.forEach(t=>{let n=t.category
g(n)||(n=e.categoryForInvalid),n&&(n in a?a[n].count++:e.categoryHideDynamic||(a[n]={index:l++,count:1}))})}if(!e.categoryShowAll)for(const e in a)0===a[e].count&&delete a[e]
t=t.filter(e=>b(e)&&e.categoryName?a.hasOwnProperty(e.categoryName):!!g(e)&&a.hasOwnProperty(e))}return t}return t.watch(d,w),t.onMounted(()=>{r.updateEventVisibility(),w()}),t.onUpdated(()=>{window.requestAnimationFrame(r.updateEventVisibility)}),sa(()=>{const{start:a,end:i,maxDays:s,component:u,categories:c}=d.value
return t.withDirectives(t.createVNode(u,t.mergeProps({ref:o,class:["v-calendar",{"v-calendar-events":!r.noEvents.value}],role:"grid"},u.filterProps(e),{start:a.date,end:i.date,maxDays:s,weekdays:r.effectiveWeekdays.value,categories:c,"onClick:date":(e,t)=>{l["onUpdate:modelValue"]&&n("update:modelValue",t.date)}}),r.getScopedSlots()),[[Bc,r.updateEventVisibility,void 0,{quiet:!0}]])}),ir({...r,lastStart:i,lastEnd:s,parsedCategoryDays:u,renderProps:d,eventWeekdays:v,categoryMode:p,title:y,monthLongFormatter:m,monthShortFormatter:f,parsedCategories:c,checkChange:w,move:V,next:function(e=1){V(e)},prev:function(e=1){V(-e)},getCategoryList:S},o)}}),bd=Tt({...Ft(),...ol()},"VCardActions"),wd=Kt()({name:"VCardActions",props:bd(),setup:(e,{slots:a})=>(Ht({VBtn:{slim:!0,variant:"text"}}),sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-card-actions",e.class]),style:t.normalizeStyle(e.style)},a)),{})}),Vd=Tt({opacity:[Number,String],...Ft(),...ol()},"VCardSubtitle"),Sd=Kt()({name:"VCardSubtitle",props:Vd(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-card-subtitle",e.class]),style:t.normalizeStyle([{"--v-card-subtitle-opacity":e.opacity},e.style])},a)),{})}),kd=qt("v-card-title"),xd=Tt({appendAvatar:String,appendIcon:ua,prependAvatar:String,prependIcon:ua,subtitle:{type:[String,Number,Boolean],default:void 0},title:{type:[String,Number,Boolean],default:void 0},...Ft(),...yn(),...ol()},"VCardItem"),Nd=Kt()({name:"VCardItem",props:xd(),setup:(e,{slots:a})=>(sa(()=>{const l=!(!e.prependAvatar&&!e.prependIcon),n=!(!l&&!a.prepend),o=!(!e.appendAvatar&&!e.appendIcon),r=!(!o&&!a.append),i=!(null==e.title&&!a.title),s=!(null==e.subtitle&&!a.subtitle)
return t.createVNode(e.tag,{class:t.normalizeClass(["v-card-item",e.class]),style:t.normalizeStyle(e.style)},{default:()=>[n&&t.createElementVNode("div",{key:"prepend",class:"v-card-item__prepend"},[a.prepend?t.createVNode(Bl,{key:"prepend-defaults",disabled:!l,defaults:{VAvatar:{density:e.density,image:e.prependAvatar},VIcon:{density:e.density,icon:e.prependIcon}}},a.prepend):t.createElementVNode(t.Fragment,null,[e.prependAvatar&&t.createVNode(Bo,{key:"prepend-avatar",density:e.density,image:e.prependAvatar},null),e.prependIcon&&t.createVNode(Mn,{key:"prepend-icon",density:e.density,icon:e.prependIcon},null)])]),t.createElementVNode("div",{class:"v-card-item__content"},[i&&t.createVNode(kd,{key:"title"},{default:()=>[a.title?.()??t.toDisplayString(e.title)]}),s&&t.createVNode(Sd,{key:"subtitle"},{default:()=>[a.subtitle?.()??t.toDisplayString(e.subtitle)]}),a.default?.()]),r&&t.createElementVNode("div",{key:"append",class:"v-card-item__append"},[a.append?t.createVNode(Bl,{key:"append-defaults",disabled:!o,defaults:{VAvatar:{density:e.density,image:e.appendAvatar},VIcon:{density:e.density,icon:e.appendIcon}}},a.append):t.createElementVNode(t.Fragment,null,[e.appendIcon&&t.createVNode(Mn,{key:"append-icon",density:e.density,icon:e.appendIcon},null),e.appendAvatar&&t.createVNode(Bo,{key:"append-avatar",density:e.density,image:e.appendAvatar},null)])])]})}),{})}),Cd=Tt({opacity:[Number,String],...Ft(),...ol()},"VCardText"),Ed=Kt()({name:"VCardText",props:Cd(),setup:(e,{slots:a})=>(sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-card-text",e.class]),style:t.normalizeStyle([{"--v-card-text-opacity":e.opacity},e.style])},a)),{})}),Id=Tt({appendAvatar:String,appendIcon:ua,disabled:Boolean,flat:Boolean,hover:Boolean,image:String,link:{type:Boolean,default:void 0},prependAvatar:String,prependIcon:ua,ripple:{type:[Boolean,Object],default:!0},subtitle:{type:[String,Number,Boolean],default:void 0},text:{type:[String,Number,Boolean],default:void 0},title:{type:[String,Number,Boolean],default:void 0},...an(),...Ft(),...yn(),...Tl(),...nn(),...Gn(),...sn(),...Zn(),...Gl(),...to(),...ol(),...Ga(),...Nn({variant:"elevated"})},"VCard"),Ad=Kt()({name:"VCard",directives:{vRipple:bo},props:Id(),setup(e,{attrs:a,slots:l}){const{themeClasses:n}=tl(e),{borderClasses:o}=ln(e),{colorClasses:r,colorStyles:i,variantClasses:s}=Cn(e),{densityClasses:u}=bn(e),{dimensionStyles:c}=Fl(e),{elevationClasses:d}=on(e),{loaderClasses:v}=Kn(e),{locationStyles:p}=un(e),{positionClasses:m}=Qn(e),{roundedClasses:f,roundedStyles:h}=Kl(e),b=eo(e,a),w=t.shallowRef(void 0)
return t.watch(()=>e.loading,(e,t)=>{w.value=!e&&g(t)?t:y(e)?void 0:e},{immediate:!0}),sa(()=>{const a=!1!==e.link&&b.isLink.value,g=!e.disabled&&!1!==e.link&&(e.link||b.isClickable.value),y=a?"a":e.tag,V=!(!l.title&&null==e.title),S=!(!l.subtitle&&null==e.subtitle),k=V||S,x=!!(l.append||e.appendAvatar||e.appendIcon),N=!!(l.prepend||e.prependAvatar||e.prependIcon),C=!(!l.image&&!e.image),E=k||N||x,I=!(!l.text&&null==e.text)
return t.withDirectives(t.createVNode(y,t.mergeProps(b.linkProps,{class:["v-card",{"v-card--disabled":e.disabled,"v-card--flat":e.flat,"v-card--hover":e.hover&&!(e.disabled||e.flat),"v-card--link":g},n.value,o.value,r.value,u.value,d.value,v.value,m.value,f.value,s.value,e.class],style:[i.value,c.value,p.value,{"--v-card-height":z(e.height)},h.value,e.style],onClick:g&&b.navigate.value,tabindex:e.disabled?-1:void 0}),{default:()=>[C&&t.createElementVNode("div",{key:"image",class:"v-card__image"},[l.image?t.createVNode(Bl,{key:"image-defaults",disabled:!e.image,defaults:{VImg:{cover:!0,src:e.image}}},l.image):t.createVNode(tn,{key:"image-img",cover:!0,src:e.image},null)]),t.createVNode(qn,{name:"v-card",active:!!e.loading,color:w.value},{default:l.loader}),E&&t.createVNode(Nd,{key:"item",prependAvatar:e.prependAvatar,prependIcon:e.prependIcon,title:e.title,subtitle:e.subtitle,appendAvatar:e.appendAvatar,appendIcon:e.appendIcon},{default:l.item,prepend:l.prepend,title:l.title,subtitle:l.subtitle,append:l.append}),I&&t.createVNode(Ed,{key:"text"},{default:()=>[l.text?.()??e.text]}),l.default?.(),l.actions&&t.createVNode(wd,null,{default:l.actions}),xn(g,"v-card")]}),[[bo,g&&e.ripple]])}),{}}})
function Pd(e,t,a){const l=e.changedTouches[0]
t.touchendX=l.clientX,t.touchendY=l.clientY,t.end?.({originalEvent:e,...t}),((e,t)=>{const{touchstartX:a,touchendX:l,touchstartY:n,touchendY:o}=e
e.offsetX=l-a,e.offsetY=o-n,!t.x&&Math.abs(e.offsetY)<.5*Math.abs(e.offsetX)&&(e.left&&l<a-16&&e.left(e),e.right&&l>a+16&&e.right(e)),!t.y&&Math.abs(e.offsetX)<.5*Math.abs(e.offsetY)&&(e.up&&o<n-16&&e.up(e),e.down&&o>n+16&&e.down(e))})(t,a)}function _d(e={}){const t={touchstartX:0,touchstartY:0,touchendX:0,touchendY:0,touchmoveX:0,touchmoveY:0,offsetX:0,offsetY:0,left:e.left,right:e.right,up:e.up,down:e.down,start:e.start,move:e.move,end:e.end}
let a=()=>({x:!1,y:!1})
return{touchstart:e=>{a=function(e){const t=[]
for(let a=e instanceof Element?e:null;a;a=a.parentElement)t.push([a,a.scrollLeft,a.scrollTop])
return()=>({x:t.some(([e,t])=>e.scrollLeft!==t),y:t.some(([e,,t])=>e.scrollTop!==t)})}(e.target),function(e,t){const a=e.changedTouches[0]
t.touchstartX=a.clientX,t.touchstartY=a.clientY,t.start?.({originalEvent:e,...t})}(e,t)},touchend:e=>Pd(e,t,a()),touchmove:e=>function(e,t){const a=e.changedTouches[0]
t.touchmoveX=a.clientX,t.touchmoveY=a.clientY,t.move?.({originalEvent:e,...t})}(e,t)}}function Rd(e,t){const a=t.value,l=a?.parent?e.parentElement:e,n=a?.options??{passive:!0},o=t.instance?.$.uid
if(!a||!l||void 0===o)return
const r=_d(t.value)
l._touchHandlers=l._touchHandlers??Object.create(null),l._touchHandlers[o]=r,H(r).forEach(e=>{l.addEventListener(e,r[e],n)})}function Dd(e,t){const a=t.value?.parent?e.parentElement:e,l=t.instance?.$.uid
if(!a?._touchHandlers||void 0===l)return
const n=a._touchHandlers[l]
n&&(H(n).forEach(e=>{a.removeEventListener(e,n[e])}),delete a._touchHandlers[l],H(a._touchHandlers).length||delete a._touchHandlers)}const Bd={mounted:Rd,unmounted:Dd,updated:function(e,t){t.value!==t.oldValue&&(Dd(e,{...t,value:t.oldValue}),Rd(e,t))}},Td=Symbol.for("vuetify:v-window"),Fd=Symbol.for("vuetify:v-window-group"),$d=Tt({continuous:Boolean,nextIcon:{type:[Boolean,String,Function,Object],default:"$next"},prevIcon:{type:[Boolean,String,Function,Object],default:"$prev"},reverse:Boolean,showArrows:{type:[Boolean,String],validator:e=>y(e)||"hover"===e},verticalArrows:[Boolean,String],touch:{type:[Object,Boolean],default:void 0},direction:{type:String,default:"horizontal"},modelValue:null,disabled:Boolean,selectedClass:{type:String,default:"v-window-item--active"},mandatory:{type:[Boolean,String],default:"force"},crossfade:Boolean,transitionDuration:Number,...Ft(),...ol(),...Ga()},"VWindow"),Md=Kt()({name:"VWindow",directives:{vTouch:Bd},props:$d(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{themeClasses:l}=tl(e),{isRtl:n}=Ua(),{t:o}=Ha(),r=Rn(e,Fd),i=t.ref(),s=t.computed(()=>n.value?!e.reverse:e.reverse),u=t.shallowRef(!1),c=t.computed(()=>{if(e.crossfade)return"v-window-crossfade-transition"
return`v-window-${"vertical"===e.direction?"y":"x"}${(s.value?!u.value:u.value)?"-reverse":""}-transition`}),d=t.shallowRef(0),v=t.ref(void 0),p=t.computed(()=>r.items.value.findIndex(e=>r.selected.value.includes(e.id)))
t.watch(p,(e,a)=>{let l
const n={left:0,top:0}
E&&a>=0&&(l=na(i.value),n.left=l?.scrollLeft,n.top=l?.scrollTop)
const o=r.items.value.length,s=o-1
u.value=o<=2?e<a:(e!==s||0!==a)&&(0===e&&a===s||e<a),t.nextTick(()=>{if(!E||!l)return
l.scrollTop!==n.top&&l.scrollTo({...n,behavior:"instant"}),requestAnimationFrame(()=>{if(!l)return
l.scrollTop!==n.top&&l.scrollTo({...n,behavior:"instant"})})})},{flush:"sync"}),t.provide(Td,{transition:c,isReversed:u,transitionCount:d,transitionHeight:v,rootRef:i})
const m=t.toRef(()=>e.continuous||0!==p.value),f=t.toRef(()=>e.continuous||p.value!==r.items.value.length-1)
function g(){m.value&&r.prev()}function h(){f.value&&r.next()}const y=t.computed(()=>{const l=[],i={icon:n.value?e.nextIcon:e.prevIcon,class:"v-window__"+(s.value?"right":"left"),onClick:r.prev,"aria-label":o("$vuetify.carousel.prev")}
l.push(m.value?a.prev?a.prev({props:i}):t.createVNode(Vo,i,null):t.createElementVNode("div",null,null))
const u={icon:n.value?e.prevIcon:e.nextIcon,class:"v-window__"+(s.value?"left":"right"),onClick:r.next,"aria-label":o("$vuetify.carousel.next")}
return l.push(f.value?a.next?a.next({props:u}):t.createVNode(Vo,u,null):t.createElementVNode("div",null,null)),l}),b=t.computed(()=>{if(!1===e.touch)return e.touch
return{...{left:()=>{s.value?g():h()},right:()=>{s.value?h():g()},start:({originalEvent:e})=>{e.stopPropagation()}},...!0===e.touch?{}:e.touch}})
function w(a){("horizontal"===e.direction&&"ArrowLeft"===a.key||"vertical"===e.direction&&"ArrowUp"===a.key)&&(a.preventDefault(),g(),t.nextTick(()=>{m.value?V(0):V(1)})),("horizontal"===e.direction&&"ArrowRight"===a.key||"vertical"===e.direction&&"ArrowDown"===a.key)&&(a.preventDefault(),h(),t.nextTick(()=>{f.value?V(1):V(0)}))}function V(e){const t=y.value[e]
if(!t)return
const a=Array.isArray(t)?t[0]:t
a.el?.focus()}return sa(()=>t.withDirectives(t.createVNode(e.tag,{ref:i,class:t.normalizeClass(["v-window",{"v-window--show-arrows-on-hover":"hover"===e.showArrows,"v-window--vertical-arrows":!!e.verticalArrows,"v-window--crossfade":!!e.crossfade},l.value,e.class]),style:t.normalizeStyle([e.style,{"--v-window-transition-duration":R()?null:z(e.transitionDuration,"ms")}])},{default:()=>[t.createElementVNode("div",{class:"v-window__container",style:{height:v.value}},[a.default?.({group:r}),!1!==e.showArrows&&t.createElementVNode("div",{class:t.normalizeClass(["v-window__controls",{"v-window__controls--left":"left"===e.verticalArrows||!0===e.verticalArrows},{"v-window__controls--right":"right"===e.verticalArrows}]),onKeydown:w},[y.value])]),a.additional?.({group:r})]}),[[Bd,b.value]])),{group:r}}}),zd=Tt({color:String,cycle:Boolean,delimiterIcon:{type:ua,default:"$delimiter"},height:{type:[Number,String],default:500},hideDelimiters:Boolean,hideDelimiterBackground:Boolean,interval:{type:[Number,String],default:6e3,validator:e=>Number(e)>0},progress:[Boolean,String],verticalDelimiters:[Boolean,String],...$d({continuous:!0,mandatory:"force",showArrows:!0})},"VCarousel"),Ld=Kt()({name:"VCarousel",props:zd(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),{t:n}=Ha(),o=t.ref(),r=Ut("VBtn")
let i=-1
function s(){e.cycle&&o.value&&(i=window.setTimeout(o.value.group.next,Number(e.interval)>0?Number(e.interval):6e3))}function u(){window.clearTimeout(i),window.requestAnimationFrame(s)}function c(a,l){("horizontal"===e.direction&&"ArrowLeft"===a.key||"vertical"===e.direction&&"ArrowUp"===a.key)&&(a.preventDefault(),l.prev(),t.nextTick(()=>o.value?.$el.querySelector(".v-btn--active")?.focus())),("horizontal"===e.direction&&"ArrowRight"===a.key||"vertical"===e.direction&&"ArrowDown"===a.key)&&(a.preventDefault(),l.next(),t.nextTick(()=>o.value?.$el.querySelector(".v-btn--active")?.focus()))}return t.watch(l,u),t.watch(()=>e.interval,u),t.watch(()=>e.cycle,e=>{e?u():window.clearTimeout(i)}),t.onMounted(s),sa(()=>{const i=Md.filterProps(e)
return t.createVNode(Md,t.mergeProps({ref:o},i,{modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,class:["v-carousel",{"v-carousel--hide-delimiter-background":e.hideDelimiterBackground,"v-carousel--vertical-delimiters":e.verticalDelimiters},e.class],style:[{height:z(e.height)},e.style]}),{default:a.default,additional:({group:o})=>t.createElementVNode(t.Fragment,null,[!e.hideDelimiters&&t.createElementVNode("div",{class:"v-carousel__controls",style:{left:"left"===e.verticalDelimiters&&e.verticalDelimiters?0:"auto",right:"right"===e.verticalDelimiters?0:"auto"}},[o.items.value.length>0&&t.createVNode(Bl,{defaults:{VBtn:{color:e.color,icon:e.delimiterIcon,size:r.value?.size??"x-small",variant:r.value?.variant??"text"}},scoped:!0},{default:()=>[o.items.value.map((e,l)=>{const r={id:`carousel-item-${e.id}`,"aria-label":n("$vuetify.carousel.ariaLabel.delimiter",l+1,o.items.value.length),class:["v-carousel__controls__item",o.isSelected(e.id)&&"v-btn--active"],onClick:()=>o.select(e.id,!0),onKeydown:e=>c(e,o)}
return a.item?a.item({props:r,item:e}):t.createVNode(Vo,t.mergeProps(e,r),null)})]})]),e.progress&&t.createVNode(Yn,{absolute:!0,class:"v-carousel__progress",color:g(e.progress)?e.progress:void 0,modelValue:(o.getItemIndex(l.value)+1)/o.items.value.length*100},null)]),prev:a.prev,next:a.next})}),{}}}),Od=Tt({reverseTransition:{type:[Boolean,String],default:void 0},transition:{type:[Boolean,String],default:void 0},...Ft(),...Pn(),...as()},"VWindowItem"),jd=Kt()({name:"VWindowItem",directives:{vTouch:Bd},props:Od(),emits:{"group:selected":e=>!0},setup(e,{slots:a}){const l=t.inject(Td),n=_n(e,Fd),{isBooted:o}=mn()
if(!l||!n)throw new Error("[Vuetify] VWindowItem must be used inside VWindow")
const r=t.shallowRef(!1),i=t.computed(()=>o.value&&(l.isReversed.value?!1!==e.reverseTransition:!1!==e.transition))
function s(){r.value&&l&&(r.value=!1,l.transitionCount.value>0&&(l.transitionCount.value-=1,0===l.transitionCount.value&&(l.transitionHeight.value=void 0)))}function u(){!r.value&&l&&(r.value=!0,0===l.transitionCount.value&&(l.transitionHeight.value=z(l.rootRef.value?.clientHeight)),l.transitionCount.value+=1)}function c(){s()}function d(e){r.value&&t.nextTick(()=>{i.value&&r.value&&l&&(l.transitionHeight.value=z(e.clientHeight))})}const v=t.computed(()=>{const t=l.isReversed.value?e.reverseTransition:e.transition
return!!i.value&&{name:g(t)?t:l.transition.value,onBeforeEnter:u,onAfterEnter:s,onEnterCancelled:c,onBeforeLeave:u,onAfterLeave:s,onLeaveCancelled:c,onEnter:d}}),{hasContent:p}=ls(e,n.isSelected)
return sa(()=>t.createVNode(Xl,{transition:v.value,disabled:!o.value},{default:()=>[t.withDirectives(t.createElementVNode("div",{class:t.normalizeClass(["v-window-item",n.selectedClass.value,e.class]),style:t.normalizeStyle(e.style)},[p.value&&a.default?.()]),[[t.vShow,n.isSelected.value]])]})),{groupItem:n}}}),Hd=Tt({...en(),...Od()},"VCarouselItem"),Wd=Kt()({name:"VCarouselItem",inheritAttrs:!1,props:Hd(),setup(e,{slots:a,attrs:l}){sa(()=>{const n=tn.filterProps(e),o=jd.filterProps(e)
return t.createVNode(jd,t.mergeProps({class:["v-carousel-item",e.class]},o),{default:()=>[t.createVNode(tn,t.mergeProps(l,n),a)]})})}}),Ud=qt("v-code","code"),Yd=Gt({name:"VColorPickerCanvas",props:Tt({color:{type:Object},disabled:Boolean,readonly:Boolean,dotSize:{type:[Number,String],default:10},height:{type:[Number,String],default:150},width:{type:[Number,String],default:300},...Ft()},"VColorPickerCanvas")(),emits:{"update:color":e=>!0,"update:position":e=>!0},setup(e,{emit:a}){const l=t.shallowRef(!1),n=t.ref(),o=t.shallowRef(parseFloat(e.width)),r=t.shallowRef(parseFloat(e.height)),i=t.ref({x:0,y:0}),s=t.toRef(()=>!e.disabled&&!e.readonly),u=t.computed({get:()=>i.value,set(t){if(!n.value)return
const{x:l,y:s}=t
i.value=t,a("update:color",{h:e.color?.h??0,s:ae(l,0,o.value)/o.value,v:1-ae(s,0,r.value)/r.value,a:e.color?.a??1})}}),c=t.computed(()=>{const{x:t,y:a}=u.value,l=parseInt(e.dotSize,10)/2
return{width:z(e.dotSize),height:z(e.dotSize),transform:`translate(${z(t-l)}, ${z(a-l)})`}}),{resizeRef:d}=Sa(e=>{if(!d.el?.offsetParent)return
const{width:t,height:a}=e[0].contentRect
o.value=Math.round(t),r.value=Math.round(a)})
function v(e){"mousedown"===e.type&&e.preventDefault(),s.value&&(p(e),window.addEventListener("mousemove",p),window.addEventListener("mouseup",m),window.addEventListener("touchmove",p),window.addEventListener("touchend",m))}function p(e){if(!s.value||!n.value)return
l.value=!0
const t=function(e){return"touches"in e?{clientX:e.touches[0].clientX,clientY:e.touches[0].clientY}:{clientX:e.clientX,clientY:e.clientY}}(e),a=Ue([t.clientX,t.clientY])
!function(e,t,a){const{left:l,top:n,width:o,height:r}=a
u.value={x:ae(e-l,0,o),y:ae(t-n,0,r)}}(a.x,a.y,Ue(n.value))}function m(){window.removeEventListener("mousemove",p),window.removeEventListener("mouseup",m),window.removeEventListener("touchmove",p),window.removeEventListener("touchend",m)}function f(){if(!n.value)return
const t=n.value,a=t.getContext("2d")
if(!a)return
const l=a.createLinearGradient(0,0,t.width,0)
l.addColorStop(0,"hsla(0, 0%, 100%, 1)"),l.addColorStop(1,`hsla(${e.color?.h??0}, 100%, 50%, 1)`),a.fillStyle=l,a.fillRect(0,0,t.width,t.height)
const o=a.createLinearGradient(0,0,0,t.height)
o.addColorStop(0,"hsla(0, 0%, 0%, 0)"),o.addColorStop(1,"hsla(0, 0%, 0%, 1)"),a.fillStyle=o,a.fillRect(0,0,t.width,t.height)}return t.watch(()=>e.color?.h,f,{immediate:!0}),t.watch(()=>[o.value,r.value],(e,t)=>{f(),i.value={x:u.value.x*e[0]/t[0],y:u.value.y*e[1]/t[1]}},{flush:"post"}),t.watch(()=>e.color,()=>{l.value?l.value=!1:i.value=e.color?{x:e.color.s*o.value,y:(1-e.color.v)*r.value}:{x:0,y:0}},{deep:!0,immediate:!0}),t.onMounted(()=>f()),sa(()=>t.createElementVNode("div",{ref:d,class:t.normalizeClass(["v-color-picker-canvas",e.class]),style:t.normalizeStyle(e.style),onMousedown:v,onTouchstartPassive:v},[t.createElementVNode("canvas",{ref:n,width:o.value,height:r.value},null),e.color&&t.createElementVNode("div",{class:t.normalizeClass(["v-color-picker-canvas__dot",{"v-color-picker-canvas__dot--disabled":e.disabled}]),style:t.normalizeStyle(c.value)},null)])),{}}})
const Gd={h:0,s:0,v:0,a:1},Kd={inputProps:{type:"number",min:0},inputs:[{label:"R",max:255,step:1,getValue:e=>Math.round(e.r),getColor:(e,t)=>({...e,r:Number(t)}),localeKey:"redInput"},{label:"G",max:255,step:1,getValue:e=>Math.round(e.g),getColor:(e,t)=>({...e,g:Number(t)}),localeKey:"greenInput"},{label:"B",max:255,step:1,getValue:e=>Math.round(e.b),getColor:(e,t)=>({...e,b:Number(t)}),localeKey:"blueInput"},{label:"A",max:1,step:.01,getValue:({a:e})=>null!=e?Math.round(100*e)/100:1,getColor:(e,t)=>({...e,a:Number(t)}),localeKey:"alphaInput"}],to:bt,from:Vt},qd={inputProps:{type:"number",min:0},inputs:[{label:"H",max:360,step:1,getValue:e=>Math.round(e.h),getColor:(e,t)=>({...e,h:Number(t)}),localeKey:"hueInput"},{label:"S",max:1,step:.01,getValue:e=>Math.round(100*e.s)/100,getColor:(e,t)=>({...e,s:Number(t)}),localeKey:"saturationInput"},{label:"L",max:1,step:.01,getValue:e=>Math.round(100*e.l)/100,getColor:(e,t)=>({...e,l:Number(t)}),localeKey:"lightnessInput"},{label:"A",max:1,step:.01,getValue:({a:e})=>null!=e?Math.round(100*e)/100:1,getColor:(e,t)=>({...e,a:Number(t)}),localeKey:"alphaInput"}],to:St,from:kt},Xd={inputProps:{type:"text"},inputs:[{label:"HEXA",getValue:e=>e,getColor:(e,t)=>t,localeKey:"hexaInput"}],to:At,from:function(e){return Vt(It(e))}},Zd={rgb:{...Kd,inputs:Kd.inputs?.slice(0,3)},rgba:Kd,hsl:{...qd,inputs:qd.inputs.slice(0,3)},hsla:qd,hex:{...Xd,inputs:[{label:"HEX",getValue:e=>e.slice(0,7),getColor:(e,t)=>t,localeKey:"hexInput"}]},hexa:Xd},Qd=({label:e,...a})=>t.createElementVNode("div",{class:"v-color-picker-edit__input"},[t.createElementVNode("input",t.normalizeProps(t.guardReactiveProps(a)),null),t.createElementVNode("span",null,[e])]),Jd=Gt({name:"VColorPickerEdit",props:Tt({color:Object,disabled:Boolean,hideInputLabels:Boolean,readonly:Boolean,mode:{type:String,default:"rgba",validator:e=>Object.keys(Zd).includes(e)},modes:{type:Array,default:()=>Object.keys(Zd),validator:e=>Array.isArray(e)&&e.every(e=>Object.keys(Zd).includes(e))},...Ft()},"VColorPickerEdit")(),emits:{"update:color":e=>!0,"update:mode":e=>!0},setup(e,{emit:a}){const{t:l}=Ha(),n=t.computed(()=>e.modes.map(e=>({...Zd[e],name:e}))),o=t.computed(()=>{const t=n.value.find(t=>t.name===e.mode)
if(!t)return[]
const o=e.color?t.to(e.color):null
return t.inputs?.map(({getValue:n,getColor:r,localeKey:i,...s})=>({...t.inputProps,...s,ariaLabel:l(`$vuetify.colorPicker.ariaLabel.${i}`),disabled:e.disabled,readonly:e.readonly,value:o&&n(o),onChange:e=>{const l=e.target
l&&a("update:color",t.from(r(o??t.to(Gd),l.value)))}}))})
return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-color-picker-edit",e.class]),style:t.normalizeStyle(e.style)},[o.value?.map(a=>t.createVNode(Qd,t.mergeProps(a,{label:e.hideInputLabels?void 0:a.label}),null)),n.value.length>1&&t.createVNode(Vo,{icon:"$unfold",size:"x-small",variant:"plain","aria-label":l("$vuetify.colorPicker.ariaLabel.changeFormat"),onClick:()=>{const t=n.value.findIndex(t=>t.name===e.mode)
a("update:mode",n.value[(t+1)%n.value.length].name)}},null)])),{}}}),ev=Symbol.for("vuetify:v-slider")
function tv(e,t,a){const l="vertical"===a,n=t.getBoundingClientRect(),o="touches"in e?e.touches[0]:e
return l?o.clientY-(n.top+n.height/2):o.clientX-(n.left+n.width/2)}const av=Tt({disabled:{type:Boolean,default:null},error:Boolean,readonly:{type:Boolean,default:null},max:{type:[Number,String],default:100},min:{type:[Number,String],default:0},step:{type:[Number,String],default:0},thumbColor:String,thumbLabel:{type:[Boolean,String],default:void 0,validator:e=>y(e)||"always"===e||"hover"===e},thumbSize:{type:[Number,String],default:20},showTicks:{type:[Boolean,String],default:!1,validator:e=>y(e)||"always"===e},ticks:{type:[Array,Object]},tickSize:{type:[Number,String],default:2},color:String,trackColor:String,trackFillColor:String,trackSize:{type:[Number,String],default:4},direction:{type:String,default:"horizontal",validator:e=>["vertical","horizontal"].includes(e)},reverse:Boolean,noKeyboard:Boolean,...Gl(),...nn({elevation:1}),ripple:{type:Boolean,default:!0}},"Slider"),lv=e=>{const a=t.computed(()=>parseFloat(e.min)),l=t.computed(()=>parseFloat(e.max)),n=t.computed(()=>Number(e.step)>0?parseFloat(e.step):0),o=t.computed(()=>Math.max(le(n.value),le(a.value)))
return{min:a,max:l,step:n,decimals:o,roundValue:function(e){if(e=parseFloat(e),n.value<=0)return e
const t=ae(e,a.value,l.value),r=a.value%n.value
let i=Math.round((t-r)/n.value)*n.value+r
return t>i&&i+n.value>l.value&&(i=l.value),parseFloat(Math.min(i,l.value).toFixed(o.value))}}},nv=({props:e,steps:a,onSliderStart:l,onSliderMove:n,onSliderEnd:o,getActiveThumb:r})=>{const i=Qo(e),{isRtl:s}=Ua(),u=t.toRef(()=>e.reverse),c=t.computed(()=>"vertical"===e.direction),d=t.computed(()=>c.value!==u.value),{min:v,max:p,step:m,decimals:f,roundValue:g}=a,h=t.computed(()=>parseInt(e.thumbSize,10)),y=t.computed(()=>parseInt(e.tickSize,10)),b=t.computed(()=>parseInt(e.trackSize,10)),w=t.computed(()=>(p.value-v.value)/m.value),V=t.computed(()=>e.error||i.isDisabled.value?void 0:e.thumbColor??e.color),S=t.computed(()=>e.error||i.isDisabled.value?void 0:e.thumbColor),k=t.computed(()=>e.error||i.isDisabled.value?void 0:e.trackColor??e.color),x=t.computed(()=>e.error||i.isDisabled.value?void 0:e.trackFillColor??e.color),N=t.shallowRef(!1),I=t.shallowRef(0),A=t.ref(),P=t.ref()
function _(t){const a=A.value?.$el
if(!a)return
const l="vertical"===e.direction,n=l?"top":"left",o=l?"height":"width",r=l?"clientY":"clientX",{[n]:i,[o]:u}=a.getBoundingClientRect(),c=function(e,t){return"touches"in e&&e.touches.length?e.touches[0][t]:"changedTouches"in e&&e.changedTouches.length?e.changedTouches[0][t]:e[t]}(t,r)
let m=ae((c-i-I.value)/u)||0
return(l?d.value:d.value!==s.value)&&(m=1-m),g(v.value+m*(p.value-v.value))}const R=e=>{const t=_(e)
null!=t&&o({value:t}),N.value=!1,I.value=0},D=a=>{const o=_(a)
P.value=r(a),P.value&&(N.value=!0,P.value.contains(a.target)?I.value=tv(a,P.value,e.direction):(I.value=0,null!=o&&n({value:o})),null!=o&&l({value:o}),t.nextTick(()=>P.value?.focus()))},B={passive:!0,capture:!0}
function T(e){const t=_(e)
null!=t&&n({value:t})}function F(e){e.stopPropagation(),e.preventDefault(),R(e),window.removeEventListener("mousemove",T,B),window.removeEventListener("mouseup",F)}function $(e){R(e),window.removeEventListener("touchmove",T,B),e.target?.removeEventListener("touchend",$)}t.onScopeDispose(()=>{E&&(window.removeEventListener("touchmove",T),window.removeEventListener("mousemove",T),window.removeEventListener("mouseup",F))})
const M=e=>{const t=(e-v.value)/(p.value-v.value)*100
return ae(isNaN(t)?0:t,0,100)},z=t.toRef(()=>e.showTicks),L=t.computed(()=>z.value?e.ticks?Array.isArray(e.ticks)?e.ticks.map(e=>({value:e,position:M(e),label:e.toString()})):Object.keys(e.ticks).map(t=>({value:parseFloat(t),position:M(parseFloat(t)),label:e.ticks[t]})):w.value!==1/0?C(w.value+1).map(e=>{const t=v.value+e*m.value
return{value:t,position:M(t)}}):[]:[]),O=t.computed(()=>L.value.some(({label:e})=>!!e)),j={activeThumbRef:P,color:t.toRef(()=>e.color),decimals:f,disabled:i.isDisabled,direction:t.toRef(()=>e.direction),elevation:t.toRef(()=>e.elevation),hasLabels:O,isReversed:u,indexFromEnd:d,min:v,max:p,mousePressed:N,noKeyboard:t.toRef(()=>e.noKeyboard),numTicks:w,onSliderMousedown:function(e){0===e.button&&(e.preventDefault(),D(e),window.addEventListener("mousemove",T,B),window.addEventListener("mouseup",F,{passive:!1}))},onSliderTouchstart:function(e){D(e),window.addEventListener("touchmove",T,B),e.target?.addEventListener("touchend",$,{passive:!1})},parsedTicks:L,parseMouseMove:_,position:M,readonly:i.isReadonly,rounded:t.toRef(()=>e.rounded),roundValue:g,showTicks:z,startOffset:I,step:m,thumbSize:h,thumbColor:V,thumbLabelColor:S,thumbLabel:t.toRef(()=>e.thumbLabel),ticks:t.toRef(()=>e.ticks),tickSize:y,trackColor:k,trackContainerRef:A,trackFillColor:x,trackSize:b,vertical:c}
return t.provide(ev,j),j},ov=Tt({focused:Boolean,max:{type:Number,required:!0},min:{type:Number,required:!0},modelValue:{type:Number,required:!0},position:{type:Number,required:!0},ripple:{type:[Boolean,Object],default:!0},name:String,noKeyboard:Boolean,...Ft()},"VSliderThumb"),rv=Kt()({name:"VSliderThumb",directives:{vRipple:bo},props:ov(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a,emit:l}){const n=t.inject(ev),{isRtl:o,rtlClasses:r}=Ua()
if(!n)throw new Error("[Vuetify] v-slider-thumb must be used inside v-slider or v-range-slider")
const{min:i,max:s,thumbColor:u,thumbLabelColor:c,step:d,disabled:v,thumbSize:p,thumbLabel:m,direction:f,isReversed:g,vertical:h,readonly:y,elevation:b,mousePressed:w,decimals:V,indexFromEnd:S}=n,k=t.shallowRef(!1),x=t.shallowRef(!1),N=t.computed(()=>v.value?void 0:b.value),{elevationClasses:C}=on(N),{textColorClasses:E,textColorStyles:I}=Ll(u),{backgroundColorClasses:A,backgroundColorStyles:P}=Ol(c),{pageup:_,pagedown:R,end:D,home:B,left:T,right:F,down:$,up:M}=j,L=[_,R,D,B,T,F,$,M],O=t.computed(()=>d.value?[1,2,3]:[1,5,10])
function H(t){const a=function(t,a){if(e.noKeyboard||v.value)return
if(!L.includes(t.key))return
t.preventDefault()
const l=d.value||.1,n=(s.value-i.value)/l
if([T,F,$,M].includes(t.key)){const e=(h.value?[o.value?T:F,g.value?$:M]:S.value!==o.value?[T,M]:[F,M]).includes(t.key)?1:-1,r=t.shiftKey?2:t.ctrlKey?1:0;-1!==e||a!==s.value||r||Number.isInteger(n)?a+=e*l*O.value[r]:a-=n%1*l}else t.key===B?a=i.value:t.key===D?a=s.value:a-=(t.key===R?1:-1)*l*(n>100?n/10:10)
return Math.max(e.min,Math.min(e.max,a))}(t,e.modelValue)
null!=a&&(x.value=!1,l("update:modelValue",a))}return t.watch(()=>e.focused,e=>{e&&(x.value=!1)}),sa(()=>{const l=z(S.value?100-e.position:e.position,"%"),n="always"===m.value||!0===m.value&&e.focused||"hover"===m.value&&(k.value||e.focused&&!x.value)
return t.createElementVNode("div",{class:t.normalizeClass(["v-slider-thumb",{"v-slider-thumb--focused":e.focused,"v-slider-thumb--pressed":e.focused&&w.value},e.class,r.value]),style:t.normalizeStyle([{"--v-slider-thumb-position":l,"--v-slider-thumb-size":z(p.value)},e.style]),role:"slider",tabindex:v.value?-1:0,"aria-label":e.name,"aria-valuemin":i.value,"aria-valuemax":s.value,"aria-valuenow":e.modelValue,"aria-readonly":!!y.value,"aria-orientation":f.value,onKeydown:y.value?void 0:H,onMouseenter:()=>{k.value=!0},onMouseleave:()=>{k.value=!1,x.value=!0}},[t.createElementVNode("div",{class:t.normalizeClass(["v-slider-thumb__surface",E.value,C.value]),style:t.normalizeStyle(I.value)},null),t.withDirectives(t.createElementVNode("div",{class:t.normalizeClass(["v-slider-thumb__ripple",E.value]),style:t.normalizeStyle(I.value)},null),[[bo,e.ripple,null,{circle:!0,center:!0}]]),t.createVNode(Vl,{origin:"bottom center"},{default:()=>[t.withDirectives(t.createElementVNode("div",{class:"v-slider-thumb__label-container"},[t.createElementVNode("div",{class:t.normalizeClass(["v-slider-thumb__label",A.value]),style:t.normalizeStyle(P.value)},[t.createElementVNode("div",null,[a["thumb-label"]?.({modelValue:e.modelValue})??e.modelValue.toFixed(d.value?V.value:1)]),t.createElementVNode("div",{class:"v-slider-thumb__label-wedge"},null)])]),[[t.vShow,n]])]})])}),{}}}),iv=Tt({start:{type:Number,required:!0},stop:{type:Number,required:!0},...Ft()},"VSliderTrack"),sv=Kt()({name:"VSliderTrack",props:iv(),emits:{},setup(e,{slots:a}){const l=t.inject(ev)
if(!l)throw new Error("[Vuetify] v-slider-track must be inside v-slider or v-range-slider")
const{color:n,parsedTicks:o,rounded:r,showTicks:i,tickSize:s,trackColor:u,trackFillColor:c,trackSize:d,vertical:v,min:p,max:m,indexFromEnd:f}=l,{roundedClasses:g,roundedStyles:h}=Kl(r),{backgroundColorClasses:y,backgroundColorStyles:b}=Ol(c),{backgroundColorClasses:w,backgroundColorStyles:V}=Ol(u),S=t.computed(()=>`inset-${v.value?"block":"inline"}-${f.value?"end":"start"}`),k=t.computed(()=>v.value?"height":"width"),x=t.computed(()=>({[S.value]:"0%",[k.value]:"100%"})),N=t.computed(()=>e.stop-e.start),C=t.computed(()=>({[S.value]:z(e.start,"%"),[k.value]:z(N.value,"%")})),E=t.computed(()=>{if(!i.value)return[]
return(v.value?o.value.slice().reverse():o.value).map((l,n)=>{const o=l.value!==p.value&&l.value!==m.value?z(l.position,"%"):void 0
return t.createElementVNode("div",{key:l.value,class:t.normalizeClass(["v-slider-track__tick",{"v-slider-track__tick--filled":l.position>=e.start&&l.position<=e.stop,"v-slider-track__tick--first":l.value===p.value,"v-slider-track__tick--last":l.value===m.value}]),style:{[S.value]:o}},[(l.label||a["tick-label"])&&t.createElementVNode("div",{class:"v-slider-track__tick-label"},[a["tick-label"]?.({tick:l,index:n})??l.label])])})})
return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-slider-track",g.value,e.class]),style:t.normalizeStyle([{"--v-slider-track-size":z(d.value),"--v-slider-tick-size":z(s.value)},h.value,e.style])},[t.createElementVNode("div",{class:t.normalizeClass(["v-slider-track__background",w.value,{"v-slider-track__background--opacity":!!n.value||!c.value}]),style:{...x.value,...V.value}},null),t.createElementVNode("div",{class:t.normalizeClass(["v-slider-track__fill",y.value]),style:{...C.value,...b.value}},null),i.value&&t.createElementVNode("div",{class:t.normalizeClass(["v-slider-track__ticks",{"v-slider-track__ticks--always-show":"always"===i.value}])},[E.value])])),{}}}),uv=Tt({...Ko(),...av(),...lr(),modelValue:{type:[Number,String],default:0}},"VSlider"),cv=Kt()({name:"VSlider",inheritAttrs:!1,props:uv(),emits:{"update:focused":e=>!0,"update:modelValue":e=>!0,start:e=>!0,end:e=>!0},setup(e,{slots:a,emit:l,attrs:n}){const o=t.ref(),r=t.ref(),{rtlClasses:i}=Ua(),s=lv(e),u=_a(e,"modelValue",void 0,e=>s.roundValue(null==e?s.min.value:e)),{min:c,max:d,mousePressed:v,roundValue:p,onSliderMousedown:m,onSliderTouchstart:f,trackContainerRef:g,position:h,hasLabels:y,disabled:b,readonly:w,noKeyboard:V}=nv({props:e,steps:s,onSliderStart:()=>{b.value||w.value||l("start",u.value)},onSliderEnd:({value:e})=>{const t=p(e)
b.value||w.value||(u.value=t),l("end",t)},onSliderMove:({value:e})=>{b.value||w.value||(u.value=p(e))},getActiveThumb:()=>o.value?.$el}),{isFocused:S,focus:k,blur:x}=qo(e),N=t.computed(()=>h(u.value))
return sa(()=>{const l=nr.filterProps(e),[s,p]=J(n),h=!!(e.label||a.label||a.prepend)
return t.createVNode(nr,t.mergeProps({ref:r,class:["v-slider",{"v-slider--has-labels":!!a["tick-label"]||y.value,"v-slider--focused":S.value,"v-slider--pressed":v.value,"v-slider--disabled":b.value},i.value,e.class],style:e.style},l,s,{focused:S.value}),{...a,prepend:h?l=>t.createElementVNode(t.Fragment,null,[a.label?.(l)??(e.label?t.createVNode(Fo,{id:l.id.value,class:"v-slider__label",text:e.label},null):void 0),a.prepend?.(l)]):void 0,default:({id:l,messagesId:n})=>t.createElementVNode("div",{class:"v-slider__container",onMousedown:w.value?void 0:m,onTouchstartPassive:w.value?void 0:f},[t.createElementVNode("input",{id:l.value,name:e.name||l.value,disabled:b.value,readonly:w.value,tabindex:"-1",value:u.value},null),t.createVNode(sv,{ref:g,start:0,stop:N.value},{"tick-label":a["tick-label"]}),t.createVNode(rv,t.mergeProps({ref:o,"aria-describedby":n.value,focused:S.value,noKeyboard:V.value,min:c.value,max:d.value,modelValue:u.value,"onUpdate:modelValue":e=>u.value=e,position:N.value,elevation:e.elevation,onFocus:k,onBlur:x,ripple:e.ripple,name:e.name},p),{"thumb-label":a["thumb-label"]})])})}),ir({focus:()=>o.value?.$el.focus()},r)}}),dv=Tt({color:{type:Object},disabled:Boolean,readonly:Boolean,hideAlpha:Boolean,hideEyeDropper:Boolean,eyeDropperIcon:{type:ua,default:"$eyeDropper"},...Ft()},"VColorPickerPreview"),vv=Gt({name:"VColorPickerPreview",props:dv(),emits:{"update:color":e=>!0},setup(e,{emit:a}){const{t:l}=Ha(),n=new AbortController,o=t.toRef(()=>!e.disabled&&!e.readonly)
async function r(){if(!P||!o.value)return
const t=new window.EyeDropper
try{const l=Vt(yt((await t.open({signal:n.signal})).sRGBHex))
a("update:color",{...e.color??Gd,...l})}catch(e){}}return t.onUnmounted(()=>n.abort()),sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-color-picker-preview",{"v-color-picker-preview--hide-alpha":e.hideAlpha},e.class]),style:t.normalizeStyle(e.style)},[P&&!e.hideEyeDropper&&t.createElementVNode("div",{class:"v-color-picker-preview__eye-dropper",key:"eyeDropper"},[t.createVNode(Vo,{"aria-label":l("$vuetify.colorPicker.ariaLabel.eyedropper"),density:"comfortable",disabled:e.disabled,readonly:e.readonly,icon:e.eyeDropperIcon,variant:"plain",onClick:r},null)]),t.createElementVNode("div",{class:"v-color-picker-preview__dot"},[t.createElementVNode("div",{style:{background:Nt(e.color??Gd)}},null)]),t.createElementVNode("div",{class:"v-color-picker-preview__sliders"},[t.createVNode(cv,{class:"v-color-picker-preview__track v-color-picker-preview__hue","aria-label":l("$vuetify.colorPicker.ariaLabel.hueSlider"),modelValue:e.color?.h,"onUpdate:modelValue":t=>a("update:color",{...e.color??Gd,h:t}),step:1,min:0,max:360,disabled:e.disabled,readonly:e.readonly,thumbSize:14,trackSize:8,trackFillColor:"white",hideDetails:!0},null),!e.hideAlpha&&t.createVNode(cv,{class:"v-color-picker-preview__track v-color-picker-preview__alpha","aria-label":l("$vuetify.colorPicker.ariaLabel.alphaSlider"),modelValue:e.color?.a??1,"onUpdate:modelValue":t=>a("update:color",{...e.color??Gd,a:t}),step:.01,min:0,max:1,disabled:e.disabled,readonly:e.readonly,thumbSize:14,trackSize:8,trackFillColor:"white",hideDetails:!0},null)])])),{}}})
var pv={red:{base:"#f44336",lighten5:"#ffebee",lighten4:"#ffcdd2",lighten3:"#ef9a9a",lighten2:"#e57373",lighten1:"#ef5350",darken1:"#e53935",darken2:"#d32f2f",darken3:"#c62828",darken4:"#b71c1c",accent1:"#ff8a80",accent2:"#ff5252",accent3:"#ff1744",accent4:"#d50000"},pink:{base:"#e91e63",lighten5:"#fce4ec",lighten4:"#f8bbd0",lighten3:"#f48fb1",lighten2:"#f06292",lighten1:"#ec407a",darken1:"#d81b60",darken2:"#c2185b",darken3:"#ad1457",darken4:"#880e4f",accent1:"#ff80ab",accent2:"#ff4081",accent3:"#f50057",accent4:"#c51162"},purple:{base:"#9c27b0",lighten5:"#f3e5f5",lighten4:"#e1bee7",lighten3:"#ce93d8",lighten2:"#ba68c8",lighten1:"#ab47bc",darken1:"#8e24aa",darken2:"#7b1fa2",darken3:"#6a1b9a",darken4:"#4a148c",accent1:"#ea80fc",accent2:"#e040fb",accent3:"#d500f9",accent4:"#aa00ff"},deepPurple:{base:"#673ab7",lighten5:"#ede7f6",lighten4:"#d1c4e9",lighten3:"#b39ddb",lighten2:"#9575cd",lighten1:"#7e57c2",darken1:"#5e35b1",darken2:"#512da8",darken3:"#4527a0",darken4:"#311b92",accent1:"#b388ff",accent2:"#7c4dff",accent3:"#651fff",accent4:"#6200ea"},indigo:{base:"#3f51b5",lighten5:"#e8eaf6",lighten4:"#c5cae9",lighten3:"#9fa8da",lighten2:"#7986cb",lighten1:"#5c6bc0",darken1:"#3949ab",darken2:"#303f9f",darken3:"#283593",darken4:"#1a237e",accent1:"#8c9eff",accent2:"#536dfe",accent3:"#3d5afe",accent4:"#304ffe"},blue:{base:"#2196f3",lighten5:"#e3f2fd",lighten4:"#bbdefb",lighten3:"#90caf9",lighten2:"#64b5f6",lighten1:"#42a5f5",darken1:"#1e88e5",darken2:"#1976d2",darken3:"#1565c0",darken4:"#0d47a1",accent1:"#82b1ff",accent2:"#448aff",accent3:"#2979ff",accent4:"#2962ff"},lightBlue:{base:"#03a9f4",lighten5:"#e1f5fe",lighten4:"#b3e5fc",lighten3:"#81d4fa",lighten2:"#4fc3f7",lighten1:"#29b6f6",darken1:"#039be5",darken2:"#0288d1",darken3:"#0277bd",darken4:"#01579b",accent1:"#80d8ff",accent2:"#40c4ff",accent3:"#00b0ff",accent4:"#0091ea"},cyan:{base:"#00bcd4",lighten5:"#e0f7fa",lighten4:"#b2ebf2",lighten3:"#80deea",lighten2:"#4dd0e1",lighten1:"#26c6da",darken1:"#00acc1",darken2:"#0097a7",darken3:"#00838f",darken4:"#006064",accent1:"#84ffff",accent2:"#18ffff",accent3:"#00e5ff",accent4:"#00b8d4"},teal:{base:"#009688",lighten5:"#e0f2f1",lighten4:"#b2dfdb",lighten3:"#80cbc4",lighten2:"#4db6ac",lighten1:"#26a69a",darken1:"#00897b",darken2:"#00796b",darken3:"#00695c",darken4:"#004d40",accent1:"#a7ffeb",accent2:"#64ffda",accent3:"#1de9b6",accent4:"#00bfa5"},green:{base:"#4caf50",lighten5:"#e8f5e9",lighten4:"#c8e6c9",lighten3:"#a5d6a7",lighten2:"#81c784",lighten1:"#66bb6a",darken1:"#43a047",darken2:"#388e3c",darken3:"#2e7d32",darken4:"#1b5e20",accent1:"#b9f6ca",accent2:"#69f0ae",accent3:"#00e676",accent4:"#00c853"},lightGreen:{base:"#8bc34a",lighten5:"#f1f8e9",lighten4:"#dcedc8",lighten3:"#c5e1a5",lighten2:"#aed581",lighten1:"#9ccc65",darken1:"#7cb342",darken2:"#689f38",darken3:"#558b2f",darken4:"#33691e",accent1:"#ccff90",accent2:"#b2ff59",accent3:"#76ff03",accent4:"#64dd17"},lime:{base:"#cddc39",lighten5:"#f9fbe7",lighten4:"#f0f4c3",lighten3:"#e6ee9c",lighten2:"#dce775",lighten1:"#d4e157",darken1:"#c0ca33",darken2:"#afb42b",darken3:"#9e9d24",darken4:"#827717",accent1:"#f4ff81",accent2:"#eeff41",accent3:"#c6ff00",accent4:"#aeea00"},yellow:{base:"#ffeb3b",lighten5:"#fffde7",lighten4:"#fff9c4",lighten3:"#fff59d",lighten2:"#fff176",lighten1:"#ffee58",darken1:"#fdd835",darken2:"#fbc02d",darken3:"#f9a825",darken4:"#f57f17",accent1:"#ffff8d",accent2:"#ffff00",accent3:"#ffea00",accent4:"#ffd600"},amber:{base:"#ffc107",lighten5:"#fff8e1",lighten4:"#ffecb3",lighten3:"#ffe082",lighten2:"#ffd54f",lighten1:"#ffca28",darken1:"#ffb300",darken2:"#ffa000",darken3:"#ff8f00",darken4:"#ff6f00",accent1:"#ffe57f",accent2:"#ffd740",accent3:"#ffc400",accent4:"#ffab00"},orange:{base:"#ff9800",lighten5:"#fff3e0",lighten4:"#ffe0b2",lighten3:"#ffcc80",lighten2:"#ffb74d",lighten1:"#ffa726",darken1:"#fb8c00",darken2:"#f57c00",darken3:"#ef6c00",darken4:"#e65100",accent1:"#ffd180",accent2:"#ffab40",accent3:"#ff9100",accent4:"#ff6d00"},deepOrange:{base:"#ff5722",lighten5:"#fbe9e7",lighten4:"#ffccbc",lighten3:"#ffab91",lighten2:"#ff8a65",lighten1:"#ff7043",darken1:"#f4511e",darken2:"#e64a19",darken3:"#d84315",darken4:"#bf360c",accent1:"#ff9e80",accent2:"#ff6e40",accent3:"#ff3d00",accent4:"#dd2c00"},brown:{base:"#795548",lighten5:"#efebe9",lighten4:"#d7ccc8",lighten3:"#bcaaa4",lighten2:"#a1887f",lighten1:"#8d6e63",darken1:"#6d4c41",darken2:"#5d4037",darken3:"#4e342e",darken4:"#3e2723"},blueGrey:{base:"#607d8b",lighten5:"#eceff1",lighten4:"#cfd8dc",lighten3:"#b0bec5",lighten2:"#90a4ae",lighten1:"#78909c",darken1:"#546e7a",darken2:"#455a64",darken3:"#37474f",darken4:"#263238"},grey:{base:"#9e9e9e",lighten5:"#fafafa",lighten4:"#f5f5f5",lighten3:"#eeeeee",lighten2:"#e0e0e0",lighten1:"#bdbdbd",darken1:"#757575",darken2:"#616161",darken3:"#424242",darken4:"#212121"},shades:{black:"#000000",white:"#ffffff",transparent:"#ffffff00"}}
const mv=Tt({swatches:{type:Array,default:()=>function(e){return Object.keys(e).map(t=>{const a=e[t]
return a.base?[a.base,a.darken4,a.darken3,a.darken2,a.darken1,a.lighten1,a.lighten2,a.lighten3,a.lighten4,a.lighten5]:[a.black,a.white,a.transparent]})}(pv)},disabled:Boolean,readonly:Boolean,color:Object,maxHeight:[Number,String],...Ft()},"VColorPickerSwatches")
const fv=Gt({name:"VColorPickerSwatches",props:mv(),emits:{"update:color":e=>!0},setup(e,{emit:a}){const l=t.toRef(()=>!e.disabled&&!e.readonly)
return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-color-picker-swatches",e.class]),style:t.normalizeStyle([{maxHeight:z(e.maxHeight)},e.style])},[t.createElementVNode("div",null,[e.swatches.map(n=>t.createElementVNode("div",{class:"v-color-picker-swatches__swatch"},[n.map(n=>{const o=yt(n),r=Vt(o),i=xt(o)
return t.createElementVNode("div",{class:t.normalizeClass(["v-color-picker-swatches__color",{"v-color-picker-swatches__color--disabled":e.disabled}]),onClick:()=>function(e){l.value&&e&&a("update:color",e)}(r)},[t.createElementVNode("div",{style:{background:i}},[e.color&&Xt(e.color,r)?t.createVNode(Mn,{size:"x-small",icon:"$success",color:Dt(n,"#FFFFFF")>2?"white":"black"},null):void 0])])})]))])])),{}}}),gv=qt("v-picker-title"),hv=Tt({bgColor:String,divided:Boolean,landscape:Boolean,title:String,hideHeader:Boolean,hideTitle:Boolean,...ys()},"VPicker"),yv=Kt()({name:"VPicker",props:hv(),setup(e,{slots:a}){const{backgroundColorClasses:l,backgroundColorStyles:n}=Ol(()=>e.color)
return sa(()=>{const o=bs.filterProps(e),r=!(e.hideTitle||!e.title&&!a.title)
return t.createVNode(bs,t.mergeProps(o,{color:e.bgColor,class:["v-picker",{"v-picker--divided":e.divided,"v-picker--landscape":e.landscape,"v-picker--with-actions":!!a.actions},e.class],style:e.style}),{default:()=>[!e.hideHeader&&t.createElementVNode("div",{key:"header",class:t.normalizeClass(["v-picker__header-wrapper",l.value]),style:t.normalizeStyle([n.value])},[r&&t.createVNode(gv,{key:"picker-title"},{default:()=>[a.title?.()??e.title]}),a.header&&t.createElementVNode("div",{class:"v-picker__header"},[a.header()])]),t.createElementVNode("div",{class:"v-picker__body"},[a.default?.()]),a.actions&&t.createVNode(Bl,{defaults:{VBtn:{slim:!0,variant:"text"}}},{default:()=>[t.createElementVNode("div",{class:"v-picker__actions"},[a.actions()])]})]})}),{}}}),bv=Tt({canvasHeight:{type:[String,Number],default:150},disabled:Boolean,dotSize:{type:[Number,String],default:10},hideCanvas:Boolean,hideSliders:Boolean,hideInputs:Boolean,hideInputLabels:Boolean,mode:{type:String,default:"rgba",validator:e=>Object.keys(Zd).includes(e)},modes:{type:Array,default:()=>Object.keys(Zd),validator:e=>Array.isArray(e)&&e.every(e=>Object.keys(Zd).includes(e))},showSwatches:Boolean,readonly:Boolean,swatches:Array,swatchesMaxHeight:{type:[Number,String],default:150},modelValue:{type:[Object,String]},...hv({hideHeader:!0}),...U(dv(),["hideEyeDropper","eyeDropperIcon"])},"VColorPicker"),wv=Gt({name:"VColorPicker",props:bv(),emits:{"update:modelValue":e=>!0,"update:mode":e=>!0},setup(e,{slots:l}){const n=_a(e,"mode"),o=t.ref(null),r=_a(e,"modelValue",void 0,e=>{if(null==e||""===e)return null
let t
try{t=Vt(yt(e))}catch(e){return a(e),null}return t},t=>t?function(e,t){if(null==t||g(t)){const a=h(e.a)&&e.a<1
if(t?.startsWith("rgb(")){const{r:t,g:l,b:n,a:o}=bt(e)
return`rgb(${t} ${l} ${n}`+(a?` / ${o})`:")")}if(t?.startsWith("hsl(")){const{h:t,s:l,l:n,a:o}=St(e)
return`hsl(${t} ${Math.round(100*l)} ${Math.round(100*n)}`+(a?` / ${o})`:")")}const l=At(e)
return 1===e.a?l.slice(0,7):l}if(b(t)){let a
return W(t,["r","g","b"])?a=bt(e):W(t,["h","s","l"])?a=St(e):W(t,["h","s","v"])&&(a=e),function(e,t){if(t){const{a:t,...a}=e
return a}return e}(a,!W(t,["a"])&&1===e.a)}return e}(t,e.modelValue):null),i=t.computed(()=>r.value?{...r.value,h:o.value??r.value.h}:null),{rtlClasses:s}=Ua()
let u=!0
t.watch(r,e=>{u?e&&(o.value=e.h):u=!0},{immediate:!0})
const c=e=>{u=!1,o.value=e.h,r.value=e}
return t.onBeforeMount(()=>{e.modes.includes(n.value)||(n.value=e.modes[0])}),Ht({VSlider:{color:null,trackColor:null,trackFillColor:null}}),sa(()=>{const a=yv.filterProps(e)
return t.createVNode(yv,t.mergeProps(a,{class:["v-color-picker",s.value,e.class],style:[{"--v-color-picker-color-hsv":Nt({...i.value??Gd,a:1})},e.style]}),{...l,default:()=>t.createElementVNode(t.Fragment,null,[!e.hideCanvas&&t.createVNode(Yd,{key:"canvas",color:i.value,"onUpdate:color":c,disabled:e.disabled,readonly:e.readonly,dotSize:e.dotSize,width:e.width,height:e.canvasHeight},null),(!e.hideSliders||!e.hideInputs)&&t.createElementVNode("div",{key:"controls",class:"v-color-picker__controls"},[!e.hideSliders&&t.createVNode(vv,{key:"preview",color:i.value,"onUpdate:color":c,hideAlpha:!n.value.endsWith("a"),disabled:e.disabled,readonly:e.readonly,hideEyeDropper:e.hideEyeDropper,eyeDropperIcon:e.eyeDropperIcon},null),!e.hideInputs&&t.createVNode(Jd,{key:"edit",modes:e.modes,mode:n.value,"onUpdate:mode":e=>n.value=e,color:i.value,"onUpdate:color":c,disabled:e.disabled,readonly:e.readonly,hideInputLabels:e.hideInputLabels},null)]),e.showSwatches&&t.createVNode(fv,{key:"swatches",color:i.value,"onUpdate:color":c,maxHeight:e.swatchesMaxHeight,swatches:e.swatches,disabled:e.disabled,readonly:e.readonly},null)])})}),{}}}),Vv=Tt({modelValue:null,color:String,cancelText:{type:String,default:"$vuetify.confirmEdit.cancel"},okText:{type:String,default:"$vuetify.confirmEdit.ok"},disabled:{type:[Boolean,Array],default:void 0},hideActions:Boolean},"VConfirmEdit"),Sv=Kt()({name:"VConfirmEdit",props:Vv(),emits:{cancel:()=>!0,save:e=>!0,"update:modelValue":e=>!0},setup(e,{emit:a,slots:l}){const n=Ut("VBtn"),o=_a(e,"modelValue"),r=t.ref()
t.watchEffect(()=>{r.value=structuredClone(Be(o.value))})
const{t:i}=Ha(),s=t.computed(()=>Xt(o.value,r.value))
function u(t){return y(e.disabled)?e.disabled:Array.isArray(e.disabled)?e.disabled.includes(t):s.value}const c=t.computed(()=>u("save")),d=t.computed(()=>u("cancel"))
function v(){o.value=r.value,a("save",r.value)}function p(){r.value=structuredClone(Be(o.value)),a("cancel")}function m(a){return t.createElementVNode(t.Fragment,null,[t.createVNode(Vo,t.mergeProps({disabled:d.value,variant:n.value?.variant??"text",color:e.color,onClick:p,text:i(e.cancelText)},a),null),t.createVNode(Vo,t.mergeProps({disabled:c.value,variant:n.value?.variant??"text",color:e.color,onClick:v,text:i(e.okText)},a),null)])}let f=!1
return sa(()=>t.createElementVNode(t.Fragment,null,[l.default?.({model:r,save:v,cancel:p,isPristine:s.value,get actions(){return f=!0,m}}),!e.hideActions&&!f&&m()])),{save:v,cancel:p,isPristine:s}}}),kv=["prepend","prepend-inner","append","append-inner"],xv=Tt({hidePip:Boolean,colorPip:Boolean,menuProps:Object,openOnFocus:Boolean,pipIcon:{type:String,default:"$color"},pipLocation:{type:String,default:"prepend",validator:e=>kv.includes(e)},pipVariant:{type:String,default:"text"},pickerProps:Object,...Ko(),...Vv(),..._s(),...G(bv(),["location","height","minHeight","maxHeight"])},"VColorInput"),Nv=Kt()({name:"VColorInput",props:xv(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),n=t.shallowRef(!1),o=t.ref(),r=t.ref(),i=t.shallowRef(e.focused),s=t.computed(()=>!e.disabled&&!e.readonly),u=t.computed(()=>l.value||null)
function c(e){if("Enter"!==e.key)return
if(!n.value||!i.value)return void(n.value=!0)
const t=e.target
l.value=t.value}function d(e){e.preventDefault(),e.stopPropagation(),n.value=!0}function v(){qs(n,r.value?.$el,o.value?.contentEl)}function p(){n.value=!1}function m(){n.value=!1}Xs(n,i,()=>e.openOnFocus&&s.value),sa(()=>{const f=Sv.filterProps(e),g={...wv.filterProps(G(e,["active","bgColor","color","rounded","maxWidth","minWidth","width"])),...e.pickerProps},h=Rs.filterProps(e),y=e.hidePip?void 0:{[e.pipLocation]:n=>t.createElementVNode(t.Fragment,null,[t.createVNode(Bo,{class:"v-color-input__pip",color:e.colorPip?l.value:void 0,variant:e.pipVariant,icon:e.pipIcon},null),a[e.pipLocation]?.(n)])}
return t.createVNode(Rs,t.mergeProps({ref:r},h,{class:["v-color-input",e.class],style:e.style,modelValue:u.value,onKeydown:s.value?c:void 0,focused:n.value||i.value,"onClick:control":e.disabled?void 0:d,"onClick:prependInner":e.disabled?void 0:d,"onUpdate:focused":e=>i.value=e,onBlur:v,"onClick:appendInner":e.disabled?void 0:d,"onUpdate:modelValue":e=>{l.value=e}}),{...a,...y,default:()=>t.createElementVNode(t.Fragment,null,[t.createVNode(hs,t.mergeProps({ref:o,modelValue:n.value,"onUpdate:modelValue":e=>n.value=e,activator:"parent",minWidth:"0",closeOnContentClick:!1,openOnClick:!1},e.menuProps),{default:()=>[t.createVNode(Sv,t.mergeProps(f,{modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,onSave:p,onCancel:m}),{default:({actions:n,model:o,save:r,cancel:i,isPristine:s})=>t.createVNode(wv,t.mergeProps(g,{modelValue:e.hideActions?l.value:o.value,"onUpdate:modelValue":t=>function(t){e.hideActions?l.value=t:o.value=t}(t)}),{actions:e.hideActions?void 0:()=>a.actions?.({save:r,cancel:i,isPristine:s})??n()})})]}),a.default?.()])})})}}),Cv=Tt({alwaysFilter:Boolean,autoSelectFirst:{type:[Boolean,String]},clearOnSelect:{type:Boolean,default:!0},delimiters:Array,closeOnInputClick:Boolean,trimValues:Boolean,...eu({filterKeys:["title"]}),...ou({hideNoData:!0,returnObject:!0}),...G(_s({modelValue:null,role:"combobox"}),["validationValue","dirty"])},"VCombobox"),Ev=Kt()({name:"VCombobox",props:Cv(),emits:{"update:focused":e=>!0,"update:modelValue":e=>!0,"update:search":e=>!0,"update:menu":e=>!0,"item:added":e=>!0,"item:removed":e=>!0,"item:created":e=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),o=t.ref(),r=t.ref(),i=t.ref(),s=t.ref(),u=t.ref(),c=t.ref(),d=t.shallowRef(!1),v=t.shallowRef(!0),p=t.shallowRef(!1),m=t.shallowRef(-1)
let g=!1
const{items:y,transformIn:b,transformOut:w}=yi(e),{textColorClasses:V,textColorStyles:S}=Ll(()=>o.value?.color),{InputIcon:k}=Uo(e),x=_a(e,"modelValue",[],e=>b(ee(e)),t=>{const a=w(t)
return e.multiple?a:a[0]??null}),N=Qo(e),C=t.toRef(()=>e.closableChips&&!N.isReadonly.value&&!N.isDisabled.value),I=Ut("VChip"),A=t.computed(()=>!(!e.chips&&!l.chip)),P=t.computed(()=>A.value||!!l.selection),_=t.shallowRef(e.multiple||P.value?"":x.value[0]?.title??""),R=t.shallowRef(null),D=t.computed({get:()=>_.value,set:async l=>{if(_.value=l??"",null===l||""===l&&!e.multiple&&!P.value){for(const e of x.value)a("item:removed",e)
x.value=[]}else e.multiple||P.value||(x.value=[gi(e,l)],t.nextTick(()=>c.value?.scrollToIndex(0)))
if(l&&e.multiple&&e.delimiters?.length){const e=pe(l)
e.length>1&&(me(e),_.value="")}l||(m.value=-1),v.value=!l}}),B=t.computed(()=>f(e.counterValue)?e.counterValue(x.value):h(e.counterValue)?e.counterValue:e.multiple?x.value.length:D.value.length),{filteredItems:T,getMatches:F}=au(e,y,()=>R.value??(e.alwaysFilter||!v.value?D.value:"")),$=t.computed(()=>e.hideSelected&&null===R.value?T.value.filter(e=>!x.value.some(t=>t.value===e.value)):T.value),M=t.computed(()=>e.hideNoData&&!$.value.length||N.isReadonly.value||N.isDisabled.value),{menu:z,closeOnSelect:L}=Zs(e,{vMenuRef:r,menuDisabled:M,isFocused:d}),{menuId:O,ariaExpanded:j,ariaControls:H}=nu(0,z),{listEvents:W,onActivatorKeydown:U,setPendingFocus:Y,flushPendingFocus:G}=Ks(i,o,c,$,{selectedIndex:()=>v.value?se():-1,headerEl:()=>s.value,menuContentEl:()=>r.value?.contentEl,noAutoScroll:()=>e.noAutoScroll})
t.watch(_,e=>{g?t.nextTick(()=>g=!1):d.value&&!z.value&&(z.value=!0),z.value&&d.value&&t.nextTick(()=>{c.value?.scrollToIndex(0),i.value?.$el?.contains(be())&&o.value?.focus()}),a("update:search",e)}),t.watch(x,t=>{e.multiple||P.value||(_.value=t[0]?.title??"")})
const K=t.computed(()=>x.value.map(e=>e.value)),q=t.computed(()=>$.value.find(e=>"item"===e.type&&!e.props.disabled)),X=t.computed(()=>(!0===e.autoSelectFirst||"exact"===e.autoSelectFirst&&D.value===q.value?.title)&&$.value.length>0&&!v.value&&!p.value),Z=Us(z,()=>r.value?.contentEl,()=>o.value?.controlRef),{onTabKeydown:J}=Qs({groups:[{type:"element",contentRef:s},{type:"list",contentRef:i,displayItemsCount:()=>$.value.length},{type:"element",contentRef:u}],onLeave:()=>{z.value=!1,o.value?.focus()}})
function te(a){g=!0,t.nextTick(()=>g=!1),e.openOnClear&&(z.value=!0)}function ae(){M.value||(z.value=!e.closeOnInputClick||!z.value)}function le(e){M.value||(d.value&&(e.preventDefault(),e.stopPropagation()),z.value=!z.value)}function ne(e){"Tab"===e.key&&J(e),i.value?.$el.contains(e.target)&&(Ie(e)||"Backspace"===e.key)&&o.value?.focus()}function oe(t){if(!Q(t)&&!N.isReadonly.value)switch(t.key){case"Escape":z.value=!1
break
case"ArrowDown":case"ArrowUp":if(t.preventDefault(),U(t,z))break
"ArrowDown"===t.key&&X.value&&i.value?.focus("next")
break
case"Enter":t.preventDefault(),z.value=!0,re(),D.value&&function(){const t=e.trimValues?D.value.trim():D.value
if(!t)return void(D.value="")
ve(gi(e,t),!0,!0),P.value&&(_.value="")}()
break
case"Tab":re(),z.value=!1
break
default:!function(t){const a=x.value.length
if(["Backspace","Delete"].includes(t.key)){if(!e.multiple&&P.value&&a>0&&!D.value)return ve(x.value[0],!1)
if(~m.value){t.preventDefault()
const e=m.value
ve(x.value[m.value],!1),m.value=e>=a-1?a-2:e}else"Backspace"!==t.key||D.value||(m.value=a-1)
return}if(!e.multiple)return
if("ArrowLeft"===t.key){if(m.value<0&&(o.value?.selectionStart??0)>0)return
const e=m.value>-1?m.value-1:a-1
x.value[e]?m.value=e:(m.value=-1,o.value?.setSelectionRange(D.value.length,D.value.length))}else if("ArrowRight"===t.key){if(m.value<0)return
const e=m.value+1
x.value[e]?m.value=e:(m.value=-1,o.value?.setSelectionRange(0,0))}else~m.value&&Ie(t)&&(m.value=-1)}(t)}}function re(){const e=q.value
X.value&&e&&(x.value.some(({value:t})=>t===e.value)||ve(e))}function ie(t){const a=pe(t?.clipboardData?.getData("Text")??"")
a.length>1&&e.multiple&&(t.preventDefault(),me(a))}function se(){return $.value.findIndex(t=>x.value.some(a=>(e.valueComparator||Xt)(a.value,t.value)))}function ue(){e.eager&&c.value?.calculateVisibleItems(),G()}function ce(){d.value&&(r.value?.contentEl?._clickOutside?.lastMousedownWasOutside?d.value=!1:o.value?.focus()),v.value=!0,R.value=null}function de(t){const a=e.valueComparator||Xt
return y.value.some(e=>a(e.value,t.value))}function ve(l,n=!0,o=!1){if(!l||l.props.disabled)return
const r=e.valueComparator||Xt
if(e.multiple){const t=x.value.findIndex(e=>r(e.value,l.value)),o=null==n?!~t:n
if(~t){const e=o?[...x.value,l]:[...x.value],[n]=e.splice(t,1)
o||a("item:removed",n),x.value=e}else o&&(a("item:added",l),de(l)||a("item:created",l),x.value=[...x.value,l])
e.clearOnSelect&&(D.value="")}else{const i=!1!==n,s=x.value[0]
i?(s&&!r(s.value,l.value)?(a("item:removed",s),a("item:added",l),de(l)||a("item:created",l)):s||(a("item:added",l),de(l)||a("item:created",l)),x.value=[l]):(s&&a("item:removed",s),x.value=[]),v.value&&!e.alwaysFilter||!_.value||(R.value=_.value),_.value=i&&!P.value?l.title:"",t.nextTick(()=>{o||L(),v.value=!0})}}function pe(t){const a=["\n",...e.delimiters??[]].map(Pe).join("|")
return t.split(new RegExp(`(?:${a})+`))}async function me(a){for(let l of a)l=l.trim(),l&&(ve(gi(e,l)),await t.nextTick())}function fe(e){d.value=!0,setTimeout(()=>{p.value=!0})}function ge(e){if(p.value=!1,!o.value?.$el.contains(e.relatedTarget)){if(Z(e))return
d.value=!1}}let he=0
function ye(){he=performance.now()}function we(e){const t=e.relatedTarget,a=r.value?.contentEl;(a?.contains(t)||!t&&performance.now()-he<10)&&(d.value=!0)}return t.watch(d,(t,a)=>{if(!t&&t!==a&&(m.value=-1,z.value=!1,D.value)){const t=e.trimValues?D.value.trim():D.value
if(!t)return void(D.value="")
if(e.multiple)return void ve(gi(e,t))
if(!P.value)return void(t!==D.value&&ve(gi(e,t)))
x.value.some(({title:e})=>e===t)?_.value="":ve(gi(e,t))}}),t.watch(z,t=>{if(t||Y(null),!e.hideSelected&&t&&x.value.length&&v.value){const t=se()
E&&!e.noAutoScroll&&window.requestAnimationFrame(()=>{t>=0&&c.value?.scrollToIndex(t,"center")})}t&&(R.value=null)}),t.watch(y,(e,t)=>{z.value||d.value&&!t.length&&e.length&&(z.value=!0)}),sa(()=>{const a=!!(!e.hideNoData||$.value.length||l["prepend-item"]||l["append-item"]||l["no-data"]),p=x.value.length>0,f=Rs.filterProps(e),g={search:D,filteredItems:T.value}
return t.createVNode(Rs,t.mergeProps({ref:o},f,{form:"",modelValue:D.value,"onUpdate:modelValue":e=>D.value=e,focused:d.value,"onUpdate:focused":e=>d.value=e,validationValue:x.externalValue,counterValue:B.value,dirty:p,class:["v-combobox",{"v-combobox--active-menu":z.value,"v-combobox--chips":!!e.chips,"v-combobox--selection-slot":!!P.value,"v-combobox--selecting-index":m.value>-1,["v-combobox--"+(e.multiple?"multiple":"single")]:!0},e.class],style:e.style,readonly:N.isReadonly.value,placeholder:p?void 0:e.placeholder,"onClick:clear":te,"onMousedown:control":ae,onKeydown:oe,onPaste:ie,onBlur:we,"aria-expanded":j.value,"aria-controls":H.value}),{...l,default:({id:o})=>t.createElementVNode(t.Fragment,null,[K.value.map((a,l)=>t.createElementVNode("input",{key:l,type:"hidden",name:e.name,value:a,form:e.form},null)),t.createVNode(hs,t.mergeProps({id:O.value,ref:r,modelValue:z.value,"onUpdate:modelValue":e=>z.value=e,activator:"parent",captureFocus:!1,openOnArrow:!1,disabled:M.value,_disableKeys:!0,eager:e.eager,maxHeight:310,openOnClick:!1,closeOnContentClick:!1,onAfterEnter:ue,onAfterLeave:ce},e.menuProps,{contentClass:["v-combobox__content",e.menuProps?.contentClass]}),{default:()=>[t.createVNode(bs,{elevation:e.menuElevation,onFocusin:fe,onKeydown:ne,onMousedown:ye},{default:()=>[l["menu-header"]&&t.createElementVNode("header",{ref:s},[l["menu-header"](g)]),a&&t.createVNode(xi,t.mergeProps({key:"combobox-list",ref:i,class:"v-list--navigable",filterable:!0,selected:K.value,selectStrategy:e.multiple?"independent":"single-independent",onMousedown:e=>e.preventDefault(),selectable:!!$.value.length,onFocusout:ge,tabindex:"-1","aria-live":"polite","aria-labelledby":`${o.value}-label`,"aria-multiselectable":e.multiple,color:e.itemColor??e.color},W,e.listProps),{default:()=>[l["prepend-item"]?.(),!$.value.length&&!e.hideNoData&&(l["no-data"]?.()??t.createVNode(ui,{key:"no-data",title:n(e.noDataText)},null)),t.createVNode(zs,{ref:c,renderless:!0,items:$.value,itemKey:"value"},{default:({item:a,index:n,itemRef:o})=>{const r=De(a.props),i=t.mergeProps(a.props,{ref:o,key:a.value,active:!(!X.value||a!==q.value)||void 0,onClick:()=>ve(a,null),"aria-posinset":n+1,"aria-setsize":$.value.length})
return"divider"===a.type?l.divider?.({props:a.raw,index:n})??t.createVNode(zr,t.mergeProps(a.props,{ref:o,key:`divider-${n}`}),null):"subheader"===a.type?l.subheader?.({props:a.raw,index:n})??t.createVNode(di,t.mergeProps(a.props,{ref:o,key:`subheader-${n}`}),null):l.item?.({item:a.raw,internalItem:a,index:n,props:i})??t.createVNode(ui,t.mergeProps(i,{role:"option"}),{prepend:({isSelected:l})=>t.createElementVNode(t.Fragment,null,[e.multiple&&!e.hideSelected?t.createVNode(Wo,{key:a.value,modelValue:l,ripple:!1,tabindex:"-1","aria-hidden":!0,onClick:e=>e.preventDefault()},null):void 0,r.prependAvatar&&t.createVNode(Bo,{image:r.prependAvatar},null),r.prependIcon&&t.createVNode(Mn,{icon:r.prependIcon},null)]),title:()=>v.value?a.title:t.createVNode(Ws,{text:a.title,matches:F(a)?.title,markClass:"v-combobox__mask",matchAll:!0,ignoreCase:!0},null)})}}),l["append-item"]?.()]}),l["menu-footer"]&&t.createElementVNode("footer",{ref:u},[l["menu-footer"](g)])]})]}),x.value.map((a,n)=>{function o(e){e.stopPropagation(),e.preventDefault(),ve(a,!1)}const r=t.mergeProps(Fr.filterProps(a.props),{"onClick:close":o,onKeydown(e){"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),e.stopPropagation(),o(e))},onMousedown(e){e.preventDefault(),e.stopPropagation()},modelValue:!0,"onUpdate:modelValue":void 0}),i=A.value?!!l.chip:!!l.selection,s=i?Ne(A.value?l.chip({item:a.raw,internalItem:a,index:n,props:r}):l.selection({item:a.raw,internalItem:a,index:n})):void 0
if(!i||s)return t.createElementVNode("div",{key:a.value,class:t.normalizeClass(["v-combobox__selection",n===m.value&&["v-combobox__selection--selected",V.value]]),style:t.normalizeStyle(n===m.value?S.value:{})},[A.value?l.chip?t.createVNode(Bl,{key:"chip-defaults",defaults:{VChip:{closable:C.value,size:I.value?.size??"small",text:a.title}}},{default:()=>[s]}):t.createVNode(Fr,t.mergeProps({key:"chip",closable:C.value,size:I.value?.size??"small",text:a.title,disabled:a.props.disabled},r),null):s??t.createElementVNode("span",{class:"v-combobox__selection-text"},[a.title,e.multiple&&n<x.value.length-1&&t.createElementVNode("span",{class:"v-combobox__selection-comma"},[t.createTextVNode(",")])])])})]),"append-inner":(...a)=>t.createElementVNode(t.Fragment,null,[l["append-inner"]?.(...a),e.hideNoData&&!e.items.length||!e.menuIcon?void 0:t.createVNode(Mn,{class:"v-combobox__menu-icon",color:o.value?.fieldIconColor,icon:e.menuIcon,onMousedown:le,onClick:ke,"aria-hidden":!0,tabindex:"-1"},null),e.appendInnerIcon&&t.createVNode(k,{key:"append-icon",name:"appendInner",color:a[0].iconColor.value},null)])})}),ir({isFocused:d,isPristine:v,menu:z,search:D,selectionIndex:m,filteredItems:T,select:ve},o)}}),Iv=Tt({expandOnClick:Boolean,showExpand:Boolean,expanded:{type:Array,default:()=>[]},expandStrategy:{type:String,default:"multiple"}},"DataTable-expand"),Av=Symbol.for("vuetify:datatable:expanded")
function Pv(e){const a=t.toRef(()=>e.expandOnClick),l=_a(e,"expanded",e.expanded,e=>new Set(e),e=>[...e.values()])
function n(a,n){const o=t.toRaw(a.value),r=n&&"single"===e.expandStrategy?new Set:new Set(l.value)
if(n)r.add(a.value)
else{const e=[...l.value].find(e=>t.toRaw(e)===o)
r.delete(e)}l.value=r}function o(e){const a=t.toRaw(e.value)
return[...l.value].some(e=>t.toRaw(e)===a)}const r={expand:n,expanded:l,expandOnClick:a,isExpanded:o,toggleExpand:function(e){n(e,!o(e))}}
return t.provide(Av,r),r}function _v(){const e=t.inject(Av)
if(!e)throw new Error("foo")
return e}const Rv=Tt({groupBy:{type:Array,default:()=>[]},opened:{type:Array,default:()=>[]},openAll:Boolean,groupKey:Function},"DataTable-group"),Dv=Symbol.for("vuetify:data-table-group")
function Bv(e){return{groupBy:_a(e,"groupBy"),opened:_a(e,"opened"),openAll:t.toRef(()=>e.openAll),groupKey:t.toRef(()=>e.groupKey)}}function Tv(e){const{disableSort:a,groupBy:l,sortBy:n}=e,o=e.opened??t.ref([]),r=t.shallowRef(new Set(o.value))
t.watch(o,e=>{r.value=new Set(e)})
const i=t.computed({get:()=>r.value,set:e=>{r.value=e,o.value=[...e.values()]}})
function s(e){return i.value.has(e.id)}const u={sortByWithGroups:t.computed(()=>l.value.map(e=>({...e,order:e.order??!1})).concat(a?.value?[]:n.value)),toggleGroup:function(e){const t=new Set(i.value)
s(e)?t.delete(e.id):t.add(e.id),i.value=t},opened:i,groupBy:l,extractRows:function(e){return function e(t){const a=[]
for(const l of t.items)"type"in l&&"group"===l.type?a.push(...e(l)):a.push(l)
return[...new Set(a)]}({items:e})},isGroupOpen:s}
return t.provide(Dv,u),u}function Fv(){const e=t.inject(Dv)
if(!e)throw new Error("Missing group!")
return e}function $v(e,t,a,l=0,n="root"){if(!t.length)return[]
const o=function(e,t){if(!e.length)return[]
const a=new Map
for(const l of e){const e=T(l.raw,t)
a.has(e)||a.set(e,[]),a.get(e).push(l)}return a}(e,t[0]),r=[],i=t.slice(1)
return o.forEach((e,o)=>{const s=t[0],u=a?a({key:s,value:o,parentKey:0===l?null:n}):((e,t,a)=>`${a}_${e}_${t}`)(s,o,n)
r.push({depth:l,id:u,key:s,value:o,items:i.length?$v(e,i,a,l+1,u):e,type:"group"})}),r}function Mv(e){return e.flatMap(e=>[e.id,...Mv(e.items.filter(e=>"type"in e&&"group"===e.type))])}function zv(e,a,l,n,o){const r=t.computed(()=>t.toValue(a)&&n.value.length?new Set(Mv($v(t.toValue(l),n.value.map(e=>e.key),t.toValue(o)))):new Set)
t.watch(r,(l,n)=>{if(!t.toValue(a))return
const o=new Set(e.value)
let r=!1
for(const e of l)n?.has(e)||o.has(e)||(o.add(e),r=!0)
for(const e of n??[])!l.has(e)&&o.has(e)&&(o.delete(e),r=!0)
r&&(e.value=o)},{immediate:!0})}function Lv(e,t,a){const l=[]
for(const n of e)"type"in n&&"group"===n.type?(null!=n.value&&l.push(n),(t(n)||null==n.value)&&(l.push(...Lv(n.items,t,a)),a&&l.push({...n,type:"group-summary"}))):l.push(n)
return l}function Ov(e,a,l,n,o,r){const i=t.computed(()=>a.value.length?$v(t.toValue(e),a.value.map(e=>e.key),t.toValue(r)):[]),s=o??(e=>l.value.has(e.id)),u=t.computed(()=>a.value.length?Lv(i.value,s,t.toValue(n)):t.toValue(e))
return{groups:i,flatItems:u}}function jv({page:e,itemsPerPage:a,sortBy:l,groupBy:n,search:o}){const r=$t("VDataTable")
let i=null
t.watch(()=>({page:e.value,itemsPerPage:a.value,sortBy:l.value,groupBy:n.value,search:o.value}),t=>{Xt(i,t)||(i&&i.search!==t.search&&(e.value=1),r.emit("update:options",t),i=t)},{deep:!0,immediate:!0})}const Hv=Tt({page:{type:[Number,String],default:1},itemsPerPage:{type:[Number,String],default:10},pageBy:{type:String,default:"any"}},"DataTable-paginate"),Wv=Symbol.for("vuetify:data-table-pagination")
function Uv(e){return{page:_a(e,"page",void 0,e=>Number(e??1)),itemsPerPage:_a(e,"itemsPerPage",void 0,e=>Number(e??10))}}function Yv(e){const{page:a,itemsPerPage:l,itemsLength:n}=e,o=t.computed(()=>-1===l.value?0:l.value*(a.value-1)),r=t.computed(()=>-1===l.value?n.value:Math.min(n.value,o.value+l.value)),i=t.computed(()=>-1===l.value||0===n.value?1:Math.ceil(n.value/l.value))
t.watch([a,i],()=>{a.value>i.value&&(a.value=i.value)})
const s={page:a,itemsPerPage:l,startIndex:o,stopIndex:r,pageCount:i,itemsLength:n,nextPage:function(){a.value=ae(a.value+1,1,i.value)},prevPage:function(){a.value=ae(a.value-1,1,i.value)},setPage:function(e){a.value=ae(e,1,i.value)},setItemsPerPage:function(e){l.value=e,a.value=1}}
return t.provide(Wv,s),s}function Gv(e){const a=$t("usePaginatedItems"),{items:l,startIndex:n,stopIndex:o,itemsPerPage:r}=e,i=t.computed(()=>r.value<=0?t.toValue(l):t.toValue(l).slice(n.value,o.value))
return t.watch(i,e=>{a.emit("update:currentItems",e)},{immediate:!0}),{paginatedItems:i}}const Kv={showSelectAll:!1,allSelected:()=>[],select:({items:e,value:t})=>new Set(t?[e[0]?.value]:[]),selectAll:({selected:e})=>e},qv={showSelectAll:!0,allSelected:({currentPage:e})=>e,select:({items:e,value:t,selected:a})=>{for(const l of e)t?a.add(l.value):a.delete(l.value)
return a},selectAll:({value:e,currentPage:t,selected:a})=>qv.select({items:t,value:e,selected:a})},Xv={showSelectAll:!0,allSelected:({allItems:e})=>e,select:({items:e,value:t,selected:a})=>{for(const l of e)t?a.add(l.value):a.delete(l.value)
return a},selectAll:({value:e,allItems:t})=>new Set(e?t.map(e=>e.value):[])},Zv=Tt({showSelect:Boolean,selectStrategy:{type:[String,Object],default:"page"},modelValue:{type:Array,default:()=>[]},valueComparator:Function},"DataTable-select"),Qv=Symbol.for("vuetify:data-table-selection")
function Jv(e,{allItems:a,currentPage:l}){const n=_a(e,"modelValue",e.modelValue,t=>{const l=e.valueComparator
return l?new Set(ee(t).map(e=>a.value.find(t=>l(e,t.value))?.value??e)):new Set(ee(t).map(e=>Ae(e)?a.value.find(t=>e===t.value)?.value??e:a.value.find(t=>Xt(e,t.value))?.value??e))},e=>[...e.values()]),o=t.computed(()=>a.value.filter(e=>e.selectable)),r=t.computed(()=>t.toValue(l).filter(e=>e.selectable)),i=t.computed(()=>{if(b(e.selectStrategy))return e.selectStrategy
switch(e.selectStrategy){case"single":return Kv
case"all":return Xv
default:return qv}}),s=t.shallowRef(null)
function u(e){return ee(e).every(e=>n.value.has(e.value))}function c(e,t){const a=i.value.select({items:e,value:t,selected:new Set(n.value)})
n.value=a}const d=t.computed(()=>n.value.size>0),v=t.computed(()=>{const e=i.value.allSelected({allItems:o.value,currentPage:r.value})
return!!e.length&&u(e)}),p={toggleSelect:function(a,n,o){const r=[],i=t.toValue(l)
if(n=n??i.findIndex(e=>e.value===a.value),"single"!==e.selectStrategy&&o?.shiftKey&&null!==s.value){const[e,t]=[s.value,n].sort((e,t)=>e-t)
r.push(...i.slice(e,t+1).filter(e=>e.selectable))}else r.push(a),s.value=n
c(r,!u([a]))},select:c,selectAll:function(e){const t=i.value.selectAll({value:e,allItems:o.value,currentPage:r.value,selected:new Set(n.value)})
n.value=t},isSelected:u,isSomeSelected:function(e){return ee(e).some(e=>n.value.has(e.value))},someSelected:d,allSelected:v,showSelectAll:t.toRef(()=>i.value.showSelectAll),lastSelectedIndex:s,selectStrategy:i}
return t.provide(Qv,p),p}function ep(){const e=t.inject(Qv)
if(!e)throw new Error("Missing selection!")
return e}const tp=Tt({initialSortOrder:{type:String,default:"asc",validator:e=>!e||["asc","desc"].includes(e)},sortBy:{type:Array,default:()=>[]},customKeySort:Object,multiSort:{type:[Boolean,Object],default:!1},mustSort:Boolean},"DataTable-sort"),ap=Symbol.for("vuetify:data-table-sort")
function lp(e){const a=t.toRef(()=>e.initialSortOrder),l=_a(e,"sortBy"),n=t.toRef(()=>e.mustSort)
return{initialSortOrder:a,sortBy:l,multiSort:t.toRef(()=>e.multiSort),mustSort:n}}function np(e){const{initialSortOrder:a,sortBy:l,mustSort:n,multiSort:o,page:r}=e
const i={sortBy:l,toggleSort:(e,t,i=!1)=>{if(null==e.key)return
let s=l.value.map(e=>({...e}))??[]
const u=s.find(t=>t.key===e.key),c=a.value,d="desc"===a.value?"asc":"desc"
if(u)u.order===d?i||n.value&&1===s.length?u.order=a.value:s=s.filter(t=>t.key!==e.key):u.order=d
else{const{active:a,mode:l}=function(e,t){if(!b(e))return{active:!!e}
const{key:a,mode:l,modifier:n}=e,o="alt"===n&&t?.altKey||"shift"===n&&t?.shiftKey
return{active:!a||t?.ctrlKey||t?.metaKey||!1,mode:o?"append"===l?"prepend":"append":l}}(o.value,t)
a?"prepend"===l?s.unshift({key:e.key,order:c}):s.push({key:e.key,order:c}):s=[{key:e.key,order:c}]}l.value=s,r&&(r.value=1)},isSorted:function(e){return!!l.value.find(t=>t.key===e.key)}}
return t.provide(ap,i),i}function op(){const e=t.inject(ap)
if(!e)throw new Error("Missing sort!")
return e}function rp(e,a,l,n){const o=Ha(),r=t.computed(()=>l.value.length?function(e,t,a,l){const n=new Intl.Collator(a,{sensitivity:"accent",usage:"sort"}),o=e.map(e=>[e,l?.transform?l.transform(e):e])
return o.sort((e,a)=>{for(let o=0;o<t.length;o++){let r=!1
const i=t[o].key,s=t[o].order??"asc"
if(!1===s)continue
let u=T(e[1],i),c=T(a[1],i),d=e[0].raw,v=a[0].raw
if("desc"===s&&([u,c]=[c,u],[d,v]=[v,d]),l?.sortRawFunctions?.[i]){const e=l.sortRawFunctions[i](d,v)
if(null==e)continue
if(r=!0,e)return e}if(l?.sortFunctions?.[i]){const e=l.sortFunctions[i](u,c)
if(null==e)continue
if(r=!0,e)return e}if(!r&&(u instanceof Date&&c instanceof Date&&(u=u.getTime(),c=c.getTime()),[u,c]=[u,c].map(e=>null!=e?e.toString().toLocaleLowerCase():e),u!==c))return Se(u)&&Se(c)?0:Se(u)?-1:Se(c)?1:isNaN(u)||isNaN(c)?n.compare(u,c):Number(u)-Number(c)}return 0}).map(([e])=>e)}(a.value,l.value,o.current.value,{transform:n?.transform,sortFunctions:{...e.customKeySort,...n?.sortFunctions?.value},sortRawFunctions:n?.sortRawFunctions?.value}):a.value)
return{sortedItems:r}}const ip=Tt({items:{type:Array,default:()=>[]},itemValue:{type:[String,Array,Function],default:"id"},itemSelectable:{type:[String,Array,Function],default:null},returnObject:Boolean},"DataIterator-items")
function sp(e,t){return{type:"item",value:e.returnObject?t:F(t,e.itemValue),selectable:F(t,e.itemSelectable,!0),raw:t}}function up(e){const a=t.computed(()=>function(e,t){const a=[]
for(const l of t)a.push(sp(e,l))
return a}(e,e.items))
return{items:a}}const cp=Tt({search:String,loading:Boolean,itemsLength:[Number,String],...Ft(),...ip(),...Zv(),...tp(),...Hv({itemsPerPage:5}),...Iv(),...Rv(),...eu(),...ol(),...ql({transition:{component:wl,hideOnLeave:!0}})},"VDataIterator"),dp=Kt()({name:"VDataIterator",props:cp(),emits:{"update:modelValue":e=>!0,"update:groupBy":e=>!0,"update:page":e=>!0,"update:itemsPerPage":e=>!0,"update:sortBy":e=>!0,"update:options":e=>!0,"update:expanded":e=>!0,"update:opened":e=>!0,"update:currentItems":e=>!0},setup(e,{slots:a}){const{groupBy:l,opened:n,openAll:o,groupKey:r}=Bv(e),i=t.toRef(()=>e.search),{items:s}=up(e),{filteredItems:u}=au(e,s,i,{transform:e=>e.raw}),{initialSortOrder:c,sortBy:d,multiSort:v,mustSort:p}=lp(e),{page:m,itemsPerPage:f}=Uv(e),{toggleSort:g}=np({initialSortOrder:c,sortBy:d,multiSort:v,mustSort:p,page:m}),{sortByWithGroups:h,opened:y,extractRows:b,isGroupOpen:w,toggleGroup:V}=Tv({groupBy:l,sortBy:d,opened:n}),{sortedItems:S}=rp(e,u,h,{transform:e=>e.raw})
zv(y,o,S,l,r)
const{flatItems:k}=Ov(S,l,y,!1,w,r),x=t.toRef(()=>!Se(e.itemsLength)),N=t.toRef(()=>x.value?Number(e.itemsLength):k.value.length),{startIndex:C,stopIndex:E,pageCount:I,prevPage:A,nextPage:P,setItemsPerPage:_,setPage:R}=Yv({page:m,itemsPerPage:f,itemsLength:N}),D=t.shallowRef([]),B=t.computed(()=>x.value?k.value:D.value)
Pa(()=>!x.value,()=>{const{paginatedItems:e}=Gv({items:k,startIndex:C,stopIndex:E,itemsPerPage:f})
t.watchEffect(()=>{D.value=e.value})})
const T=t.computed(()=>b(B.value)),{isSelected:F,select:$,selectAll:M,toggleSelect:z}=Jv(e,{allItems:s,currentPage:T}),{isExpanded:L,toggleExpand:O}=Pv(e)
jv({page:m,itemsPerPage:f,sortBy:d,groupBy:l,search:i})
const j=t.computed(()=>({page:m.value,itemsPerPage:f.value,sortBy:d.value,pageCount:I.value,toggleSort:g,prevPage:A,nextPage:P,setPage:R,setItemsPerPage:_,isSelected:F,select:$,selectAll:M,toggleSelect:z,isExpanded:L,toggleExpand:O,isGroupOpen:w,toggleGroup:V,items:T.value,itemsCount:u.value.length,groupedItems:B.value}))
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-data-iterator",{"v-data-iterator--loading":e.loading},e.class]),style:t.normalizeStyle(e.style)},{default:()=>[a.header?.(j.value),t.createVNode(Xl,{transition:e.transition},{default:()=>[e.loading?t.createVNode(qn,{key:"loader",name:"v-data-iterator",active:!0},{default:e=>a.loader?.(e)}):t.createElementVNode("div",{key:"items"},[B.value.length?a.default?.(j.value):a["no-data"]?.()])]}),a.footer?.(j.value)]})),{}}})
const vp=Tt({activeColor:String,start:{type:[Number,String],default:1},modelValue:{type:Number,default:e=>e.start},disabled:Boolean,length:{type:[Number,String],default:1,validator:e=>e%1==0},totalVisible:[Number,String],firstIcon:{type:ua,default:"$first"},prevIcon:{type:ua,default:"$prev"},nextIcon:{type:ua,default:"$next"},lastIcon:{type:ua,default:"$last"},ariaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.root"},pageAriaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.page"},currentPageAriaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.currentPage"},firstAriaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.first"},previousAriaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.previous"},nextAriaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.next"},lastAriaLabel:{type:String,default:"$vuetify.pagination.ariaLabel.last"},ellipsis:{type:String,default:"..."},showFirstLastPage:{type:[Boolean,String],default:!1},...an(),...Ft(),...yn(),...nn(),...Gl(),...Vn(),...ol({tag:"nav"}),...Ga(),...Nn({variant:"text"})},"VPagination"),pp=Kt()({name:"VPagination",props:vp(),emits:{"update:modelValue":e=>!0,first:e=>!0,prev:e=>!0,next:e=>!0,last:e=>!0},setup(e,{slots:a,emit:l}){const n=_a(e,"modelValue"),{t:o,n:r}=Ha(),{isRtl:i}=Ua(),{themeClasses:s}=tl(e),{width:u}=yr(),c=t.shallowRef(-1)
Ht(void 0,{scoped:!0})
const{resizeRef:d}=Sa(e=>{if(!e.length)return
const{target:t,contentRect:a}=e[0],l=t.querySelector(".v-pagination__list > *")
if(!l)return
const n=a.width,o=l.offsetWidth+2*parseFloat(getComputedStyle(l).marginRight)
c.value=f(n,o)}),v=t.computed(()=>parseInt(e.length,10)),p=t.computed(()=>parseInt(e.start,10)),m=t.computed(()=>null!=e.totalVisible?parseInt(e.totalVisible,10):c.value>=0?c.value:f(u.value,58))
function f(t,a){const l=e.showFirstLastPage?5:3
return Math.max(0,Math.floor(Number(((t-a*l)/a).toFixed(2))))}const h=t.computed(()=>{if(v.value<=0||isNaN(v.value)||v.value>Number.MAX_SAFE_INTEGER)return[]
if(null==e.totalVisible&&v.value<3)return C(v.value,p.value)
if(m.value<=0)return[]
if(1===m.value)return[n.value]
if(v.value<=m.value)return C(v.value,p.value)
const t=m.value%2==0,a=t?m.value/2:Math.floor(m.value/2),l=t?a:a+1,o=v.value-a
if(l-n.value>=0)return[...C(Math.max(1,m.value-1),p.value),e.ellipsis,v.value]
if(n.value-o>=(t?1:0)){const t=m.value-1,a=v.value-t+p.value
return[p.value,e.ellipsis,...C(t,a)]}{const t=Math.max(1,m.value-2),a=1===t?n.value:n.value-Math.ceil(t/2)+p.value
return[p.value,e.ellipsis,...C(t,a),e.ellipsis,v.value]}})
function y(e,t,a){e.preventDefault(),n.value=t,a&&l(a,t)}const{refs:b,updateRef:w}=function(){const e=t.ref([])
return t.onBeforeUpdate(()=>e.value=[]),{refs:e,updateRef:function(t,a){e.value[a]=t}}}()
Ht({VPaginationBtn:{color:t.toRef(()=>e.color),border:t.toRef(()=>e.border),density:t.toRef(()=>e.density),size:t.toRef(()=>e.size),variant:t.toRef(()=>e.variant),rounded:t.toRef(()=>e.rounded),elevation:t.toRef(()=>e.elevation)}})
const V=t.computed(()=>h.value.map((t,a)=>{const l=e=>w(e,a)
if(g(t))return{isActive:!1,key:`ellipsis-${a}`,page:t,props:{ref:l,ellipsis:!0,icon:!0,disabled:!0}}
{const a=t===n.value
return{isActive:a,key:t,page:r(t),props:{ref:l,ellipsis:!1,icon:!0,disabled:!!e.disabled||Number(e.length)<2,color:a?e.activeColor:e.color,"aria-current":a,"aria-label":o(a?e.currentPageAriaLabel:e.pageAriaLabel,t),onClick:e=>y(e,t)}}}})),S=t.computed(()=>{const t=!!e.disabled||n.value<=p.value,a=!!e.disabled||n.value>=p.value+v.value-1
return{first:[!0,"only-first"].includes(e.showFirstLastPage)?{icon:i.value?e.lastIcon:e.firstIcon,onClick:e=>y(e,p.value,"first"),disabled:t,"aria-label":o(e.firstAriaLabel),"aria-disabled":t}:void 0,prev:{icon:i.value?e.nextIcon:e.prevIcon,onClick:e=>y(e,n.value-1,"prev"),disabled:t,"aria-label":o(e.previousAriaLabel),"aria-disabled":t},next:{icon:i.value?e.prevIcon:e.nextIcon,onClick:e=>y(e,n.value+1,"next"),disabled:a,"aria-label":o(e.nextAriaLabel),"aria-disabled":a},last:!0===e.showFirstLastPage?{icon:i.value?e.firstIcon:e.lastIcon,onClick:e=>y(e,p.value+v.value-1,"last"),disabled:a,"aria-label":o(e.lastAriaLabel),"aria-disabled":a}:void 0}})
function k(){const e=n.value-p.value
b.value[e]?.$el.focus()}function x(a){a.key===j.left&&!e.disabled&&n.value>Number(e.start)?(n.value=n.value-1,t.nextTick(k)):a.key===j.right&&!e.disabled&&n.value<p.value+v.value-1&&(n.value=n.value+1,t.nextTick(k))}return sa(()=>t.createVNode(e.tag,{ref:d,class:t.normalizeClass(["v-pagination",s.value,e.class]),style:t.normalizeStyle(e.style),role:"navigation","aria-label":o(e.ariaLabel),onKeydown:x,"data-testid":"v-pagination-root"},{default:()=>[t.createElementVNode("ul",{class:"v-pagination__list"},[[!0,"only-first"].includes(e.showFirstLastPage)&&t.createElementVNode("li",{key:"first",class:"v-pagination__first","data-testid":"v-pagination-first"},[a.first?a.first(S.value.first):t.createVNode(Vo,t.mergeProps({_as:"VPaginationBtn"},S.value.first),null)]),t.createElementVNode("li",{key:"prev",class:"v-pagination__prev","data-testid":"v-pagination-prev"},[a.prev?a.prev(S.value.prev):t.createVNode(Vo,t.mergeProps({_as:"VPaginationBtn"},S.value.prev),null)]),V.value.map((e,l)=>t.createElementVNode("li",{key:e.key,class:t.normalizeClass(["v-pagination__item",{"v-pagination__item--is-active":e.isActive}]),"data-testid":"v-pagination-item"},[a.item?a.item(e):t.createVNode(Vo,t.mergeProps({_as:"VPaginationBtn"},e.props),{default:()=>[e.page]})])),t.createElementVNode("li",{key:"next",class:"v-pagination__next","data-testid":"v-pagination-next"},[a.next?a.next(S.value.next):t.createVNode(Vo,t.mergeProps({_as:"VPaginationBtn"},S.value.next),null)]),!0===e.showFirstLastPage&&t.createElementVNode("li",{key:"last",class:"v-pagination__last","data-testid":"v-pagination-last"},[a.last?a.last(S.value.last):t.createVNode(Vo,t.mergeProps({_as:"VPaginationBtn"},S.value.last),null)])])]})),{}}}),mp=Tt({color:String,prevIcon:{type:ua,default:"$prev"},nextIcon:{type:ua,default:"$next"},firstIcon:{type:ua,default:"$first"},lastIcon:{type:ua,default:"$last"},itemsPerPageText:{type:String,default:"$vuetify.dataFooter.itemsPerPageText"},pageText:{type:String,default:"$vuetify.dataFooter.pageText"},firstPageLabel:{type:String,default:"$vuetify.dataFooter.firstPage"},prevPageLabel:{type:String,default:"$vuetify.dataFooter.prevPage"},nextPageLabel:{type:String,default:"$vuetify.dataFooter.nextPage"},lastPageLabel:{type:String,default:"$vuetify.dataFooter.lastPage"},itemsPerPageOptions:{type:Array,default:()=>[{value:10,title:"10"},{value:25,title:"25"},{value:50,title:"50"},{value:100,title:"100"},{value:-1,title:"$vuetify.dataFooter.itemsPerPageAll"}]},showCurrentPage:Boolean,...U(vp({showFirstLastPage:!0}),["showFirstLastPage"])},"VDataTableFooter"),fp=Kt()({name:"VDataTableFooter",props:mp(),setup(e,{slots:a}){const{t:l}=Ha(),n=Ut("VSelect"),{page:o,pageCount:r,startIndex:i,stopIndex:s,itemsLength:u,itemsPerPage:c,setItemsPerPage:d}=function(){const e=t.inject(Wv)
if(!e)throw new Error("Missing pagination!")
return e}(),v=t.computed(()=>e.itemsPerPageOptions.map(e=>h(e)?{value:e,title:-1===e?l("$vuetify.dataFooter.itemsPerPageAll"):String(e)}:{...e,title:isNaN(Number(e.title))?l(e.title):e.title}))
return sa(()=>{const p=pp.filterProps(e)
return t.createElementVNode("div",{class:"v-data-table-footer"},[a.prepend?.(),t.createElementVNode("div",{class:"v-data-table-footer__items-per-page"},[t.createElementVNode("span",null,[l(e.itemsPerPageText)]),t.createVNode(iu,{items:v.value,itemColor:e.color,modelValue:c.value,"onUpdate:modelValue":e=>d(Number(e)),density:"compact",variant:n.value?.variant??"outlined","aria-label":l(e.itemsPerPageText),hideDetails:!0},null)]),t.createElementVNode("div",{class:"v-data-table-footer__info"},[t.createElementVNode("div",null,[l(e.pageText,u.value?i.value+1:0,s.value,u.value)])]),t.createElementVNode("div",{class:"v-data-table-footer__pagination"},[t.createVNode(pp,t.mergeProps({modelValue:o.value,"onUpdate:modelValue":e=>o.value=e,density:"comfortable",firstAriaLabel:e.firstPageLabel,lastAriaLabel:e.lastPageLabel,length:r.value,nextAriaLabel:e.nextPageLabel,previousAriaLabel:e.prevPageLabel,rounded:!0,showFirstLastPage:!0,totalVisible:e.showCurrentPage?1:0,variant:"plain"},G(p,["color"])),null)])])}),{}}}),gp=(hp={align:{type:String,default:"start"},fixed:{type:[Boolean,String],default:!1},fixedOffset:[Number,String],fixedEndOffset:[Number,String],height:[Number,String],lastFixed:Boolean,firstFixedEnd:Boolean,noPadding:Boolean,indent:[Number,String],empty:Boolean,tag:String,width:[Number,String],maxWidth:[Number,String],nowrap:Boolean},yp=(e,{slots:a})=>{const l=e.tag??"td",n=g(e.fixed)?e.fixed:e.fixed?"start":"none"
return t.createVNode(l,{class:t.normalizeClass(["v-data-table__td",{"v-data-table-column--fixed":"start"===n,"v-data-table-column--fixed-end":"end"===n,"v-data-table-column--last-fixed":e.lastFixed,"v-data-table-column--first-fixed-end":e.firstFixedEnd,"v-data-table-column--no-padding":e.noPadding,"v-data-table-column--nowrap":e.nowrap,"v-data-table-column--empty":e.empty},`v-data-table-column--align-${e.align}`]),style:{height:z(e.height),width:z(e.width),maxWidth:z(e.maxWidth),left:"start"===n?z(e.fixedOffset||null):void 0,right:"end"===n?z(e.fixedEndOffset||null):void 0,paddingInlineStart:e.indent?z(e.indent):void 0}},{default:()=>[a.default?.()]})},yp.props=hp,yp)
var hp,yp
const bp=Tt({headers:Array},"DataTable-header"),wp=Symbol.for("vuetify:data-table-headers"),Vp={title:"",sortable:!1},Sp={...Vp,width:48}
function kp(e,t=[]){if(e.children)for(const a of e.children)kp(a,t)
else t.push(e)
return t}function xp(e,t=new Set){for(const a of e)a.key&&t.add(a.key),a.children&&xp(a.children,t)
return t}function Np(e){if(e.key)return"data-table-group"===e.key?Vp:["data-table-expand","data-table-select"].includes(e.key)?Sp:void 0}function Cp(e,t=0){return e.children?Math.max(t,...e.children.map(e=>Cp(e,t+1))):t}function Ep(e,t=0){if(!e)return t
if(e.children){e.fixedOffset=t
for(const a of e.children)t=Ep(a,t)}else e.fixed&&"end"!==e.fixed&&(e.fixedOffset=t,t+=parseFloat(e.width||"0")||0)
return t}function Ip(e,t=0){if(!e)return t
if(e.children){e.fixedEndOffset=t
for(const a of e.children)t=Ip(a,t)}else"end"===e.fixed&&(e.fixedEndOffset=t,t+=parseFloat(e.width||"0")||0)
return t}function Ap(e,t){const a=[]
let l=0
const n=function(e=[]){const t=e.map(e=>({element:e,priority:0}))
return{enqueue:(e,a)=>{let l=!1
for(let n=0;n<t.length;n++)if(t[n].priority>a){t.splice(n,0,{element:e,priority:a}),l=!0
break}l||t.push({element:e,priority:a})},size:()=>t.length,count:()=>{let e=0
if(!t.length)return 0
const a=Math.floor(t[0].priority)
for(let l=0;l<t.length;l++)Math.floor(t[l].priority)===a&&(e+=1)
return e},dequeue:()=>t.shift()}}(e)
for(;n.size()>0;){let e=n.count()
const o=[]
let r=1
for(;e>0;){const{element:a,priority:i}=n.dequeue(),s=t-l-Cp(a)
if(o.push({...a,rowspan:s??1,colspan:a.children?kp(a).length:1}),a.children)for(const e of a.children){const t=i%1+r/Math.pow(10,l+2)
n.enqueue(e,l+s+t)}r+=1,e-=1}l+=1,a.push(o)}return{columns:e.map(e=>kp(e)).flat(),headers:a}}function Pp(e){const t=[]
for(const a of e){const e={...Np(a),...a},l=e.key??(g(e.value)?e.value:null),n=e.value??l??null,o={...e,key:l,value:n,sortable:e.sortable??(null!=e.key||!!e.sort),children:e.children?Pp(e.children):void 0}
t.push(o)}return t}function _p(e,a){const n=t.ref([]),o=t.ref([]),r=t.ref({}),i=t.ref({}),s=t.ref({})
t.watchEffect(()=>{const u=(e.headers||Object.keys(e.items[0]??{}).map(e=>({key:e,title:t.capitalize(e)}))).slice(),c=xp(u)
a?.groupBy?.value.length&&!c.has("data-table-group")&&u.unshift({key:"data-table-group",title:"Group"}),a?.showSelect?.value&&!c.has("data-table-select")&&u.unshift({key:"data-table-select"}),a?.showExpand?.value&&!c.has("data-table-expand")&&u.push({key:"data-table-expand"})
const d=Pp(u)
!function(e){let t=!1
function a(e,n,o="none"){if(e)if("none"!==o&&(e.fixed=o),!0===e.fixed&&(e.fixed="start"),e.fixed===n)if(e.children)if("start"===n)for(let t=e.children.length-1;t>=0;t--)a(e.children[t],n,n)
else for(let t=0;t<e.children.length;t++)a(e.children[t],n,n)
else t||"start"!==n?t||"end"!==n?isNaN(Number(e.width))?l(`Multiple fixed columns should have a static width (key: ${e.key})`):e.minWidth=Math.max(Number(e.width)||0,Number(e.minWidth)||0):e.firstFixedEnd=!0:e.lastFixed=!0,t=!0
else if(e.children)if("start"===n)for(let t=e.children.length-1;t>=0;t--)a(e.children[t],n)
else for(let t=0;t<e.children.length;t++)a(e.children[t],n)
else t=!1}for(let t=e.length-1;t>=0;t--)a(e[t],"start")
for(let t=0;t<e.length;t++)a(e[t],"end")
let n=0
for(let t=0;t<e.length;t++)n=Ep(e[t],n)
let o=0
for(let t=e.length-1;t>=0;t--)o=Ip(e[t],o)}(d)
const v=Math.max(...d.map(e=>Cp(e)))+1,p=Ap(d,v)
n.value=p.headers,o.value=p.columns
const m=p.headers.flat(1)
r.value={},i.value={},s.value={}
for(const e of m)e.key&&(e.sortable&&(e.sort&&(r.value[e.key]=e.sort),e.sortRaw&&(i.value[e.key]=e.sortRaw)),e.filter&&(s.value[e.key]=e.filter))})
const u={headers:n,columns:o,sortFunctions:r,sortRawFunctions:i,filterFunctions:s}
return t.provide(wp,u),u}function Rp(){const e=t.inject(wp)
if(!e)throw new Error("Missing headers!")
return e}function Dp(e,a){return{active:t.computed(()=>{const t=e()
return null!=t&&!1!==t&&"false"!==t}),side:t.computed(()=>{const t=e()
return b(t)&&t.side?t.side:"start"}),color:t.computed(()=>{const t=e()
return b(t)&&t.color?t.color:g(t)&&"true"!==t?t:a()})}}const Bp=Tt({color:String,disableSort:Boolean,fixedHeader:Boolean,multiSort:Boolean,initialSortOrder:String,sortIcon:{type:ua},sortAscIcon:{type:ua,default:"$sortAsc"},sortDescIcon:{type:ua,default:"$sortDesc"},headerProps:{type:Object},selectAllLabel:{type:String,default:"$vuetify.dataTable.ariaLabel.selectAll"},sticky:Boolean,...yn(),...hr(),...Gn()},"VDataTableHeaders"),Tp=Kt()({name:"VDataTableHeaders",props:Bp(),setup(e,{slots:a}){const{t:l}=Ha(),{toggleSort:n,sortBy:o,isSorted:r}=op(),{someSelected:i,allSelected:s,selectAll:u,showSelectAll:c}=ep(),{columns:d,headers:v}=Rp(),{loaderClasses:p}=Kn(e),m=Ut("VSelect")
function f(t,a){if(!e.sticky&&!e.fixedHeader&&!t.fixed)return
const l=g(t.fixed)?t.fixed:t.fixed?"start":"none"
return{position:"sticky",left:"start"===l?z(t.fixedOffset):void 0,right:"end"===l?z(t.fixedEndOffset):void 0,top:e.sticky||e.fixedHeader?`calc(var(--v-table-header-height) * ${a})`:void 0}}function h(t){const a=o.value.find(e=>e.key===t.key)
switch(a?.order){case"asc":return e.sortAscIcon
case"desc":return e.sortDescIcon
default:return e.sortIcon||("asc"===e.initialSortOrder?e.sortAscIcon:e.sortDescIcon)}}const{backgroundColorClasses:y,backgroundColorStyles:b}=Ol(()=>e.color),{displayClasses:w,mobile:V}=yr(e),S=Dp(()=>e.loading,()=>e.color),k=t.computed(()=>({headers:v.value,columns:d.value,toggleSort:n,isSorted:r,sortBy:o.value,someSelected:i.value,allSelected:s.value,selectAll:u,getSortIcon:h})),x=t.computed(()=>["v-data-table__th",{"v-data-table__th--sticky":e.sticky||e.fixedHeader},w.value,p.value]),N=({column:d,x:v,y:p})=>{const m="data-table-select"===d.key||"data-table-expand"===d.key,g="data-table-group"===d.key&&0===d.width&&!d.title,w=t.mergeProps(e.headerProps??{},d.headerProps??{}),V=d.sortable&&!e.disableSort,S=V?o.value.find(e=>e.key===d.key):void 0,k="asc"===S?.order?"ascending":"desc"===S?.order?"descending":void 0
return t.createVNode(gp,t.mergeProps({tag:"th","aria-sort":k,align:d.align,class:[{"v-data-table__th--sortable":V,"v-data-table__th--sorted":r(d),"v-data-table__th--fixed":d.fixed},...x.value],style:{width:z(d.width),minWidth:z(d.minWidth),maxWidth:z(d.maxWidth),...f(d,p)},colspan:d.colspan,rowspan:d.rowspan,fixed:d.fixed,nowrap:d.nowrap,lastFixed:d.lastFixed,firstFixedEnd:d.firstFixedEnd,noPadding:m,empty:g,tabindex:V?0:void 0,onClick:V?e=>n(d,e):void 0,onKeydown:V?t=>function(t,a){"Enter"!==t.key||e.disableSort||n(a,t)}(t,d):void 0},w),{default:()=>{const v=`header.${d.key}`,p={column:d,selectAll:u,isSorted:r,toggleSort:n,sortBy:o.value,someSelected:i.value,allSelected:s.value,getSortIcon:h}
return a[v]?a[v](p):g?"":"data-table-select"===d.key?a["header.data-table-select"]?.(p)??(c.value&&t.createVNode(Wo,{"aria-label":l(e.selectAllLabel),color:e.color,density:e.density,modelValue:s.value,indeterminate:i.value&&!s.value,"onUpdate:modelValue":u},null)):t.createElementVNode("div",{class:"v-data-table-header__content"},[t.createElementVNode("span",null,[d.title]),d.sortable&&!e.disableSort&&t.createVNode(Mn,{key:"icon",class:"v-data-table-header__sort-icon",icon:h(d)},null),e.multiSort&&r(d)&&t.createElementVNode("div",{key:"badge",class:t.normalizeClass(["v-data-table-header__sort-badge",...y.value]),style:t.normalizeStyle(b.value)},[o.value.findIndex(e=>e.key===d.key)+1])])}})},C=()=>{const c=t.computed(()=>d.value.filter(t=>t?.sortable&&!e.disableSort)),p=d.value.find(e=>"data-table-select"===e.key),f=t.computed({get:()=>c.value.filter(({key:e})=>o.value.some(t=>t.key===e)),set:e=>{const a=ee(e),l=o.value.map(e=>e.key)
a.filter(({key:e})=>!l.includes(e)).forEach(e=>n(e)),t.nextTick(()=>o.value=o.value.filter(({key:e})=>a.some(t=>t.key===e)))}})
return t.createVNode(gp,t.mergeProps({tag:"th",class:[...x.value],colspan:v.value.length+1},e.headerProps),{default:()=>[t.createElementVNode("div",{class:"v-data-table-header__content"},[a["mobile.header"]?.(k.value)??t.createElementVNode(t.Fragment,null,[c.value.length>0&&t.createVNode(iu,{modelValue:f.value,"onUpdate:modelValue":e=>f.value=e,chips:!0,color:e.color,class:"v-data-table__td-sort-select",clearable:!0,density:"default",items:c.value,label:l("$vuetify.dataTable.sortBy"),multiple:e.multiSort,variant:m.value?.variant??"underlined",returnObject:!0,"onClick:clear":()=>o.value=[]},{chip:({internalItem:e})=>t.createVNode(Fr,{onClick:e.raw.sortable?()=>n(e.raw,void 0,!0):void 0,onMousedown:e=>{e.preventDefault(),e.stopPropagation()}},{default:()=>[e.title,t.createVNode(Mn,{class:t.normalizeClass(["v-data-table__td-sort-icon",r(e.raw)&&"v-data-table__td-sort-icon-active"]),icon:h(e.raw),size:"small"},null)]})}),p&&t.createVNode(Wo,{"aria-label":l(e.selectAllLabel),class:"v-data-table-header__select-all",color:e.color,density:"compact",modelValue:s.value,indeterminate:i.value&&!s.value,"onUpdate:modelValue":()=>u(!s.value)},null)])])]})},E=t.computed(()=>{if(a["mobile.header"])return!0
const t=d.value.some(t=>t?.sortable&&!e.disableSort),l=d.value.some(e=>"data-table-select"===e.key)
return t||l})
sa(()=>V.value?t.createElementVNode(t.Fragment,null,[E.value&&t.createElementVNode("tr",null,[t.createVNode(C,null,null)])]):t.createElementVNode(t.Fragment,null,[a.headers?a.headers(k.value):v.value.map((e,a)=>t.createElementVNode("tr",null,[e.map((e,l)=>t.createVNode(N,{key:e.key??l,column:e,x:l,y:a},null))])),S.active.value&&["start","both"].includes(S.side.value)&&t.createElementVNode("tr",{class:"v-data-table-progress"},[t.createElementVNode("th",{colspan:d.value.length},[t.createVNode(qn,{name:"v-data-table-progress",absolute:!0,active:!0,color:S.color.value,indeterminate:!0},{default:a.loader})])])]))}}),Fp=Tt({item:{type:Object,required:!0},groupCollapseIcon:{type:ua,default:"$tableGroupCollapse"},groupExpandIcon:{type:ua,default:"$tableGroupExpand"},selectGroupLabel:{type:String,default:"$vuetify.dataTable.ariaLabel.selectGroup"},...yn()},"VDataTableGroupHeaderRow"),$p=Kt()({name:"VDataTableGroupHeaderRow",props:Fp(),setup(e,{slots:a}){const{t:l}=Ha(),{isGroupOpen:n,toggleGroup:o,extractRows:r}=Fv(),{isSelected:i,isSomeSelected:s,select:u}=ep(),{columns:c}=Rp(),d=t.computed(()=>r([e.item])),v=t.toRef(()=>c.value.length-(c.value.some(e=>"data-table-select"===e.key)?1:0))
return()=>t.createElementVNode("tr",{class:"v-data-table-group-header-row",style:{"--v-data-table-group-header-row-depth":e.item.depth}},[c.value.map(r=>{if("data-table-group"===r.key){const l=n(e.item)?e.groupCollapseIcon:e.groupExpandIcon,r=()=>o(e.item)
return a["data-table-group"]?.({item:e.item,count:d.value.length,props:{icon:l,onClick:r}})??t.createVNode(gp,{class:"v-data-table-group-header-row__column",colspan:v.value},{default:()=>[t.createVNode(Vo,{size:"small",variant:"text",icon:l,onClick:r},null),t.createElementVNode("span",null,[e.item.value]),t.createElementVNode("span",null,[t.createTextVNode("("),d.value.length,t.createTextVNode(")")])]})}if("data-table-select"===r.key){const n=d.value.filter(e=>e.selectable),o=n.length>0&&i(n),r=s(n)&&!o,c=e=>u(n,e)
return a["data-table-select"]?.({props:{modelValue:o,indeterminate:r,"onUpdate:modelValue":c}})??t.createVNode(gp,{class:"v-data-table__td--select-row",noPadding:!0},{default:()=>[t.createVNode(Wo,{"aria-label":l(e.selectGroupLabel),density:e.density,disabled:0===n.length,modelValue:o,indeterminate:r,"onUpdate:modelValue":c},null)]})}return""})])}}),Mp=Tt({color:String,index:Number,item:Object,cellProps:[Object,Function],collapseIcon:{type:ua,default:"$collapse"},expandIcon:{type:ua,default:"$expand"},selectRowLabel:{type:String,default:"$vuetify.dataTable.ariaLabel.selectRow"},getMatches:Function,onClick:fe(),onContextmenu:fe(),onDblclick:fe(),...yn(),...hr()},"VDataTableRow"),zp=Kt()({name:"VDataTableRow",props:Mp(),setup(e,{slots:a}){const{t:l}=Ha(),{displayClasses:n,mobile:o}=yr(e,"v-data-table__tr"),{isSelected:r,toggleSelect:i,someSelected:s,allSelected:u,selectAll:c}=ep(),{isExpanded:d,toggleExpand:v}=_v(),{toggleSort:p,sortBy:m,isSorted:g}=op(),{columns:h}=Rp()
sa(()=>t.createElementVNode("tr",{class:t.normalizeClass(["v-data-table__tr",{"v-data-table__tr--clickable":!!(e.onClick||e.onContextmenu||e.onDblclick)},n.value]),onClick:e.onClick,onContextmenu:e.onContextmenu,onDblclick:e.onDblclick},[e.item&&h.value.map((n,h)=>{const y=e.item,b=`item.${n.key}`,w=`header.${n.key}`,V={index:e.index,item:y.raw,internalItem:y,value:T(y.columns,n.key),column:n,isSelected:r,toggleSelect:i,isExpanded:d,toggleExpand:v},S={column:n,selectAll:c,isSorted:g,toggleSort:p,sortBy:m.value,someSelected:s.value,allSelected:u.value,getSortIcon:()=>""},k=f(e.cellProps)?e.cellProps({index:V.index,item:V.item,internalItem:V.internalItem,value:V.value,column:n}):e.cellProps,x=f(n.cellProps)?n.cellProps({index:V.index,item:V.item,internalItem:V.internalItem,value:V.value}):n.cellProps,N="data-table-select"===n.key||"data-table-expand"===n.key,C="data-table-group"===n.key&&0===n.width&&!n.title
return t.createVNode(gp,t.mergeProps({key:n.key??h,align:n.align,indent:n.indent,class:{"v-data-table__td--expanded-row":"data-table-expand"===n.key,"v-data-table__td--select-row":"data-table-select"===n.key},fixed:n.fixed,fixedOffset:n.fixedOffset,fixedEndOffset:n.fixedEndOffset,lastFixed:n.lastFixed,firstFixedEnd:n.firstFixedEnd,maxWidth:o.value?void 0:n.maxWidth,noPadding:N,empty:C,nowrap:n.nowrap,width:o.value?void 0:n.width},k,x),{default:()=>{if("data-table-select"===n.key)return a["item.data-table-select"]?.({...V,props:{color:e.color,disabled:!y.selectable,modelValue:r([y]),onClick:t.withModifiers(()=>i(y),["stop"])}})??t.createVNode(Wo,{"aria-label":l(e.selectRowLabel),color:e.color,disabled:!y.selectable,density:e.density,modelValue:r([y]),onClick:t.withModifiers(t=>i(y,e.index,t),["stop"])},null)
if("data-table-expand"===n.key)return a["item.data-table-expand"]?.({...V,props:{icon:d(y)?e.collapseIcon:e.expandIcon,size:"small",variant:"text",onClick:t.withModifiers(()=>v(y),["stop"])}})??t.createVNode(Vo,{icon:d(y)?e.collapseIcon:e.expandIcon,size:"small",variant:"text",onClick:t.withModifiers(()=>v(y),["stop"])},null)
if(a[b]&&!o.value)return a[b](V)
const s=t.toDisplayString(V.value),u=e.getMatches?.(y)?.[n.key],c=u?.length?t.createVNode(Ws,{text:s,matches:u},null):s
return o.value?t.createElementVNode(t.Fragment,null,[t.createElementVNode("div",{class:"v-data-table__td-title"},[a[w]?.(S)??n.title]),t.createElementVNode("div",{class:"v-data-table__td-value"},[a[b]?.(V)??c])]):c}})})]))}}),Lp=Tt({color:String,loading:[Boolean,String,Object],loadingText:{type:String,default:"$vuetify.dataIterator.loadingText"},hideNoData:Boolean,items:{type:Array,default:()=>[]},noDataText:{type:String,default:"$vuetify.noDataText"},rowProps:[Object,Function],cellProps:[Object,Function],expandTransition:{type:null,default:()=>({component:Pl}),validator:e=>!0!==e},...U(Mp(),["collapseIcon","expandIcon","density","getMatches"]),...U(Fp(),["groupCollapseIcon","groupExpandIcon","density"]),...hr()},"VDataTableRows"),Op=Kt()({name:"VDataTableRows",inheritAttrs:!1,props:Lp(),setup(e,{attrs:a,slots:l}){const{columns:n}=Rp(),{expandOnClick:o,toggleExpand:r,isExpanded:i}=_v(),{isSelected:s,toggleSelect:u}=ep(),{toggleGroup:c,isGroupOpen:d}=Fv(),{t:v}=Ha(),{mobile:p}=yr(e)
return sa(()=>{const m=U(e,["groupCollapseIcon","groupExpandIcon","density"])
return!e.loading||e.items.length&&!l.loading?e.loading||e.items.length||e.hideNoData?t.createElementVNode(t.Fragment,null,[e.items.map((v,g)=>{if("group"===v.type){const e={index:g,item:v,columns:n.value,isExpanded:i,toggleExpand:r,isSelected:s,toggleSelect:u,toggleGroup:c,isGroupOpen:d}
return l["group-header"]?l["group-header"](e):t.createVNode($p,t.mergeProps({key:`group-header_${v.id}`,item:v},la(a,":groupHeader",()=>e),m),l)}if("group-summary"===v.type){const e={index:g,item:v,columns:n.value,toggleGroup:c}
return l["group-summary"]?.(e)??""}const h={index:v.virtualIndex??g,item:v.raw,internalItem:v,columns:n.value,isExpanded:i,toggleExpand:r,isSelected:s,toggleSelect:u},y={...h,props:t.mergeProps({key:`item_${v.key??v.index}`,onClick:o.value?()=>{r(v)}:void 0,index:g,item:v,color:e.color,cellProps:e.cellProps,collapseIcon:e.collapseIcon,expandIcon:e.expandIcon,density:e.density,mobile:p.value,getMatches:e.getMatches},la(a,":row",()=>h),f(e.rowProps)?e.rowProps({item:h.item,index:h.index,internalItem:h.internalItem}):e.rowProps)}
return t.createElementVNode(t.Fragment,{key:y.props.key},[l.item?l.item(y):t.createVNode(zp,y.props,l),l["expanded-row"]?i(v)&&l["expanded-row"](h):l.expanded&&t.createElementVNode("tr",{class:"v-data-table__tr--expanded"},[t.createElementVNode("td",{colspan:n.value.length},[e.expandTransition?t.createVNode(Xl,{transition:e.expandTransition},{default:()=>[i(v)?t.createElementVNode("div",null,[l.expanded(h)]):null]}):i(v)&&t.createElementVNode("div",null,[l.expanded(h)])])])])})]):t.createElementVNode("tr",{class:"v-data-table-rows-no-data",key:"no-data"},[t.createElementVNode("td",{colspan:n.value.length},[l["no-data"]?.()??v(e.noDataText)])]):t.createElementVNode("tr",{class:"v-data-table-rows-loading",key:"loading"},[t.createElementVNode("td",{colspan:n.value.length},[l.loading?.()??v(e.loadingText)])])}),{}}}),jp=Tt({gridlines:{type:[Boolean,String],default:"horizontal",validator:e=>y(e)||["horizontal","vertical","all"].includes(e)},fixedHeader:Boolean,fixedFooter:Boolean,height:[Number,String],hover:Boolean,striped:{type:String,default:null,validator:e=>["even","odd"].includes(e)},...Ft(),...yn(),...ol(),...Ga()},"VTable"),Hp=Kt()({name:"VTable",inheritAttrs:!1,props:jp(),setup(e,{attrs:a,slots:l,emit:n}){const{themeClasses:o}=tl(e),{densityClasses:r}=bn(e),i=t.computed(()=>!1===e.gridlines?"none":!0===e.gridlines?"all":e.gridlines)
return sa(()=>{const[n,s]=Y(a,[/^aria-label/])
return t.createVNode(e.tag,t.mergeProps(s,{class:["v-table",`v-table--gridlines-${i.value}`,{"v-table--fixed-height":!!e.height,"v-table--fixed-header":e.fixedHeader,"v-table--fixed-footer":e.fixedFooter,"v-table--has-top":!!l.top,"v-table--has-bottom":!!l.bottom,"v-table--hover":e.hover,"v-table--striped-even":"even"===e.striped,"v-table--striped-odd":"odd"===e.striped},o.value,r.value,e.class],style:e.style}),{default:()=>[l.top?.(),l.default?t.createElementVNode("div",{class:"v-table__wrapper",style:{height:z(e.height)}},[t.createElementVNode("table",t.normalizeProps(t.guardReactiveProps(n)),[l.caption?.(),l.default()])]):l.wrapper?.(),l.bottom?.()]})}),{}}}),Wp=Tt({items:{type:Array,default:()=>[]},itemValue:{type:[String,Array,Function],default:"id"},itemSelectable:{type:[String,Array,Function],default:null},rowProps:[Object,Function],cellProps:[Object,Function],returnObject:Boolean},"DataTable-items")
function Up(e,t,a){return t.map((t,l)=>function(e,t,a,l){const n=e.returnObject?t:F(t,e.itemValue),o=F(t,e.itemSelectable,!0),r=l.reduce((e,a)=>(null!=a.key&&(e[a.key]=F(t,a.value)),e),{})
return{type:"item",key:e.returnObject?F(t,e.itemValue):n,index:a,value:n,selectable:o,columns:r,raw:t}}(e,t,l,a))}function Yp(e,a){return{items:t.computed(()=>Up(e,e.items,a.value))}}const Gp=Tt({...Lp(),hideDefaultBody:Boolean,hideDefaultFooter:Boolean,hideDefaultHeader:Boolean,width:[String,Number],search:String,...Iv(),...Rv(),...bp(),...Wp(),...Zv(),...tp(),...G(Bp(),["multiSort","initialSortOrder"]),...jp()},"DataTable"),Kp=Tt({...Hv(),...Gp(),...eu(),...mp()},"VDataTable"),qp=Kt()({name:"VDataTable",props:Kp(),emits:{"update:modelValue":e=>!0,"update:page":e=>!0,"update:itemsPerPage":e=>!0,"update:sortBy":e=>!0,"update:options":e=>!0,"update:groupBy":e=>!0,"update:expanded":e=>!0,"update:opened":e=>!0,"update:currentItems":e=>!0},setup(e,{attrs:a,slots:l}){const{groupBy:n,opened:o,openAll:r,groupKey:i}=Bv(e),{initialSortOrder:s,sortBy:u,multiSort:c,mustSort:d}=lp(e),{page:v,itemsPerPage:p}=Uv(e),{disableSort:m}=t.toRefs(e),{columns:f,headers:g,sortFunctions:h,sortRawFunctions:y,filterFunctions:b}=_p(e,{groupBy:n,showSelect:t.toRef(()=>e.showSelect),showExpand:t.toRef(()=>e.showExpand)}),{items:w}=Yp(e,f),V=t.toRef(()=>e.search),{filteredItems:S,getMatches:k}=au(e,w,V,{transform:e=>e.columns,customKeyFilter:b}),{toggleSort:x}=np({initialSortOrder:s,sortBy:u,multiSort:c,mustSort:d,page:v}),{sortByWithGroups:N,opened:C,extractRows:E,isGroupOpen:I,toggleGroup:A}=Tv({groupBy:n,sortBy:u,disableSort:m,opened:o}),{sortedItems:P}=rp(e,S,N,{transform:e=>({...e.raw,...e.columns}),sortFunctions:h,sortRawFunctions:y})
zv(C,r,P,n,i)
const _=t.computed(()=>"auto"===e.pageBy?e.groupBy.length?"group":"item":e.pageBy),{pageCount:R,setItemsPerPage:D,prevPage:B,nextPage:T,setPage:F,paginatedItems:$}=function(e){const{sortedItems:a,paginate:l,group:n}=e,o=t.toValue(e.pageBy)
if("item"===o){const{paginatedItems:e,pageCount:t,setItemsPerPage:o,prevPage:r,nextPage:i,setPage:s}=l(a),{flatItems:u}=n(e)
return{pageCount:t,setItemsPerPage:o,prevPage:r,nextPage:i,setPage:s,paginatedItems:u}}if("group"===o){const{flatItems:e,groups:o}=n(a),{paginatedItems:r,pageCount:i,setItemsPerPage:s,prevPage:u,nextPage:c,setPage:d}=l(o)
return{pageCount:i,setItemsPerPage:s,prevPage:u,nextPage:c,setPage:d,paginatedItems:t.computed(()=>{if(!r.value.length)return[]
const t=r.value.at(0).id,a=r.value.at(-1).id,l=e.value.findIndex(e=>"group"===e.type&&e.id===t),n=e.value.findIndex(e=>"group"===e.type&&e.id===a),o=e.value.findIndex((e,t)=>t>n&&"group"===e.type&&0===e.depth)
return e.value.slice(l,-1===o?void 0:o)})}}if("any"===o){const{flatItems:e}=n(a),{paginatedItems:t,pageCount:o,setItemsPerPage:r,prevPage:i,nextPage:s,setPage:u}=l(e)
return{pageCount:o,setItemsPerPage:r,prevPage:i,nextPage:s,setPage:u,paginatedItems:t}}throw new Error(`Unrecognized pagination target ${o}`)}({pageBy:_,sortedItems:P,paginate:e=>{const a=t.computed(()=>t.toValue(e).length),{startIndex:l,stopIndex:n,pageCount:o,setItemsPerPage:r,prevPage:i,nextPage:s,setPage:u}=Yv({page:v,itemsPerPage:p,itemsLength:a}),{paginatedItems:c}=Gv({items:e,startIndex:l,stopIndex:n,itemsPerPage:p})
return{paginatedItems:c,pageCount:o,setItemsPerPage:r,prevPage:i,nextPage:s,setPage:u}},group:e=>Ov(e,n,C,()=>!!l["group-summary"],I,i)}),M=t.computed(()=>E($.value)),{isSelected:z,select:L,selectAll:O,toggleSelect:j,someSelected:H,allSelected:W}=Jv(e,{allItems:w,currentPage:M}),{isExpanded:U,toggleExpand:Y}=Pv(e),K=Dp(()=>e.loading,()=>e.color)
jv({page:v,itemsPerPage:p,sortBy:u,groupBy:n,search:V}),Ht({VDataTableRows:{hideNoData:t.toRef(()=>e.hideNoData),noDataText:t.toRef(()=>e.noDataText),loading:t.toRef(()=>e.loading),loadingText:t.toRef(()=>e.loadingText)}})
const q=t.computed(()=>({page:v.value,itemsPerPage:p.value,itemsLength:S.value.length,sortBy:u.value,pageCount:R.value,toggleSort:x,setItemsPerPage:D,prevPage:B,nextPage:T,setPage:F,someSelected:H.value,allSelected:W.value,isSelected:z,select:L,selectAll:O,toggleSelect:j,isExpanded:U,toggleExpand:Y,isGroupOpen:I,toggleGroup:A,items:M.value.map(e=>e.raw),internalItems:M.value,groupedItems:$.value,columns:f.value,headers:g.value}))
return sa(()=>{const n=fp.filterProps(e),o=Tp.filterProps(G(e,["multiSort"])),r=Op.filterProps(e),i=Hp.filterProps(e)
return t.createVNode(Hp,t.mergeProps({class:["v-data-table",{"v-data-table--show-select":e.showSelect,"v-data-table--loading":e.loading},e.class],style:e.style},i,{fixedHeader:e.fixedHeader||e.sticky}),{top:()=>l.top?.(q.value),caption:l.caption,default:()=>l.default?l.default(q.value):t.createElementVNode(t.Fragment,null,[l.colgroup?.(q.value),!e.hideDefaultHeader&&t.createElementVNode("thead",{key:"thead"},[t.createVNode(Tp,t.mergeProps(o,{multiSort:!!e.multiSort}),l)]),l.thead?.(q.value),!e.hideDefaultBody&&t.createElementVNode("tbody",null,[l["body.prepend"]?.(q.value),l.body?l.body(q.value):t.createVNode(Op,t.mergeProps(a,r,{items:$.value,getMatches:k}),l),l["body.append"]?.(q.value),K.active.value&&["end","both"].includes(K.side.value)&&t.createElementVNode("tr",{class:"v-data-table-progress v-data-table-progress--bottom"},[t.createElementVNode("th",{colspan:f.value.length},[t.createVNode(qn,{name:"v-data-table-progress",absolute:!0,active:!0,color:K.color.value,indeterminate:!0},{default:l.loader})])])]),l.tbody?.(q.value),l.tfoot?.(q.value)]),bottom:()=>l.bottom?l.bottom(q.value):!e.hideDefaultFooter&&t.createElementVNode(t.Fragment,null,[t.createVNode(zr,null,null),t.createVNode(fp,n,{prepend:l["footer.prepend"]})])})}),{}}}),Xp=Tt({...G(Gp(),["hideDefaultFooter"]),...Rv(),...Fs(),...eu()},"VDataTableVirtual")
function Zp(e){return(e??[]).flatMap(e=>Array.isArray(e)?Zp(e):t.isVNode(e)?e.type===t.Fragment?Zp(e.children):"symbol"==typeof e.type?[]:[e]:[])}const Qp=Kt()({name:"VDataTableVirtual",props:Xp(),emits:{"update:modelValue":e=>!0,"update:sortBy":e=>!0,"update:options":e=>!0,"update:groupBy":e=>!0,"update:expanded":e=>!0,"update:opened":e=>!0},setup(e,{attrs:a,slots:l}){const{groupBy:n,opened:o,openAll:r,groupKey:i}=Bv(e),{initialSortOrder:s,sortBy:u,multiSort:c,mustSort:d}=lp(e),{disableSort:v}=t.toRefs(e),{columns:p,headers:m,filterFunctions:f,sortFunctions:g,sortRawFunctions:h}=_p(e,{groupBy:n,showSelect:t.toRef(()=>e.showSelect),showExpand:t.toRef(()=>e.showExpand)}),{items:y}=Yp(e,p),b=t.toRef(()=>e.search),{filteredItems:w,getMatches:V}=au(e,y,b,{transform:e=>e.columns,customKeyFilter:f}),{toggleSort:S}=np({initialSortOrder:s,sortBy:u,multiSort:c,mustSort:d}),{sortByWithGroups:k,opened:x,extractRows:N,isGroupOpen:C,toggleGroup:E}=Tv({groupBy:n,sortBy:u,disableSort:v,opened:o}),{sortedItems:I}=rp(e,w,k,{transform:e=>({...e.raw,...e.columns}),sortFunctions:g,sortRawFunctions:h})
zv(x,r,I,n,i)
const{flatItems:A}=Ov(I,n,x,()=>!!l["group-summary"],C,i),P=t.computed(()=>N(A.value)),{isSelected:_,select:R,selectAll:D,toggleSelect:B,someSelected:T,allSelected:F}=Jv(e,{allItems:P,currentPage:P}),{expanded:$,isExpanded:M,toggleExpand:L}=Pv(e),{containerRef:O,markerRef:j,paddingTop:H,paddingBottom:W,computedItems:U,handleItemResize:K,handleScroll:q,handleScrollend:X,calculateVisibleItems:Z,scrollToIndex:Q}=$s(e,A),J=t.computed(()=>U.value.map(e=>({...e.raw,virtualIndex:e.index}))),ee=new Map,te=new Map
function ae(e){const t=te.get(e)?.reduce((e,t)=>e+(t||0),0)??0
K(e,(ee.get(e)??0)+t)}function le(e,t,a){const l=te.get(e)??[]
l[t]=a,te.set(e,l),ae(e)}t.watch($,()=>{if(l["expanded-row"])for(const e of[...te.keys()]){const t=A.value[e]
"item"===t?.type&&M(t)||(te.delete(e),ae(e))}}),t.watch(A,()=>{ee.clear(),te.clear()}),jv({sortBy:u,page:t.shallowRef(1),itemsPerPage:t.shallowRef(-1),groupBy:n,search:b}),Ht({VDataTableRows:{hideNoData:t.toRef(()=>e.hideNoData),noDataText:t.toRef(()=>e.noDataText),loading:t.toRef(()=>e.loading),loadingText:t.toRef(()=>e.loadingText)}})
const ne=t.computed(()=>({itemsLength:P.value.length,sortBy:u.value,toggleSort:S,someSelected:T.value,allSelected:F.value,isSelected:_,select:R,selectAll:D,toggleSelect:B,isExpanded:M,toggleExpand:L,isGroupOpen:C,toggleGroup:E,items:P.value.map(e=>e.raw),internalItems:P.value,groupedItems:A.value,columns:p.value,headers:m.value}))
return sa(()=>{const n=Tp.filterProps(G(e,["multiSort"])),o=Op.filterProps(e),r=Hp.filterProps(e),[i]=Y(a,[/^aria-label/])
return t.createVNode(Hp,t.mergeProps({class:["v-data-table",{"v-data-table--loading":e.loading},e.class],style:e.style},r,{fixedHeader:e.fixedHeader||e.sticky}),{top:()=>l.top?.(ne.value),wrapper:()=>t.createElementVNode("div",{ref:O,onScrollPassive:q,onScrollend:X,class:"v-table__wrapper",style:{height:z(e.height)}},[t.createElementVNode("table",t.normalizeProps(t.guardReactiveProps(i)),[l.caption?.(),l.colgroup?.(ne.value),!e.hideDefaultHeader&&t.createElementVNode("thead",{key:"thead"},[t.createVNode(Tp,t.mergeProps(n,{multiSort:!!e.multiSort}),l)]),l.thead?.(ne.value),!e.hideDefaultBody&&t.createElementVNode("tbody",{key:"tbody"},[t.createElementVNode("tr",{ref:j,style:{height:z(H.value),border:0}},[t.createElementVNode("td",{colspan:p.value.length,style:{height:0,border:0}},null)]),l["body.prepend"]?.(ne.value),t.createVNode(Op,t.mergeProps(a,o,{items:J.value,getMatches:V}),{...G(l,["expanded","expanded-row"]),item:a=>{const{props:n,...o}=a,r=a.internalItem.virtualIndex??a.internalItem.index,i=M(a.internalItem),s=e.showExpand&&i&&l["expanded-row"]?Zp(l["expanded-row"](o)):[]
return l["expanded-row"]&&(te.get(r)?.length??0)>s.length&&t.nextTick(()=>function(e,t){const a=te.get(e)
!a||a.length<=t||(a.length=t,ae(e))}(r,s.length)),t.createElementVNode(t.Fragment,null,[t.createVNode(Bs,{key:r,renderless:!0,"onUpdate:height":e=>function(e,t){ee.set(e,t),ae(e)}(r,e)},{default:({itemRef:e})=>l.item?.({...a,itemRef:e})??t.createVNode(zp,t.mergeProps(n,{ref:e,index:a.index,getMatches:V}),l)}),e.showExpand&&(l["expanded-row"]?s.map((e,a)=>t.createVNode(Bs,{key:`${r}-expanded-${a}`,renderless:!0,"onUpdate:height":e=>le(r,a,e)},{default:({itemRef:a})=>t.cloneVNode(e,{ref:a},!0)})):l.expanded&&t.createVNode(Bs,{key:`${r}-expanded`,renderless:!0,"onUpdate:height":e=>le(r,0,e)},{default:({itemRef:a})=>t.createElementVNode("tr",{class:"v-data-table__tr--expanded",ref:a},[t.createElementVNode("td",{colspan:p.value.length},[e.expandTransition?t.createVNode(Xl,{transition:e.expandTransition},{default:()=>[i?t.createElementVNode("div",null,[l.expanded(o)]):null]}):i&&t.createElementVNode("div",null,[l.expanded(o)])])])}))])}}),l["body.append"]?.(ne.value),t.createElementVNode("tr",{style:{height:z(W.value),border:0}},[t.createElementVNode("td",{colspan:p.value.length,style:{height:0,border:0}},null)])]),l.tbody?.(ne.value),l.tfoot?.(ne.value)])]),bottom:()=>l.bottom?.(ne.value)})}),{calculateVisibleItems:Z,scrollToIndex:Q}}}),Jp=Tt({itemsLength:{type:[Number,String],required:!0},...Hv(),...Gp(),...mp()},"VDataTableServer"),em=Kt()({name:"VDataTableServer",props:Jp(),emits:{"update:modelValue":e=>!0,"update:page":e=>!0,"update:itemsPerPage":e=>!0,"update:sortBy":e=>!0,"update:options":e=>!0,"update:expanded":e=>!0,"update:groupBy":e=>!0,"update:opened":e=>!0},setup(e,{attrs:a,slots:l}){const{groupBy:n,opened:o,openAll:r,groupKey:i}=Bv(e),{initialSortOrder:s,sortBy:u,multiSort:c,mustSort:d}=lp(e),{page:v,itemsPerPage:p}=Uv(e),{disableSort:m}=t.toRefs(e),f=t.computed(()=>parseInt(e.itemsLength,10)),{columns:g,headers:h}=_p(e,{groupBy:n,showSelect:t.toRef(()=>e.showSelect),showExpand:t.toRef(()=>e.showExpand)}),{items:y}=Yp(e,g),{toggleSort:b}=np({initialSortOrder:s,sortBy:u,multiSort:c,mustSort:d,page:v}),{opened:w,isGroupOpen:V,toggleGroup:S,extractRows:k}=Tv({groupBy:n,sortBy:u,disableSort:m,opened:o})
zv(w,r,y,n,i)
const{pageCount:x,setItemsPerPage:N,prevPage:C,nextPage:E,setPage:I}=Yv({page:v,itemsPerPage:p,itemsLength:f}),{flatItems:A}=Ov(y,n,w,()=>!!l["group-summary"],V,i),{isSelected:P,select:_,selectAll:R,toggleSelect:D,someSelected:B,allSelected:T}=Jv(e,{allItems:y,currentPage:y}),{isExpanded:F,toggleExpand:$}=Pv(e),M=t.computed(()=>k(y.value))
jv({page:v,itemsPerPage:p,sortBy:u,groupBy:n,search:t.toRef(()=>e.search)}),t.provide("v-data-table",{toggleSort:b,sortBy:u}),Ht({VDataTableRows:{hideNoData:t.toRef(()=>e.hideNoData),noDataText:t.toRef(()=>e.noDataText),loading:t.toRef(()=>e.loading),loadingText:t.toRef(()=>e.loadingText)}})
const z=t.computed(()=>({page:v.value,itemsPerPage:p.value,itemsLength:f.value,sortBy:u.value,pageCount:x.value,toggleSort:b,setItemsPerPage:N,prevPage:C,nextPage:E,setPage:I,someSelected:B.value,allSelected:T.value,isSelected:P,select:_,selectAll:R,toggleSelect:D,isExpanded:F,toggleExpand:$,isGroupOpen:V,toggleGroup:S,items:M.value.map(e=>e.raw),internalItems:M.value,groupedItems:A.value,columns:g.value,headers:h.value}))
sa(()=>{const n=fp.filterProps(e),o=Tp.filterProps(G(e,["multiSort"])),r=Op.filterProps(e),i=Hp.filterProps(e)
return t.createVNode(Hp,t.mergeProps({class:["v-data-table",{"v-data-table--loading":e.loading},e.class],style:e.style},i,{fixedHeader:e.fixedHeader||e.sticky}),{top:()=>l.top?.(z.value),caption:l.caption,default:()=>l.default?l.default(z.value):t.createElementVNode(t.Fragment,null,[l.colgroup?.(z.value),!e.hideDefaultHeader&&t.createElementVNode("thead",{key:"thead",class:"v-data-table__thead",role:"rowgroup"},[t.createVNode(Tp,t.mergeProps(o,{multiSort:!!e.multiSort}),l)]),l.thead?.(z.value),!e.hideDefaultBody&&t.createElementVNode("tbody",{class:"v-data-table__tbody",role:"rowgroup"},[l["body.prepend"]?.(z.value),l.body?l.body(z.value):t.createVNode(Op,t.mergeProps(a,r,{items:A.value}),l),l["body.append"]?.(z.value)]),l.tbody?.(z.value),l.tfoot?.(z.value)]),bottom:()=>l.bottom?l.bottom(z.value):!e.hideDefaultFooter&&t.createElementVNode(t.Fragment,null,[t.createVNode(zr,null,null),t.createVNode(fp,n,{prepend:l["footer.prepend"]})])})})}}),tm=Tt({fluid:{type:Boolean,default:!1},...Ft(),...Tl(),...ol()},"VContainer"),am=Kt()({name:"VContainer",props:tm(),setup(e,{slots:a}){const{rtlClasses:l}=Ua(),{dimensionStyles:n}=Fl(e)
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-container",{"v-container--fluid":e.fluid},l.value,e.class]),style:t.normalizeStyle([n.value,e.style])},a)),{}}}),lm=cr.reduce((e,t)=>(e[t]={type:[Boolean,String,Number],default:!1},e),{}),nm=cr.reduce((e,a)=>(e["offset"+t.capitalize(a)]={type:[String,Number],default:null},e),{}),om={col:H(lm),offset:H(nm),order:["order","orderSm","orderMd","orderLg","orderXl","orderXxl"]}
function rm(e){if(g(e)&&e.includes("/")){const[t,a]=e.split("/")
return{cols:Number(t),size:Number(a)}}return{cols:e}}function im(e,t,a){if(null==a||!1===a)return{}
const{cols:l,size:n}=rm(a),o=t.replace(e,"").toLowerCase()
return"offset"===e?{className:`v-col--offset-${o}-${l}`,variables:[{[`--v-col-offset-base-${o}`]:n}]}:"order"===e?{className:`order-${o}-${l}`}:{className:""===l||!0===l?`v-col--${o}`:`v-col--cols-${o}-${l}`,variables:[{[`--v-col-size-base-${o}`]:n}]}}const sm=["auto","start","end","center","baseline","stretch"],um=Tt({cols:{type:[Boolean,String,Number],default:!1},...lm,offset:{type:[String,Number],default:null},...nm,order:{type:[String,Number],default:null},orderSm:{type:[String,Number],default:null},orderMd:{type:[String,Number],default:null},orderLg:{type:[String,Number],default:null},orderXl:{type:[String,Number],default:null},orderXxl:{type:[String,Number],default:null},alignSelf:{type:String,default:null,validator:e=>sm.includes(e)},...Ft(),...ol()},"VCol"),cm=Kt()({name:"VCol",props:um(),setup(e,{slots:a}){const l=t.computed(()=>rm(e.cols).size),n=t.computed(()=>rm(e.offset).size),o=t.computed(()=>{const t=["v-col"],a=[]
let l
for(l in om)om[l].forEach(n=>{const o=e[n],{className:r,variables:i}=im(l,n,o)
r&&t.push(r),i&&a.push(...i)})
const{cols:n}=rm(e.cols),{cols:o}=rm(e.offset)
return t.push({[`v-col--cols-${n}`]:n,[`v-col--offset-${o}`]:o,[`order-${e.order}`]:e.order,[`align-self-${e.alignSelf}`]:e.alignSelf}),{classes:t,variables:a}})
return()=>t.h(e.tag,{class:[o.value.classes,e.class],style:[{"--v-col-size-base":l.value},{"--v-col-offset-base":n.value},o.value.variables,e.style]},a.default?.())}}),dm=["start","end","center"],vm=["space-between","space-around","space-evenly"],pm=[...dm,"baseline","stretch"],mm=e=>pm.includes(e),fm=[...dm,...vm],gm=e=>fm.includes(e),hm=[...dm,...vm,"stretch"],ym=e=>hm.includes(e),bm={align:["align","alignSm","alignMd","alignLg","alignXl","alignXxl"],justify:["justify","justifySm","justifyMd","justifyLg","justifyXl","justifyXxl"],alignContent:["alignContent","alignContentSm","alignContentMd","alignContentLg","alignContentXl","alignContentXxl"]},wm={align:"align",justify:"justify",alignContent:"align-content"}
function Vm(e,t,a){let l=wm[e]
if(null!=a){if(t){l+=`-${t.replace(e,"")}`}return l+=`-${a}`,l.toLowerCase()}}const Sm=Tt({dense:Boolean,align:{type:String,default:null,validator:mm},alignSm:{type:String,default:null,validator:mm},alignMd:{type:String,default:null,validator:mm},alignLg:{type:String,default:null,validator:mm},alignXl:{type:String,default:null,validator:mm},alignXxl:{type:String,default:null,validator:mm},justify:{type:String,default:null,validator:gm},justifySm:{type:String,default:null,validator:gm},justifyMd:{type:String,default:null,validator:gm},justifyLg:{type:String,default:null,validator:gm},justifyXl:{type:String,default:null,validator:gm},justifyXxl:{type:String,default:null,validator:gm},alignContent:{type:String,default:null,validator:ym},alignContentSm:{type:String,default:null,validator:ym},alignContentMd:{type:String,default:null,validator:ym},alignContentLg:{type:String,default:null,validator:ym},alignContentXl:{type:String,default:null,validator:ym},alignContentXxl:{type:String,default:null,validator:ym},noGutters:Boolean,gap:[Number,String,Array],size:[Number,String],...Ft(),...yn(),...ol()},"VRow"),km=Kt()({name:"VRow",props:Sm(),setup(e,{slots:a}){e.dense&&n("dense",'density="compact"')
const l=t.computed(()=>{const t=[]
let a
for(a in bm)bm[a].forEach(l=>{const n=e[l],o=Vm(a,l,n)
o&&t.push(o)})
return t.push({"v-row--no-gutters":e.noGutters,"v-row--density-default":"default"===e.density&&!e.noGutters&&!e.dense,"v-row--density-compact":"compact"===e.density||e.dense,"v-row--density-comfortable":"comfortable"===e.density,[`align-${e.align}`]:e.align,[`justify-${e.justify}`]:e.justify,[`align-content-${e.alignContent}`]:e.alignContent}),t}),o=t.computed(()=>Array.isArray(e.gap)?z(e.gap[0]||0):z(e.gap)),r=t.computed(()=>Array.isArray(e.gap)?z(e.gap[1]||0):o.value)
return()=>t.h(e.tag,{class:["v-row",l.value,e.class],style:[{"--v-col-gap-x":o.value,"--v-col-gap-y":r.value,"--v-row-columns":e.size},e.style]},a.default?.())}}),xm=qt("v-spacer","div","VSpacer"),Nm=Tt({active:{type:[String,Array],default:void 0},controlHeight:[Number,String],controlVariant:{type:String,default:"docked"},noMonthPicker:Boolean,disabled:{type:[Boolean,String,Array],default:null},nextIcon:{type:ua,default:"$next"},prevIcon:{type:ua,default:"$prev"},modeIcon:{type:ua,default:"$subgroup"},text:String,monthText:String,yearText:String,viewMode:{type:String,default:"month"}},"VDatePickerControls"),Cm=Kt()({name:"VDatePickerControls",props:Nm(),emits:{"click:year":()=>!0,"click:month":()=>!0,"click:prev":()=>!0,"click:next":()=>!0,"click:prev-year":()=>!0,"click:next-year":()=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),o=t.computed(()=>Array.isArray(e.disabled)?e.disabled.includes("text"):!!e.disabled),r=t.computed(()=>Array.isArray(e.disabled)?e.disabled.includes("mode"):!!e.disabled),i=t.computed(()=>Array.isArray(e.disabled)?e.disabled.includes("prev-month"):!!e.disabled),s=t.computed(()=>Array.isArray(e.disabled)?e.disabled.includes("next-month"):!!e.disabled),u=t.computed(()=>Array.isArray(e.disabled)?e.disabled.includes("prev-year"):!!e.disabled),c=t.computed(()=>Array.isArray(e.disabled)?e.disabled.includes("next-year"):!!e.disabled)
function d(){a("click:prev")}function v(){a("click:next")}function p(){a("click:prev-year")}function m(){a("click:next-year")}function f(){a("click:year")}function g(){a("click:month")}return sa(()=>{const a=t.createVNode(Vo,{"data-testid":"prev-month",disabled:i.value,icon:e.prevIcon,"aria-label":n("$vuetify.datePicker.ariaLabel.previousMonth"),onClick:d},null),h=t.createVNode(Vo,{"data-testid":"next-month",disabled:s.value,icon:e.nextIcon,"aria-label":n("$vuetify.datePicker.ariaLabel.nextMonth"),onClick:v},null),y=t.createVNode(Vo,{"data-testid":"prev-year",disabled:u.value,icon:e.prevIcon,"aria-label":n("$vuetify.datePicker.ariaLabel.previousYear"),onClick:p},null),b=t.createVNode(Vo,{"data-testid":"next-year",disabled:c.value,icon:e.nextIcon,"aria-label":n("$vuetify.datePicker.ariaLabel.nextYear"),onClick:m},null),w=t.createVNode(Vo,{class:"v-date-picker-controls__only-month-btn","data-testid":"month-btn",density:"default",disabled:o.value,text:e.monthText,appendIcon:e.modeIcon,rounded:!0,"aria-label":n("$vuetify.datePicker.ariaLabel.selectMonth"),onClick:g},null),V=t.createVNode(Vo,{class:"v-date-picker-controls__only-year-btn","data-testid":"year-btn",density:"default",disabled:r.value,text:e.yearText,appendIcon:e.modeIcon,rounded:!0,"aria-label":n("$vuetify.datePicker.ariaLabel.selectYear"),onClick:f},null),S=t.createVNode(Vo,{class:"v-date-picker-controls__year-btn","data-testid":"year-btn",density:"default",disabled:r.value,text:e.text,appendIcon:e.modeIcon,rounded:!0,"aria-label":n("$vuetify.datePicker.ariaLabel.selectYear"),onClick:f},null),k=t.createElementVNode(t.Fragment,null,[t.createVNode(Vo,{class:"v-date-picker-controls__month-btn","data-testid":"month-btn",height:"36",disabled:o.value,text:e.text,rounded:!0,"aria-label":n("$vuetify.datePicker.ariaLabel.selectMonth"),onClick:g},null),t.createVNode(Vo,{class:"v-date-picker-controls__mode-btn","data-testid":"year-btn",disabled:r.value,icon:e.modeIcon,"aria-label":n("$vuetify.datePicker.ariaLabel.selectYear"),onClick:f},null)]),x={viewMode:e.viewMode,disabled:Array.isArray(e.disabled)?e.disabled:[],monthYearText:e.text??"",monthText:e.monthText??"",yearText:e.yearText??"",openMonths:g,openYears:f,prevMonth:d,nextMonth:v,prevYear:p,nextYear:m},N=t.createElementVNode(t.Fragment,null,[e.noMonthPicker?S:k,t.createVNode(xm,null,null),t.createElementVNode("div",{class:"v-date-picker-controls__month"},[a,h])]),C=t.createElementVNode(t.Fragment,null,[t.createElementVNode("div",{class:"v-date-picker-controls__month"},[a,w,h]),t.createVNode(xm,null,null),t.createElementVNode("div",{class:"v-date-picker-controls__year"},[y,V,b])])
return t.createVNode(Bl,{defaults:{VBtn:{density:"comfortable",variant:"text"}}},{default:()=>[t.createElementVNode("div",{class:t.normalizeClass(["v-date-picker-controls",`v-date-picker-controls--variant-${e.controlVariant}`]),style:{"--v-date-picker-controls-height":z(e.controlHeight)}},[l.default?.(x)??t.createElementVNode(t.Fragment,null,["modal"===e.controlVariant&&N,"docked"===e.controlVariant&&C])])]})}),{}}}),Em=Tt({appendIcon:ua,color:String,header:String,transition:String,onClick:fe(),onClickOnce:fe()},"VDatePickerHeader"),Im=Kt()({name:"VDatePickerHeader",props:Em(),emits:{click:()=>!0,"click:append":()=>!0},setup(e,{emit:a,slots:l}){const{backgroundColorClasses:n,backgroundColorStyles:o}=Ol(()=>e.color)
function r(){a("click")}function i(){a("click:append")}return sa(()=>{const a=!(!l.default&&!e.header),s=!(!l.append&&!e.appendIcon)
return t.createElementVNode("div",{class:t.normalizeClass(["v-date-picker-header",{"v-date-picker-header--clickable":!(!e.onClick&&!e.onClickOnce)},n.value]),style:t.normalizeStyle(o.value),onClick:(e.onClick||e.onClickOnce)&&r},[l.prepend&&t.createElementVNode("div",{key:"prepend",class:"v-date-picker-header__prepend"},[l.prepend()]),a&&t.createVNode(Xl,{key:"content",name:e.transition},{default:()=>[t.createElementVNode("div",{key:e.header,class:"v-date-picker-header__content"},[l.default?.()??e.header])]}),s&&t.createElementVNode("div",{class:"v-date-picker-header__append"},[l.append?t.createVNode(Bl,{key:"append-defaults",disabled:!e.appendIcon,defaults:{VBtn:{icon:e.appendIcon,variant:"text"}}},{default:()=>[l.append?.()]}):t.createVNode(Vo,{key:"append-btn",icon:e.appendIcon,variant:"text",onClick:i},null)])])}),{}}}),Am=Tt({allowedDates:[Array,Function],disabled:{type:Boolean,default:null},displayValue:null,modelValue:Array,month:[Number,String],max:null,min:null,showAdjacentMonths:Boolean,year:[Number,String],weekdays:{type:Array,default:()=>[0,1,2,3,4,5,6]},weeksInMonth:{type:String,default:"dynamic"},firstDayOfWeek:{type:[Number,String],default:void 0},firstDayOfYear:{type:[Number,String],default:void 0},weekdayFormat:String},"calendar")
function Pm(e){const a=Ec(),l=t.computed(()=>{if(!e.min)return null
const t=a.date(e.min)
return a.isValid(t)?t:null}),n=t.computed(()=>{if(!e.max)return null
const t=a.date(e.max)
return a.isValid(t)?t:null})
return{minDate:l,maxDate:n,clampDate:function(e){return l.value&&a.isBefore(e,l.value)?l.value:n.value&&a.isAfter(e,n.value)?n.value:e},isInAllowedRange:function(e){return(!l.value||a.isAfter(e,l.value))&&(!n.value||a.isBefore(e,n.value))}}}function _m(e,a){const{control:l,orientation:n="vertical",circular:o=!1,columns:r,onHighlight:i}=a,s=t.shallowRef()
let u=null
function c(a){const n=e().find(e=>e.id===a)
if(!n?.el)return!1
const o=t.toValue(n.el)
if(!o)return!1
const r=t.toValue(l)
if(r){const e=o.getAttribute("id")
e&&r.setAttribute("aria-activedescendant",e)}return u&&delete u.dataset.highlighted,o.dataset.highlighted="",u=o,o.scrollIntoView?.({block:"nearest"}),i?.(a),!0}function d(e,t){return(t%e+e)%e}function v(t){return e().findIndex(e=>e.id===t)}function p(e){s.value=e,c(e)}function m(a){const l=e()
if(!l.length)return
const n=k(s.value)?-1:v(s.value),r=a>0?1:-1,i=Math.abs(a),u=Math.ceil(l.length/i)
let c=n+a,m=0
if(o)c=d(l.length,c)
else if(c<0||c>=l.length)return
for(;m<u;){const e=l[c]
if(e&&!t.toValue(e.disabled))return void p(e.id)
if(m++,c=o?d(l.length,c+a):c+r*i,!o&&(c<0||c>=l.length))return}}function f(){const a=e().find(e=>!t.toValue(e.disabled))
a&&p(a.id)}function g(){const a=[...e()].reverse().find(e=>!t.toValue(e.disabled))
a&&p(a.id)}function h(){s.value=void 0,t.toValue(l)?.removeAttribute("aria-activedescendant"),u&&(delete u.dataset.highlighted,u=null)}return t.onScopeDispose(h),{highlightedId:s,highlight:function(e){const t=s.value
s.value=e,c(e)||(s.value=t)},focusHighlighted:function(){if(k(s.value))return
const a=e().find(e=>e.id===s.value)
a?.el&&t.toValue(a.el)?.focus()},clear:h,next:()=>m(1),prev:()=>m(-1),first:f,last:g,onKeydown:function(a){const l=t.toValue(r),o=function(e){const t=e.currentTarget
return!!t&&"rtl"===getComputedStyle(t).direction}(a)
if(l){switch(a.key){case"ArrowRight":a.preventDefault(),m(o?-1:1)
break
case"ArrowLeft":a.preventDefault(),m(o?1:-1)
break
case"ArrowDown":a.preventDefault(),m(l)
break
case"ArrowUp":a.preventDefault(),m(-l)
break
case"Home":a.preventDefault(),a.ctrlKey?f():function(){const a=t.toValue(r)??0
if(!a)return f()
const l=e(),n=k(s.value)?0:Math.max(0,v(s.value)),o=n-n%a
for(let e=o;e<Math.min(o+a,l.length);e++)if(!t.toValue(l[e]?.disabled))return void p(l[e].id)}()
break
case"End":a.preventDefault(),a.ctrlKey?g():function(){const a=t.toValue(r)??0
if(!a)return g()
const l=e(),n=k(s.value)?0:Math.max(0,v(s.value)),o=n-n%a
for(let e=Math.min(o+a,l.length)-1;e>=o;e--)if(!t.toValue(l[e]?.disabled))return void p(l[e].id)}()}return}const i=[],u=[]
"vertical"!==n&&"both"!==n||(i.push("ArrowUp"),u.push("ArrowDown")),"horizontal"!==n&&"both"!==n||(i.push(o?"ArrowRight":"ArrowLeft"),u.push(o?"ArrowLeft":"ArrowRight")),i.includes(a.key)?(a.preventDefault(),m(-1)):u.includes(a.key)?(a.preventDefault(),m(1)):"Home"===a.key?(a.preventDefault(),f()):"End"===a.key&&(a.preventDefault(),g())}}}function Rm({items:e,columns:a,initialValue:l,itemAttribute:n,onSelect:o,onNavigation:r,onHighlight:i,onEscape:s}){const u=t.shallowRef(!1),c=t.shallowRef(),d=_m(()=>e().map(e=>({id:e.value,disabled:e.isDisabled,el:()=>c.value?.querySelector(`[${n}="${e.value}"]`)})),{control:c,columns:a})
function v(t){const a=c.value
if(!a||a.contains(t.relatedTarget))return
u.value=!0
const o=t.target,r=o?.getAttribute?.(n)
if(!k(r)&&e().some(e=>String(e.value)===r))return void d.highlight(r)
const i=l(d.highlightedId.value)
k(i)||d.highlight(i),d.focusHighlighted()}function p(e){c.value?.contains(e.relatedTarget)||(u.value=!1,d.clear())}function m(t){if("Escape"===t.key)return t.preventDefault(),void s?.()
if(("Enter"===t.key||" "===t.key)&&!k(d.highlightedId.value))return t.preventDefault(),void function(){const t=d.highlightedId.value
if(k(t))return
const a=e().find(e=>e.value===t)
a&&!a.isDisabled&&o(t)}()
const a=function(e){switch(e){case"ArrowUp":return"up"
case"ArrowDown":return"down"
case"ArrowLeft":return"left"
case"ArrowRight":return"right"
default:return null}}(t.key)
a&&r?.(a,t,d.highlightedId.value)||(d.onKeydown(t),d.focusHighlighted())}i&&t.watch(d.highlightedId,e=>i(e))
return{containerProps:t.computed(()=>({ref:e=>c.value=e??void 0,tabindex:u.value?-1:0,onKeydown:m,onFocusin:v,onFocusout:p})),containerEl:c,selectItem:function(e){d.highlight(e),d.focusHighlighted(),o(e)},focusItem:function(e){d.highlight(e),k(d.highlightedId.value)&&d.first(),d.focusHighlighted()},clear:d.clear}}function Dm({multiple:e,model:a,compare:l,normalizeEnd:n=e=>e,previewValue:o}){const r=t.computed(()=>a.value.length>=1?a.value[0]:void 0),i=t.computed(()=>a.value.length>=2?a.value[a.value.length-1]:void 0),s=o??t.shallowRef(),u=t.computed(()=>{if("range"!==e.value)return null
if(!r.value||i.value)return null
if(!s.value)return null
const t=r.value,a=s.value
return 0===l(t,a)?null:l(t,a)<0?[t,a]:[a,t]})
function c(t){if("range"!==e.value||a.value.length<2)return!1
const[n,o]=[a.value[0],a.value[a.value.length-1]]
return l(t,n)>=0&&l(t,o)<=0}function d(t){return!("range"!==e.value||a.value.length<2)&&0===l(t,a.value[0])}function v(t){return!("range"!==e.value||a.value.length<2)&&0===l(t,a.value[a.value.length-1])}function p(e){const t=u.value
return!!t&&0===l(e,t[0])}function m(e){const t=u.value
return!!t&&0===l(e,t[1])}function f(e){const t=u.value
return!!t&&(l(e,t[0])>0&&l(e,t[1])<0)}return{isSelected:function(t){if("range"===e.value&&2===a.value.length)return c(t)
for(const e of a.value)if(0===l(e,t))return!0
return!1},isRangeStart:d,isRangeEnd:v,isRangeMiddle:function(e){return c(e)&&!d(e)&&!v(e)},select:function(t){"range"===e.value?function(e){if(0===a.value.length)a.value=[e]
else if(1===a.value.length){const t=a.value[0]
0===l(e,t)?a.value=[]:l(e,t)<0?a.value=[e,n(t)]:a.value=[t,n(e)]}else a.value=[e]}(t):e.value?function(e){const t=a.value.findIndex(t=>0===l(t,e))
if(-1===t)a.value=[...a.value,e]
else{const e=[...a.value]
e.splice(t,1),a.value=e}}(t):a.value=[t]},setPreview:function(e){s.value=e},clearPreview:function(){s.value=void 0},isPreviewStart:p,isPreviewEnd:m,isPreviewMiddle:f,isInPreviewRange:function(e){return p(e)||m(e)||f(e)}}}const Bm=Tt({color:String,hideWeekdays:Boolean,multiple:[Boolean,Number,String],showWeek:Boolean,readonly:Boolean,transition:{type:String,default:"picker-transition"},reverseTransition:{type:String,default:"picker-reverse-transition"},events:{type:[Array,Function,Object],default:()=>null},eventColor:{type:[Array,Function,Object,String],default:()=>null},noAutoNavigation:Boolean,previewValue:null,...G(Am(),["displayValue"])},"VDatePickerMonth"),Tm=Kt()({name:"VDatePickerMonth",props:Bm(),emits:{"update:modelValue":e=>!0,"update:month":e=>!0,"update:year":e=>!0,"update:previewValue":e=>!0,"boundary-navigate":e=>!0},setup(e,{emit:a,slots:l}){const n=t.useId(),{t:o}=Ha(),{daysInMonth:r,model:i,weekNumbers:s,weekdayLabels:u}=function(e){const a=Ec(),l=_a(e,"modelValue",[],e=>ee(e).map(e=>a.date(e))),n=t.computed(()=>e.displayValue?a.date(e.displayValue):l.value.length>0?a.date(l.value[0]):e.min?a.date(e.min):Array.isArray(e.allowedDates)?a.date(e.allowedDates[0]):a.date()),o=_a(e,"year",void 0,e=>{const t=k(e)?a.getYear(n.value):Number(e)
return a.startOfYear(a.setYear(a.date(),t))},e=>a.getYear(e)),r=_a(e,"month",void 0,e=>{const t=k(e)?a.getMonth(n.value):Number(e),l=a.setYear(a.startOfMonth(a.date()),a.getYear(o.value))
return a.setMonth(l,t)},e=>a.getMonth(e)),i=t.computed(()=>{const t=a.toJsDate(a.startOfWeek(a.date(),e.firstDayOfWeek)).getDay()
return a.getWeekdays(e.firstDayOfWeek,e.weekdayFormat).filter((a,l)=>e.weekdays.includes((l+t)%7))}),s=t.computed(()=>{const t=a.getWeekArray(r.value,e.firstDayOfWeek),l=t.flat()
if("static"===e.weeksInMonth&&l.length<42){const e=l[l.length-1]
let n=[]
for(let o=1;o<=42-l.length;o++)n.push(a.addDays(e,o)),o%7==0&&(t.push(n),n=[])}return t})
function u(t,n){return t.filter(t=>e.weekdays.includes(a.toJsDate(t).getDay())).map((t,o)=>{const i=a.toISO(t),s=!a.isSameMonth(t,r.value),u=a.isSameDay(t,a.startOfMonth(r.value)),c=a.isSameDay(t,a.endOfMonth(r.value)),d=a.isSameDay(t,r.value),v=e.weekdays.length
return{date:t,formatted:a.format(t,"keyboardDate"),isAdjacent:s,isDisabled:g(t),isEnd:c,isHidden:s&&!e.showAdjacentMonths,isSame:d,isSelected:l.value.some(e=>a.isSameDay(t,e)),isStart:u,isToday:a.isSameDay(t,n),isWeekEnd:o%v===v-1,isWeekStart:o%v===0,isoDate:i,localized:a.format(t,"dayOfMonth"),month:a.getMonth(t),year:a.getYear(t)}})}const c=t.computed(()=>{const t=a.startOfWeek(n.value,e.firstDayOfWeek),l=[]
for(let e=0;e<=6;e++)l.push(a.addDays(t,e))
return u(l,a.date())}),d=t.computed(()=>u(s.value.flat(),a.date())),v=t.computed(()=>s.value.map(t=>t.length?a.getWeek(t[0],e.firstDayOfWeek,e.firstDayOfYear):null)),{minDate:p,maxDate:m}=Pm(e)
function g(t){if(e.disabled)return!0
const l=a.date(t)
return!((!p.value||!a.isBefore(a.endOfDay(l),p.value))&&(!m.value||!a.isAfter(l,m.value))&&(Array.isArray(e.allowedDates)&&e.allowedDates.length>0?e.allowedDates.some(e=>a.isSameDay(a.date(e),l)):!f(e.allowedDates)||e.allowedDates(l)))}return{displayValue:n,daysInMonth:d,daysInWeek:c,genDays:u,model:l,weeksInMonth:s,weekdayLabels:i,weekNumbers:v}}(e),c=Ec(),d=t.shallowRef(!1),v=t.toRef(()=>d.value?e.reverseTransition:e.transition)
const p=_a(e,"previewValue"),m=Dm({multiple:t.computed(()=>"range"===e.multiple?"range":!!e.multiple),model:i,compare:function(e,t){return c.isSameDay(e,t)?0:c.isBefore(e,t)?-1:1},normalizeEnd:e=>c.endOfDay(e),previewValue:p}),h=t.toRef(()=>e.color||"surface-variant"),{backgroundColorClasses:y,backgroundColorStyles:w}=Ol(h),V=t.computed(()=>{const t=["number","string"].includes(typeof e.multiple)?Number(e.multiple):1/0
return i.value.length>=t}),S=t.computed(()=>function(e,t=1){return Array.from({length:Math.ceil(e.length/t)},(a,l)=>e.slice(l*t,l*t+t))}(r.value,e.weekdays.length))
function x(e){return m.isSelected(e.date)}function N(e){return e.isDisabled||e.isHidden||V.value&&!x(e)}function C(e){const t=c.format(e.date,"fullDateWithWeekday"),a=e.isToday?"currentDate":"selectDate"
return o(`$vuetify.datePicker.ariaLabel.${a}`,t)}const{containerProps:E,containerEl:I,selectItem:A,focusItem:P,clear:_}=Rm({items:()=>r.value.map(e=>({value:e.isoDate,isDisabled:N(e)})),columns:()=>e.weekdays.length,initialValue:function(e){const t=e=>!e.isAdjacent&&!e.isDisabled
if(null!=e){const t=r.value.find(t=>t.isoDate===e)
if(t&&!t.isAdjacent)return e}const a=r.value.find(e=>t(e)&&i.value.some(t=>c.isSameDay(t,e.date)))
return(a??r.value.find(t))?.isoDate},itemAttribute:"data-v-date",onSelect:R,onNavigation:function(l,n,o){if(null==o)return!1
const i=e.weekdays.length,s="rtl"===getComputedStyle(n.currentTarget).direction
let u,d
"left"===l?(u=s?1:-1,d=u):"right"===l?(u=s?-1:1,d=u):"up"===l?(u=-i,d=-7):(u=i,d=7)
const v=r.value,p=v.findIndex(e=>e.isoDate===o)
if(p<0)return!1
const m=v[p+u]
if(m&&!m.isHidden)return!1
let f
if(n.preventDefault(),m)f=m.isoDate
else{const t=d<0?-1:1
let a=c.addDays(c.date(o),d)
for(;!e.weekdays.includes(c.toJsDate(a).getDay());)a=c.addDays(a,t)
f=c.toISO(a)}if(e.noAutoNavigation)return a("boundary-navigate",{direction:l,targetIsoDate:f}),!0
const g=c.date(f)
return a("update:month",c.getMonth(g)),a("update:year",c.getYear(g)),t.nextTick(()=>P(f)),!0},onEscape:function(){const e=i.value[0]??c.date(),l=c.toISO(c.date(e))
if(r.value.find(e=>e.isoDate===l&&!e.isAdjacent))return void P(l)
const n=c.date(e)
a("update:month",c.getMonth(n)),a("update:year",c.getYear(n)),t.nextTick(()=>P(l))}})
function R(e){const l=r.value.find(t=>t.isoDate===e)
var n
l&&!N(l)&&(n=l.date,m.select(c.startOfDay(n)),l.isAdjacent&&(a("update:month",c.getMonth(l.date)),a("update:year",c.getYear(l.date)),t.nextTick(()=>P(e))))}function D(a){const l=function(t){const{events:a,eventColor:l}=e
let n,o=[]
return n=Array.isArray(a)?a.includes(t):a instanceof Function?a(t)||!1:a&&a[t]||!1,n?(!0!==n?o=ee(n):g(l)?o=[l]:f(l)?o=ee(l(t)):Array.isArray(l)?o=l:b(l)&&(o=ee(l[t])),o.length?o.filter(Boolean).map(e=>g(e)?e:"surface-variant"):["surface-variant"]):[]}(a)
return l.length?t.createElementVNode("div",{class:"v-date-picker-month__events"},[l.map(e=>t.createVNode(Ro,{dot:!0,color:e},null))]):null}return t.watch(r,(e,t)=>{t&&e[0].isoDate!==t[0].isoDate&&(d.value=c.isBefore(e[0].date,t[0].date),_())}),sa(()=>t.createElementVNode("div",{class:"v-date-picker-month",style:{"--v-date-picker-days-in-week":e.weekdays.length}},[e.showWeek&&t.createElementVNode("div",{key:"weeks",class:"v-date-picker-month__weeks"},[!e.hideWeekdays&&t.createElementVNode("div",{key:"hide-week-days",class:"v-date-picker-month__day"},[t.createTextVNode(" ")]),s.value.map(e=>t.createElementVNode("div",{class:t.normalizeClass(["v-date-picker-month__day","v-date-picker-month__day--adjacent"])},[e]))]),t.createVNode(Xl,{name:v.value},{default:()=>[t.createElementVNode("div",t.mergeProps({key:r.value[0].date?.toString(),class:"v-date-picker-month__days",role:"grid",onMouseleave:m.clearPreview},E.value),[!e.hideWeekdays&&t.createElementVNode("div",{key:"weekday-labels",class:"v-date-picker-month__days-row"},[u.value.map(e=>t.createElementVNode("div",{class:t.normalizeClass(["v-date-picker-month__day","v-date-picker-month__weekday"])},[e]))]),S.value.map((a,o)=>t.createElementVNode("div",{class:"v-date-picker-month__days-row",role:"row"},[a.map((a,r)=>{const i=o*e.weekdays.length+r,s=x(a),u=N(a),c=m.isRangeStart(a.date),d=m.isRangeEnd(a.date),v=m.isRangeMiddle(a.date),p=m.isPreviewStart(a.date),f=m.isPreviewEnd(a.date),g=m.isPreviewMiddle(a.date),h={props:{class:"v-date-picker-month__day-btn",color:s&&!v||a.isToday?e.color:void 0,disabled:u,readonly:e.readonly,icon:!0,ripple:!1,tabindex:-1,variant:s&&!v?"flat":a.isToday?"outlined":"text","aria-label":C(a),"aria-current":a.isToday?"date":void 0,id:`${n}-day-${a.isoDate}`,"data-v-date":u?void 0:a.isoDate,onMousedown:e=>e.preventDefault(),onClick:()=>function(e){e.isAdjacent?R(e.isoDate):A(e.isoDate)}(a),onMouseenter:()=>m.setPreview(a.date),onFocus:()=>m.setPreview(a.date),onBlur:m.clearPreview},item:a,i},b=c||d||v,V=p||f||g
return t.createElementVNode("div",{class:t.normalizeClass(["v-date-picker-month__day",{"v-date-picker-month__day--adjacent":a.isAdjacent,"v-date-picker-month__day--hide-adjacent":a.isHidden,"v-date-picker-month__day--selected":s,"v-date-picker-month__day--week-end":a.isWeekEnd,"v-date-picker-month__day--week-start":a.isWeekStart,"v-date-picker-month__day--range-start":c,"v-date-picker-month__day--range-end":d,"v-date-picker-month__day--range-middle":v,"v-date-picker-month__day--preview-start":p,"v-date-picker-month__day--preview-end":f,"v-date-picker-month__day--preview-middle":g}]),role:"gridcell"},[(b||V)&&t.createElementVNode("div",{key:"range-bg",class:t.normalizeClass(["v-date-picker-month__range-bg",b?"v-date-picker-month__range-bg--range":"v-date-picker-month__range-bg--preview",y.value]),style:t.normalizeStyle(w.value)},null),(e.showAdjacentMonths||!a.isAdjacent)&&(l.day?.(h)??t.createVNode(Vo,h.props,{default:()=>[a.localized,D(a.isoDate)]}))])})]))])]})])),{focusGrid:function(){I.value?.focus()},focusItem:P}}}),Fm=Tt({color:String,columns:{type:Number,default:2},height:[String,Number],min:null,max:null,modelValue:Number,year:Number,allowedMonths:[Array,Function]},"VDatePickerMonths"),$m=Kt()({name:"VDatePickerMonths",props:Fm(),emits:{"update:modelValue":e=>!0,escape:()=>!0},setup(e,{emit:a,slots:l}){const n=Ec(),o=_a(e,"modelValue"),r=t.useId(),i=t.computed(()=>{let t=n.startOfYear(n.date())
return e.year&&(t=n.setYear(t,e.year)),C(12).map(a=>{const l=n.format(t,"monthShort"),o=n.format(t,"month"),r=!!(!function(t){if(Array.isArray(e.allowedMonths)&&e.allowedMonths.length)return e.allowedMonths.includes(t)
if(f(e.allowedMonths))return e.allowedMonths(t)
return!0}(a)||e.min&&n.isAfter(n.startOfMonth(n.date(e.min)),t)||e.max&&n.isAfter(t,n.startOfMonth(n.date(e.max))))
return t=n.getNextMonth(t),{isDisabled:r,text:l,label:o,value:a}})})
t.watchEffect(()=>{o.value=o.value??n.getMonth(n.date())})
const{containerProps:s,selectItem:u}=Rm({items:()=>i.value,columns:()=>e.columns,initialValue:e=>e??o.value??n.getMonth(n.date()),itemAttribute:"data-v-month",onSelect:function(e){o.value===e?a("update:modelValue",e):o.value=e},onEscape:()=>a("escape")})
return sa(()=>t.createElementVNode("div",{class:"v-date-picker-months",style:{height:z(e.height)}},[t.createElementVNode("div",t.mergeProps({class:"v-date-picker-months__content",style:{"--v-date-picker-months-columns":e.columns}},s.value),[i.value.map((a,n)=>{const i={id:`${r}-month-${n}`,active:o.value===n,ariaLabel:a.label,color:o.value===n?e.color:void 0,disabled:a.isDisabled,rounded:!0,tabindex:-1,text:a.text,variant:o.value===a.value?"flat":"text","data-v-month":a.value,onMousedown:e=>e.preventDefault(),onClick:()=>u(n)}
return l.month?.({month:a,i:n,props:i})??t.createVNode(Vo,t.mergeProps({key:"month"},i),null)})])])),{}}}),Mm=Tt({color:String,columns:{type:Number,default:3},height:[String,Number],min:null,max:null,modelValue:Number,allowedYears:[Array,Function]},"VDatePickerYears"),zm=Kt()({name:"VDatePickerYears",props:Mm(),directives:{vIntersect:Jl},emits:{"update:modelValue":e=>!0,escape:()=>!0},setup(e,{emit:a,slots:l}){const n=Ec(),o=_a(e,"modelValue"),r=Ee(),i=t.useId(),s=t.computed(()=>{const t=n.getYear(n.date())
let a=t-100,l=t+52
e.min&&(a=n.getYear(n.date(e.min))),e.max&&(l=n.getYear(n.date(e.max)))
let o=n.startOfYear(n.date())
return o=n.setYear(o,a),C(l-a+1,a).map(e=>{const t=n.format(o,"year")
return o=n.setYear(o,n.getYear(o)+1),{text:t,value:e,isDisabled:!u(e)}})})
function u(t){return Array.isArray(e.allowedYears)&&e.allowedYears.length?e.allowedYears.includes(t):!f(e.allowedYears)||e.allowedYears(t)}t.watchEffect(()=>{o.value=o.value??n.getYear(n.date())})
const{containerProps:c,containerEl:d,selectItem:v}=Rm({items:()=>s.value,columns:()=>e.columns,initialValue:e=>e??o.value??n.getYear(n.date()),itemAttribute:"data-v-year",onSelect:function(e){o.value===e?a("update:modelValue",e):o.value=e},onEscape:()=>a("escape")})
function p(){const e=r.el,t=d.value?.querySelector(`[data-v-year="${o.value}"]`)
if(!e||!t)return
const a=e.getBoundingClientRect(),l=t.getBoundingClientRect()
e.scrollTop+=l.top-a.top-e.clientHeight/2+l.height/2}return sa(()=>t.withDirectives(t.createElementVNode("div",{class:"v-date-picker-years",ref:r,tabindex:-1,style:{height:z(e.height)}},[t.createElementVNode("div",t.mergeProps({class:"v-date-picker-years__content",style:{"--v-date-picker-years-columns":e.columns}},c.value),[s.value.map((a,n)=>{const r={id:`${i}-year-${a.value}`,active:o.value===a.value,color:o.value===a.value?e.color:void 0,rounded:!0,tabindex:-1,text:a.text,disabled:a.isDisabled,variant:o.value===a.value?"flat":"text","data-v-year":a.value,onMousedown:e=>e.preventDefault(),onClick:()=>v(a.value)}
return l.year?.({year:a,i:n,props:r})??t.createVNode(Vo,t.mergeProps({key:"month"},r),null)})])]),[[Jl,{handler:p},null,{once:!0}]])),{}}}),Lm=Tt({header:{type:String,default:"$vuetify.datePicker.header"},headerColor:String,headerDateFormat:{type:String,default:"normalDateWithWeekday"},landscapeHeaderWidth:[Number,String],...G(Nm(),["active","monthText","yearText"]),...Bm({weeksInMonth:"static"}),...G(Fm(),["modelValue","columns"]),...G(Mm(),["modelValue","columns"]),...hv({title:"$vuetify.datePicker.title"}),modelValue:null},"VDatePicker"),Om=Kt()({name:"VDatePicker",props:Lm(),emits:{"update:modelValue":e=>!0,"update:month":e=>!0,"update:year":e=>!0,"update:previewValue":e=>!0,"update:viewMode":e=>!0,"boundary-navigate":e=>!0},setup(e,{emit:a,slots:l}){const n=Ec(),{t:o}=Ha(),{rtlClasses:r}=Ua(),i=_a(e,"modelValue",void 0,e=>ee(e).map(e=>n.date(e)),t=>e.multiple?t:t[0]),s=_a(e,"viewMode"),u=_a(e,"previewValue"),{minDate:c,maxDate:d,clampDate:v}=Pm(e),p=t.computed(()=>{const e=n.date(),t=i.value?.[0]?n.date(i.value[0]):v(e)
return t&&n.isValid(t)?t:e}),m=t.toRef(()=>e.headerColor??e.color),h=_a(e,"month"),y=t.computed({get:()=>Number(h.value??n.getMonth(n.startOfMonth(p.value))),set:e=>h.value=e}),b=_a(e,"year"),w=t.computed({get:()=>Number(b.value??n.getYear(n.startOfYear(n.setMonth(p.value,y.value)))),set:e=>b.value=e}),V=t.shallowRef(!1),S=t.computed(()=>{if("range"===e.multiple&&2===i.value.length){const[e,t]=i.value,a=n.getDiff(t,e,"days")+1
return o("$vuetify.datePicker.itemsSelected",a)}if(e.multiple&&i.value.length>1)return o("$vuetify.datePicker.itemsSelected",i.value.length)
const t=i.value[0]&&n.isValid(i.value[0])?n.format(n.date(i.value[0]),e.headerDateFormat):o(e.header)
return e.landscape&&3===t.split(" ").length?t.replace(" ","\n"):t}),k=t.toRef(()=>{let e=n.date()
return e=n.setDate(e,1),e=n.setMonth(e,y.value),e=n.setYear(e,w.value),e}),x=t.toRef(()=>n.format(k.value,"monthAndYear")),N=t.toRef(()=>n.format(k.value,"monthShort")),C=t.toRef(()=>n.format(k.value,"year")),E=t.toRef(()=>`date-picker-header${V.value?"-reverse":""}-transition`),I=t.computed(()=>{if(e.disabled)return!0
const t=[]
if("month"!==s.value)t.push("prev-month","next-month","prev-year","next-year")
else{let e=n.date()
if(e=n.startOfMonth(e),e=n.setMonth(e,y.value),e=n.setYear(e,w.value),c.value){const a=n.addDays(n.startOfMonth(e),-1),l=n.addDays(n.startOfYear(e),-1)
n.isAfter(c.value,a)&&t.push("prev-month"),n.isAfter(c.value,l)&&t.push("prev-year")}if(d.value){const a=n.addDays(n.endOfMonth(e),1),l=n.addDays(n.endOfYear(e),1)
n.isAfter(a,d.value)&&t.push("next-month"),n.isAfter(l,d.value)&&t.push("next-year")}}return t}),A=t.computed(()=>e.allowedYears||R),P=t.computed(()=>e.allowedMonths||D)
function _(t,a){const l=e.allowedDates
if(!f(l))return!0
const o=1+function(e,t,a){const l=[`${e.toISO(a??t).split("T")[0]}T00:00:00Z`,`${e.toISO(t).split("T")[0]}T00:00:00Z`]
return g(e.date())?e.getDiff(l[0],l[1],"days"):e.getDiff(e.date(l[0]),e.date(l[1]),"days")}(n,t,a)
for(let e=0;e<o;e++)if(l(n.addDays(t,e)))return!0
return!1}function R(t){if(f(e.allowedDates)){const e=n.parseISO(`${t}-01-01`)
return _(e,n.endOfYear(e))}if(Array.isArray(e.allowedDates)&&e.allowedDates.length){for(const a of e.allowedDates)if(n.getYear(n.date(a))===t)return!0
return!1}return!0}function D(t){if(f(e.allowedDates)){const e=String(t+1).padStart(2,"0"),a=n.parseISO(`${w.value}-${e}-01`)
return _(a,n.endOfMonth(a))}if(Array.isArray(e.allowedDates)&&e.allowedDates.length){for(const a of e.allowedDates)if(n.getYear(n.date(a))===w.value&&n.getMonth(n.date(a))===t)return!0
return!1}return!0}function B(){y.value<11?y.value++:(w.value++,y.value=0,U()),W()}function T(){y.value>0?y.value--:(w.value--,y.value=11,U()),W()}function F(){if(w.value++,d.value){const e=String(y.value+1).padStart(2,"0"),t=n.parseISO(`${w.value}-${e}-01`)
n.isAfter(t,d.value)&&(y.value=n.getMonth(d.value))}U()}function $(){if(w.value--,c.value){const e=String(y.value+1).padStart(2,"0"),t=n.endOfMonth(n.parseISO(`${w.value}-${e}-01`))
n.isAfter(c.value,t)&&(y.value=n.getMonth(c.value))}U()}const M=t.shallowRef()
function L(){s.value="month"}function O(){s.value="month",t.nextTick(()=>M.value?.focusGrid())}function j(){s.value="months"===s.value?"month":"months"}function H(){s.value="year"===s.value?"month":"year"}function W(){"months"===s.value&&j()}function U(){"year"===s.value&&H()}return t.watch(i,(t,a)=>{if(e.noAutoNavigation)return
const l=ee(a),o=ee(t)
if(!o.length)return
const r=n.date(l[l.length-1]),i=n.date(o[o.length-1])
if(n.isSameDay(r,i))return
const s=n.getMonth(i),u=n.getYear(i)
s!==y.value&&(y.value=s,W()),u!==w.value&&(w.value=u,U()),V.value=n.isBefore(r,i)}),sa(()=>{const n=yv.filterProps(e),v=G(Cm.filterProps(e),["viewMode"]),p=Im.filterProps(e),f=Tm.filterProps(e),g=G($m.filterProps(e),["modelValue"]),h=G(zm.filterProps(e),["modelValue"]),b={color:m.value,header:S.value,transition:E.value}
return t.createVNode(yv,t.mergeProps(n,{color:m.value,class:["v-date-picker",`v-date-picker--${s.value}`,{"v-date-picker--show-week":e.showWeek},r.value,e.class],style:[{"--v-date-picker-landscape-header-width":z(e.landscapeHeaderWidth)},e.style]}),{title:()=>l.title?.()??t.createElementVNode("div",{class:"v-date-picker__title"},[o(e.title)]),header:()=>l.header?t.createVNode(Bl,{defaults:{VDatePickerHeader:{...b}}},{default:()=>[l.header?.(b)]}):t.createVNode(Im,t.mergeProps({key:"header"},p,b,{onClick:"month"!==s.value?L:void 0}),{prepend:l.prepend,append:l.append}),default:()=>t.createElementVNode(t.Fragment,null,[t.createVNode(Cm,t.mergeProps(v,{disabled:I.value,viewMode:s.value,text:x.value,monthText:N.value,yearText:C.value,"onClick:next":B,"onClick:prev":T,"onClick:nextYear":F,"onClick:prevYear":$,"onClick:month":j,"onClick:year":H}),{default:l.controls}),t.createVNode(wl,{hideOnLeave:!0},{default:()=>["months"===s.value?t.createVNode($m,t.mergeProps({key:"date-picker-months"},g,{modelValue:y.value,"onUpdate:modelValue":[e=>y.value=e,W],min:c.value,max:d.value,year:w.value,allowedMonths:P.value,onEscape:O}),{month:l.month}):"year"===s.value?t.createVNode(zm,t.mergeProps({key:"date-picker-years"},h,{modelValue:w.value,"onUpdate:modelValue":[e=>w.value=e,U],min:c.value,max:d.value,allowedYears:A.value,onEscape:O}),{year:l.year}):t.createVNode(Tm,t.mergeProps({ref:M,key:"date-picker-month"},f,{modelValue:i.value,"onUpdate:modelValue":e=>i.value=e,month:y.value,"onUpdate:month":[e=>y.value=e,W],year:w.value,"onUpdate:year":[e=>w.value=e,U],previewValue:u.value,"onUpdate:previewValue":e=>u.value=e,onBoundaryNavigate:e=>a("boundary-navigate",e),min:c.value,max:d.value}),{day:l.day})]})]),actions:l.actions})}),{focusDate:function(e){M.value?.focusItem(e)}}}})
function jm(e,t,a,l,n){const o=e.max??10**e.size-1,r=Math.min(o,e.softMax?.(n)??o)
let i=a,s="",u=!1
for(;i<t.length&&!u&&/\d/.test(t[i]);){if(Number(s+t[i])>r){s=String(r).padStart(s.length+1,"0"),i++,u=!0
break}s+=t[i++],e.min&&!Number(s)&&(s="0"),u=s.length===e.size}const c=i
if(l)for(;i<t.length&&!/\d/.test(t[i]);)i++
else i<t.length&&!/\d/.test(t[i])&&i++
return u||=!!s&&Number(s)*10**(e.size-s.length)>r,{digits:s,index:i,end:c,filled:u,closed:i>c}}function Hm(e,t,a){const l=e.close?.(t)??t,n=a?e.min??0:0
return String(Math.max(Number(l),n)).padStart(e.size,"0")}function Wm(e,t,a=0,l=-1){let n=a,o="",r=!1,i=!1,s=-1,u=0,c=0,d="",v=!0
const p={},m=[]
for(let a=0;a<e.length;a++){const f=e[a]
if("separator"===f.type)continue
const g=e[a+1],h=!e.slice(a+1).some(e=>"value"===e.type),y=h||"separator"!==g?.type?"":g.value,b=n,w=jm(f,t,n,h,p),V=w.filled
let S=w.digits
n=w.index,r=w.closed
const k=S.length,x=l>=b&&l<=w.end,N=x||l>=b&&l<n
if(!S){if(!h&&r||(v=!1),!r)break
N&&s<0&&(s=o.length+d.length),d+=y,c+=f.size+y.length
continue}const C=V||k===f.size||r&&!x
if(k<f.size&&C&&(S=Hm(f,S,l>=w.end)),d&&(i=!0),p[f.key]=S,o+=d+S,d="",f.softMax&&m.push({segment:f,at:o.length-S.length}),u=c+S.length,N&&s<0&&(s=l>=b+k&&C?o.length+y.length:o.length-k+Math.min(l-b,k)),k<f.size&&!V&&!r){v=!1
break}c+=f.size+y.length,o+=y,y&&(u=c)}for(const{segment:e,at:t}of m){const a=p[e.key],l=e.softMax(p)
if(Number(a)<=l)continue
const n=String(l).padStart(a.length,"0")
p[e.key]=n,o=o.slice(0,t)+n+o.slice(t+a.length)}return{value:o,index:n,closed:r,caret:s,width:u,gaps:i,complete:v}}function Um(e,t,a,l){const n=e.slice(t,t+a),o=e.slice(t+a),r=/\d/.test(o)?n.replace(/\d/g,""):"",i=e.slice(0,t)+r+o
return{value:/\d/.test(i)?i:"",caret:l?t+r.length:t}}function Ym(e){let t=[31,29,31,30,31,30,31,31,30,31,30,31][Number(e.m)-1]??31
const a=Number(e.y),l=!(a%4)&&(a%100||!(a%400))
return 29!==t||4!==e.y?.length||l||(t=28),t}class Gm{constructor(e,t){this.order=e,this.separator=t}get format(){return this.order.split("").map(e=>`${e}${e}`).join(this.separator).replace("yy","yyyy")}static canBeParsed(e){if(!g(e))return!1
const t=e.toLowerCase()
return["y","m","d"].every(e=>t.includes(e))&&["/","-","."].some(t=>e.includes(t))}static parse(e){if(!Gm.canBeParsed(e))throw new Error(`[${e}] cannot be parsed into date format specification`)
const t=e.toLowerCase().split("").filter((e,t,a)=>"dmy".includes(e)&&a.indexOf(e)===t).join(""),a=["/","-","."].find(t=>e.includes(t))
return new Gm(t,a)}}const Km=Tt({inputFormat:{type:String,validator:e=>!e||Gm.canBeParsed(e)}},"date-format")
function qm(e,l,n){const o=Ec()
const r=t.toRef(()=>Gm.canBeParsed(e.inputFormat)?Gm.parse(e.inputFormat):function(){const e=l.value??"en-US",t=new Intl.DateTimeFormat(e,{year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(o.toJsDate(o.parseISO("1999-12-07"))),n=t.filter(e=>["year","month","day"].includes(e.type)).map(e=>e.type[0]).join(""),r=t.find(e=>"literal"===e.type)?.value??"",i=["/","-","."].find(e=>r.includes(e))??"/"
if(3!==n.length)return a(`Date format inferred from locale [${e}] is invalid: [${n}]`),new Gm("mdy","/")
const s=r.includes("‏")?[...n].reverse().join(""):n
return new Gm(s,i)}())
function i(e){const t=o.getYear(o.date())
if(e>100||t%100>=50)return e
const a=100*~~(t/100)
return e<50?a+e:a-100+e}const s=t.toRef(()=>{const{order:e}=r.value
return n.value?[...e].reverse().join(""):e}),u=t.toRef(()=>{const t="range"===e.multiple,a=t?2:e.multiple?1/0:1
return{join:t?" - ":", ",limit:a,bounded:Number.isFinite(a)}}),c=t.toRef(()=>{const{format:t,separator:a}=r.value,l=e.placeholder?.slice(0,t.length)
return l?.length===t.length&&!/\d/.test(l)&&[...t].every((e,t)=>e===a==(l[t]===a))?l:t}),d=t.toRef(()=>function(e,t,a){const l={y:{type:"value",key:"y",size:4,max:9999,close:e=>String(a?.(Number(e))??e)},m:{type:"value",key:"m",size:2,min:1,max:12},d:{type:"value",key:"d",size:2,min:1,max:31,softMax:Ym}}
return[...e].flatMap((e,a)=>[...a?[{type:"separator",value:t}]:[],l[e]])}(s.value,r.value.separator,i))
function v(e,t=-1){const a=e.split(/(\D+)/),l=[...a].reverse().join("")
if(t<0)return{value:l,caret:t}
let n=0,o=0
for(;n<a.length-1&&t>o+a[n].length;)o+=a[n].length+a[n+1].length,n+=2
return{value:l,caret:e.length-o-a[n].length+Math.max(t-o,0)}}function p(e){const t=function(e){const{y:t,m:a,d:l}=e
return t&&a&&l?a<1||a>12||l<1||l>31?null:{year:i(t),month:a,day:l}:null}(function(e){const t=e.trim().split(r.value.separator)
return{y:Number(t[r.value.order.indexOf("y")]),m:Number(t[r.value.order.indexOf("m")]),d:Number(t[r.value.order.indexOf("d")])}}(e))
if(!t)return null
const{year:a,month:l,day:n}=t,s=e=>String(e).padStart(2,"0")
return o.parseISO(`${a}-${s(l)}-${s(n)}`)}function m(e,t){const{join:a,limit:l}=u.value,{text:o,caret:r}=function(e,t,a=-1){return{text:e.trimStart().replace(t,""),caret:a<0?-1:e.slice(0,a).trimStart().replace(t,"").length}}(e,/[^\d/.\- ]/g,t)
let i="",s=0,v=0,p=-1,m=!1,f=1
for(let e=0;e<l;e++){const t=s,n=Wm(d.value,o,s,r)
if(s=n.index,s===t||!n.value)break
if(n.caret>=0&&p<0&&(p=i.length+n.caret),i+=n.value,v+=n.width,m||=n.gaps,!n.complete||!n.closed&&s>=o.length)break
e+1<l&&(i+=a,v+=a.length,f++)}const g=function(e,t){const{bounded:a,join:l,limit:o}=u.value,r=Array.from({length:a?o:t},()=>c.value).join(l)
return n.value?r.slice(0,r.length-e):r.slice(e)}(v,f)
return{value:i,caret:p<0?i.length:p,width:v,gaps:m,hint:g,complete:u.value.bounded&&!g}}function f(e,t=-1,a=!1){if(!n.value)return m(e,t)
const l=v(e,t),o=t>=e.length?l.value.length:l.caret,r=m(l.value,o),i=v(r.value,r.caret),s=!a&&r.caret>=r.value.length&&u.value.bounded&&!r.hint
return{...r,value:i.value,caret:s?0:i.caret}}return{isValid:function(e){return!!p(e)},getHint:function(e){const{value:t,hint:a}=f(e),l=e=>n.value?[...e].reverse().join(""):e
return l(function(e,t,a){const l=(e,t)=>/^\d*/.exec(e.slice(t))[0].length
let n=0,o=0
for(;n<e.length&&o<a.length;)if(e[n]===a[o])n++,o++
else{if(!(l(e,n)>l(a,o)))return""
n++}let r=e.slice(n)+t
for(const e of a.slice(o)){const t=r.indexOf(e)
if(t<0)return""
r=r.slice(t+1)}return r}(l(t),l(a),l(e)))},joinDates:function(e){return(n.value?[...e].reverse():e).join(u.value.join)},maskDate:f,parseDate:p,formatDate:function(e){const t=o.toISO(e).split("T")[0].split("-")
return r.value.order.split("").map(e=>t["ymd".indexOf(e)]).join(r.value.separator)},separator:t.toRef(()=>r.value.separator),parserFormat:t.toRef(()=>r.value.format)}}const Xm=Tt({displayFormat:{type:[Function,String],default:void 0},location:{type:String,default:"bottom start"},menu:Boolean,menuProps:Object,openOnFocus:Boolean,updateOn:{type:Array,default:()=>["blur","enter"]},pickerProps:Object,...Km(),...hr({mobile:null}),...Ko(),...Vv({hideActions:!0}),..._s({prependIcon:"$calendar"}),...G(Lm({hideHeader:!0,showAdjacentMonths:!0}),["location","rounded","height","minHeight","maxHeight"])},"VDateInput"),Zm=Kt()({name:"VDateInput",props:Xm(),emits:{save:e=>!0,cancel:()=>!0,"update:focused":e=>!0,"update:modelValue":e=>!0,"update:menu":e=>!0},setup(e,{emit:a,slots:l}){const{t:n,isRtl:o}=Ha(),r=Ec(),i=t.computed(()=>r.locale),{getHint:s,isValid:u,joinDates:c,maskDate:d,parseDate:v,formatDate:p,separator:m,parserFormat:g}=qm(e,i,o),{onBeforeinput:h,onInput:y,onKeydown:b,text:w}=function(e,a,l){const n=t.shallowRef("")
let o,r
function i(e,t){t.value!==e.value&&(e.value=t.value),t.caret!==e.selectionStart&&e.setSelectionRange(t.caret,t.caret),r=t.caret,n.value=e.value}function s(a,n,o=!1){const{value:r,caret:i}=a,s=e(r),u=!!t.toValue(l)
if(i!==(u?s.complete?-1:s.caret:r.length)&&(!s.gaps||/\d/.test(r[i]))&&s.value===r&&e(r+"0").value!==r+"0"){const{value:t,caret:a,wrote:l}=function(e,t,a,l=!1,n=!1){const o=[...e],r=e=>/\d/.test(o[e]??"")
let i=t,s=-1
l&&n&&i&&!r(i)&&r(i-1)&&i--
for(const e of a){const t=o.length-2
if(/[ap]/i.test(e)&&/[ap]/i.test(o[t]??"")&&"m"===o[t+1]?.toLowerCase())o[t]=e.toUpperCase(),i=o.length
else{for(;i<o.length&&!r(i);)i++
if(/\d/.test(e))i<o.length&&(o[i]=e,s=i++)
else if(i&&r(i-1))for(;i<o.length&&r(i);)i++}}if(!l)for(;i<o.length&&!r(i);)i++
return{value:o.join(""),caret:i,wrote:s}}(r,i,n,u,o),s=e(t,a,!0)
if(l<0||s.value.length!==t.length||s.value[l]===t[l])return s
const{start:c,end:d}=function(e,t){let a=t,l=t
for(;a&&/\d/.test(e[a-1]);)a--
for(;l<e.length&&/\d/.test(e[l]);)l++
return{start:a,end:l}}(t,l)
return e(t.slice(0,c)+t[l]+t.slice(d),c+1,!0)}const c=t=>e(r.slice(0,t)+n+r.slice(t),t+n.length),d=e=>e.replace(/\D/g,"").length,v=c(i)
return s.gaps&&/^\D\D/.test(r.slice(i))&&d(v.value)<=d(r)?c(i+1):v}return{onBeforeinput:function(e){const t=e.target
o={value:t.value,start:t.selectionStart??0,end:t.selectionEnd??0}},onInput:function(e){const a=e.target,u=o?.value??"",c=u.length-a.value.length
if(e.isComposing)return void(n.value=a.value)
if(e.inputType?.startsWith("delete")&&o&&c>0){const t=o.start===o.end,l=t&&!!e.inputType.includes("Forward")
return void i(a,Um(u,t&&!l?o.start-c:o.start,c,l))}const d=o?a.value.slice(o.start,a.value.length-u.length+o.end):""
if(o&&o.start!==o.end&&e.inputType?.startsWith("insert")&&(v=u,p=o.start,m=o.end,!t.toValue(l)||!/\d/.test(v[p-1]??"")&&!/\d/.test(v[m]??""))){const e=Um(u,o.start,o.end-o.start,!1)
return void i(a,[...d].reduce((e,t)=>s(e,t),e))}var v,p,m
i(a,s({value:u,caret:o?.start??u.length},d,o?.start!==r))},onKeydown:function(n){const o="ArrowRight"===n.key?1:"ArrowLeft"===n.key?-1:0,r=n.target,s=r.selectionStart??0
if(!o||n.altKey||n.ctrlKey||n.metaKey||n.shiftKey||s!==r.selectionEnd)return
const u=!!t.toValue(l),c=u?r.value.slice(0,s):r.value.slice(s),d=u?0:s,v=(u?o<0:o>0)&&!(u?/\D/:/\d/).test(c)?e(r.value.slice(0,d)+t.toValue(a)+r.value.slice(d),u?0:s+1):e(r.value,ae(s+o,0,r.value.length))
v.value!==r.value&&(n.preventDefault(),i(r,v))},text:n}}(d,m,o),{mobile:V}=yr(e),{InputIcon:S}=Uo(e),{clampDate:k,isInAllowedRange:x}=Pm(e),N=()=>e.multiple?[]:null,C=_a(e,"modelValue",N(),e=>Array.isArray(e)?e.map(e=>r.toJsDate(e)):e?r.toJsDate(e):e,e=>Array.isArray(e)?e.map(e=>r.date(e)):e?r.date(e):e),E=_a(e,"menu"),I=t.shallowRef(!1),A=t.shallowRef(e.focused),P=t.ref(),_=t.ref(),R=t.ref(["save"])
function D(t){return f(e.displayFormat)?e.displayFormat(t):e.displayFormat?r.format(t,e.displayFormat??"keyboardDate"):p(t)}Xs(E,A,()=>e.openOnFocus&&!e.disabled)
const B=t.computed(()=>{const t=ee(C.value)
if(!t.length)return null
if(!0===e.multiple)return n("$vuetify.datePicker.itemsSelected",t.length)
if("range"===e.multiple){const e=t[0],a=t[t.length-1]
return r.isValid(e)&&r.isValid(a)?c([D(r.date(e)),D(r.date(a))]):""}return r.isValid(C.value)?D(r.date(C.value)):""}),T=t.computed(()=>e.placeholder?e.placeholder:"range"===e.multiple?c([g.value,g.value]):e.multiple?`${g.value}, ...`:g.value),F=t.computed(()=>s(w.value))
t.watch(B,e=>w.value=e??"",{immediate:!0})
const $=t.computed(()=>{if(V.value)return I.value?"text":"none"}),M=t.computed(()=>!e.disabled&&!e.readonly),z=t.computed(()=>!e.updateOn.length||!(V.value&&I.value)&&e.readonly)
function L(t){b(t),"Enter"===t.key&&(E.value&&A.value||(E.value=!0),e.updateOn.includes("enter")&&!e.readonly&&K(t.target))}function O(t){e.disabled||(t.preventDefault(),t.stopPropagation(),E.value&&V.value?I.value=!e.readonly:E.value=!0)}function j(){a("cancel"),E.value=!1,I.value=!1}function H(e){a("save",e),E.value=!1}function W(e){null==e&&(C.value=N())}function Y(t){t.relatedTarget?.closest("[data-v-date]")||(e.updateOn.includes("blur")&&!e.readonly&&K(t.target),w.value=B.value??"",V.value&&I.value&&!A.value&&(E.value=!1,I.value=!1),qs(E,P.value?.$el,_.value?.contentEl))}function K({value:t}){if(t.trim())if(e.multiple){const a=t.trim().split(/\D+-\D+|[^\d\-/.]+/).filter(Boolean)
if(a.every(u))if("range"===e.multiple){const[e,t]=a.map(v).map(k).toSorted((e,t)=>r.isAfter(e,t)?1:-1)
C.value=null==t?[e]:[e,r.endOfDay(t)]}else C.value=a.map(v).filter(x)}else u(t)&&(C.value=k(v(t)))
else C.value=N()}return t.watch(E,e=>{e||(I.value=!1,R.value=["save"])}),sa(()=>{const n=!(!e.prependIcon&&!l.prepend),r=Sv.filterProps(e),i={...Om.filterProps(G(e,["active","bgColor","color","location","rounded","maxWidth","minWidth","width"])),...e.pickerProps},s=U(l,["title","header","day","month","year"]),u=Rs.filterProps(G(e,["placeholder"]))
return t.createVNode(Rs,t.mergeProps({ref:P},u,{class:["v-date-input",e.class],style:e.style,modelValue:w.value,inputmode:$.value,placeholder:T.value,readonly:z.value,onKeydown:M.value?L:void 0,onBeforeinput:M.value?h:void 0,onInput:M.value?y:void 0,focused:E.value||A.value,onBlur:Y,validationValue:C.value,"onClick:control":O,"onUpdate:modelValue":W,"onUpdate:focused":e=>A.value=e}),{...l,default:()=>t.createElementVNode(t.Fragment,null,[A.value&&!z.value&&!!w.value&&t.createElementVNode("div",{class:"v-date-input__format-hint","aria-hidden":"true"},[t.createElementVNode("span",{style:{order:o.value?1:0}},[w.value]),F.value]),t.createVNode(hs,t.mergeProps({ref:_,modelValue:E.value,"onUpdate:modelValue":e=>E.value=e,activator:"parent",minWidth:"0",eager:A.value,location:e.location,closeOnContentClick:!1,openOnClick:!1},e.menuProps),{default:()=>[t.createVNode(Sv,t.mergeProps(r,{modelValue:C.value,"onUpdate:modelValue":e=>C.value=e,disabled:R.value,onSave:H,onCancel:j}),{default:({actions:n,model:o,save:r,cancel:u,isPristine:c})=>t.createVNode(Om,t.mergeProps(i,{modelValue:e.hideActions?C.value:o.value,"onUpdate:modelValue":t=>function(t){e.hideActions?(C.value=t,e.multiple||(E.value=!1)):o.value=t,a("save",t),R.value=[]}(t),onMousedown:e=>e.preventDefault()}),{...s,actions:e.hideActions?void 0:()=>l.actions?.({save:r,cancel:u,isPristine:c})??n()})})]}),l.default?.()]),prepend:n?a=>l.prepend?l.prepend(a):e.prependIcon&&t.createVNode(S,{key:"prepend-icon",name:"prepend",tabindex:e["onClick:prepend"]?void 0:-1,onClick:M.value?O:void 0},null):void 0})}),ir({},P)}}),Qm=Tt({actionText:String,bgColor:String,color:String,icon:ua,image:String,justify:{type:String,default:"center"},headline:String,title:String,text:String,textWidth:{type:[Number,String],default:500},href:String,to:String,...Ft(),...Tl(),...Vn({size:void 0}),...Ga()},"VEmptyState"),Jm=Kt()({name:"VEmptyState",props:Qm(),emits:{"click:action":e=>!0},setup(e,{emit:a,slots:l}){const{themeClasses:n}=tl(e),{backgroundColorClasses:o,backgroundColorStyles:r}=Ol(()=>e.bgColor),{dimensionStyles:i}=Fl(e),{displayClasses:s}=yr()
function u(e){a("click:action",e)}return sa(()=>{const a=!(!l.actions&&!e.actionText),c=!(!l.headline&&!e.headline),d=!(!l.title&&!e.title),v=!(!l.text&&!e.text),p=!!(l.media||e.image||e.icon),m=e.size||(e.image?200:96)
return t.createElementVNode("div",{class:t.normalizeClass(["v-empty-state",{[`v-empty-state--${e.justify}`]:!0},n.value,o.value,s.value,e.class]),style:t.normalizeStyle([r.value,i.value,e.style])},[p&&t.createElementVNode("div",{key:"media",class:"v-empty-state__media"},[l.media?t.createVNode(Bl,{key:"media-defaults",defaults:{VImg:{src:e.image,height:m},VIcon:{size:m,icon:e.icon}}},{default:()=>[l.media()]}):t.createElementVNode(t.Fragment,null,[e.image?t.createVNode(tn,{key:"image",src:e.image,height:m},null):e.icon?t.createVNode(Mn,{key:"icon",color:e.color,size:m,icon:e.icon},null):void 0])]),c&&t.createElementVNode("div",{key:"headline",class:"v-empty-state__headline"},[l.headline?.()??e.headline]),d&&t.createElementVNode("div",{key:"title",class:"v-empty-state__title"},[l.title?.()??e.title]),v&&t.createElementVNode("div",{key:"text",class:"v-empty-state__text",style:{maxWidth:z(e.textWidth)}},[l.text?.()??e.text]),l.default&&t.createElementVNode("div",{key:"content",class:"v-empty-state__content"},[l.default()]),a&&t.createElementVNode("div",{key:"actions",class:"v-empty-state__actions"},[t.createVNode(Bl,{defaults:{VBtn:{class:"v-empty-state__action-btn",color:e.color??"surface-variant",href:e.href,text:e.actionText,to:e.to}}},{default:()=>[l.actions?.({props:{onClick:u}})??t.createVNode(Vo,{onClick:u},null)]})])])}),{}}}),ef=Symbol.for("vuetify:v-expansion-panel"),tf=Tt({...Ft(),...as()},"VExpansionPanelText"),af=Kt()({name:"VExpansionPanelText",props:tf(),setup(e,{slots:a}){const l=t.inject(ef)
if(!l)throw new Error("[Vuetify] v-expansion-panel-text needs to be placed inside v-expansion-panel")
const{hasContent:n,onAfterLeave:o}=ls(e,l.isSelected)
return sa(()=>t.createVNode(Pl,{onAfterLeave:o},{default:()=>[t.withDirectives(t.createElementVNode("div",{class:t.normalizeClass(["v-expansion-panel-text",e.class]),style:t.normalizeStyle(e.style)},[a.default&&n.value&&t.createElementVNode("div",{class:"v-expansion-panel-text__wrapper"},[a.default?.()])]),[[t.vShow,l.isSelected.value]])]})),{}}}),lf=Tt({color:String,expandIcon:{type:ua,default:"$expand"},collapseIcon:{type:ua,default:"$collapse"},hideActions:Boolean,focusable:Boolean,static:Boolean,ripple:{type:[Boolean,Object],default:!1},readonly:Boolean,hover:{type:Boolean,default:!0},...Ft(),...Tl()},"VExpansionPanelTitle"),nf=Kt()({name:"VExpansionPanelTitle",directives:{vRipple:bo},props:lf(),setup(e,{slots:a}){const l=t.inject(ef)
if(!l)throw new Error("[Vuetify] v-expansion-panel-title needs to be placed inside v-expansion-panel")
const{backgroundColorClasses:n,backgroundColorStyles:o}=Ol(()=>e.color),{dimensionStyles:r}=Fl(e),i=t.computed(()=>({collapseIcon:e.collapseIcon,disabled:l.disabled.value,expanded:l.isSelected.value,expandIcon:e.expandIcon,readonly:e.readonly})),s=t.toRef(()=>l.isSelected.value?e.collapseIcon:e.expandIcon)
return sa(()=>t.withDirectives(t.createElementVNode("button",{class:t.normalizeClass(["v-expansion-panel-title",{"v-expansion-panel-title--active":l.isSelected.value,"v-expansion-panel-title--focusable":e.focusable,"v-expansion-panel-title--static":e.static,"v-expansion-panel-title--hover":e.hover},n.value,e.class]),style:t.normalizeStyle([o.value,r.value,e.style]),type:"button",tabindex:l.disabled.value?-1:void 0,disabled:l.disabled.value,"aria-expanded":l.isSelected.value,onClick:e.readonly?void 0:l.toggle},[t.createElementVNode("span",{class:"v-expansion-panel-title__overlay"},null),a.default?.(i.value),!e.hideActions&&t.createVNode(Bl,{defaults:{VIcon:{icon:s.value}}},{default:()=>[t.createElementVNode("span",{class:"v-expansion-panel-title__icon"},[a.actions?.(i.value)??t.createVNode(Mn,null,null)])]})]),[[bo,e.ripple]])),{}}}),of=Tt({title:String,text:String,bgColor:String,...nn(),...Pn(),...Gl(),...ol(),...lf(),...tf()},"VExpansionPanel"),rf=Kt()({name:"VExpansionPanel",props:of(),emits:{"group:selected":e=>!0},setup(e,{slots:a}){const l=_n(e,ef),{backgroundColorClasses:n,backgroundColorStyles:o}=Ol(()=>e.bgColor),{elevationClasses:r}=on(e),{roundedClasses:i,roundedStyles:s}=Kl(e),u=t.toRef(()=>l?.disabled.value||e.disabled),c=t.computed(()=>l.group.items.value.reduce((e,t,a)=>(l.group.selected.value.includes(t.id)&&e.push(a),e),[])),d=t.computed(()=>{const e=l.group.items.value.findIndex(e=>e.id===l.id)
return!l.isSelected.value&&c.value.some(t=>t-e===1)}),v=t.computed(()=>{const e=l.group.items.value.findIndex(e=>e.id===l.id)
return!l.isSelected.value&&c.value.some(t=>t-e===-1)})
return t.provide(ef,l),sa(()=>{const c=!(!a.text&&!e.text),p=!(!a.title&&!e.title),m=nf.filterProps(e),f=af.filterProps(e)
return t.createVNode(e.tag,{class:t.normalizeClass(["v-expansion-panel",{"v-expansion-panel--active":l.isSelected.value,"v-expansion-panel--before-active":d.value,"v-expansion-panel--after-active":v.value,"v-expansion-panel--disabled":u.value},i.value,n.value,e.class]),style:t.normalizeStyle([o.value,s.value,e.style])},{default:()=>[t.createElementVNode("div",{class:t.normalizeClass(["v-expansion-panel__shadow",...r.value])},null),t.createVNode(Bl,{defaults:{VExpansionPanelTitle:{...m},VExpansionPanelText:{...f}}},{default:()=>[p&&t.createVNode(nf,{key:"title"},{default:()=>[a.title?a.title():e.title]}),c&&t.createVNode(af,{key:"text"},{default:()=>[a.text?a.text():e.text]}),a.default?.()]})]})}),{groupItem:l}}}),sf=["default","accordion","inset","popout"],uf=Tt({flat:Boolean,gap:[String,Number],noDivider:Boolean,rounded:[Boolean,Number,String,Array],...An(),...U(of(),["bgColor","collapseIcon","color","eager","elevation","expandIcon","focusable","hideActions","hover","readonly","ripple","static","tile"]),...Ga(),...Ft(),...ol(),variant:{type:String,default:"default",validator:e=>sf.includes(e)}},"VExpansionPanels"),cf=Kt()({name:"VExpansionPanels",props:uf(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{next:l,prev:n}=Rn(e,ef),{themeClasses:o}=tl(e),r=t.toRef(()=>Array.isArray(e.rounded)?e.rounded[0]:e.rounded),i=t.toRef(()=>Array.isArray(e.rounded)?e.rounded[1]:void 0),{roundedClasses:s,roundedStyles:u}=Kl(r),c=t.toRef(()=>e.variant&&`v-expansion-panels--variant-${e.variant}`)
return Ht({VExpansionPanel:{bgColor:t.toRef(()=>e.bgColor),collapseIcon:t.toRef(()=>e.collapseIcon),color:t.toRef(()=>e.color),eager:t.toRef(()=>e.eager),elevation:t.toRef(()=>e.elevation),expandIcon:t.toRef(()=>e.expandIcon),focusable:t.toRef(()=>e.focusable),hideActions:t.toRef(()=>e.hideActions),hover:t.toRef(()=>e.hover),readonly:t.toRef(()=>e.readonly),ripple:t.toRef(()=>e.ripple),static:t.toRef(()=>e.static)}}),sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-expansion-panels",{"v-expansion-panels--flat":e.flat,"v-expansion-panels--tile":e.tile,"v-expansion-panels--no-divider":e.noDivider||!!e.gap},o.value,s.value,c.value,e.class]),style:t.normalizeStyle([u.value,{"--v-expansion-panels-inner-radius":z(i.value),gap:e.gap?z(e.gap):void 0},e.style])},{default:()=>[a.default?.({prev:n,next:l})]})),{next:l,prev:n}}}),df=Tt({app:Boolean,appear:Boolean,extended:Boolean,layout:Boolean,offset:Boolean,modelValue:{type:Boolean,default:!0},...G(wo({active:!0}),["location","spaced"]),...Ca(),...sn(),...ql({transition:"fab-transition"})},"VFab"),vf=Kt()({name:"VFab",props:df(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),n=t.shallowRef(56),o=t.ref(),{resizeRef:r}=Sa(e=>{e.length&&(n.value=e[0].target.clientHeight)}),i=t.toRef(()=>e.app||e.absolute),s=t.computed(()=>!!i.value&&(e.location?.split(" ").shift()??"bottom")),u=t.computed(()=>!!i.value&&(e.location?.split(" ")[1]??"end"))
Pa(()=>e.app,()=>{const a=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:s,layoutSize:t.computed(()=>e.layout?n.value+24:0),elementSize:t.computed(()=>n.value+24),active:t.computed(()=>e.app&&l.value),absolute:t.toRef(()=>e.absolute)})
t.watchEffect(()=>{o.value=a.layoutItemStyles.value})})
const c=t.ref()
return sa(()=>{const l=Vo.filterProps(e)
return t.createElementVNode("div",{ref:c,class:t.normalizeClass(["v-fab",{"v-fab--absolute":e.absolute,"v-fab--app":!!e.app,"v-fab--extended":e.extended,"v-fab--offset":e.offset,[`v-fab--${s.value}`]:i.value,[`v-fab--${u.value}`]:i.value},e.class]),style:t.normalizeStyle([e.app?{...o.value}:{height:e.absolute?"100%":"inherit"},e.style])},[t.createElementVNode("div",{class:"v-fab__container"},[t.createVNode(Xl,{appear:e.appear,transition:e.transition},{default:()=>[t.withDirectives(t.createVNode(Vo,t.mergeProps({ref:r},l,{active:void 0,location:void 0}),a),[[t.vShow,e.active]])]})])])}),{}}})
function pf(){function e(e){return e.dataTransfer??e.clipboardData??null}return{handleDrop:async function(t){const a=e(t),l=[],n=[...a?.items??[]].filter(e=>"file"===e.kind).map(e=>e.webkitGetAsEntry()).filter(Boolean)
if(n.length)for(const e of n){const t=await mf(e,ff(".",e))
l.push(...t.map(e=>e.file))}else l.push(...a?.files??[])
return l},hasFilesOrFolders:function(t){const a=e(t)
return[...a?.items??[]].filter(e=>"file"===e.kind).map(e=>e.webkitGetAsEntry()).filter(Boolean).length>0||[...a?.files??[]].length>0},isDraggingFiles:function(e){return e.dataTransfer?.types.includes("Files")??!1}}}function mf(e,t=""){return new Promise((a,l)=>{if(e.isFile){e.file(e=>a([{file:e,path:t}]),l)}else if(e.isDirectory){e.createReader().readEntries(async e=>{const l=[]
for(const a of e)l.push(...await mf(a,ff(t,a)))
a(l)})}})}function ff(e,t){return t.isDirectory?`${e}/${t.name}`:e}const gf=Tt({filterByType:String},"file-accept")
function hf(e){const a=t.computed(()=>e.filterByType?function(e){const t=e.split(",").map(e=>e.trim().toLowerCase()),a=t.filter(e=>e.startsWith(".")),l=t.filter(e=>e.endsWith("/*")),n=t.filter(e=>!a.includes(e)&&!l.includes(e))
return e=>{const t=e.name.split(".").at(-1)?.toLowerCase()??"",o=e.type.split("/").at(0)?.toLowerCase()??""
return n.includes(e.type)||a.includes(`.${t}`)||l.includes(`${o}/*`)}}(e.filterByType):null)
return{filterAccepted:function(e){if(a.value){const t=e.filter(a.value)
return{accepted:t,rejected:e.filter(e=>!t.includes(e))}}return{accepted:e,rejected:[]}}}}const yf=Tt({chips:Boolean,counter:{type:Boolean,default:void 0},counterSizeString:{type:String,default:"$vuetify.fileInput.counterSize"},counterString:{type:String,default:"$vuetify.fileInput.counter"},hideInput:Boolean,multiple:Boolean,placeholder:String,persistentPlaceholder:Boolean,showSize:{type:[Boolean,Number,String],default:!1,validator:e=>y(e)||[1e3,1024].includes(Number(e))},truncateLength:{type:[Number,String],default:22},...G(lr({prependIcon:"$file"}),["direction"]),modelValue:{type:[Array,Object],default:e=>e.multiple?[]:null,validator:e=>ee(e).every(b)},...gf(),...Ns({clearable:!0})},"VFileInput"),bf=Kt()({name:"VFileInput",inheritAttrs:!1,props:yf(),emits:{"click:control":e=>!0,"mousedown:control":e=>!0,"update:focused":e=>!0,"update:modelValue":e=>!0,rejected:e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{t:o}=Ha(),{filterAccepted:r}=hf(e),i=_a(e,"modelValue",e.modelValue,e=>ee(e),t=>!e.multiple&&Array.isArray(t)?t[0]:t),{isFocused:s,focus:u,blur:c}=qo(e),d=Ut("VChip"),v=t.computed(()=>y(e.showSize)?void 0:e.showSize),p=t.computed(()=>(i.value??[]).reduce((e,{size:t=0})=>e+t,0)),m=t.computed(()=>re(p.value,v.value)),f=t.computed(()=>(i.value??[]).map(t=>{const{name:a="",size:l=0}=t,n=function(t){if(t.length<Number(e.truncateLength))return t
const a=Math.floor((Number(e.truncateLength)-1)/2)
return`${t.slice(0,a)}…${t.slice(t.length-a)}`}(a)
return e.showSize?`${n} (${re(l,v.value)})`:n})),g=t.computed(()=>{const t=i.value?.length??0
return e.showSize?o(e.counterSizeString,t,m.value):o(e.counterString,t)}),h=t.ref(),b=t.ref(),w=t.ref(),V=t.toRef(()=>e.persistentPlaceholder||s.value||e.active),S=t.computed(()=>["plain","underlined"].includes(e.variant)),k=t.shallowRef(!1),{handleDrop:x,hasFilesOrFolders:N,isDraggingFiles:C}=pf()
function E(){w.value!==be()&&w.value?.focus(),s.value||u()}function I(e){w.value?.click()}function A(e){l("mousedown:control",e)}function P(e){w.value?.click(),l("click:control",e)}function _(a){a.stopPropagation(),E(),t.nextTick(()=>{i.value=[],he(e["onClick:clear"],a)})}function R(t){e.disabled||e.readonly||(t.preventDefault(),t.stopImmediatePropagation(),C(t)&&(k.value=!0))}function D(e){e.preventDefault()
e.currentTarget.contains(e.relatedTarget)||(k.value=!1)}async function B(t){if(t.preventDefault(),t.stopImmediatePropagation(),k.value=!1,!w.value||e.disabled||e.readonly||!N(t))return
$(await x(t))}async function T(t){if(!w.value||e.disabled||e.readonly||!N(t))return
t.preventDefault()
const a=await x(t)
a.length&&$(a)}function F(t){if(t.target&&!t.repack)if(e.filterByType)$([...t.target.files])
else{const e=t.target
i.value=[...e.files??[]]}}function $(e){const t=new DataTransfer,{accepted:a,rejected:n}=r(e)
n.length&&l("rejected",n)
for(const e of a)t.items.add(e)
w.value.files=t.files,i.value=[...t.files]
const o=new Event("change",{bubbles:!0})
o.repack=!0,w.value.dispatchEvent(o)}return t.watch(i,e=>{(!Array.isArray(e)||!e.length)&&w.value&&(w.value.value="")}),sa(()=>{const l=!(!n.counter&&void 0===e.counter),o=!1!==e.counter&&null!==e.counter&&!!i.value?.length,r=!0!==e.hideDetails&&!(!n.details&&!l),u=!!(n.details||l&&o),[v,y]=J(a),{modelValue:x,...N}=nr.filterProps(e),C={...Cs.filterProps(e),"onClick:clear":_},$=void 0!==a.webkitdirectory&&!1!==a.webkitdirectory,M=a.accept?String(a.accept):void 0,z=$?void 0:e.filterByType??M,L=!!e.placeholder&&!i.value?.length&&(s.value||e.persistentPlaceholder||!e.label)
return t.createVNode(nr,t.mergeProps({ref:h,modelValue:e.multiple?i.value:i.value[0],class:["v-file-input",{"v-file-input--chips":!!e.chips,"v-file-input--dragging":k.value,"v-file-input--hide":e.hideInput,"v-input--plain-underlined":S.value},e.class],style:e.style,"onClick:prepend":I},v,N,{centerAffix:!S.value,focused:s.value,detailsActive:u,indentDetails:e.indentDetails??!S.value}),{...n,default:({id:a,isDisabled:l,isDirty:o,isReadonly:r,isValid:u,hasDetails:v})=>t.createVNode(Cs,t.mergeProps({ref:b,prependIcon:e.prependIcon,onMousedown:A,onClick:P,"onClick:prependInner":e["onClick:prependInner"],"onClick:appendInner":e["onClick:appendInner"]},C,{id:a.value,active:V.value||o.value,dirty:o.value||e.dirty,disabled:l.value,focused:s.value,details:v.value,error:!1===u.value,onDragleave:D,onDragover:R,onDrop:B}),{...n,default:({props:{class:a,...o},controlRef:s})=>t.createElementVNode(t.Fragment,null,[t.createElementVNode("input",t.mergeProps({ref:e=>w.value=s.value=e,type:"file",accept:z,readonly:r.value,disabled:l.value,multiple:e.multiple,name:e.name,onClick:e=>{e.stopPropagation(),r.value&&e.preventDefault(),E()},onChange:F,onFocus:E,onBlur:c,onPaste:T},o,y),null),L?t.createElementVNode("input",{class:t.normalizeClass(a),inert:!0,placeholder:e.placeholder,readonly:!0,form:"",type:"text"},null):t.createElementVNode("div",{class:t.normalizeClass(a)},[!!i.value?.length&&!e.hideInput&&(n.selection?n.selection({fileNames:f.value,totalBytes:p.value,totalBytesReadable:m.value}):e.chips?f.value.map(e=>t.createVNode(Fr,{key:e,size:d.value?.size??"small",text:e},null)):f.value.join(", "))])])}),details:r?a=>t.createElementVNode(t.Fragment,null,[n.details?.(a),l&&t.createElementVNode(t.Fragment,null,[t.createElementVNode("span",null,null),t.createVNode(Vs,{active:o,value:g.value,disabled:e.disabled},n.counter)])]):void 0})}),ir({},h,b,w)}}),wf=Tt({clearable:Boolean,file:{type:Object,default:null},fileIcon:{type:String,default:"mdi-file-document"},showSize:Boolean,...si({border:!0,rounded:!0,lines:"two"})},"VFileUploadItem"),Vf=Kt()({name:"VFileUploadItem",props:wf(),emits:{"click:remove":()=>!0,click:e=>!0},setup(e,{emit:a,slots:l}){const n=Ut("VBtn"),o=t.ref(),r=t.computed(()=>y(e.showSize)?void 0:e.showSize)
function i(){a("click:remove")}t.watchEffect(()=>{o.value=e.file?.type.startsWith("image")?URL.createObjectURL(e.file):void 0}),sa(()=>{const a=ui.filterProps(e)
return t.createVNode(ui,t.mergeProps(a,{class:["v-file-upload-item",e.class],title:e.title??e.file?.name,subtitle:e.showSize?re(e.file?.size,r.value):e.file?.type,style:e.style}),{...l,title:l.title??(()=>e?.title??e.file?.name),prepend:a=>t.createElementVNode(t.Fragment,null,[l.prepend?t.createVNode(Bl,{defaults:{VAvatar:{image:o.value,icon:o.value?void 0:e.fileIcon,rounded:!0}}},{default:()=>[l.prepend?.(a)??t.createVNode(Bo,null,null)]}):t.createVNode(Bo,{icon:e.fileIcon,image:o.value,rounded:!0},null)]),append:a=>t.createElementVNode(t.Fragment,null,[e.clearable&&t.createElementVNode(t.Fragment,null,[l.clear?t.createVNode(Bl,{defaults:{VBtn:{icon:"$clear",density:"comfortable",variant:n.value?.variant??"text"}}},{default:()=>[l.clear?.({...a,props:{onClick:i}})??t.createVNode(Vo,null,null)]}):t.createVNode(Vo,{icon:"$clear",density:"comfortable",variant:n.value?.variant??"text",onClick:i},null)]),l.append?.(a)])})})}})
let Sf=0
const kf=new WeakMap
function xf(e){let t=kf.get(e)
return null==t&&(t=++Sf,kf.set(e,t)),t}const Nf=Symbol.for("vuetify:file-upload"),Cf=Tt({browseText:{type:String,default:"$vuetify.fileUpload.browse"},dividerText:{type:String,default:"$vuetify.fileUpload.divider"},title:{type:String,default:"$vuetify.fileUpload.title"},subtitle:String,icon:{type:ua,default:"$upload"},clearable:Boolean,disabled:Boolean,readonly:Boolean,error:Boolean,hideBrowse:Boolean,insetFileList:Boolean,multiple:Boolean,scrim:{type:[Boolean,String],default:!0},showSize:Boolean,...Ui(),...yn(),...U(Mr({length:150}),["length","thickness","opacity"]),...ys(),modelValue:{type:Array,default:()=>[]}},"VFileUploadDropzone"),Ef=Kt()({name:"VFileUploadDropzone",props:Cf(),emits:{"click:browse":()=>!0,"click:remove":e=>!0,drop:e=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),o=Ut("VBtn"),r=t.toRef(()=>o.value?.variant??"text"),i=t.toRef(()=>o.value?.size??"large"),s=t.toRef(()=>o.value?.variant??"tonal"),{densityClasses:u}=bn(e),{handleDrop:c,hasFilesOrFolders:d,isDraggingFiles:v}=pf(),p=t.inject(Nf,null),m=t.ref(),f=t.shallowRef(!1),g=t.toRef(()=>p?.disabled.value??e.disabled),h=t.toRef(()=>p?.readonly.value??e.readonly),y=t.toRef(()=>!g.value&&!h.value)
function b(e){y.value&&(e.preventDefault(),e.stopImmediatePropagation(),v(e)&&(f.value=!0))}function w(e){e.preventDefault()
e.currentTarget.contains(e.relatedTarget)||(f.value=!1)}async function V(e){if(e.preventDefault(),e.stopImmediatePropagation(),f.value=!1,!y.value||!d(e))return
const t=await c(e)
p?p.onDrop(t):a("drop",t)}function S(){y.value&&(p?p.onClickBrowse():a("click:browse"))}function k(e){y.value&&("Enter"!==e.key&&" "!==e.key||(e.preventDefault(),S()))}function x(e){y.value&&(p?p.onClickRemove(e):a("click:remove",e))}async function N(e){if(!y.value||!d(e))return
e.preventDefault()
const t=await c(e)
t.length&&(p?p.onDrop(t):a("drop",t))}return sa(()=>{const a=p?.files.value??e.modelValue,o=g.value,c=h.value,d=y.value,v=p?.error.value||e.error,C=!(!l.title&&!e.title),E=!(!l.icon&&!e.icon),I=!(e.hideBrowse||!l.browse&&"default"!==e.density),A=a.length>0,P=e.insetFileList&&A,_=bs.filterProps(e),R=zr.filterProps(e)
return t.createVNode(bs,t.mergeProps({ref:m,tabindex:o?-1:0},_,{class:["v-file-upload-dropzone",{"v-file-upload-dropzone--clickable":!I,"v-file-upload-dropzone--disabled":o,"v-file-upload-dropzone--readonly":c,"v-file-upload-dropzone--dragging":f.value,"v-file-upload-dropzone--has-files":A,"v-file-upload-dropzone--inset":P,"v-file-upload-dropzone--error":v},u.value,e.class],style:e.style,onDragleave:w,onDragover:b,onDrop:V,onPaste:N,onClick:I||P&&A?void 0:S,onKeydown:k}),{default:()=>[l.default?.({isDragging:f.value,hasFiles:A,files:a,props:{onClick:S}})??(P?t.createElementVNode("div",{key:"inset",class:"v-file-upload-inset"},[1!==a.length||e.multiple?a.map((a,n)=>{const r=xf(a),i={file:a,props:{"onClick:remove":()=>x(n)}}
return t.createVNode(Bl,{key:r,defaults:{VFileUploadItem:{file:a,clearable:e.clearable&&!c,disabled:o,showSize:e.showSize,border:!1}}},{default:()=>[l.item?.(i)??t.createVNode(Vf,{key:r,"onClick:remove":()=>x(n)},null)]})}):l.single?.({file:a[0],props:{"onClick:remove":()=>x(0)}})??t.createVNode(Bl,{defaults:{VFileUploadItem:{file:a[0],clearable:e.clearable&&!c,disabled:o,showSize:e.showSize,border:!1}}},{default:()=>[t.createVNode(Vf,{"onClick:remove":()=>x(0)},null)]}),t.createVNode(zr,null,null),t.createElementVNode("div",{class:"v-file-upload-inset__action"},[l.browse?t.createVNode(Bl,{defaults:{VBtn:{readonly:!d,text:n(e.browseText),variant:r.value}}},{default:()=>[l.browse({props:{onClick:S}})]}):t.createVNode(Vo,{readonly:!d,text:n(e.browseText),variant:r.value,onClick:S},null)])]):t.createElementVNode(t.Fragment,null,[E&&t.createElementVNode("div",{key:"icon",class:"v-file-upload-icon"},[l.icon?t.createVNode(Bl,{key:"icon-defaults",defaults:{VIcon:{icon:e.icon}}},{default:()=>[l.icon()]}):t.createVNode(Mn,{key:"icon-icon",icon:e.icon},null)]),C&&t.createElementVNode("div",{key:"title",class:"v-file-upload-title"},[l.title?.()??n(e.title)]),"default"===e.density&&t.createElementVNode(t.Fragment,null,[I&&t.createElementVNode(t.Fragment,null,[t.createElementVNode("div",{key:"upload-divider",class:"v-file-upload-divider"},[l.divider?.()??t.createVNode(zr,R,{default:()=>[n(e.dividerText)]})]),l.browse?t.createVNode(Bl,{defaults:{VBtn:{readonly:!d,size:i.value,text:n(e.browseText),variant:s.value}}},{default:()=>[l.browse({props:{onClick:S}})]}):t.createVNode(Vo,{readonly:!d,size:i.value,text:n(e.browseText),variant:s.value,onClick:S},null)]),e.subtitle&&t.createElementVNode("div",{class:"v-file-upload-subtitle"},[e.subtitle])])])),t.createVNode(fs,{modelValue:f.value,contained:!0,scrim:e.scrim},null),l.input?.(),l.loader?.()]})}),ir({},m)}}),If=Tt({clearable:Boolean,showSize:Boolean,files:Array,...ki({border:!1,elevation:0,lines:!1})},"VFileUploadList"),Af=Kt()({name:"VFileUploadList",props:If(),setup(e,{slots:a}){const l=t.inject(Nf,null)
sa(()=>{const n=e.files??l?.files.value??[],o=l?.disabled.value??e.disabled,r=l?.readonly.value??!1,i=xi.filterProps(e)
return a.default||n.length?t.createVNode(xi,t.mergeProps(i,{disabled:o,class:["v-file-upload-list",e.class],style:e.style,bgColor:"transparent"}),{default:()=>[a.default?.({files:n,onClickRemove:e=>l?.onClickRemove(e)})??n.map((n,i)=>{const s=xf(n),u={file:n,props:{"onClick:remove":()=>l?.onClickRemove(i)}}
return t.createVNode(Bl,{key:s,defaults:{VFileUploadItem:{file:n,clearable:e.clearable&&!r,disabled:o,showSize:e.showSize,variant:"flat"}}},{default:()=>[a.item?.(u)??t.createVNode(Vf,{key:s,"onClick:remove":()=>l?.onClickRemove(i)},null)]})})]}):t.createCommentVNode()})}}),Pf=Tt({browseText:{type:String,default:"$vuetify.fileUpload.browse"},dividerText:{type:String,default:"$vuetify.fileUpload.divider"},title:{type:String,default:"$vuetify.fileUpload.title"},subtitle:String,icon:{type:ua,default:"$upload"},clearable:Boolean,insetFileList:Boolean,hideBrowse:Boolean,multiple:Boolean,scrim:{type:[Boolean,String],default:!0},showSize:Boolean,...gf(),...Gn(),...G(lr(),["direction"]),modelValue:{type:[Array,Object],default:null,validator:e=>ee(e).every(b)}},"VFileUpload"),_f=Kt()({name:"VFileUpload",inheritAttrs:!1,props:Pf(),emits:{"update:modelValue":e=>!0,"update:focused":e=>!0,rejected:e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{filterAccepted:o}=hf(e),{isFocused:r}=qo(e),{loaderClasses:i}=Kn(e),s=Qo(e),u=_a(e,"modelValue",e.modelValue,e=>ee(e),t=>e.multiple||Array.isArray(e.modelValue)?t:t[0]),c=t.ref(),d=t.ref(),v=t.ref(null),p=t.toRef(()=>!1===c.value?.isValid),m=t.toRef(()=>!s.isDisabled.value&&!s.isReadonly.value),f=t.shallowRef(void 0)
function h(t){if(!t.target||t.repack)return
const a=[...t.target.files??[]]
a.length&&(e.filterByType?b(a):u.value=e.multiple?[...u.value,...a]:a)}function b(t){const a=new DataTransfer,{accepted:n,rejected:r}=o(t)
r.length&&l("rejected",r)
for(const e of n)a.items.add(e)
v.value.files=a.files
const i=[...a.files]
u.value=e.multiple?[...u.value,...i]:i
const s=new Event("change",{bubbles:!0})
s.repack=!0,v.value.dispatchEvent(s)}return t.watch(()=>e.loading,(e,t)=>{f.value=!e&&g(t)?t:y(e)?void 0:e},{immediate:!0}),t.provide(Nf,{files:u,disabled:s.isDisabled,readonly:s.isReadonly,error:p,onDrop:function(e){if(!m.value)return
b(e)},onClickBrowse:function(){if(!m.value)return
v.value?.click()},onClickRemove:function(e){if(!m.value)return
const t=u.value.filter((t,a)=>a!==e)
if(u.value=t,t.length>0||!v.value)return
v.value.value=""}}),t.watch(u,e=>{(!Array.isArray(e)||!e.length)&&v.value&&(v.value.value="")}),sa(()=>{const{modelValue:l,...o}=nr.filterProps(e),{modelValue:s,...p}=Ef.filterProps(e),[m,g]=J(a),y=void 0!==a.webkitdirectory&&!1!==a.webkitdirectory,b=a.accept?String(a.accept):void 0,w=y?void 0:e.filterByType??b,V=t.createElementVNode("input",t.mergeProps({ref:v,type:"file",accept:w,disabled:e.disabled??void 0,multiple:e.multiple,name:e.name,onChange:h},g),null)
return t.createVNode(nr,t.mergeProps({ref:c,modelValue:e.multiple?u.value:u.value[0],"onUpdate:modelValue":e=>{(null==e||Array.isArray(e)&&!e.length)&&(u.value=[])},class:["v-file-upload",i.value,e.class],style:e.style,focused:r.value},m,o),{...n,default:()=>t.createElementVNode(t.Fragment,null,[n.default?t.createElementVNode(t.Fragment,null,[n.default(),t.createElementVNode("input",t.mergeProps({ref:v,type:"file",accept:w,disabled:e.disabled??void 0,multiple:e.multiple,name:e.name,style:"display: none;",onChange:h},g),null)]):t.createVNode(Ef,t.mergeProps({ref:d},p),{browse:n.browse,icon:n.icon,title:n.title,divider:n.divider,single:n.single,item:n.item,input:()=>n.input?.({inputNode:V})??V,loader:()=>t.createVNode(qn,{name:"v-file-upload",active:!!e.loading,color:f.value},{default:n.loader})}),!n.default&&!e.insetFileList&&t.createVNode(Bl,{defaults:{VFileUploadList:{clearable:e.clearable,showSize:e.showSize}}},{default:()=>[t.createVNode(Af,null,{item:n.item})]})])})}),ir({controlRef:v},c,d)}}),Rf=Tt({app:Boolean,color:String,height:{type:[Number,String],default:"auto"},...an(),...Ft(),...nn(),...Ca(),...Gl(),...ol({tag:"footer"}),...Ga()},"VFooter"),Df=Kt()({name:"VFooter",props:Rf(),setup(e,{slots:a}){const l=t.ref(),{themeClasses:n}=tl(e),{backgroundColorClasses:o,backgroundColorStyles:r}=Ol(()=>e.color),{borderClasses:i}=ln(e),{elevationClasses:s}=on(e),{roundedClasses:u,roundedStyles:c}=Kl(e),d=t.shallowRef(32),{resizeRef:v}=Sa(e=>{e.length&&(d.value=e[0].target.clientHeight)}),p=t.computed(()=>"auto"===e.height?d.value:e.height)
return Pa(()=>e.app,()=>{const a=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:t.toRef(()=>"bottom"),layoutSize:p,elementSize:t.computed(()=>"auto"===e.height?void 0:p.value),active:t.toRef(()=>e.app),absolute:t.toRef(()=>e.absolute)})
t.watchEffect(()=>{l.value=a.layoutItemStyles.value})}),sa(()=>t.createVNode(e.tag,{ref:v,class:t.normalizeClass(["v-footer",n.value,o.value,i.value,s.value,u.value,e.class]),style:t.normalizeStyle([r.value,e.app?l.value:{height:z(e.height)},c.value,e.style])},a)),{}}}),Bf=Tt({...Ft(),...Zo()},"VForm"),Tf=Kt()({name:"VForm",props:Bf(),emits:{"update:modelValue":e=>!0,submit:e=>!0},setup(e,{slots:l,emit:n}){const o=function(e){const l=_a(e,"modelValue"),n=t.toRef(()=>e.disabled),o=t.toRef(()=>e.readonly),r=t.shallowRef(!1),i=t.ref([]),s=t.ref([])
return t.watch(i,()=>{let e=0,t=0
const a=[]
for(const l of i.value)!1===l.isValid?(t++,a.push({id:l.id,errorMessages:l.errorMessages})):!0===l.isValid&&e++
s.value=a,l.value=!(t>0)&&(e===i.value.length||null)},{deep:!0,flush:"post"}),t.provide(Xo,{register:({id:e,vm:l,validate:n,reset:o,resetValidation:r})=>{i.value.some(t=>t.id===e)&&a(`Duplicate input name "${e}"`),i.value.push({id:e,validate:n,reset:o,resetValidation:r,vm:t.markRaw(l),isValid:null,errorMessages:[]})},unregister:e=>{i.value=i.value.filter(t=>t.id!==e)},update:(e,t,a)=>{const l=i.value.find(t=>t.id===e)
l&&(l.isValid=t,l.errorMessages=a)},isDisabled:n,isReadonly:o,isValidating:r,isValid:l,items:i,validateOn:t.toRef(()=>e.validateOn)}),{errors:s,isDisabled:n,isReadonly:o,isValidating:r,isValid:l,items:i,validate:async function(){const t=[]
let a=!0
s.value=[],r.value=!0
for(const l of i.value){const n=await l.validate()
if(n.length>0&&(a=!1,t.push({id:l.id,errorMessages:n})),!a&&e.fastFail)break}return s.value=t,r.value=!1,{valid:a,errors:s.value}},reset:function(){i.value.forEach(e=>e.reset())},resetValidation:function(){i.value.forEach(e=>e.resetValidation())}}}(e),r=t.ref()
function i(e){e.preventDefault(),o.reset()}function s(e){const t=e,a=o.validate()
t.then=a.then.bind(a),t.catch=a.catch.bind(a),t.finally=a.finally.bind(a),n("submit",t),t.defaultPrevented||a.then(({valid:e})=>{e&&r.value?.submit()}),t.preventDefault()}return sa(()=>t.createElementVNode("form",{ref:r,class:t.normalizeClass(["v-form",e.class]),style:t.normalizeStyle(e.style),novalidate:!0,onReset:i,onSubmit:s},[l.default?.({get errors(){return o.errors.value},get isDisabled(){return o.isDisabled.value},get isReadonly(){return o.isReadonly.value},get isValidating(){return o.isValidating.value},get isValid(){return o.isValid.value},get items(){return o.items.value},validate:o.validate,reset:o.reset,resetValidation:o.resetValidation})])),ir(o,r)}}),Ff=Tt({color:String,...an(),...Ft(),...Gl(),...ol({tag:"kbd"}),...Ga(),...nn()},"VKbd"),$f=Kt()({name:"VKbd",props:Ff(),setup(e,{slots:a}){const{themeClasses:l}=tl(e),{borderClasses:n}=ln(e),{roundedClasses:o,roundedStyles:r}=Kl(e),{backgroundColorClasses:i,backgroundColorStyles:s}=Ol(()=>e.color),{elevationClasses:u}=on(e)
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-kbd",l.value,i.value,n.value,u.value,o.value,e.class]),style:t.normalizeStyle([s.value,r.value,e.style])},a)),{}}})
function Mf(e,t,a){const l=a&&e.mac?e.mac:e.default,n="icon"===t&&!l.icon||"symbol"===t&&!l.symbol?"text":t
let o=l[n]??l.text
return"text"===n&&g(o)&&o.startsWith("$")&&!o.startsWith("$vuetify.")&&(o=o.slice(1).toUpperCase()),"icon"===n?["icon",o]:[n,o]}const zf={ctrl:{mac:{symbol:"⌃",icon:"$ctrl",text:"$vuetify.hotkey.ctrl"},default:{text:"Ctrl"}},meta:{mac:{symbol:"⌘",icon:"$command",text:"$vuetify.hotkey.command"},default:{text:"Ctrl"}},cmd:{mac:{symbol:"⌘",icon:"$command",text:"$vuetify.hotkey.command"},default:{text:"Ctrl"}},shift:{mac:{symbol:"⇧",icon:"$shift",text:"$vuetify.hotkey.shift"},default:{text:"Shift"}},alt:{mac:{symbol:"⌥",icon:"$alt",text:"$vuetify.hotkey.option"},default:{text:"Alt"}},enter:{default:{symbol:"↵",icon:"$enter",text:"$vuetify.hotkey.enter"}},arrowup:{default:{symbol:"↑",icon:"$arrowup",text:"$vuetify.hotkey.upArrow"}},arrowdown:{default:{symbol:"↓",icon:"$arrowdown",text:"$vuetify.hotkey.downArrow"}},arrowleft:{default:{symbol:"←",icon:"$arrowleft",text:"$vuetify.hotkey.leftArrow"}},arrowright:{default:{symbol:"→",icon:"$arrowright",text:"$vuetify.hotkey.rightArrow"}},backspace:{default:{symbol:"⌫",icon:"$backspace",text:"$vuetify.hotkey.backspace"}},escape:{default:{text:"$vuetify.hotkey.escape"}}," ":{mac:{symbol:"␣",icon:"$space",text:"$vuetify.hotkey.space"},default:{text:"$vuetify.hotkey.space"}},"-":{default:{text:"-"}},"+":{default:{text:"+"}}},Lf=Tt({keys:String,displayMode:{type:String,default:"icon"},keyMap:{type:Object,default:()=>zf},platform:{type:String,default:"auto"},inline:Boolean,disabled:Boolean,prefix:String,suffix:String,variant:{type:String,default:"elevated",validator:e=>["elevated","flat","tonal","outlined","text","plain","contained"].includes(e)},...Ft(),...Ga(),...an(),...Gl(),...nn(),color:String},"VHotkey"),Of=Symbol("VHotkey:AND_DELINEATOR"),jf=Symbol("VHotkey:OR_DELINEATOR"),Hf=Symbol("VHotkey:THEN_DELINEATOR")
function Wf(e,t,a,l){const n=a.toLowerCase()
if(n in e){const o=Mf(e[n],t,l)
return"text"===o[0]&&g(o[1])&&o[1].startsWith("$")&&!o[1].startsWith("$vuetify.")?["text",o[1].replace("$","").toUpperCase(),a]:[...o,a]}return["text",a.toUpperCase(),a]}const Uf=Kt()({name:"VHotkey",props:Lf(),setup(e){const{t:a}=Ha(),{themeClasses:l}=tl(e),{rtlClasses:n}=Ua(),{borderClasses:o}=ln(e),{roundedClasses:r,roundedStyles:i}=Kl(e),{elevationClasses:s}=on(e),{colorClasses:u,colorStyles:c,variantClasses:d}=Cn(()=>({color:e.color,variant:"contained"===e.variant?"elevated":e.variant})),v=t.computed(()=>"auto"===e.platform?"undefined"!=typeof navigator&&/macintosh/i.test(navigator.userAgent):"mac"===e.platform),p=t.computed(()=>e.keys?e.keys.split(/\b \b/).map(t=>{const a=[]
return function t(l){if(g(l))""!==l&&a.push(Wf(e.keyMap,e.displayMode,l,v.value))
else for(let e=0;e<l.parts.length;e++)e>0&&("sequence"===l.type?a.push(Hf):"alternate"===l.type?a.push(jf):"combo"===l.type&&a.push(Of)),t(l.parts[e])}(Lc(t)),a}):[]),m=t.computed(()=>{if(!e.keys)return""
const t=p.value.map(t=>{const l=[]
for(const n of t)if(Array.isArray(n)){const t="icon"===n[0]||"symbol"===n[0]?Wf(ie(zf,e.keyMap),"text",String(n[1]),v.value)[1]:n[1]
l.push(f(t))}else n===Of?l.push(a("$vuetify.hotkey.plus")):n===jf?l.push(a("$vuetify.hotkey.or")):n===Hf&&l.push(a("$vuetify.hotkey.then"))
return l.join(" ")}).join(", ")
return a("$vuetify.hotkey.shortcut",t)})
function f(e){return e.startsWith("$vuetify.")?a(e):e}function h(t){if("text"===e.displayMode)return
const a=function(e,t,a){const l=t.toLowerCase()
if(l in e){const t=Mf(e[l],"text",a)
return g(t[1])?t[1]:String(t[1])}return t.toUpperCase()}(e.keyMap,String(t[2]),v.value)
return f(a)}sa(()=>{const v=t.createElementVNode(t.Fragment,null,[e.prefix&&t.createElementVNode("span",{key:"prefix",class:"v-hotkey__prefix"},[e.prefix]),p.value.map((l,n)=>t.createElementVNode("span",{class:"v-hotkey__combination",key:n},[l.map((l,n)=>Array.isArray(l)?function(a,l){const n="contained"===e.variant,d=n?"kbd":$f,v=["v-hotkey__key",`v-hotkey__key-${a[0]}`,...n?["v-hotkey__key--nested"]:[o.value,r.value,s.value,u.value]]
return t.createVNode(d,{key:l,class:t.normalizeClass(v),style:t.normalizeStyle(n?void 0:[c.value,i.value]),"aria-hidden":"true",title:h(a)},{default:()=>["icon"===a[0]?t.createVNode(Mn,{icon:a[1],"aria-hidden":"true"},null):f(a[1])]})}(l,n):function(e,l){return t.createElementVNode("span",{key:l,class:"v-hotkey__divider","aria-hidden":"true"},[e===Of?"+":a(e===jf?"$vuetify.hotkey.or":"$vuetify.hotkey.then")])}(l,n)),n<p.value.length-1&&t.createElementVNode("span",{"aria-hidden":"true"},[t.createTextVNode(" ")])])),e.suffix&&t.createElementVNode("span",{key:"suffix",class:"v-hotkey__suffix"},[e.suffix])])
return t.createElementVNode("div",{class:t.normalizeClass(["v-hotkey",{"v-hotkey--disabled":e.disabled,"v-hotkey--inline":e.inline,"v-hotkey--contained":"contained"===e.variant},l.value,n.value,d.value,e.class]),style:t.normalizeStyle(e.style),role:"img","aria-label":m.value},["contained"!==e.variant?v:t.createVNode($f,{key:"contained",class:t.normalizeClass(["v-hotkey__contained-wrapper",o.value,r.value,s.value,u.value]),style:t.normalizeStyle([c.value,i.value]),"aria-hidden":"true"},{default:()=>[v]})])})}}),Yf=Tt({disabled:Boolean,modelValue:{type:Boolean,default:null},...Ui()},"VHover"),Gf=Kt()({name:"VHover",props:Yf(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),n=t.shallowRef(!1),{runOpenDelay:o,runCloseDelay:r}=Yi(e,t=>{n.value=t,e.disabled||(l.value=t)})
return t.watch(()=>e.disabled,(e,t)=>{t&&!e&&(l.value=n.value)}),()=>a.default?.({isHovering:l.value,props:{onMouseenter:o,onMouseleave:r}})}}),Kf=Tt({color:String,direction:{type:String,default:"vertical",validator:e=>["vertical","horizontal"].includes(e)},side:{type:String,default:"end",validator:e=>["start","end","both"].includes(e)},mode:{type:String,default:"intersect",validator:e=>["intersect","manual"].includes(e)},margin:[Number,String],loadMoreText:{type:String,default:"$vuetify.infiniteScroll.loadMore"},emptyText:{type:String,default:"$vuetify.infiniteScroll.empty"},...Tl(),...ol()},"VInfiniteScroll"),qf=Gt({name:"VInfiniteScrollIntersect",props:{side:{type:String,required:!0},rootMargin:String},emits:{intersect:(e,t)=>!0},setup(e,{emit:a}){const{intersectionRef:l,isIntersecting:n}=zn()
return t.watch(n,async t=>{a("intersect",e.side,t)}),sa(()=>t.createElementVNode("div",{class:"v-infinite-scroll-intersect",style:{"--v-infinite-margin-size":e.rootMargin},ref:l},[t.createTextVNode(" ")])),{}}}),Xf=Kt()({name:"VInfiniteScroll",props:Kf(),emits:{load:e=>!0},setup(e,{slots:a,emit:l}){const n=t.ref(),o=t.shallowRef("ok"),r=t.shallowRef("ok"),i=t.computed(()=>z(e.margin)),s=t.shallowRef(!1)
function u(t){if(!n.value)return
const a="vertical"===e.direction?"scrollTop":"scrollLeft"
n.value[a]=t}function c(){if(!n.value)return 0
const t="vertical"===e.direction?"scrollTop":"scrollLeft"
return n.value[t]}function d(){if(!n.value)return 0
const t="vertical"===e.direction?"scrollHeight":"scrollWidth"
return n.value[t]}function v(e,t){"start"===e?o.value=t:"end"===e?r.value=t:"both"===e&&(o.value=t,r.value=t)}t.onMounted(()=>{n.value&&("start"===e.side?u(d()):"both"===e.side&&u(d()/2-function(){if(!n.value)return 0
const t="vertical"===e.direction?"clientHeight":"clientWidth"
return n.value[t]}()/2))})
let p=0
function m(e,t){s.value=t,s.value&&f(e)}function f(a){if("manual"!==e.mode&&!s.value)return
const i=function(e){return"start"===e?o.value:r.value}(a)
n.value&&!["empty","loading"].includes(i)&&(p=d(),v(a,"loading"),l("load",{side:a,done:function(l){v(a,l),t.nextTick(()=>{"empty"!==l&&"error"!==l&&("ok"===l&&"start"===a&&u(d()-p+c()),"manual"!==e.mode&&t.nextTick(()=>{window.requestAnimationFrame(()=>{window.requestAnimationFrame(()=>{window.requestAnimationFrame(()=>{f(a)})})})}))})}}))}const{t:g}=Ha()
function h(l,n){if(e.side!==l&&"both"!==e.side)return
const o=()=>f(l),r={side:l,props:{onClick:o,color:e.color}}
return"error"===n?a.error?.(r):"empty"===n?a.empty?.(r)??t.createElementVNode("div",null,[g(e.emptyText)]):"manual"===e.mode?"loading"===n?a.loading?.(r)??t.createVNode(Hn,{indeterminate:!0,color:e.color},null):a["load-more"]?.(r)??t.createVNode(Vo,{variant:"outlined",color:e.color,onClick:o},{default:()=>[g(e.loadMoreText)]}):a.loading?.(r)??t.createVNode(Hn,{indeterminate:!0,color:e.color},null)}const{dimensionStyles:y}=Fl(e)
return sa(()=>{const l=e.tag,s="start"===e.side||"both"===e.side,u="end"===e.side||"both"===e.side,c="intersect"===e.mode
return t.createVNode(l,{ref:n,class:t.normalizeClass(["v-infinite-scroll",`v-infinite-scroll--${e.direction}`,{"v-infinite-scroll--start":s,"v-infinite-scroll--end":u}]),style:t.normalizeStyle(y.value)},{default:()=>[t.createElementVNode("div",{class:"v-infinite-scroll__side"},[h("start",o.value)]),s&&c&&t.createVNode(qf,{key:"start",side:"start",onIntersect:m,rootMargin:i.value},null),a.default?.(),u&&c&&t.createVNode(qf,{key:"end",side:"end",onIntersect:m,rootMargin:i.value},null),t.createElementVNode("div",{class:"v-infinite-scroll__side"},[h("end",r.value)])]})}),{reset:function(a){const l=a??e.side
v(l,"ok"),t.nextTick(()=>{"end"!==l&&u(d()-p+c()),"manual"!==e.mode&&t.nextTick(()=>{window.requestAnimationFrame(()=>{window.requestAnimationFrame(()=>{window.requestAnimationFrame(()=>{"both"===l?(f("start"),f("end")):f(l)})})})})})}}}}),Zf=Symbol.for("vuetify:v-item-group"),Qf=Tt({...Ft(),...An({selectedClass:"v-item--selected"}),...ol(),...Ga()},"VItemGroup"),Jf=Kt()({name:"VItemGroup",props:Qf(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{themeClasses:l}=tl(e),{isSelected:n,select:o,next:r,prev:i,selected:s}=Rn(e,Zf)
return()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-item-group",l.value,e.class]),style:t.normalizeStyle(e.style)},{default:()=>[a.default?.({isSelected:n,select:o,next:r,prev:i,selected:s.value})]})}}),eg=Kt()({name:"VItem",props:Pn(),emits:{"group:selected":e=>!0},setup(e,{slots:t}){const{isSelected:a,select:l,toggle:n,selectedClass:o,value:r,disabled:i}=_n(e,Zf)
return()=>t.default?.({isSelected:a.value,selectedClass:o.value,select:l,toggle:n,value:r.value,disabled:i.value})}}),tg=Tt({...Ft(),...Tl(),...Na()},"VLayout"),ag=Kt()({name:"VLayout",props:tg(),setup(e,{slots:a}){const{layoutClasses:l,layoutStyles:n,getLayoutItem:o,items:r,layoutRef:i}=Aa(e),{dimensionStyles:s}=Fl(e)
return sa(()=>t.createElementVNode("div",{ref:i,class:t.normalizeClass([l.value,e.class]),style:t.normalizeStyle([s.value,n.value,e.style])},[a.default?.()])),{getLayoutItem:o,items:r}}}),lg=Tt({position:{type:String,required:!0},size:{type:[Number,String],default:300},modelValue:Boolean,...Ft(),...Ca()},"VLayoutItem"),ng=Kt()({name:"VLayoutItem",props:lg(),setup(e,{slots:a}){const{layoutItemStyles:l}=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:t.toRef(()=>e.position),elementSize:t.toRef(()=>e.size),layoutSize:t.toRef(()=>e.size),active:t.toRef(()=>e.modelValue),absolute:t.toRef(()=>e.absolute)})
return()=>t.createElementVNode("div",{class:t.normalizeClass(["v-layout-item",e.class]),style:t.normalizeStyle([l.value,e.style])},[a.default?.()])}}),og=Tt({modelValue:Boolean,options:{type:Object,default:()=>({root:void 0,rootMargin:void 0,threshold:void 0})},...Ft(),...Tl(),...ol(),...ql({transition:"fade-transition"})},"VLazy"),rg=Kt()({name:"VLazy",directives:{vIntersect:Jl},props:og(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{dimensionStyles:l}=Fl(e),n=_a(e,"modelValue")
function o(e){n.value||(n.value=e)}return sa(()=>t.withDirectives(t.createVNode(e.tag,{class:t.normalizeClass(["v-lazy",e.class]),style:t.normalizeStyle([l.value,e.style])},{default:()=>[n.value&&t.createVNode(Xl,{transition:e.transition,appear:!0},{default:()=>[a.default?.()]})]}),[[Jl,{handler:o,options:e.options},null]])),{}}}),ig=Tt({locale:String,fallbackLocale:String,messages:Object,rtl:{type:Boolean,default:void 0},...Ft()},"VLocaleProvider"),sg=Kt()({name:"VLocaleProvider",props:ig(),setup(e,{slots:a}){const{rtlClasses:l}=Wa(e)
return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-locale-provider",l.value,e.class]),style:t.normalizeStyle(e.style)},[a.default?.()])),{}}}),ug=Tt({scrollable:Boolean,...Ft(),...Tl(),...ol({tag:"main"})},"VMain"),cg=Kt()({name:"VMain",props:ug(),setup(e,{slots:a}){const{dimensionStyles:l}=Fl(e),{mainStyles:n}=Ea(),{ssrBootStyles:o}=mn()
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-main",{"v-main--scrollable":e.scrollable},e.class]),style:t.normalizeStyle([n.value,o.value,l.value,e.style])},{default:()=>[e.scrollable?t.createElementVNode("div",{class:"v-main__scroller"},[a.default?.()]):a.default?.()]})),{}}})
function dg(e){return(e<0?-1:1)*Math.sqrt(Math.abs(e))*1.41421356237}function vg(e){if(e.length<2)return 0
if(2===e.length)return e[1].t===e[0].t?0:(e[1].d-e[0].d)/(e[1].t-e[0].t)
let t=0
for(let a=e.length-1;a>0;a--){if(e[a].t===e[a-1].t)continue
const l=dg(t),n=(e[a].d-e[a-1].d)/(e[a].t-e[a-1].t)
t+=(n-l)*Math.abs(n),a===e.length-1&&(t*=.5)}return 1e3*dg(t)}function pg(){const e={}
return{addMovement:function(t){Array.from(t.changedTouches).forEach(a=>{(e[a.identifier]??(e[a.identifier]=new de(20))).push([t.timeStamp,a])})},endTouch:function(t){Array.from(t.changedTouches).forEach(t=>{delete e[t.identifier]})},getVelocity:function(t){const a=e[t]?.values().reverse()
if(!a)throw new Error(`No samples for touch id ${t}`)
const l=a[0],n=[],o=[]
for(const e of a){if(l[0]-e[0]>100)break
n.push({t:e[0],d:e[1].clientX}),o.push({t:e[0],d:e[1].clientY})}return{x:vg(n),y:vg(o),get direction(){const{x:e,y:t}=this,[a,l]=[Math.abs(e),Math.abs(t)]
return a>l&&e>=0?"right":a>l&&e<=0?"left":l>a&&t>=0?"down":l>a&&t<=0?"up":function(){throw new Error}()}}}}}function mg(){throw new Error}const fg=["start","end","left","right","top","bottom"],gg=Tt({color:String,disableResizeWatcher:Boolean,disableRouteWatcher:Boolean,expandOnHover:Boolean,floating:Boolean,modelValue:{type:Boolean,default:null},permanent:Boolean,rail:{type:Boolean,default:null},railWidth:{type:[Number,String],default:56},scrim:{type:[Boolean,String],default:!0},image:String,temporary:Boolean,persistent:Boolean,touchless:Boolean,width:{type:[Number,String],default:256},location:{type:String,default:"start",validator:e=>fg.includes(e)},sticky:Boolean,...an(),...Ft(),...Ui(),...hr({mobile:null}),...nn(),...Ca(),...Gl(),...G(Xi(),["disableInitialFocus"]),...ol({tag:"nav"}),...Ga()},"VNavigationDrawer"),hg=Kt()({name:"VNavigationDrawer",props:gg(),emits:{"update:modelValue":e=>!0,"update:rail":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{isRtl:o}=Ua(),{themeClasses:r}=tl(e),{borderClasses:i}=ln(e),{backgroundColorClasses:s,backgroundColorStyles:u}=Ol(()=>e.color),{elevationClasses:c}=on(e),{displayClasses:d,mobile:v}=yr(e),{roundedClasses:p,roundedStyles:m}=Kl(e),f=Jn(),h=_a(e,"modelValue",null,e=>!!e),{ssrBootStyles:b}=mn(),{scopeId:w}=ns(),V=t.ref(),S=t.shallowRef(!1),{runOpenDelay:k,runCloseDelay:x}=Yi(e,e=>{S.value=e}),{layoutRect:N}=Ea(),C=t.computed(()=>Me(e.location,o.value)),E=t.computed(()=>"top"===C.value||"bottom"===C.value),I=t.computed(()=>(E.value?N.value?.height:N.value?.width)??0),A=t.computed(()=>e.rail&&e.expandOnHover&&S.value?e.width:e.rail?e.railWidth:e.width),P=t.computed(()=>M(A.value,I.value)),_=t.toRef(()=>e.persistent),R=t.computed(()=>!e.permanent&&(v.value||e.temporary)),D=t.computed(()=>e.sticky&&!R.value&&"bottom"!==C.value)
es(e,{isActive:h,localTop:R,contentEl:V}),Pa(()=>e.expandOnHover&&null!=e.rail,()=>{t.watch(S,e=>l("update:rail",!e))}),Pa(()=>!e.disableResizeWatcher,()=>{t.watch(R,a=>!e.permanent&&t.nextTick(()=>h.value=!a))}),Pa(()=>!e.disableRouteWatcher&&!!f,()=>{t.watch(f.currentRoute,()=>R.value&&(h.value=!1))}),t.watch(()=>e.permanent,e=>{e&&(h.value=!0)}),null!=e.modelValue||R.value||(h.value=e.permanent||!v.value)
const{isDragging:B,dragProgress:T}=function({el:e,isActive:a,isTemporary:l,width:n,touchless:o,position:r}){t.onMounted(()=>{window.addEventListener("touchstart",y,{passive:!0}),window.addEventListener("touchmove",b,{passive:!1}),window.addEventListener("touchend",w,{passive:!0})}),t.onBeforeUnmount(()=>{window.removeEventListener("touchstart",y),window.removeEventListener("touchmove",b),window.removeEventListener("touchend",w)})
const i=t.computed(()=>["left","right"].includes(r.value)),{addMovement:s,endTouch:u,getVelocity:c}=pg()
let d=!1
const v=t.shallowRef(!1),p=t.shallowRef(0),m=t.shallowRef(0)
let f
function g(e,t){return("left"===r.value?e:"right"===r.value?document.documentElement.clientWidth-e:"top"===r.value?e:"bottom"===r.value?document.documentElement.clientHeight-e:mg())-(t?n.value:0)}function h(e,t=!0){const a="left"===r.value?(e-m.value)/n.value:"right"===r.value?(document.documentElement.clientWidth-e-m.value)/n.value:"top"===r.value?(e-m.value)/n.value:"bottom"===r.value?(document.documentElement.clientHeight-e-m.value)/n.value:mg()
return t?ae(a):a}function y(e){if(o.value)return
const t=e.changedTouches[0].clientX,c=e.changedTouches[0].clientY,v="left"===r.value?t<25:"right"===r.value?t>document.documentElement.clientWidth-25:"top"===r.value?c<25:"bottom"===r.value?c>document.documentElement.clientHeight-25:mg(),y=a.value&&("left"===r.value?t<n.value:"right"===r.value?t>document.documentElement.clientWidth-n.value:"top"===r.value?c<n.value:"bottom"===r.value?c>document.documentElement.clientHeight-n.value:mg());(v||y||a.value&&l.value)&&(f=[t,c],m.value=g(i.value?t:c,a.value),p.value=h(i.value?t:c),d=m.value>-20&&m.value<80,u(e),s(e))}function b(e){const t=e.changedTouches[0].clientX,a=e.changedTouches[0].clientY
if(d){if(!e.cancelable)return void(d=!1)
const l=Math.abs(t-f[0]),n=Math.abs(a-f[1]);(i.value?l>n&&l>3:n>l&&n>3)?(v.value=!0,d=!1):(i.value?n:l)>3&&(d=!1)}if(!v.value)return
e.preventDefault(),s(e)
const l=h(i.value?t:a,!1)
p.value=Math.max(0,Math.min(1,l)),l>1?m.value=g(i.value?t:a,!0):l<0&&(m.value=g(i.value?t:a,!1))}function w(e){if(d=!1,!v.value)return
s(e),v.value=!1
const t=c(e.changedTouches[0].identifier),l=Math.abs(t.x),n=Math.abs(t.y),o=i.value?l>n&&l>400:n>l&&n>3
a.value=o?t.direction===({left:"right",right:"left",top:"down",bottom:"up"}[r.value]||mg()):p.value>.5}const V=t.computed(()=>v.value?{transform:"left"===r.value?`translateX(calc(-100% + ${p.value*n.value}px))`:"right"===r.value?`translateX(calc(100% - ${p.value*n.value}px))`:"top"===r.value?`translateY(calc(-100% + ${p.value*n.value}px))`:"bottom"===r.value?`translateY(calc(100% - ${p.value*n.value}px))`:mg(),transition:"none"}:void 0)
return Pa(v,()=>{const a=e.value?.style.transform??null,l=e.value?.style.transition??null
t.watchEffect(()=>{e.value?.style.setProperty("transform",V.value?.transform||"none"),e.value?.style.setProperty("transition",V.value?.transition||null)}),t.onScopeDispose(()=>{e.value?.style.setProperty("transform",a),e.value?.style.setProperty("transition",l)})}),{isDragging:v,dragProgress:p,dragStyles:V}}({el:V,isActive:h,isTemporary:R,width:P,touchless:t.toRef(()=>e.touchless),position:C}),F=t.computed(()=>{const t=R.value?0:e.rail&&e.expandOnHover?e.railWidth:A.value
return B.value?M(t,I.value)*T.value:t}),{layoutItemStyles:$,layoutItemScrimStyles:L}=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:C,layoutSize:F,elementSize:A,active:t.readonly(h),disableTransitions:t.toRef(()=>B.value),absolute:t.computed(()=>e.absolute||D.value&&!g(O.value))}),{isStuck:O,stickyStyles:j}=function({rootEl:e,isSticky:a,layoutItemStyles:l}){const n=t.shallowRef(!1),o=t.shallowRef(0),r=t.computed(()=>{const e=y(n.value)?"top":n.value
return[a.value?{top:"auto",bottom:"auto",height:void 0}:void 0,n.value?{[e]:z(o.value)}:{top:l.value.top}]})
t.onMounted(()=>{t.watch(a,e=>{e?window.addEventListener("scroll",s,{passive:!0}):window.removeEventListener("scroll",s)},{immediate:!0})}),t.onBeforeUnmount(()=>{window.removeEventListener("scroll",s)})
let i=0
function s(){const t=i>window.scrollY?"up":"down",a=e.value.getBoundingClientRect(),r=parseFloat(l.value.top??0),s=window.scrollY-Math.max(0,o.value-r),u=a.height+Math.max(o.value,r)-window.scrollY-window.innerHeight,c=parseFloat(getComputedStyle(e.value).getPropertyValue("--v-body-scroll-y"))||0
a.height<window.innerHeight-r?(n.value="top",o.value=r):"up"===t&&"bottom"===n.value||"down"===t&&"top"===n.value?(o.value=window.scrollY+a.top-c,n.value=!0):"down"===t&&u<=0?(o.value=0,n.value="bottom"):"up"===t&&s<=0&&(c?"top"!==n.value&&(o.value=-s+c+r,n.value="top"):(o.value=a.top+s,n.value="top")),i=window.scrollY}return{isStuck:n,stickyStyles:r}}({rootEl:V,isSticky:D,layoutItemStyles:$}),H=Ol(()=>g(e.scrim)?e.scrim:null),W=t.computed(()=>({...B.value?{opacity:.2*T.value,transition:"none"}:void 0,...L.value}))
return Ht({VList:{bgColor:"transparent"}}),sa(()=>{const l=n.image||e.image
return t.createElementVNode(t.Fragment,null,[t.createVNode(e.tag,t.mergeProps({ref:V,onMouseenter:k,onMouseleave:x,class:["v-navigation-drawer",`v-navigation-drawer--${C.value}`,{"v-navigation-drawer--expand-on-hover":e.expandOnHover,"v-navigation-drawer--floating":e.floating,"v-navigation-drawer--is-hovering":S.value,"v-navigation-drawer--rail":e.rail,"v-navigation-drawer--temporary":R.value,"v-navigation-drawer--persistent":_.value,"v-navigation-drawer--active":h.value,"v-navigation-drawer--sticky":D.value},r.value,s.value,i.value,d.value,c.value,p.value,e.class],style:[u.value,$.value,b.value,j.value,m.value,e.style],inert:!h.value},w,a),{default:()=>[l&&t.createElementVNode("div",{key:"image",class:"v-navigation-drawer__img"},[n.image?t.createVNode(Bl,{key:"image-defaults",disabled:!e.image,defaults:{VImg:{alt:"",cover:!0,height:"inherit",src:e.image}}},n.image):t.createVNode(tn,{key:"image-img",alt:"",cover:!0,height:"inherit",src:e.image},null)]),n.prepend&&t.createElementVNode("div",{class:"v-navigation-drawer__prepend"},[n.prepend?.()]),t.createElementVNode("div",{class:"v-navigation-drawer__content"},[n.default?.()]),n.append&&t.createElementVNode("div",{class:"v-navigation-drawer__append"},[n.append?.()])]}),t.createVNode(t.Transition,{name:"fade-transition"},{default:()=>[R.value&&(B.value||h.value)&&!!e.scrim&&t.createElementVNode("div",t.mergeProps({class:["v-navigation-drawer__scrim",H.backgroundColorClasses.value],style:[W.value,H.backgroundColorStyles.value],onClick:()=>{_.value||(h.value=!1)}},w),null)]})])}),{isStuck:O}}}),yg=Gt({name:"VNoSsr",setup(e,{slots:t}){const a=ts()
return()=>a.value&&t.default?.()}}),bg=[1632,1776,2406,2534,2662,2790,2918,3046,3174,3302,3430,3664,3792,3872,4160,6112,6160,65296]
function wg(e,t){const{precision:a,minFractionDigits:l}=t
return new Intl.NumberFormat(t.locale,{minimumFractionDigits:l&&null!=a?Math.min(l,a):l??a??void 0,maximumFractionDigits:a??20,useGrouping:t.useGrouping}).formatToParts(e).map(e=>"group"===e.type?t.groupSeparator:"decimal"===e.type?t.decimalSeparator:e.value.replace(/[^\x20-\x7F]/g,e=>{const t=e.codePointAt(0)
for(const e of bg)if(t>=e&&t<=e+9)return String(t-e)
return e})).join("")}function Vg(e,t){return"-"===t?e:e.replace("-",t)}function Sg(e,t,a,l,n){if(!l)return e
const o=e.indexOf(a),r=o>=0?e.slice(0,o):e,i=o>=0?e.slice(o):"",s=r.startsWith("-")?"-":"",u=s?r.slice(1):r
if(!u)return e
if(n){const a=Number(u)
if(!Number.isFinite(a))return e
return s+new Intl.NumberFormat(n,{useGrouping:l,numberingSystem:"latn"}).formatToParts(a).map(e=>"group"===e.type?t:e.value).join("")+i}return s+function(e,t,a){if("min2"===a&&e.length<=4)return e
const l=[]
for(let t=e.length;t>0;t-=3)l.unshift(e.slice(Math.max(0,t-3),t))
return l.join(t)}(u,t,l)+i}function kg(e,t,a){let l=0
for(let n=0;n<a&&n<e.length;n++)e[n]!==t&&l++
return l}const xg=Tt({controlVariant:{type:String,default:"default"},inset:Boolean,hideInput:Boolean,modelValue:{type:Number,default:null},min:{type:Number,default:Number.MIN_SAFE_INTEGER},max:{type:Number,default:Number.MAX_SAFE_INTEGER},step:{type:Number,default:1},precision:{type:Number,default:0},minFractionDigits:{type:Number,default:null},decimalSeparator:{type:String,validator:e=>!e||1===e.length},grouping:{type:[Boolean,String],default:!1},groupSeparator:{type:String,validator:e=>!e||1===e.length&&!/[0-9+-]/.test(e)},...G(_s(),["modelValue","validationValue"])},"VNumberInput"),Ng=Kt()({name:"VNumberInput",props:{...xg()},emits:{"update:focused":e=>!0,"update:modelValue":e=>!0},setup(e,{slots:l}){const n=t.ref(),o=Ut("VBtn"),{holdStart:r,holdStop:i}=function({toggleUpDown:e}){let a=-1,l=-1
function n(){E&&(window.clearTimeout(a),window.clearInterval(l),window.removeEventListener("pointerup",n),document.removeEventListener("blur",n))}function o(t){e("up"===t)}return t.onScopeDispose(n),t.onScopeDispose(n),{holdStart:function(e){n(),o(e),window.addEventListener("pointerup",n),document.addEventListener("blur",n),a=window.setTimeout(()=>{l=window.setInterval(()=>o(e),50)},500)},holdStop:n}}({toggleUpDown:$}),s=Qo(e),u=t.computed(()=>s.isDisabled.value||s.isReadonly.value),c=t.shallowRef(e.focused),{current:d,decimalSeparator:v,numericGroupSeparator:p}=Ha(),m=t.computed(()=>e.decimalSeparator?.[0]||v.value),f=t.computed(()=>{const t=e.groupSeparator?.[0]||p.value
return t!==m.value?t:(e.grouping&&a(`decimalSeparator and groupSeparator are both "${t}", groups will not be separated`),"")}),g=t.computed(()=>new Intl.NumberFormat(d.value).formatToParts(-1).find(e=>"minusSign"===e.type)?.value??"-")
function h(e){return Number(_e(e??"").replaceAll(f.value,"").replace(m.value,".").replace(/[^0-9.-]/g,""))}function y(t,a,l=!0){return a??=c.value&&l?void 0:e.precision??void 0,wg(t,{locale:d.value,precision:a,minFractionDigits:e.minFractionDigits,useGrouping:e.grouping,decimalSeparator:m.value,groupSeparator:f.value})}const b=_a(e,"modelValue",null,e=>e??null,t=>null==t?t??null:ae(Number(t),e.min,e.max)),w=t.shallowRef(null),V=t.shallowRef(null)
t.watch(b,e=>{c.value&&!u.value&&h(w.value)===e||(null==e?(w.value=null,V.value=null):isNaN(e)||(w.value=y(e),V.value=h(w.value)))},{immediate:!0})
const S=t.computed({get:()=>w.value,set(t){if(null===t||""===t)return b.value=null,w.value=null,void(V.value=null)
const a=h(t)
isNaN(a)||(w.value=t,V.value=a,a<=e.max&&a>=e.min&&(b.value=a))}}),k=t.computed(()=>{if(null===V.value)return!1
const t=h(w.value)
return t!==ae(t,e.min,e.max)})
function x(t){const a=h(S.value),l=a+(t?e.step:-e.step)
return{current:a,stepped:l,next:ae(l,e.min,e.max)}}const N=t.computed(()=>{if(u.value)return!1
if(null==b.value)return!0
const{current:e,next:t}=x(!0)
return t!==e}),C=t.computed(()=>{if(u.value)return!1
if(null==b.value)return!0
const{current:e,next:t}=x(!1)
return t!==e}),I=t.computed(()=>e.hideInput?"stacked":e.controlVariant),A=t.toRef(()=>"split"===I.value?"$plus":"$collapse"),P=t.toRef(()=>"split"===I.value?"$minus":"$expand"),_=t.toRef(()=>"split"===I.value?"default":"small"),R=t.toRef(()=>"stacked"===I.value?"auto":"100%"),D={props:{onClick:L,onPointerup:O,onPointerdown:j,onPointercancel:O}},B={props:{onClick:L,onPointerup:O,onPointerdown:H,onPointercancel:O}}
function T(e){if(null==e)return 0
const t=e.toString(),a=t.indexOf(".")+1
return a?t.length-a:0}function F(){n.value?.controlRef?.dispatchEvent(new Event("change",{bubbles:!0}))}function $(t=!0){if(u.value)return
if(t?!N.value:!C.value)return
if(null==b.value)return S.value=y(ae(0,e.min,e.max)),void F()
const{current:a,stepped:l,next:n}=x(t)
S.value=n===l?y(n,Math.max(T(a),T(e.step))):y(n),F()}function M(a){if(u.value)return
const l=a.target,n=e.grouping?function(e,t,a,l,n,o){const{groupSeparator:r,decimalSeparator:i,precision:s,grouping:u,locale:c,minusSign:d}=o
a=_e(a),t=t&&_e(t)
const v=function(e,t){return e.replaceAll(t,"")}(a,r),p=kg(a,r,l),m=kg(a,r,n),f=p!==m
let g,h
switch(e){case"insertText":if(!t)return null
g=v.slice(0,p)+t+v.slice(m),h=p+t.length
break
case"insertFromPaste":case"insertFromDrop":{if(!t)return null
const e=v.slice(0,p)
let a=Re(t,s,i)
a.startsWith("-")&&e.length>0&&(a=a.slice(1)),a.includes(i)&&e.includes(i)&&(a=a.replace(i,"")),g=e+a+v.slice(m),h=p+a.length
break}case"deleteContentBackward":f?(g=v.slice(0,p)+v.slice(m),h=p):p>0?(g=v.slice(0,p-1)+v.slice(p),h=p-1):(g=v,h=0)
break
case"deleteContentForward":f?(g=v.slice(0,p)+v.slice(m),h=p):p<v.length?(g=v.slice(0,p)+v.slice(p+1),h=p):(g=v,h=p)
break
case"deleteByCut":g=v.slice(0,p)+v.slice(m),h=p
break
case"deleteWordBackward":if(f)g=v.slice(0,p)+v.slice(m),h=p
else{let e=p
for(;e>0&&!/\d/.test(v[e-1]);)e--
for(;e>0&&/\d/.test(v[e-1]);)e--
g=v.slice(0,e)+v.slice(p),h=e}break
case"deleteWordForward":if(f)g=v.slice(0,p)+v.slice(m),h=p
else{let e=p
for(;e<v.length&&!/\d/.test(v[e]);)e++
for(;e<v.length&&/\d/.test(v[e]);)e++
g=v.slice(0,p)+v.slice(e),h=p}break
case"deleteSoftLineBackward":g=v.slice(m),h=0
break
case"deleteSoftLineForward":g=v.slice(0,p),h=p
break
default:return null}if(new RegExp(`^-?\\d*${Pe(i)}?\\d*$`).test(g)||(g=Re(g,s,i),h=Math.min(h,g.length)),null!=s){const e=g.split(i)
e[1]?.length>s&&(g=e[0]+i+e[1].slice(0,s),h=Math.min(h,g.length)),0===s&&g.endsWith(i)&&(g=g.slice(0,-1),h=Math.min(h,g.length))}const y=Sg(g,r,i,u,c),b=function(e,t,a){let l=0
for(let n=0;n<=e.length;n++){if(l===a)return n
n<e.length&&e[n]!==t&&l++}return e.length}(y,r,h)
return{text:Vg(y,d),cursor:b}}(a.inputType,a.data,l.value??"",l.selectionStart??0,l.selectionEnd??0,{groupSeparator:f.value,decimalSeparator:m.value,precision:e.precision,grouping:e.grouping,locale:d.value,minusSign:g.value}):function(e,t,a,l,n){if(!e)return null
const{decimalSeparator:o,precision:r,minusSign:i}=n,s=(t=_e(t)).slice(0,a)
let u=Re(e,r,o)
u.startsWith("-")&&s.length>0&&(u=u.slice(1)),u.includes(o)&&s.includes(o)&&(u=u.replace(o,""))
const c=s+u+t.slice(l)
if(!new RegExp(`^-?\\d*${Pe(o)}?\\d*$`).test(c))return{text:Vg(Re(c,r,o),i),cursor:a}
if(null!=r&&(c.split(o)[1]?.length??0)>r){const e=Re(c,r,o)
return{text:Vg(e,i),cursor:e===s+t.slice(l)?a:a+u.length}}return u===e?null:{text:Vg(c,i),cursor:a+u.length}}(a.data,l.value??"",l.selectionStart??0,l.selectionEnd??0,{decimalSeparator:m.value,precision:e.precision,minusSign:g.value})
null!==n&&(a.preventDefault(),l.value=n.text,l.setSelectionRange(n.cursor,n.cursor),t.nextTick(()=>S.value=n.text))}function z(e){["Enter","ArrowLeft","ArrowRight","Backspace","Delete","Tab"].includes(e.key)||e.ctrlKey||["ArrowDown","ArrowUp"].includes(e.key)&&(e.preventDefault(),e.stopPropagation(),$("ArrowUp"===e.key))}function L(e){e.stopPropagation()}function O(e){const t=e.currentTarget
t?.releasePointerCapture(e.pointerId),e.preventDefault(),i()}function j(e){const t=e.currentTarget
t?.setPointerCapture(e.pointerId),e.preventDefault(),e.stopPropagation(),r("up")}function H(e){const t=e.currentTarget
t?.setPointerCapture(e.pointerId),e.preventDefault(),e.stopPropagation(),r("down")}function W(){u.value||(null===b.value||isNaN(b.value)?S.value=null:S.value=y(b.value))}function U(){!function(){if(u.value)return
if(!n.value)return
const t=n.value.value,a=h(t)
t&&!isNaN(a)?S.value=y(ae(a,e.min,e.max)):S.value=null}()}return t.watch(()=>[d.value,m.value,f.value,e.precision,e.minFractionDigits],()=>function(){if(u.value)return
S.value=null===b.value||isNaN(b.value)?null:y(b.value,e.precision,!1)}()),sa(()=>{const{modelValue:a,type:r,...i}=Rs.filterProps(e)
function s(){return l.increment?t.createVNode(Bl,{key:"increment-defaults",defaults:{VBtn:{disabled:!N.value,height:R.value,size:_.value,icon:A.value,variant:o.value?.variant??"text"}}},{default:()=>[l.increment(D)]}):t.createVNode(Vo,{"aria-hidden":"true","data-testid":"increment",disabled:!N.value,height:R.value,icon:A.value,key:"increment-btn",onClick:L,onPointerdown:j,onPointerup:O,onPointercancel:O,size:_.value,variant:o.value?.variant??"text",tabindex:"-1"},null)}function u(){return l.decrement?t.createVNode(Bl,{key:"decrement-defaults",defaults:{VBtn:{disabled:!C.value,height:R.value,size:_.value,icon:P.value,variant:o.value?.variant??"text"}}},{default:()=>[l.decrement(B)]}):t.createVNode(Vo,{"aria-hidden":"true","data-testid":"decrement",disabled:!C.value,height:R.value,icon:P.value,key:"decrement-btn",onClick:L,onPointerdown:H,onPointerup:O,onPointercancel:O,size:_.value,variant:o.value?.variant??"text",tabindex:"-1"},null)}function d(){return t.createElementVNode("div",{class:"v-number-input__control"},[u(),t.createVNode(zr,{vertical:"stacked"!==I.value},null),s()])}function v(){return e.hideInput||e.inset?void 0:t.createVNode(zr,{vertical:!0},null)}const p="split"===I.value?t.createElementVNode("div",{class:"v-number-input__control"},[t.createVNode(zr,{vertical:!0},null),s()]):e.reverse||"hidden"===I.value?void 0:t.createElementVNode(t.Fragment,null,[v(),d()]),m=l["append-inner"]||p,f="split"===I.value?t.createElementVNode("div",{class:"v-number-input__control"},[u(),t.createVNode(zr,{vertical:!0},null)]):e.reverse&&"hidden"!==I.value?t.createElementVNode(t.Fragment,null,[d(),v()]):void 0,g=l["prepend-inner"]||f
return t.createVNode(Rs,t.mergeProps({ref:n},i,{modelValue:S.value,"onUpdate:modelValue":e=>S.value=e,focused:c.value,"onUpdate:focused":e=>c.value=e,validationValue:b.value,error:e.error||k.value||void 0,onBeforeinput:M,onFocus:W,onBlur:U,onKeydown:z,class:["v-number-input",{"v-number-input--default":"default"===I.value,"v-number-input--hide-input":e.hideInput,"v-number-input--inset":e.inset,"v-number-input--reverse":e.reverse,"v-number-input--split":"split"===I.value,"v-number-input--stacked":"stacked"===I.value},e.class],style:e.style,inputmode:"decimal"}),{...l,"append-inner":m?(...e)=>t.createElementVNode(t.Fragment,null,[l["append-inner"]?.(...e),p]):void 0,"prepend-inner":g?(...e)=>t.createElementVNode(t.Fragment,null,[f,l["prepend-inner"]?.(...e)]):void 0})}),ir({},n)}}),Cg=Symbol.for("vuetify:v-otp-input"),Eg=Tt({index:{type:Number,required:!0}},"VOtpField"),Ig=Kt()({name:"VOtpField",props:Eg(),setup(e){const a=t.inject(Cg)
if(!a)throw new Error("[Vuetify] VOtpField must be used inside VOtpInput")
const l=t.computed(()=>a.otpSlots.value[e.index]),n=t.computed(()=>a.isFocused.value&&a.focusAll.value&&!l.value?.isActive)
sa(()=>l.value?t.createVNode(Cs,{"data-otp-index":e.index,focused:l.value.isActive||n.value,class:t.normalizeClass({"v-otp-input__field--highlighted":n.value}),onMousedown:e=>e.preventDefault(),onClick:()=>a.focusAt(e.index)},{loader:void 0,default:()=>t.createElementVNode("div",{class:"v-otp-input__field"},[t.createElementVNode("input",{class:"v-otp-input__spacer","aria-hidden":"true",tabindex:"-1"},null),l.value.compositionChar?t.createElementVNode("span",{class:"v-otp-input__composition"},[l.value.compositionChar]):l.value.hasFakeCaret?t.createElementVNode("span",{class:"v-otp-input__caret"},null):t.createElementVNode("span",{class:t.normalizeClass(l.value.char?void 0:"v-otp-input__placeholder")},[l.value.char??l.value.placeholderChar??""])])}):t.createCommentVNode())}})
function Ag(e){let a=0
for(const l of e)l.type===t.Fragment&&Array.isArray(l.children)?a+=Ag(l.children):a++
return a}const Pg=Tt({merged:{type:Boolean,default:null}},"VOtpGroup"),_g=Kt()({name:"VOtpGroup",props:Pg(),setup(e,{slots:a}){const l=t.inject(Cg),n=t.computed(()=>e.merged??l?.merged.value??!1)
sa(()=>{const e=a.default?.()??[]
return t.createElementVNode("div",{class:t.normalizeClass(["v-otp-group",{"v-otp-group--merged":n.value}]),style:t.normalizeStyle(n.value?{flex:Ag(e)}:void 0)},[e])})}}),Rg=qt("v-otp-input__divider"),Dg={numeric:/[0-9]/,alpha:/[a-zA-Z]/,alphanumeric:/[a-zA-Z0-9]/,"unicode-alpha":/\p{L}/u,"unicode-alphanumeric":/[\p{L}\p{N}]/u},Bg=/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}\p{Script=Bopomofo}]/u,Tg=new Intl.Segmenter(void 0,{granularity:"grapheme"})
const Fg=Tt({autofocus:Boolean,divider:String,focusAll:Boolean,merged:Boolean,label:{type:String,default:"$vuetify.input.otp"},length:{type:[Number,String],default:6},masked:Boolean,modelValue:{type:[Number,String],default:void 0},pattern:{type:[String,Object],default:void 0},placeholder:String,type:{type:String,default:"number"},...yn(),...Tl(),...Ko(),...U(Ns({variant:"outlined"}),["baseColor","bgColor","class","color","disabled","error","loading","rounded","style","theme","variant"])},"VOtpInput"),$g=Kt()({name:"VOtpInput",props:Fg(),emits:{finish:e=>!0,"update:focused":e=>!0,"update:modelValue":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{densityClasses:o}=bn(e),{dimensionStyles:r}=Fl(e),{isFocused:i}=qo(e),{t:s}=Ha(),{isRtl:u}=Ua(),c=_a(e,"modelValue","",e=>null==e?"":String(e)),d=t.ref(),v=t.toRef(()=>Number(e.length))
let p=!1
const m=function(e){const{value:a,length:l=6,pattern:n,type:o="number",masked:r=!1,placeholder:i,isFocused:s=t.shallowRef(!1)}=e,u=t.shallowRef(null),c=t.shallowRef(""),d=t.shallowRef(!1)
let v=null,p=null,m=null
const f=t.toRef(()=>Number(t.toValue(l))),g=t.toRef(()=>t.toValue(r)||"password"===t.toValue(o)),h=t.toRef(()=>{const e=t.toValue(n)
return e instanceof RegExp?e:null!=e?Dg[e]??null:"number"===t.toValue(o)?Dg.numeric:null}),y=t.toRef(()=>h.value===Dg.numeric?"numeric":"text")
function b(e){return Array.from(Tg.segment(e),e=>e.segment)}function w(e,t){let a=0
for(const l of Tg.segment(e)){if(l.index>=t)break
a++}return a}function V(e,t){if(t<=0)return 0
let a=0
for(const l of Tg.segment(e)){if(a===t)return l.index
a++}return e.length}const S=t.computed(()=>{const e=b(a.value),l=b(c.value),n=t.toValue(i)??null,o=u.value,r=o?w(a.value,o.start):null,d=o?w(a.value,o.end):null,v=r??e.length
return Array.from({length:f.value},(t,a)=>{const o=e[a]??null,i=null!==o&&g.value?"•":o
let u=null
if(c.value&&a>=v){const e=l[a-v]
null!=e&&(u=g.value?"•":e)}const p=s.value&&null!==r&&null!==d&&(r===d&&a===r||a>=r&&a<d)
return{char:i,compositionChar:u,placeholderChar:n,isActive:p,hasFakeCaret:p&&null===o&&null===u}})})
function k(e){const t=h.value
return t?b(e).filter(e=>t.test(e)).join(""):e}function x(e,t){const a=b(e)
return a.length<=t?e:a.slice(0,t).join("")}function N(e,t,l="none"){if(null===e||null===t)return u.value=null,p=null,void(m=null)
const n={start:e,end:t,direction:l}
u.value=n,v=n
const o=w(a.value,e)
p=o,m=o}function C(e){const t=a.value,l=b(t).length,n=Math.min(e,l),o={start:V(t,n),end:n<l?V(t,n+1):t.length,direction:"forward"}
return u.value=o,v=o,p=n,m=n,o}return{value:a,length:f,slots:S,selection:u,composition:c,isComposing:d,isFocused:s,effectivePattern:h,inputMode:y,filter:k,isImeText:function(e){return Bg.test(e)},setValue:function(e){const t=x(k(e),f.value)
return a.value=t,t},insert:function(e,t){const l=a.value,n=t?.start??l.length,o=t?.end??l.length,r=k(e),i=x(l.slice(0,n)+r+l.slice(o),f.value)
a.value=i
const s=Math.min(n+r.length,i.length),u=w(i,s)
return N(V(i,Math.min(u,f.value-1)),s,"forward"),i},deleteRange:function(e,t){const l=a.value,n=l.slice(0,e)+l.slice(t)
return a.value=n,N(e,Math.min(e+1,n.length),"forward"),n},bulkDelete:function(e){const t=a.value,l=u.value,n=e?t.slice(l?.end??t.length):t.slice(0,l?.start??0)
return a.value=n,0===n.length?N(0,0,"none"):e?N(0,1,"forward"):N(n.length,n.length,"none"),n},syncSelection:function(e){if(d.value)return u.value
const{value:t,selectionStart:a,selectionEnd:l,selectionDirection:n,maxLength:o}=e
if(null===a||null===l)return u.value=null,v=null,null
const r=b(t).length,i=w(t,a),s=w(t,l)
let c,f=-1,g=-1
if(0!==r&&i===s&&!(i===r&&r<o))if(0===i)f=0,g=1,c="forward"
else if(i===o)f=i-1,g=i,c="backward"
else if(o>1&&r>1){let e=0
if(null!==v){const a=w(t,v.start),l=w(t,v.end)
c=i<l?"backward":"forward","backward"!==c||a===l&&a<o||l-a>1||(e=-1)}f=e+i,g=e+i+1}const h=-1!==f?f:i,y=-1!==g?g:s,S={start:V(t,h),end:V(t,y),direction:c??n??"none"}
return u.value=S,v=S,y-h<=1&&(p=h,m=h),S},setSelection:N,clearSelection:function(){u.value=null,p=null,m=null},selectAtEnd:function(){const e=a.value,t=b(e).length
let l,n
t>=f.value?(l=V(e,f.value-1),n=e.length):(l=e.length,n=e.length)
const o={start:l,end:n,direction:"forward"}
return u.value=o,v=o,p=t>=f.value?f.value-1:t,m=p,o},selectSlot:C,moveCaret:function(e){const t=a.value
if(0===b(t).length)return null
const l=u.value,n=l?w(t,l.start):0
return C(Math.max(0,n+e))},extendSelection:function(e){const t=a.value,l=b(t).length
if(0===l)return null
const n=Math.min(f.value-1,l)
if(null===p||null===m){const e=u.value
if(!e)return null
const a=w(t,e.start),l=w(t,e.end)
l-a<=1?(p=a,m=a):"backward"===e.direction?(p=l-1,m=a):(p=a,m=l-1)}const o=Math.max(0,Math.min(n,m+e))
m=o
const r=Math.min(p,o),i=Math.max(p,o),s={start:V(t,r),end:i+1>=l?t.length:V(t,i+1),direction:o<p?"backward":"forward"}
return u.value=s,v=s,s},startComposition:function(){d.value=!0,c.value=""},updateComposition:function(e){c.value=Bg.test(e)?e:""},endComposition:function(){d.value=!1,c.value=""},reset:function(){a.value="",u.value=null,c.value="",d.value=!1,v=null,p=null,m=null}}}({value:c,length:v,pattern:()=>e.pattern,type:()=>e.type,masked:()=>e.masked,placeholder:()=>e.placeholder,isFocused:i})
function f(){const e=d.value,t=m.selection.value
e&&t&&e.setSelectionRange(t.start,t.end,t.direction)}function g(){const e=d.value
e&&(e.value!==m.value.value&&(e.value=m.value.value),f())}function h(){const e=d.value
if(!e)return void m.clearSelection()
const t=m.syncSelection({value:e.value,selectionStart:e.selectionStart,selectionEnd:e.selectionEnd,selectionDirection:e.selectionDirection,maxLength:v.value})
t&&(e.selectionStart===t.start&&e.selectionEnd===t.end||e.setSelectionRange(t.start,t.end,t.direction))}function b(e){const t=e,a=e.target
if((t.isComposing||m.isComposing.value)&&m.isImeText(a.value))return
const l=m.setValue(a.value)
a.value!==l&&(a.value=l)}function w(){m.startComposition()}function V(e){m.updateComposition(e.data??"")}function S(e){m.endComposition(),b(e)}function k(){i.value=!0,p||d.value&&(m.selectAtEnd(),f())}function x(){i.value=!1,m.clearSelection()}function N(e){if("ArrowLeft"===e.key||"ArrowRight"===e.key){const t=("ArrowLeft"===e.key?-1:1)*(u.value?-1:1)
return void((e.shiftKey?m.extendSelection(t):m.moveCaret(t))&&(e.preventDefault(),g()))}"Backspace"!==e.key&&"Delete"!==e.key||(e.metaKey||e.ctrlKey||e.altKey)&&(e.preventDefault(),m.bulkDelete("Backspace"===e.key),g())}function C(e){if("insertText"===e.inputType&&e.data&&m.effectivePattern.value&&!m.effectivePattern.value.test(e.data))return void e.preventDefault()
if("deleteContentForward"===e.inputType){e.preventDefault()
const t=d.value
if(!t)return
const a=m.selection.value,l=a?.start??0,n=a?.end??t.value.length
return m.deleteRange(l,n),void g()}const t=["deleteWordBackward","deleteSoftLineBackward","deleteHardLineBackward"].includes(e.inputType),a=["deleteWordForward","deleteSoftLineForward","deleteHardLineForward"].includes(e.inputType);(t||a)&&(e.preventDefault(),m.bulkDelete(t),g())}function E(e){e.preventDefault()
const t=d.value
if(!t)return
const a=e.clipboardData?.getData("text/plain").trim()??"",l=m.selection.value
m.insert(a,{start:l?.start??0,end:l?.end??t.value.length}),g()}function I(e){const t=d.value
t&&(p=!0,t.focus(),p=!1,m.selectSlot(e),f())}function A(e){const t=function(e,t){const a=document.elementsFromPoint(e,t).find(e=>e.hasAttribute("data-otp-index")),l=a?Number(a.getAttribute("data-otp-index")):NaN
return Number.isNaN(l)?null:l}(e.clientX,e.clientY)
null!=t&&I(t)}return t.watch(d,(e,t,a)=>{e&&(e.addEventListener("selectionchange",h),a(()=>e.removeEventListener("selectionchange",h)))},{immediate:!0}),Pa(()=>e.autofocus,()=>{const e=t.effectScope()
e.run(()=>{const{intersectionRef:a,isIntersecting:l}=zn()
t.watchEffect(()=>{a.value=d.value}),t.watch(l,t=>{t&&(a.value?.focus(),e.stop())})})}),t.watch(c,e=>{m.isComposing.value||e.length===v.value&&l("finish",e)}),Ht({VField:{color:t.toRef(()=>e.color),bgColor:t.toRef(()=>e.color),baseColor:t.toRef(()=>e.baseColor),disabled:t.toRef(()=>e.disabled),error:t.toRef(()=>e.error),variant:t.toRef(()=>e.variant),rounded:t.toRef(()=>e.rounded)}},{scoped:!0}),t.provide(Cg,{otpSlots:m.slots,isFocused:i,focusAll:t.toRef(()=>e.focusAll),divider:t.toRef(()=>e.divider),merged:t.toRef(()=>e.merged),focusAt:I}),sa(()=>{const[l,i]=J(a)
return t.createElementVNode("div",t.mergeProps({class:["v-otp-input",{"v-otp-input--divided":!!e.divider},o.value,e.class],style:[e.style]},l),[t.createElementVNode("div",{class:"v-otp-input__content",style:t.normalizeStyle([r.value])},[n.fields?n.fields():e.merged?t.createVNode(_g,{merged:!0},{default:()=>[Array.from({length:v.value},(e,a)=>t.createVNode(Ig,{index:a,key:a},null))]}):Array.from({length:v.value},(a,l)=>t.createElementVNode(t.Fragment,null,[(e.divider||n.divider)&&0!==l&&t.createVNode(Rg,{key:`d-${l}`},{default:()=>[n.divider?.({index:l-1})??e.divider]}),t.createVNode(Ig,{index:l,key:l},null)])),t.createElementVNode("input",t.mergeProps({ref:d,class:"v-otp-input__input",type:"text",inputmode:m.inputMode.value,dir:u.value?"rtl":"ltr",autocomplete:"one-time-code",autocorrect:"off",autocapitalize:"off",spellcheck:!1,disabled:e.disabled,"aria-label":s(e.label),value:c.value},i,{onClick:A,onInput:b,onKeydown:N,onBeforeinput:C,onFocus:k,onBlur:x,onPaste:E,onCompositionstart:w,onCompositionupdate:V,onCompositionend:S}),null),t.createVNode(fs,{contained:!0,contentClass:"v-otp-input__loader",modelValue:!!e.loading,persistent:!0},{default:()=>[n.loader?.()??t.createVNode(Hn,{color:y(e.loading)?void 0:e.loading,indeterminate:!0,size:"24",width:"2"},null)]}),n.default?.()])])}),{blur:()=>{d.value?.blur()},focus:()=>{d.value?.focus()},reset:m.reset,isFocused:i}}})
const Mg=Tt({scale:{type:[Number,String],default:.5},...Ft()},"VParallax"),zg=Kt()({name:"VParallax",props:Mg(),setup(e,{slots:a}){const{intersectionRef:l,isIntersecting:n}=zn(),{resizeRef:o,contentRect:r}=Sa(),{height:i}=yr(),s=t.ref()
let u
t.watchEffect(()=>{l.value=o.value=s.value?.$el}),t.watch(n,e=>{e?(u=na(l.value),u=u===document.scrollingElement?document:u,u.addEventListener("scroll",v,{passive:!0}),v()):u.removeEventListener("scroll",v)}),t.onBeforeUnmount(()=>{u?.removeEventListener("scroll",v)}),t.watch(i,v),t.watch(()=>r.value?.height,v)
const c=t.computed(()=>1-ae(Number(e.scale)))
let d=-1
function v(){n.value&&!R()&&(cancelAnimationFrame(d),d=requestAnimationFrame(()=>{const e=(s.value?.$el).querySelector(".v-img__img")
if(!e)return
const t=u instanceof Document?document.documentElement.clientHeight:u.clientHeight,a=u instanceof Document?window.scrollY:u.scrollTop,n=l.value.getBoundingClientRect().top+a,o=r.value.height,i=(d=(a-(n+(o-t)/2))*c.value,Math.floor(Math.abs(d))*Math.sign(d))
var d
const v=Math.max(1,(c.value*(t-o)+o)/o)
e.style.setProperty("transform",`translateY(${i}px) scale(${v})`)}))}return sa(()=>t.createVNode(tn,{class:t.normalizeClass(["v-parallax",{"v-parallax--active":n.value},e.class]),style:t.normalizeStyle(e.style),ref:s,cover:!0,onLoadstart:v,onLoad:v},a)),{}}}),Lg=Kt()({name:"VPullToRefresh",props:{disabled:Boolean,pullDownThreshold:{type:Number,default:64}},emits:{load:e=>!0},setup(e,{slots:a,emit:l}){let n=0,o=[]
const r=t.shallowRef(0),i=t.ref(),s=t.shallowRef(!1),u=t.shallowRef(!1),c=t.shallowRef(!1),d=t.computed(()=>r.value>=e.pullDownThreshold&&!s.value),v=t.computed(()=>ae(r.value,0,e.pullDownThreshold))
function p(t){s.value||e.disabled||(c.value=!0,n="clientY"in t?t.clientY:t.touches[0].clientY)}function m(t){if(s.value||!c.value||e.disabled)return
const a="clientY"in t?t.clientY:t.touches[0].clientY
o.length&&!o[0].scrollTop&&(r.value=a-n)}function f(t){if(!s.value&&!e.disabled)if(c.value=!1,d.value){function a(){s.value&&(r.value=0,s.value=!1)}l("load",{done:a}),s.value=!0}else r.value=0}t.onMounted(()=>{o=oa(i.value)}),t.watch([v,s],()=>{if(o.length){const e=v.value&&!s.value
o.forEach(t=>t.style.overflow=e?"hidden":"auto")}}),t.watch(v,(e,t)=>{u.value=e<t}),sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-pull-to-refresh"]),onTouchstart:p,onTouchmove:m,onTouchend:f,onMousedown:p,onMouseup:f,onMouseleave:f,onMousemove:m,ref:i},[t.createElementVNode("div",{class:t.normalizeClass(["v-pull-to-refresh__pull-down",{"v-pull-to-refresh__pull-down--touching":c.value}]),style:{top:z(-1*e.pullDownThreshold+v.value),height:z(e.pullDownThreshold)}},[a.pullDownPanel?a.pullDownPanel({canRefresh:d.value,goingUp:u.value,refreshing:s.value}):t.createElementVNode("div",{class:t.normalizeClass(["v-pull-to-refresh__pull-down-default"])},[s.value?t.createVNode(Hn,{indeterminate:!0,active:!1},null):t.createVNode(Mn,{icon:d.value||u.value?"$sortAsc":"$sortDesc"},null)])]),t.createElementVNode("div",{class:t.normalizeClass(["v-pull-to-refresh__scroll-container",{"v-pull-to-refresh__scroll-container--touching":c.value}]),style:{top:z(v.value)}},[a.default?.()])]))}}),Og=Tt({...G(Oo({falseIcon:"$radioOff",trueIcon:"$radioOn"}),["indeterminate","indeterminateIcon"])},"VRadio"),jg=Kt()({name:"VRadio",props:Og(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue")
return sa(()=>{const n=G(jo.filterProps(e),["modelValue"])
return t.createVNode(jo,t.mergeProps(n,{modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,class:["v-radio",e.class],style:e.style,type:"radio"}),a)}),{}}}),Hg=Tt({height:{type:[Number,String],default:"auto"},...G(lr(),["direction","glow"]),...G(Mo(),["multiple"]),trueIcon:{type:ua,default:"$radioOn"},falseIcon:{type:ua,default:"$radioOff"},type:{type:String,default:"radio"}},"VRadioGroup"),Wg=Kt()({name:"VRadioGroup",inheritAttrs:!1,props:Hg(),emits:{"update:modelValue":e=>!0},setup(e,{attrs:a,slots:l}){const n=t.useId(),o=t.computed(()=>e.id||`radio-group-${n}`),r=_a(e,"modelValue"),i=t.ref()
return sa(()=>{const[n,s]=J(a),u=nr.filterProps(e),c=jo.filterProps(e),d=l.label?l.label({label:e.label,props:{for:o.value}}):e.label
return t.createVNode(nr,t.mergeProps({ref:i,class:["v-radio-group",e.class],style:e.style},n,u,{modelValue:r.value,"onUpdate:modelValue":e=>r.value=e,id:o.value}),{...l,default:({id:a,messagesId:n,isDisabled:o,isReadonly:i})=>t.createElementVNode(t.Fragment,null,[d&&t.createVNode(Fo,{id:a.value},{default:()=>[d]}),t.createVNode(Lo,t.mergeProps(c,{id:a.value,"aria-describedby":n.value,defaultsTarget:"VRadio",trueIcon:e.trueIcon,falseIcon:e.falseIcon,type:e.type,disabled:o.value,readonly:i.value,"aria-labelledby":d?a.value:void 0,multiple:!1},s,{modelValue:r.value,"onUpdate:modelValue":e=>r.value=e}),l)])})}),ir({},i)}}),Ug=Tt({...Ko(),...lr(),...av(),strict:Boolean,modelValue:{type:Array,default:()=>[0,0]}},"VRangeSlider"),Yg=Kt()({name:"VRangeSlider",inheritAttrs:!1,props:Ug(),emits:{"update:focused":e=>!0,"update:modelValue":e=>!0,end:e=>!0,start:e=>!0},setup(e,{slots:a,emit:l,attrs:n}){const o=t.ref(),r=t.ref(),i=t.ref(),{rtlClasses:s}=Ua()
const u=lv(e),c=_a(e,"modelValue",void 0,e=>e?.length?e.map(e=>u.roundValue(e)):[0,0]),{activeThumbRef:d,hasLabels:v,max:p,min:m,mousePressed:f,onSliderMousedown:g,onSliderTouchstart:h,position:y,trackContainerRef:b,disabled:w,readonly:V}=nv({props:e,steps:u,onSliderStart:()=>{w.value||V.value?d.value?.blur():l("start",c.value)},onSliderEnd:({value:t})=>{if(w.value||V.value)d.value?.blur()
else{const a=d.value===o.value?.$el?[t,c.value[1]]:[c.value[0],t]
!e.strict&&a[0]<a[1]&&(c.value=a)}l("end",c.value)},onSliderMove:({value:t})=>{const[a,l]=c.value
w.value||V.value?d.value?.blur():(e.strict||a!==l||a===m.value||(d.value=t>a?r.value?.$el:o.value?.$el,d.value?.focus()),d.value===o.value?.$el?c.value=[Math.min(t,l),l]:c.value=[a,Math.max(a,t)])},getActiveThumb:function(t){if(!o.value||!r.value)return
const a=tv(t,o.value.$el,e.direction),l=tv(t,r.value.$el,e.direction),n=Math.abs(a),i=Math.abs(l)
return n<i||n===i&&a<0?o.value.$el:r.value.$el}}),{isFocused:S,focus:k,blur:x}=qo(e),N=t.computed(()=>y(c.value[0])),C=t.computed(()=>y(c.value[1]))
return sa(()=>{const l=nr.filterProps(e),[u,y]=J(n),E=!!(e.label||a.label||a.prepend)
return t.createVNode(nr,t.mergeProps({class:["v-slider","v-range-slider",{"v-slider--has-labels":!!a["tick-label"]||v.value,"v-slider--focused":S.value,"v-slider--pressed":f.value,"v-slider--disabled":w.value},s.value,e.class],style:e.style,ref:i},l,u,{focused:S.value}),{...a,prepend:E?l=>t.createElementVNode(t.Fragment,null,[a.label?.(l)??(e.label?t.createVNode(Fo,{class:"v-slider__label",text:e.label},null):void 0),a.prepend?.(l)]):void 0,default:({id:l,messagesId:n})=>t.createElementVNode("div",{class:"v-slider__container",onMousedown:V.value?void 0:g,onTouchstartPassive:V.value?void 0:h},[t.createElementVNode("input",{id:`${l.value}_start`,name:e.name||l.value,disabled:w.value,readonly:V.value,tabindex:"-1",value:c.value[0]},null),t.createElementVNode("input",{id:`${l.value}_stop`,name:e.name||l.value,disabled:w.value,readonly:V.value,tabindex:"-1",value:c.value[1]},null),t.createVNode(sv,{ref:b,start:N.value,stop:C.value},{"tick-label":a["tick-label"]}),t.createVNode(rv,t.mergeProps({ref:o,"aria-describedby":n.value,focused:S&&d.value===o.value?.$el,modelValue:c.value[0],"onUpdate:modelValue":e=>c.value=[e,c.value[1]],onFocus:e=>{k(),d.value=o.value?.$el,p.value!==m.value&&c.value[0]===c.value[1]&&c.value[1]===m.value&&e.relatedTarget!==r.value?.$el&&(o.value?.$el.blur(),r.value?.$el.focus())},onBlur:()=>{x(),d.value=void 0},min:m.value,max:c.value[1],position:N.value,ripple:e.ripple},y),{"thumb-label":a["thumb-label"]}),t.createVNode(rv,t.mergeProps({ref:r,"aria-describedby":n.value,focused:S&&d.value===r.value?.$el,modelValue:c.value[1],"onUpdate:modelValue":e=>c.value=[c.value[0],e],onFocus:e=>{k(),d.value=r.value?.$el,p.value!==m.value&&c.value[0]===c.value[1]&&c.value[0]===p.value&&e.relatedTarget!==o.value?.$el&&(r.value?.$el.blur(),o.value?.$el.focus())},onBlur:()=>{x(),d.value=void 0},min:c.value[0],max:p.value,position:C.value,ripple:e.ripple},y),{"thumb-label":a["thumb-label"]})])})}),ir({focus:()=>o.value?.$el.focus()},i)}}),Gg=Tt({name:String,itemAriaLabel:{type:String,default:"$vuetify.rating.ariaLabel.item"},activeColor:String,color:String,clearable:Boolean,disabled:Boolean,emptyIcon:{type:ua,default:"$ratingEmpty"},fullIcon:{type:ua,default:"$ratingFull"},halfIncrements:Boolean,hover:Boolean,length:{type:[Number,String],default:5},readonly:Boolean,modelValue:{type:[Number,String],default:0},itemLabels:Array,itemLabelPosition:{type:String,default:"top",validator:e=>["top","bottom"].includes(e)},ripple:Boolean,...Ft(),...yn(),...Vn(),...ol(),...Ga()},"VRating"),Kg=Kt()({name:"VRating",props:Gg(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{t:l}=Ha(),{themeClasses:n}=tl(e),o=t.ref(),r=_a(e,"modelValue"),i=t.computed(()=>ae(parseFloat(r.value),0,Number(e.length))),s=t.computed(()=>C(Number(e.length),1)),u=t.computed(()=>s.value.flatMap(t=>e.halfIncrements?[t-.5,t]:[t])),c=t.shallowRef(-1),d=t.computed(()=>u.value.map(t=>{const a=e.hover&&c.value>-1,l=i.value>=t,n=c.value>=t,o=(a?n:l)?e.fullIcon:e.emptyIcon,r=e.activeColor??e.color
return{isFilled:l,isHovered:n,icon:o,color:l||n?r:e.color,activeColor:r}})),v=t.computed(()=>[0,...u.value].map(t=>({onMouseenter:e.hover?function(){c.value=t}:void 0,onMouseleave:e.hover?function(){c.value=-1}:void 0,onClick:function(){e.disabled||e.readonly||(r.value=i.value===t&&e.clearable?0:t)}}))),p=t.computed(()=>e.halfIncrements?1+2*Math.floor(Math.max(0,Number(r.value??0)-.5)):Math.floor(Math.max(0,Number(r.value??0)-1)))
function m(){const e=o.value?.querySelector('[tabindex="0"]')
e?.focus()}function f(a){if(e.disabled||e.readonly)return
if(a.ctrlKey||a.altKey)return
const l=e.halfIncrements?.5:1
if("ArrowRight"===a.key){const a=Math.min(Number(e.length),Number(r.value??0)+l)
r.value=a,t.nextTick(()=>m())}if("ArrowLeft"===a.key){const e=Math.max(0,Number(r.value??0)-l)
r.value=e,t.nextTick(()=>m())}}const g=t.useId(),h=t.computed(()=>e.name??`v-rating-${g}`)
function y({value:n,index:o,showStar:r=!0}){const{onMouseenter:s,onMouseleave:u,onClick:c}=v.value[o+1],m=`${h.value}-${String(n).replace(".","-")}`,g=o===p.value,y={color:d.value[o]?.color,density:e.density,disabled:e.disabled,icon:d.value[o]?.icon,ripple:e.ripple,size:e.size,variant:"plain",tabindex:g?0:-1,onKeydown:f}
return t.createElementVNode(t.Fragment,null,[t.createElementVNode("label",{for:m,class:t.normalizeClass({"v-rating__item--half":e.halfIncrements&&n%1>0,"v-rating__item--full":e.halfIncrements&&n%1==0}),onMouseenter:s,onMouseleave:u,onClick:c},[t.createElementVNode("span",{class:"v-rating__hidden"},[l(e.itemAriaLabel,n,e.length)]),r?a.item?a.item({...d.value[o],props:y,value:n,index:o,rating:i.value}):t.createVNode(Vo,t.mergeProps({"aria-label":l(e.itemAriaLabel,n,e.length)},y),null):void 0]),t.createElementVNode("input",{class:"v-rating__hidden",name:h.value,id:m,type:"radio",value:n,checked:i.value===n,tabindex:-1,readonly:e.readonly,disabled:e.disabled},null)])}function b(e){return a["item-label"]?a["item-label"](e):e.label?t.createElementVNode("span",null,[e.label]):t.createElementVNode("span",null,[t.createTextVNode(" ")])}return sa(()=>{const l=!!e.itemLabels?.length||a["item-label"]
return t.createVNode(e.tag,{class:t.normalizeClass(["v-rating",{"v-rating--hover":e.hover,"v-rating--readonly":e.readonly},n.value,e.class]),style:t.normalizeStyle(e.style),ref:o},{default:()=>[t.createVNode(y,{value:0,index:-1,showStar:!1},null),s.value.map((a,n)=>t.createElementVNode("div",{class:"v-rating__wrapper"},[l&&"top"===e.itemLabelPosition?b({value:a,index:n,label:e.itemLabels?.[n]}):void 0,t.createElementVNode("div",{class:"v-rating__item"},[e.halfIncrements?t.createElementVNode(t.Fragment,null,[t.createVNode(y,{value:a-.5,index:2*n},null),t.createVNode(y,{value:a,index:2*n+1},null)]):t.createVNode(y,{value:a,index:n},null)]),l&&"bottom"===e.itemLabelPosition?b({value:a,index:n,label:e.itemLabels?.[n]}):void 0]))]})}),{}}}),qg={actions:"button@2",article:"heading, paragraph",avatar:"avatar",button:"button",card:"image, heading","card-avatar":"image, list-item-avatar",chip:"chip","chip-group":"chip@8","date-picker":"list-item, heading, divider, date-picker-options, date-picker-days, actions","date-picker-options":"text, avatar@2","date-picker-days":"avatar@28",divider:"divider",heading:"heading",image:"image","list-item":"text","list-item-avatar":"avatar, text","list-item-two-line":"sentences","list-item-avatar-two-line":"avatar, sentences","list-item-three-line":"paragraph","list-item-avatar-three-line":"avatar, paragraph",ossein:"ossein",paragraph:"text@3",sentences:"text@2",subtitle:"text",table:"table-heading, table-thead, table-tbody, table-tfoot","table-heading":"heading, text","table-thead":"heading@6","table-tbody":"table-row-divider@6","table-row-divider":"table-row, divider","table-row":"table-cell@6","table-cell":"text","table-tfoot":"text@2, avatar@2",text:"text"}
function Xg(e,a=[]){return t.createElementVNode("div",{class:t.normalizeClass(["v-skeleton-loader__bone",`v-skeleton-loader__${e}`])},[a])}function Zg(e,t){const[a,l]=e.split("@")
return Array.from({length:l}).map(()=>Qg(a,t))}function Qg(e,t){if(!e)return[]
if(e.includes(","))return Jg(e,t)
if(e.includes("@"))return Zg(e,t)
if(!(e in t))return a(`Unknown skeleton type "${e}", register it with the types prop`),[Xg(e)]
const l=t[e]
let n=[]
return e===l||(l.includes(",")?n=Jg(l,t):l.includes("@")?n=Zg(l,t):n.push(Qg(l,t))),[Xg(e,n)]}function Jg(e,t){return e.replace(/\s/g,"").split(",").map(e=>Qg(e,t))}const eh=Tt({boilerplate:Boolean,color:String,loading:Boolean,loadingText:{type:String,default:"$vuetify.loading"},type:{type:[String,Array],default:"ossein"},types:Object,...Tl(),...nn(),...Ga()},"VSkeletonLoader"),th=Kt()({name:"VSkeletonLoader",inheritAttrs:!1,props:eh(),setup(e,{attrs:a,slots:l}){const{backgroundColorClasses:n,backgroundColorStyles:o}=Ol(()=>e.color),{dimensionStyles:r}=Fl(e),{elevationClasses:i}=on(e),{themeClasses:s}=tl(e),{t:u}=Ha(),c=t.computed(()=>Qg(ee(e.type).join(","),{...qg,...e.types}))
return sa(()=>{const d=!l.default||e.loading,v=e.boilerplate||!d?{}:{ariaLive:"polite",ariaLabel:u(e.loadingText),role:"alert"}
return d?t.createElementVNode("div",t.mergeProps({class:["v-skeleton-loader",{"v-skeleton-loader--boilerplate":e.boilerplate},s.value,n.value,i.value],style:[o.value,r.value]},v,a),[c.value]):t.createElementVNode(t.Fragment,null,[l.default?.()])}),{}}}),ah=Kt()({name:"VSlideGroupItem",props:Pn(),emits:{"group:selected":e=>!0},setup(e,{slots:t}){const a=_n(e,Ar)
return()=>t.default?.({isSelected:a.isSelected.value,select:a.select,toggle:a.toggle,selectedClass:a.selectedClass.value})}}),lh=Symbol.for("vuetify:v-snackbar-queue")
const nh=Tt({collapsed:Object,loading:Boolean,prependAvatar:String,prependIcon:ua,queueGap:Number,queueIndex:Number,title:String,text:String,reverseTimer:Boolean,timer:{type:[Boolean,String],default:!1},timerColor:String,timeout:{type:[Number,String],default:5e3},vertical:Boolean,...sn({location:"bottom center"}),...Zn(),...Gl(),...Nn(),...Ga(),...G(ms({closeOnBack:!1,locationStrategy:null,transition:"v-snackbar-transition"}),["persistent","noClickAnimation","offset","retainFocus","captureFocus","disableInitialFocus","location","scrim","scrollStrategy","stickToTarget","viewportMargin"])},"VSnackbar"),oh=Kt()({name:"VSnackbar",props:nh(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),{positionClasses:n}=Qn(e),{scopeId:o}=ns(),{themeClasses:r}=tl(e),{colorClasses:i,colorStyles:s,variantClasses:u}=Cn(e),{roundedClasses:c,roundedStyles:d}=Kl(e),v=function(e){const a=t.shallowRef(e())
let l=-1
function n(){clearInterval(l)}return t.onScopeDispose(n),{clear:n,time:a,start:function(t){const o=t?getComputedStyle(t):{transitionDuration:.2},r=1e3*parseFloat(o.transitionDuration)||200
if(n(),a.value<=0)return
const i=performance.now()
l=window.setInterval(()=>{const t=performance.now()-i+r
a.value=Math.max(e()-t,0),a.value<=0&&n()},r)},reset:function(){n(),t.nextTick(()=>a.value=e())}}}(()=>Number(e.timeout)),p=t.ref(),m=function(e,a){const l=t.inject(lh,null)
if(!l)return null
const n=t.useId()
l.register(n),t.onBeforeUnmount(()=>l.unregister(n)),t.watch(e,e=>!e&&l.unregister(n),{flush:"sync"})
const{resizeRef:o,contentRect:r}=Sa()
t.watch(a,e=>{o.value=e??null}),t.watch(r,e=>{e?.width&&l.setSize(n,e.height,e.width)})
const i=t.computed(()=>l.getOffset(n))
return{id:n,offset:i}}(l,()=>p.value?.contentEl)
let f
const h=t.ref(),y=t.shallowRef(!1),b=t.shallowRef(!1),w=t.shallowRef(0),V=t.ref(),S=t.inject(ka,void 0)
Pa(()=>!!S,()=>{const e=Ea()
t.watchEffect(()=>{V.value=e.mainStyles.value})}),t.watch(l,x),t.watch(()=>e.timeout,x),t.onMounted(()=>{l.value&&x()})
let k=-1
function x(){v.clear(),window.clearTimeout(k)
const a=Number(e.timeout)
if(!l.value||-1===a)return
v.reset()
const n=O(h.value)
t.nextTick(()=>v.start(n)),k=window.setTimeout(()=>{l.value=!1},a)}function N(){v.reset(),window.clearTimeout(k)}function C(){y.value=!0,N()}function E(){y.value=!1,b.value||x()}function I(){b.value=!0,N()}function A(e){const t=p.value?.contentEl
t?.contains(e.relatedTarget)||(b.value=!1,y.value||x())}function P(e){w.value=e.touches[0].clientY}function _(e){Math.abs(w.value-e.changedTouches[0].clientY)>50&&(l.value=!1)}function R(){y.value&&E(),b.value=!1}const D=t.computed(()=>e.location.split(" ").reduce((e,t)=>(e[`v-snackbar--${t}`]=!0,e),{})),B=t.computed(()=>{const[t,a]=e.location.split(" ")
return"bottom"===t||["left","right"].includes(t)&&"end"===a?-1:1}),T=t.computed(()=>e.collapsed?{"--v-snackbar-collapsed-height":z(e.collapsed.height),"--v-snackbar-collapsed-width":z(e.collapsed.width)}:null),F=t.computed(()=>{if(m)return null===m.offset.value?f:f=z(m.offset.value)}),$=t.computed(()=>{if(!g(e.transition)||!e.transition.endsWith("-auto"))return e.transition
const t=e.transition.replace("-auto",""),[a,l]=e.location.split(" ")
return`${t}-${["start","end","left","right"].includes(l)||["left","right"].includes(a)?"x":"y"}${["end","right"].includes(l)||!["start","left"].includes(l)&&["bottom","right"].includes(a)?"-reverse":""}-transition`})
return sa(()=>{const m=fs.filterProps({...e,location:e.location,locationStrategy:e.locationStrategy??ke}),f=!(!e.prependAvatar&&!e.prependIcon),g=!!(f||e.loading||a.prepend),b=!!(a.default||a.text||a.title||e.text||e.title)
return t.createVNode(fs,t.mergeProps({ref:p,class:["v-snackbar",{"v-snackbar--active":l.value,"v-snackbar--collapsed":!!e.collapsed,"v-snackbar--timer":!!e.timer,"v-snackbar--vertical":e.vertical},D.value,n.value,e.class],style:[V.value,{"--v-snackbar-offset":F.value,"--v-snackbar-gap":z(e.queueGap),"--v-snackbar-index":e.queueIndex,"--v-snackbar-direction":B.value},T.value,e.style]},m,{transition:$.value,modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,contentProps:t.mergeProps({class:["v-snackbar__wrapper",r.value,i.value,c.value,u.value],style:[s.value,d.value],onPointerenter:C,onPointerleave:E,onFocusin:I,onFocusout:A},m.contentProps),persistent:!0,noClickAnimation:!0,scrim:!1,scrollStrategy:"none",onTouchstartPassive:P,onTouchend:_,onAfterLeave:R},o),{default:()=>[xn(!1,"v-snackbar"),a.header&&t.createElementVNode("div",{class:"v-snackbar__header"},[a.header?.()]),e.timer&&Number(e.timeout)>0&&!y.value&&t.createElementVNode("div",{key:"timer",class:t.normalizeClass(["v-snackbar__timer","v-snackbar__timer--"+("bottom"===e.timer?"bottom":"top")])},[t.createVNode(Yn,{ref:h,color:e.timerColor??"info",max:e.timeout,modelValue:e.reverseTimer?Number(e.timeout)-v.time.value:v.time.value},null)]),g&&t.createVNode(Bl,{key:"prepend-defaults",disabled:!f&&!e.loading,defaults:{VAvatar:{image:e.prependAvatar},VIcon:{icon:e.prependIcon},VProgressCircular:{indeterminate:!0,size:24,width:3}}},{default:()=>[t.createElementVNode("div",{class:"v-snackbar__prepend"},[a.prepend?a.prepend():t.createElementVNode(t.Fragment,null,[e.loading&&t.createVNode(Hn,null,null),!e.loading&&e.prependAvatar&&t.createVNode(Bo,null,null),!e.loading&&e.prependIcon&&t.createVNode(Mn,null,null)])])]}),b&&t.createElementVNode("div",{key:"content",class:"v-snackbar__content",role:"status","aria-live":"polite"},[a.title?.()??(e.title?t.createElementVNode("div",{class:"v-snackbar__title",key:"title"},[e.title]):""),a.text?.()??e.text,a.default?.()]),a.actions&&t.createVNode(Bl,{defaults:{VBtn:{variant:"text",ripple:!1,slim:!0}}},{default:()=>[t.createElementVNode("div",{class:"v-snackbar__actions"},[a.actions({isActive:l})])]})],activator:a.activator})}),ir({},p)}})
const rh=Tt({closable:[Boolean,String],closeText:{type:String,default:"$vuetify.dismiss"},collapsed:Boolean,displayStrategy:{type:String,default:"hold"},modelValue:{type:Array,default:()=>[]},totalVisible:{type:[Number,String],default:1},gap:{type:[Number,String],default:8},...G(nh(),["modelValue","collapsed","queueIndex","queueGap"])},"VSnackbarQueue"),ih=Kt()({name:"VSnackbarQueue",inheritAttrs:!1,props:rh(),emits:{"update:modelValue":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const{t:o}=Ha(),r=function(){const e=t.shallowRef(E?document.visibilityState:"visible")
if(E){const a=()=>{e.value=document.visibilityState}
document.addEventListener("visibilitychange",a,{passive:!0}),t.onBeforeUnmount(()=>{document.removeEventListener("visibilitychange",a)})}return e}(),i=function(e){const a=t.ref(new Map),l=t.toRef(()=>Number(e.gap)),n=t.computed(()=>{for(const{width:e,height:t}of[...a.value.values()].toReversed())if(e&&t)return{width:e,height:t}
return{width:0,height:0}}),o={register:function(e){a.value.set(e,{height:0,width:0})},unregister:function(e){a.value.delete(e)},setSize:function(e,t,l){const n=a.value.get(e)
!n||n.height===t&&n.width===l||(n.height=t,n.width=l)},getOffset:function(e){if(!a.value.has(e))return null
let t=0
for(const[n,o]of[...a.value.entries()].toReversed()){if(n===e)break
t+=o.height+l.value}return t},items:a,gap:l,lastItemSize:n}
return t.provide(lh,o),o}(e),s=t.shallowRef(!1),{runOpenDelay:u,runCloseDelay:c}=Yi({openDelay:0,closeDelay:500},e=>{s.value=e,y()})
let d=0
const v=t.ref([]),p=t.toRef(()=>Number(e.totalVisible))
function m(){if(!e.modelValue.length)return
if(v.value.filter(e=>e.active).length>=p.value){if("overflow"!==e.displayStrategy)return
v.value.filter(e=>e.active).slice(p.value-1).forEach(e=>{e.active=!1,e.onDismiss?.("overflow")})}const[a,...n]=e.modelValue
l("update:modelValue",n)
const o=g(a)?{text:a}:a,{promise:r,success:i,error:s,onDismiss:u,...c}=o,m={id:d++,item:{...r?{timeout:-1,loading:!0}:{},...c},active:!0,onDismiss:u}
v.value.unshift(m),y(),r?.then(e=>{m.active&&(m.item=i?.(e)??{...m.item,timeout:1},y(),t.triggerRef(v))},e=>{m.active&&(m.item=s?.(e)??{...m.item,timeout:1},y(),t.triggerRef(v))})}function f(e,t){const a=v.value.find(t=>t.id===e)
a&&(a.active=!1,a.onDismiss?.(t),y())}t.watch(()=>e.modelValue.length,m)
const h=t.computed(()=>({color:g(e.closable)?e.closable:void 0,text:o(e.closeText)}))
function y(){let t=0
if(v.value.forEach(({item:e,active:a})=>{e.queueIndex=t,a&&t++}),e.collapsed&&!s.value)for(const{item:e}of v.value)e.collapsed=e.queueIndex>0?{width:i.lastItemSize.value.width,height:i.lastItemSize.value.height}:void 0
else v.value.forEach(({item:e})=>e.collapsed=void 0)}return t.watch(i.lastItemSize,y),t.watch(()=>e.collapsed,y),sa(()=>{const l=!(!e.closable&&!n.actions),o=G(oh.filterProps(e),["modelValue","collapsed"]),i="hidden"===r.value||e.collapsed&&s.value
return t.createElementVNode(t.Fragment,null,[v.value.map(({id:r,item:d,active:p})=>n.item?t.createVNode(Bl,{defaults:{VSnackbar:d}},{default:()=>[n.item({item:d})]}):t.createVNode(oh,t.mergeProps({key:r},a,o,d,i?{timeout:-1}:{},{queueGap:Number(e.gap),contentProps:t.mergeProps(o.contentProps,{onMouseenter:u,onMouseleave:()=>c()}),modelValue:p,"onUpdate:modelValue":()=>f(r,"auto"),onAfterLeave:()=>function(e){v.value=v.value.filter(t=>t.id!==e),0===v.value.length&&(s.value=!1),m()}(r)}),{header:n.header?()=>n.header?.({item:d}):void 0,text:n.text?()=>n.text?.({item:d}):void 0,actions:l?()=>t.createElementVNode(t.Fragment,null,[n.actions?t.createVNode(Bl,{defaults:{VBtn:h.value}},{default:()=>[n.actions({item:d,props:{onClick:()=>f(r,"dismissed")}})]}):t.createVNode(Vo,t.mergeProps(h.value,{onClick:()=>f(r,"dismissed")}),null)]):void 0}))])}),{clear:function(){l("update:modelValue",[]),v.value.toReversed().forEach((e,t)=>setTimeout(()=>{e.active=!1,e.onDismiss?.("cleared")},100*t))}}}}),sh=Tt({id:String,interactive:Boolean,text:String,color:String,...G(ms({closeOnBack:!1,location:"end",locationStrategy:"connected",eager:!0,minWidth:0,offset:10,openOnClick:!1,openOnHover:!0,origin:"auto",scrim:!1,scrollStrategy:"reposition",transition:null}),["absolute","retainFocus","captureFocus","disableInitialFocus"])},"VTooltip"),uh=Kt()({name:"VTooltip",props:sh(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),{scopeId:n}=ns(),{colorClasses:o,colorStyles:r}=zl(()=>({background:e.color})),i=t.useId(),s=t.toRef(()=>e.id||`v-tooltip-${i}`),u=t.ref(),c=t.computed(()=>e.location.split(" ").length>1?e.location:e.location+" center"),d=t.computed(()=>"auto"===e.origin||"overlap"===e.origin||e.origin.split(" ").length>1||e.location.split(" ").length>1?e.origin:e.origin+" center"),v=t.toRef(()=>null!=e.transition?e.transition:l.value?"scale-transition":"fade-transition"),p=t.computed(()=>t.mergeProps({"aria-describedby":s.value},e.activatorProps))
return sa(()=>{const i=fs.filterProps(e)
return t.createVNode(fs,t.mergeProps({ref:u,class:["v-tooltip",{"v-tooltip--interactive":e.interactive},e.class],style:[e.style],id:s.value},i,{contentClass:[o.value,e.contentClass],contentProps:t.mergeProps({style:[r.value]},e.contentProps),modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,transition:v.value,absolute:!0,location:c.value,origin:d.value,role:"tooltip",activatorProps:p.value,_disableGlobalStack:!0},n),{activator:a.activator,default:(...t)=>a.default?.(...t)??e.text})}),ir({},u)}}),ch=Tt({modelValue:Boolean,target:Object,index:{type:Number,default:null},value:{type:Number,default:0},titleFormat:{type:Function,default:e=>String(e.value)},offset:Number,contentClass:null,location:String},"VSparklineTooltip"),dh=Kt()({name:"VSparklineTooltip",props:ch(),emits:{afterLeave:()=>!0},setup:(e,{slots:a,emit:l})=>()=>t.createVNode(uh,{modelValue:e.modelValue,target:e.target,offset:e.offset,contentClass:e.contentClass,location:e.location,onAfterLeave:()=>l("afterLeave")},{default:()=>[null!==e.index&&(a.default?.({index:e.index,value:e.value})??e.titleFormat({index:e.index,value:e.value}))]})})
function vh(e,t,a=!1,l=75,n=!1){if(0===e.length)return""
const o=e.shift(),r=e[e.length-1]
return(a?`M${o.x} ${l-o.x+2} L${o.x} ${o.y}`:`M${o.x} ${o.y}`)+e.map((a,l)=>{const r=e[l+1],i=e[l-1]||o,s=r&&(c=a,d=i,ph((u=r).x+d.x)===ph(2*c.x)&&ph(u.y+d.y)===ph(2*c.y))
var u,c,d
if(!r)return n?`L${a.x} ${a.y}S${a.x} ${a.y} ${a.x} ${a.y}`:`L${a.x} ${a.y}`
if(s&&!n)return`L${a.x} ${a.y}`
const v=Math.min(mh(i,a),mh(r,a)),p=v/2<t?v/2:t,m=fh(i,a,p),f=fh(r,a,p)
return`L${m.x} ${m.y}S${a.x} ${a.y} ${f.x} ${f.y}`}).join("")+(a?`L${r.x} ${l-o.x+2} Z`:"")}function ph(e){return parseInt(e,10)}function mh(e,t){return Math.sqrt(Math.pow(t.x-e.x,2)+Math.pow(t.y-e.y,2))}function fh(e,t,a){const l=e.x-t.x,n=e.y-t.y,o=Math.sqrt(l*l+n*n),r=l/o,i=n/o
return{x:t.x+r*a,y:t.y+i*a}}const gh=Tt({animation:{type:[Boolean,Object],default:!1},autoDraw:{type:[Boolean,String],default:!1},autoDrawDuration:[Number,String],autoDrawEasing:{type:String,default:"ease"},color:String,gradient:{type:Array,default:()=>[]},gradientDirection:{type:String,validator:e=>["top","bottom","left","right"].includes(e),default:"top"},height:{type:[String,Number],default:75},labels:{type:Array,default:()=>[]},labelSize:{type:[Number,String],default:7},lineWidth:{type:[String,Number],default:4},id:String,itemValue:{type:String,default:"value"},modelValue:{type:Array,default:()=>[]},min:[String,Number],max:[String,Number],padding:{type:[String,Number],default:8},markerSize:{type:[Number,String],default:8},markerStroke:{type:String,default:"#fff"},inset:Boolean,showLabels:Boolean,showMarkers:Boolean,smooth:[Boolean,String,Number],smoothMode:{type:String,default:"default"},interactive:Boolean,tooltip:{type:[Boolean,Object],default:!1},width:{type:[Number,String],default:300}},"Line")
function hh(e,t){const a=e.length
if(0===a)return Array(t).fill(0)
if(1===a)return Array(t).fill(e[0])
const l=[]
for(let n=0;n<t;n++){const o=n/(t-1)*(a-1),r=Math.floor(o),i=Math.min(r+1,a-1),s=o-r
l.push(e[r]+(e[i]-e[r])*s)}return l}function yh(e,t,a){if(!t||e.length<2)return e
const l=e[0],n=e[1],o=e[e.length-1],r=e[e.length-2],i=(n.y-l.y)/(n.x-l.x),s=(o.y-r.y)/(o.x-r.x),u={x:0,y:l.y-l.x*i,value:l.value},c={x:a,y:o.y+(a-o.x)*s,value:o.value}
return[u,...e,c]}function bh(e,t){const a=y(t.smooth)?t.smooth?8:0:Number(t.smooth??0),l=e.slice()
return"monotone"===t.smoothMode?function(e,t,a=!1,l=75){if(0===e.length)return""
const n=e[0],o=e[e.length-1],r=a?`M${n.x} ${l-n.x+2} L${n.x} ${n.y}`:`M${n.x} ${n.y}`,i=a?`L${o.x} ${l-n.x+2} Z`:""
if(0===t||e.length<3)return r+e.slice(1).map(e=>`L${e.x} ${e.y}`).join("")+i
const s=Math.min(t/8,1),u=e.length,c=[]
for(let t=0;t<u-1;t++){const a=e[t+1].x-e[t].x
c[t]=0===a?0:(e[t+1].y-e[t].y)/a}const d=new Array(u)
d[0]=c[0],d[u-1]=c[u-2]
for(let e=1;e<u-1;e++)0===c[e-1]||0===c[e]||c[e-1]>0!=c[e]>0?d[e]=0:d[e]=(c[e-1]+c[e])/2
for(let e=0;e<u-1;e++)if(0===c[e])d[e]=0,d[e+1]=0
else{const t=d[e]/c[e],a=d[e+1]/c[e],l=t*t+a*a
if(l>9){const n=3/Math.sqrt(l)
d[e]=n*t*c[e],d[e+1]=n*a*c[e]}}const v=e.slice(1).map((t,a)=>{const l=e[a],n=t.x-l.x
return`C${l.x+n*s/3} ${l.y+d[a]*n*s/3} ${t.x-n*s/3} ${t.y-d[a+1]*n*s/3} ${t.x} ${t.y}`})
return r+v.join("")+i}(l,a,t.fill,t.height):vh(l,a,t.fill,t.height,t.animation)}const wh=Tt({autoLineWidth:Boolean,...gh()},"VBarline"),Vh=Kt()({name:"VBarline",inheritAttrs:!1,props:wh(),emits:{"update:currentIndex":e=>!0},setup(e,{slots:a,attrs:l,emit:n}){const o=t.useId(),r=t.computed(()=>e.id||`barline-${o}`),i=t.computed(()=>Number(e.autoDrawDuration)||500),s=t.ref(!1),u=t.shallowRef([]),c=t.computed(()=>b(e.animation)?e.animation.duration??300:300),d=t.computed(()=>b(e.animation)?e.animation.easing??"ease":"ease"),v=t.computed(()=>Boolean(e.showLabels||e.labels.length>0||!!a?.label)),p=t.computed(()=>parseFloat(e.lineWidth)||4),m=t.computed(()=>e.modelValue.map(t=>F(t,e.itemValue,t))),f=t.computed(()=>Math.max(m.value.length*p.value,Number(e.width))),g=t.computed(()=>({minX:0,maxX:f.value,minY:0,maxY:parseInt(e.height,10)}))
const h=t.computed(()=>function(t,a){const{minX:l,maxX:n,minY:o,maxY:r}=a,i=t.length
let s=null!=e.max?Number(e.max):Math.max(...t),u=null!=e.min?Number(e.min):Math.min(...t)
u>0&&null==e.min&&(u=0),s<0&&null==e.max&&(s=0)
const c=n/(1===i?2:i),d=(r-o)/(s-u||1),v=r-Math.abs(u*d)
return t.map((e,t)=>{const a=Math.abs(d*e)
return{x:l+t*c,y:v-a+Number(e<0)*a,height:a,value:e}})}(m.value,g.value)),w=t.ref(0)
function V(e,t,a){e.style.transition=`y ${t}ms ${a}, height ${t}ms ${a}`}function S(t){e.animation&&(u.value.forEach(e=>{e&&V(e,c.value,d.value)}),h.value.length>t&&t>0&&function(e,t,a,l){for(let n=t;n<e.length;n++){const t=u.value[n]
t&&(t.style.transition="none",t.setAttribute("y",String(e[n].y+e[n].height)),t.setAttribute("height","0"),t.getBoundingClientRect(),V(t,a,l),t.setAttribute("y",String(e[n].y)),t.setAttribute("height",String(e[n].height)))}}(h.value,t,c.value,d.value))}t.watch(()=>e.modelValue,async()=>{if(await t.nextTick(),R()||!u.value.length)return
const a=w.value
if(w.value=h.value.length,!e.autoDraw||"once"===e.autoDraw&&s.value)return void S(a)
s.value=!0
const l="once"===e.autoDraw
u.value.forEach((t,a)=>{const n=h.value[a]
t&&n&&(t.style.transition="none",t.setAttribute("y",String(n.y+n.height)),t.setAttribute("height","0"),t.getBoundingClientRect(),V(t,i.value,e.autoDrawEasing),t.setAttribute("y",String(n.y)),t.setAttribute("height",String(n.height)),l&&e.animation&&t.addEventListener("transitionend",()=>{V(t,c.value,d.value)},{once:!0}))})},{immediate:!0})
const k=t.computed(()=>h.value.map((t,a)=>({x:t.x,value:String(e.labels[a]??t.value)}))),x=t.computed(()=>1===h.value.length?(g.value.maxX-p.value)/2:(Math.abs(h.value[0].x-h.value[1].x)-p.value)/2),N=t.computed(()=>y(e.smooth)?e.smooth?2:0:Number(e.smooth)),C=t.computed(()=>{const e=h.value.length
return f.value/(1===e?2:e)}),E=t.shallowRef(null),I=t.shallowRef(null),A=t.shallowRef(!1),P=t.shallowRef(0),_=t.shallowRef(0),D=t.shallowRef(0)
t.watch(I,e=>{if(null===e)return
const t=h.value[e]
t&&(P.value=t.x+x.value,_.value=t.y,D.value=t.height)})
const B={duration:150,transition:ta.easeOutQuad},T=aa(P,B),$=aa(_,B),M=t.computed(()=>{if(null===I.value||!E.value)return
const e=E.value.getScreenCTM()
if(!e)return
const t=E.value.createSVGPoint()
t.x=T.value+p.value/2,t.y=$.value
const{x:a,y:l}=t.matrixTransform(e)
return[a,l]}),z=t.computed(()=>({showCrosshair:!1,titleFormat:e=>String(e.value),...b(e.tooltip)?e.tooltip:{}}))
let L=-1
function O(e){const t=e.currentTarget
cancelAnimationFrame(L),L=requestAnimationFrame(()=>{const a=t.getBoundingClientRect(),l=(e.clientX-a.left)/a.width*f.value
let o=0,r=1/0
h.value.forEach((e,t)=>{const a=e.x+x.value+p.value/2,n=Math.abs(a-l)
n<r&&(r=n,o=t)}),I.value=o,n("update:currentIndex",o),A.value=!0})}function j(){cancelAnimationFrame(L),A.value=!1,e.tooltip||(I.value=null,n("update:currentIndex",null))}function H(){I.value=null,n("update:currentIndex",null)}function W(e){I.value=e,n("update:currentIndex",e),A.value=null!==e}function U(){h.value.length&&W(h.value.length-1)}function Y(){A.value=!1,e.tooltip||W(null)}function G(e){if(!h.value.length)return
const t=h.value.length
if("ArrowLeft"===e.key||"ArrowRight"===e.key){e.preventDefault()
const a="ArrowLeft"===e.key?-1:1,l=I.value??(1===a?-1:t)
W(Math.max(0,Math.min(t-1,l+a)))}}sa(()=>{const n=e.gradient.slice().length?e.gradient.slice().reverse():[""]
return t.createElementVNode(t.Fragment,null,[t.createElementVNode("svg",t.mergeProps({ref:E,display:"block",tabindex:e.interactive?0:void 0,onMousemove:e.interactive?O:void 0,onMouseleave:e.interactive?j:void 0,onFocus:e.interactive?U:void 0,onBlur:e.interactive?Y:void 0,onKeydown:e.interactive?G:void 0},l),[t.createElementVNode("defs",null,[t.createElementVNode("linearGradient",{id:r.value,gradientUnits:"userSpaceOnUse",x1:"left"===e.gradientDirection?"100%":"0",y1:"top"===e.gradientDirection?"100%":"0",x2:"right"===e.gradientDirection?"100%":"0",y2:"bottom"===e.gradientDirection?"100%":"0"},[n.map((e,a)=>t.createElementVNode("stop",{offset:a/Math.max(n.length-1,1),"stop-color":e||"currentColor"},null))])]),t.createElementVNode("clipPath",{id:`${r.value}-clip`},[h.value.map((e,a)=>t.createElementVNode("rect",{ref:e=>{e&&(u.value[a]=e)},x:e.x+x.value,y:e.y,width:p.value,height:e.height,rx:N.value,ry:N.value},null))]),v.value&&t.createElementVNode("g",{key:"labels",style:{textAnchor:"middle",dominantBaseline:"mathematical",fill:"currentColor"}},[k.value.map((l,n)=>t.createElementVNode("text",{x:l.x+x.value+p.value/2,y:parseInt(e.height,10)-2+(parseInt(e.labelSize,10)||5.25),"font-size":Number(e.labelSize)||7},[a.label?.({index:n,value:l.value})??l.value]))]),e.interactive&&null!==I.value&&t.createElementVNode("rect",{key:"highlight",x:T.value-x.value,y:0,width:C.value,height:e.height,fill:"currentColor",opacity:.1,"pointer-events":"none"},null),t.createElementVNode("g",{"clip-path":`url(#${r.value}-clip)`,fill:`url(#${r.value})`},[t.createElementVNode("rect",{x:0,y:0,width:f.value,height:e.height},null)])]),!!e.tooltip&&t.createVNode(dh,{key:"tooltip",modelValue:A.value,target:M.value,index:I.value,value:null!==I.value?h.value[I.value].value:0,offset:z.value.offset,contentClass:z.value.class,titleFormat:z.value.titleFormat,location:"top center",onAfterLeave:H},{default:a.tooltip})])})}}),Sh=Tt({fill:Boolean,...gh()},"VTrendline"),kh=Kt()({name:"VTrendline",inheritAttrs:!1,props:Sh(),emits:{"update:currentIndex":e=>!0},setup(e,{slots:a,attrs:l,emit:n}){const o=t.useId(),r=t.computed(()=>e.id||`trendline-${o}`),i=t.computed(()=>Number(e.autoDrawDuration)||(e.fill?500:2e3)),s=t.ref(!1),u=t.ref(null),c=t.ref(null),d=t.computed(()=>b(e.animation)?e.animation.duration??300:300),v=t.computed(()=>b(e.animation)?e.animation.easing??"ease":"ease")
function p(t,a){const{minX:l,maxX:n,minY:o,maxY:r}=a
1===t.length&&(t=[t[0],t[0]])
const i=t.length,s=null!=e.max?Number(e.max):Math.max(...t),u=null!=e.min?Number(e.min):Math.min(...t),c=(n-l)/(i-1),d=(r-o)/(s-u||1)
return t.map((e,t)=>({x:l+t*c,y:r-(e-u)*d,value:e}))}const m=t.computed(()=>Boolean(e.showLabels||e.labels.length>0||!!a?.label)),f=t.computed(()=>Number(e.width)),g=t.computed(()=>{const t=Number(e.padding)
return{minX:t,maxX:f.value-t,minY:t,maxY:parseInt(e.height,10)-t}}),y=t.computed(()=>e.modelValue.map(t=>F(t,e.itemValue,t))),w=t.ref(0)
t.watch(y,(t,a)=>{if(!e.animation)return
const l=w.value
if(t.length>l&&(w.value=t.length,l>0&&a)){const e=hh(a,w.value)
for(const[t,a]of[[c,!1],[u,!0]]){const l=t.value
l&&l.setAttribute("d",x(e,a))}}},{immediate:!0})
const V=t.computed(()=>e.animation&&w.value&&y.value.length!==w.value?hh(y.value,w.value):y.value),S=t.computed(()=>p(V.value,g.value)),k=t.computed(()=>yh(S.value,e.inset,f.value))
function x(t,a){return bh(h(t[0])?yh(p(t,g.value),e.inset,f.value):t,{smooth:e.smooth,smoothMode:e.smoothMode,height:parseInt(e.height,10),fill:a,animation:!!e.animation})}const N=t.computed(()=>{const t=[],a=S.value.length
for(let l=0;t.length<a;l++){const a=S.value[l]
let n=e.labels[l]
n||(n=a.value),t.push({x:a.x,value:String(n)})}return t})
function C(e,t,a){e.style.transition=`d ${t}ms ${a}`}t.watch(()=>e.modelValue,async()=>{if(await t.nextTick(),R())return
if(!e.autoDraw){if(e.animation&&c.value)for(const e of[u.value,c.value])e&&C(e,d.value,v.value)
return}if(!c.value)return
if("once"===e.autoDraw&&s.value)return
s.value=!0
const a="once"===e.autoDraw
if(e.fill)for(const t of[u.value,c.value]){if(!t)continue
t.style.transformOrigin="bottom center",t.style.transition="none",t.style.transform="scaleY(0)",t.getBoundingClientRect()
const l=e.animation?`, d ${d.value}ms ${v.value}`:""
t.style.transition=`transform ${i.value}ms ${e.autoDrawEasing}${l}`,t.style.transform="scaleY(1)",a&&t.addEventListener("transitionend",a=>{"transform"===a.propertyName&&(t.style.transform="",t.style.transformOrigin="",e.animation?C(t,d.value,v.value):t.style.transition="")},{once:!0})}else{const t=c.value,l=t.getTotalLength()
t.style.transition="none",t.style.strokeDasharray=`${l}`,t.style.strokeDashoffset=`${l}`,t.getBoundingClientRect()
const n=e.animation?`, d ${d.value}ms ${v.value}`:""
t.style.transition=`stroke-dashoffset ${i.value}ms ${e.autoDrawEasing}${n}`,t.style.strokeDashoffset="0",a&&t.addEventListener("transitionend",a=>{"stroke-dashoffset"===a.propertyName&&(t.style.strokeDasharray="",t.style.strokeDashoffset="",e.animation?C(t,d.value,v.value):t.style.transition="")},{once:!0})}},{immediate:!0})
const E=t.shallowRef(null),I=t.shallowRef(null),A=t.shallowRef(!1),P=t.computed(()=>null!==I.value?S.value[I.value]:null)
const _=t.shallowRef(0)
t.watch(P,e=>{e&&c.value&&(_.value=function(e,t){let a=0,l=e.getTotalLength()
for(let n=0;n<32;n++){const n=(a+l)/2
e.getPointAtLength(n).x<t?a=n:l=n}return(a+l)/2}(c.value,e.x))})
const D=aa(_,{duration:150,transition:ta.easeOutQuad}),B=t.computed(()=>{const{x:e,y:t}=c.value?.getPointAtLength(D.value)??{x:0,y:0}
return{x:e,y:t}}),T=t.computed(()=>{if(!P.value||!E.value)return
const e=E.value.getScreenCTM()
if(!e)return
const t=E.value.createSVGPoint()
t.x=B.value.x,t.y=B.value.y
const{x:a,y:l}=t.matrixTransform(e)
return[a,l]}),$=t.computed(()=>({showCrosshair:!0,offset:16,titleFormat:e=>String(e.value),...b(e.tooltip)?e.tooltip:{}}))
let M=-1
function z(t){const a=t.currentTarget
cancelAnimationFrame(M),M=requestAnimationFrame(()=>{const l=a.getBoundingClientRect(),o=(t.clientX-l.left)/l.width*Number(e.width)
let r=0,i=1/0
S.value.forEach((e,t)=>{const a=Math.abs(e.x-o)
a<i&&(i=a,r=t)}),I.value=r,n("update:currentIndex",r),A.value=!0})}function L(){cancelAnimationFrame(M),A.value=!1,e.tooltip||(I.value=null,n("update:currentIndex",null))}function O(){I.value=null,n("update:currentIndex",null)}function j(e){I.value=e,n("update:currentIndex",e),A.value=null!==e}function H(){S.value.length&&j(S.value.length-1)}function W(){A.value=!1,e.tooltip||j(null)}function U(e){if(!S.value.length)return
const t=S.value.length
if("ArrowLeft"===e.key||"ArrowRight"===e.key){e.preventDefault()
const a="ArrowLeft"===e.key?-1:1,l=I.value??(1===a?-1:t)
j(Math.max(0,Math.min(t-1,l+a)))}}sa(()=>{const n=e.gradient.slice().length?e.gradient.slice().reverse():[""],o=(parseFloat(e.markerSize)||8)/2
return t.createElementVNode(t.Fragment,null,[t.createElementVNode("svg",t.mergeProps({ref:E,display:"block","stroke-width":parseFloat(e.lineWidth)??4,tabindex:e.interactive?0:void 0,onMousemove:e.interactive?z:void 0,onMouseleave:e.interactive?L:void 0,onFocus:e.interactive?H:void 0,onBlur:e.interactive?W:void 0,onKeydown:e.interactive?U:void 0},l),[t.createElementVNode("defs",null,[t.createElementVNode("linearGradient",{id:r.value,gradientUnits:"userSpaceOnUse",x1:"left"===e.gradientDirection?"100%":"0",y1:"top"===e.gradientDirection?"100%":"0",x2:"right"===e.gradientDirection?"100%":"0",y2:"bottom"===e.gradientDirection?"100%":"0"},[n.map((e,a)=>t.createElementVNode("stop",{offset:a/Math.max(n.length-1,1),"stop-color":e||"currentColor"},null))])]),m.value&&t.createElementVNode("g",{key:"labels",style:{textAnchor:"middle",dominantBaseline:"mathematical",fill:"currentColor"}},[N.value.map((l,n)=>t.createElementVNode("text",{x:l.x,y:parseInt(e.height,10)-4+(parseInt(e.labelSize,10)||5.25),"font-size":Number(e.labelSize)||7},[a.label?.({index:n,value:l.value})??l.value]))]),t.createElementVNode("path",{key:"fill",ref:e.fill?u:c,d:x(k.value,e.fill),fill:e.fill?`url(#${r.value})`:"none",stroke:e.fill?"none":`url(#${r.value})`},null),e.fill&&t.createElementVNode("path",{key:"trendline",ref:c,d:x(k.value,!1),fill:"none",stroke:"currentColor"},null),e.showMarkers&&t.createElementVNode("g",{key:"markers"},[S.value.map((a,l)=>t.createElementVNode("circle",{key:l,cx:a.x,cy:a.y,r:o,fill:"currentColor",stroke:e.markerStroke,"stroke-width":2,"pointer-events":"none"},null))]),e.interactive&&P.value&&t.createElementVNode("g",{key:"hover","pointer-events":"none"},[$.value.showCrosshair&&t.createElementVNode("line",{key:"crosshair-line",x1:B.value.x,y1:e.inset?0:g.value.minY,x2:B.value.x,y2:e.inset?parseInt(e.height,10):g.value.maxY,stroke:"currentColor","stroke-width":1,"stroke-dasharray":"4 2",opacity:.5},null),t.createElementVNode("circle",{key:"marker",cx:B.value.x,cy:B.value.y,r:o,fill:"currentColor",stroke:e.markerStroke,"stroke-width":2},null)])]),!!e.tooltip&&t.createVNode(dh,{key:"tooltip",modelValue:A.value,target:T.value,index:I.value,value:null!==I.value?S.value[I.value].value:0,offset:$.value.offset,contentClass:$.value.class,titleFormat:$.value.titleFormat,onAfterLeave:O},{default:a.tooltip})])})}}),xh=Tt({type:{type:String,default:"trend"},...wh(),...Sh()},"VSparkline"),Nh=Kt()({name:"VSparkline",props:xh(),emits:{"update:currentIndex":e=>!0},setup(e,{slots:a,emit:l}){const{textColorClasses:n,textColorStyles:o}=Ll(()=>e.color),r=t.computed(()=>Boolean(e.showLabels||e.labels.length>0||!!a?.label)),i=t.computed(()=>{let t=parseInt(e.height,10)
return r.value&&(t+=1.5*parseInt(e.labelSize,10)),t})
sa(()=>{const r="trend"===e.type?kh:Vh,s="trend"===e.type?kh.filterProps(e):Vh.filterProps(e)
return t.createVNode(r,t.mergeProps({key:e.type,class:n.value,style:o.value,viewBox:`0 0 ${e.width} ${i.value}`},s,{"onUpdate:currentIndex":e=>l("update:currentIndex",e)}),a)})}}),Ch=Tt({...Ft(),...gs({offset:8,minWidth:0,openDelay:0,closeDelay:100,location:"top center",transition:"scale-transition"})},"VSpeedDial"),Eh=Kt()({name:"VSpeedDial",props:Ch(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=_a(e,"modelValue"),n=Ut("VBtn"),o=t.ref(),r=t.computed(()=>{const[t,a="center"]=e.location?.split(" ")??[]
return`${t} ${a}`}),i=t.computed(()=>({[`v-speed-dial__content--${r.value.replace(" ","-")}`]:!0}))
return sa(()=>{const s=hs.filterProps(e)
return t.createVNode(hs,t.mergeProps(s,{modelValue:l.value,"onUpdate:modelValue":e=>l.value=e,class:e.class,style:e.style,contentClass:["v-speed-dial__content",i.value,e.contentClass],location:r.value,ref:o,transition:"fade-transition"}),{...a,default:l=>t.createVNode(Bl,{defaults:{VBtn:{size:n.value?.size??"small"}}},{default:()=>[t.createVNode(Xl,{appear:!0,group:!0,transition:e.transition},{default:()=>[a.default?.(l)]})]})})}),{}}}),Ih=Symbol.for("vuetify:v-stepper"),Ah=Tt({color:String,disabled:{type:[Boolean,String],default:!1},prevText:{type:String,default:"$vuetify.stepper.prev"},nextText:{type:String,default:"$vuetify.stepper.next"}},"VStepperActions"),Ph=Kt()({name:"VStepperActions",props:Ah(),emits:{"click:prev":()=>!0,"click:next":()=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),o=Ut("VBtn"),r=Wt("VStepperActionsPrevBtn"),i=Wt("VStepperActionsNextBtn")
function s(){a("click:prev")}function u(){a("click:next")}return sa(()=>{const a={onClick:s},c={onClick:u},d={disabled:["prev",!0].includes(e.disabled),text:n(e.prevText),variant:r.value?.variant??o.value?.variant??"text"},v={color:e.color,disabled:["next",!0].includes(e.disabled),text:n(e.nextText),variant:i.value?.variant??o.value?.variant??"tonal"}
return t.createElementVNode("div",{class:"v-stepper-actions"},[t.createVNode(Bl,{defaults:{VBtn:d,VStepperActionsPrevBtn:{...o.value,...r.value,...d}}},{default:()=>[l.prev?.({props:a})??t.createVNode(Vo,t.mergeProps({_as:"VStepperActionsPrevBtn"},a),null)]}),t.createVNode(Bl,{defaults:{VBtn:v,VStepperActionsNextBtn:{...o.value,...i.value,...v}}},{default:()=>[l.next?.({props:c})??t.createVNode(Vo,t.mergeProps({_as:"VStepperActionsNextBtn"},c),null)]})])}),{}}}),_h=qt("v-stepper-header"),Rh=Tt({color:String,title:String,subtitle:String,complete:Boolean,completeIcon:{type:ua,default:"$complete"},editable:Boolean,editIcon:{type:ua,default:"$edit"},error:Boolean,errorIcon:{type:ua,default:"$error"},icon:ua,ripple:{type:[Boolean,Object],default:!0},rules:{type:Array,default:()=>[]}},"StepperItem"),Dh=Tt({...Rh(),...Pn()},"VStepperItem"),Bh=Kt()({name:"VStepperItem",directives:{vRipple:bo},props:Dh(),emits:{"group:selected":e=>!0},setup(e,{slots:a}){const l=_n(e,Ih,!0),n=t.computed(()=>l?.value.value??e.value),o=t.computed(()=>e.rules.every(e=>!0===e())),r=t.computed(()=>!e.disabled&&e.editable),i=t.computed(()=>!e.disabled&&e.editable),s=t.computed(()=>e.error||!o.value),u=t.computed(()=>e.complete||e.rules.length>0&&o.value),c=t.computed(()=>s.value?e.errorIcon:u.value?e.completeIcon:l.isSelected.value&&e.editable?e.editIcon:e.icon),d=t.computed(()=>({canEdit:i.value,hasError:s.value,hasCompleted:u.value,title:e.title,subtitle:e.subtitle,step:n.value,value:e.value}))
return sa(()=>{const o=(!l||l.isSelected.value||u.value||i.value)&&!s.value&&!e.disabled,v=!(null==e.title&&!a.title),p=!(null==e.subtitle&&!a.subtitle)
return t.withDirectives(t.createElementVNode("button",{class:t.normalizeClass(["v-stepper-item",{"v-stepper-item--complete":u.value,"v-stepper-item--disabled":e.disabled,"v-stepper-item--error":s.value},l?.selectedClass.value]),disabled:!e.editable,type:"button",onClick:function(){l?.toggle()}},[r.value&&xn(!0,"v-stepper-item"),t.createVNode(Bo,{key:"stepper-avatar",class:"v-stepper-item__avatar",color:o?e.color:void 0,size:24},{default:()=>[a.icon?.(d.value)??(c.value?t.createVNode(Mn,{icon:c.value},null):n.value)]}),t.createElementVNode("div",{class:"v-stepper-item__content"},[v&&t.createElementVNode("div",{key:"title",class:"v-stepper-item__title"},[a.title?.(d.value)??e.title]),p&&t.createElementVNode("div",{key:"subtitle",class:"v-stepper-item__subtitle"},[a.subtitle?.(d.value)??e.subtitle]),a.default?.(d.value)])]),[[bo,e.editable&&e.ripple,null]])}),{}}}),Th=Tt({...G($d(),["continuous","nextIcon","prevIcon","showArrows","touch","mandatory"])},"VStepperWindow"),Fh=Kt()({name:"VStepperWindow",props:Th(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=t.inject(Ih,null),n=_a(e,"modelValue"),o=t.computed({get:()=>null==n.value&&l?l.items.value.find(e=>l.selected.value.includes(e.id))?.value:n.value,set(e){n.value=e}})
return sa(()=>{const l=Md.filterProps(e)
return t.createVNode(Md,t.mergeProps({_as:"VStepperWindow"},l,{modelValue:o.value,"onUpdate:modelValue":e=>o.value=e,class:["v-stepper-window",e.class],style:e.style,mandatory:!1,touch:!1}),a)}),{}}}),$h=Tt({...Od()},"VStepperWindowItem"),Mh=Kt()({name:"VStepperWindowItem",props:$h(),setup:(e,{slots:a})=>(sa(()=>{const l=jd.filterProps(e)
return t.createVNode(jd,t.mergeProps({_as:"VStepperWindowItem"},l,{class:["v-stepper-window-item",e.class],style:e.style}),a)}),{})}),zh=Tt({altLabels:Boolean,bgColor:String,completeIcon:ua,editIcon:ua,editable:Boolean,errorIcon:ua,hideActions:Boolean,items:{type:Array,default:()=>[]},itemTitle:{type:[String,Array,Function],default:"title"},itemValue:{type:[String,Array,Function],default:"value"},itemProps:{type:[Boolean,String,Array,Function],default:"props"},nonLinear:Boolean,flat:Boolean,...hr()},"Stepper"),Lh=Tt({...zh(),...An({mandatory:"force",selectedClass:"v-stepper-item--selected"}),...ys(),...U(Ah(),["prevText","nextText"])},"VStepper"),Oh=Kt()({name:"VStepper",props:Lh(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const{items:l,next:n,prev:o,selected:r}=Rn(e,Ih),{displayClasses:i,mobile:s}=yr(e),{completeIcon:u,editIcon:c,errorIcon:d,color:v,editable:p,prevText:m,nextText:f}=t.toRefs(e),g=t.computed(()=>e.items.map((t,a)=>{const l={title:F(t,e.itemTitle,t),value:F(t,e.itemValue,a+1),...!0===e.itemProps?t:F(t,e.itemProps)}
return{title:l.title,value:l.value,props:l,raw:t}})),h=t.computed(()=>l.value.findIndex(e=>r.value.includes(e.id)))
return Ht({VStepperItem:{editable:p,errorIcon:d,completeIcon:u,editIcon:c,prevText:m,nextText:f},VStepperActions:{color:v,disabled:t.computed(()=>e.disabled?e.disabled:0===h.value?"prev":h.value===l.value.length-1&&"next"),prevText:m,nextText:f}}),sa(()=>{const l=bs.filterProps(e),r=!(!a.header&&!e.items.length),u=e.items.length>0,c=!(e.hideActions||!u&&!a.actions)
return t.createVNode(bs,t.mergeProps(l,{color:e.bgColor,class:["v-stepper",{"v-stepper--alt-labels":e.altLabels,"v-stepper--flat":e.flat,"v-stepper--non-linear":e.nonLinear,"v-stepper--mobile":s.value},i.value,e.class],style:e.style}),{default:()=>[r&&t.createVNode(_h,{key:"stepper-header"},{default:()=>[g.value.map(({raw:e,...l},n)=>t.createElementVNode(t.Fragment,null,[!!n&&t.createVNode(zr,null,null),t.createVNode(Bh,l.props,{default:a[`header-item.${l.value}`]??a.header,icon:a.icon,title:a.title,subtitle:a.subtitle})]))]}),u&&t.createVNode(Fh,{key:"stepper-window"},{default:()=>[g.value.map(e=>t.createVNode(Mh,{value:e.value},{default:()=>a[`item.${e.value}`]?.(e)??a.item?.(e)}))]}),a.default?.({prev:o,next:n}),c&&(a.actions?.({next:n,prev:o})??t.createVNode(Ph,{key:"stepper-actions","onClick:prev":o,"onClick:next":n},a))]})}),{prev:o,next:n}}}),jh=Tt({...Ah()},"VStepperActions"),Hh=Kt()({name:"VStepperVerticalActions",props:jh(),emits:{"click:prev":()=>!0,"click:next":()=>!0},setup(e,{emit:a,slots:l}){function n(){a("click:prev")}function o(){a("click:next")}return sa(()=>{const a=Ph.filterProps(e)
return t.createVNode(Ph,t.mergeProps({class:"v-stepper-vertical-actions"},a,{"onClick:prev":n,"onClick:next":o}),l)}),{}}}),Wh=Tt({hideActions:Boolean,...Rh(),...G(of({expandIcon:"",collapseIcon:""}),["hideActions"])},"VStepperVerticalItem"),Uh=Kt()({name:"VStepperVerticalItem",props:Wh(),emits:{"click:next":()=>!0,"click:prev":()=>!0,"click:finish":()=>!0},setup(e,{emit:a,slots:l}){const n=t.ref(),o=t.computed(()=>isNaN(parseInt(e.value))?e.value:Number(e.value)),r=t.computed(()=>n.value?.groupItem),i=t.computed(()=>e.rules.every(e=>!0===e())),s=t.computed(()=>!e.disabled&&e.editable),u=t.computed(()=>e.error||!i.value),c=t.computed(()=>e.complete||e.rules.length>0&&i.value),d=t.computed(()=>e.disabled?e.disabled:!!r.value?.isFirst.value&&"prev"),v=t.computed(()=>u.value?e.errorIcon:c.value?e.completeIcon:r.value?.isSelected.value&&e.editable?e.editIcon:e.icon),p=t.computed(()=>({canEdit:s.value,hasError:u.value,hasCompleted:c.value,title:e.title,subtitle:e.subtitle,step:o.value})),m=t.computed(()=>({...p.value,prev:g,next:f}))
function f(){a("click:next"),r.value?.isLast.value||r.value.group.next()}function g(){a("click:prev"),r.value.group.prev()}return sa(()=>{const a=(!r.value||r.value?.isSelected.value||c.value||s.value)&&!u.value&&!e.disabled,i=!e.hideActions||!!l.actions,h=rf.filterProps(e)
return t.createVNode(rf,t.mergeProps({_as:"VStepperVerticalItem",ref:n},h,{class:["v-stepper-vertical-item",{"v-stepper-vertical-item--complete":c.value,"v-stepper-vertical-item--disabled":e.disabled,"v-stepper-vertical-item--editable":s.value,"v-stepper-vertical-item--error":u.value},e.class],readonly:!e.editable,style:e.style,color:"",hideActions:!1,value:o.value}),{title:()=>t.createElementVNode(t.Fragment,null,[t.createVNode(Bo,{key:"stepper-avatar",class:"v-stepper-vertical-item__avatar",color:a?e.color:void 0,size:24,start:!0},{default:()=>[l.icon?.(p.value)??(v.value?t.createVNode(Mn,{icon:v.value},null):o.value)]}),t.createElementVNode("div",null,[t.createElementVNode("div",{class:"v-stepper-vertical-item__title"},[l.title?.(p.value)??e.title]),t.createElementVNode("div",{class:"v-stepper-vertical-item__subtitle"},[l.subtitle?.(p.value)??e.subtitle])])]),text:()=>t.createElementVNode(t.Fragment,null,[l.default?.(p.value)??e.text,i&&t.createVNode(Bl,{defaults:{VStepperVerticalActions:{disabled:d.value,finish:r.value?.isLast.value}}},{default:()=>[l.actions?.(m.value)??t.createVNode(Hh,{"onClick:next":f,"onClick:prev":g},{prev:l.prev?()=>l.prev?.(m.value):void 0,next:l.next?()=>l.next?.(m.value):void 0})]})])})}),{}}}),Yh=Tt({prevText:{type:String,default:"$vuetify.stepper.prev"},nextText:{type:String,default:"$vuetify.stepper.next"},...zh(),...G(uf({mandatory:"force",variant:"accordion"}),["static"])},"VStepperVertical"),Gh=Kt()({name:"VStepperVertical",props:Yh(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=t.ref(),{color:n,eager:o,editable:r,prevText:i,nextText:s,hideActions:u}=t.toRefs(e),c=_a(e,"modelValue"),d=t.computed(()=>e.items.map((t,a)=>{const l={title:F(t,e.itemTitle,t),value:F(t,e.itemValue,a+1),...!0===e.itemProps?t:F(t,e.itemProps)}
return{title:l.title,value:l.value,props:l,raw:t}}))
return Ht({VStepperVerticalItem:{color:n,eager:o,editable:r,hideActions:u,static:!0},VStepperVerticalActions:{color:n,nextText:s,prevText:i}}),sa(()=>{const n=cf.filterProps(e)
return t.createVNode(cf,t.mergeProps(n,{modelValue:c.value,"onUpdate:modelValue":e=>c.value=e,ref:l,class:["v-stepper",{"v-stepper--alt-labels":e.altLabels,"v-stepper--flat":e.flat,"v-stepper--non-linear":e.nonLinear,"v-stepper--mobile":e.mobile},e.class],style:e.style}),{...a,default:({prev:e,next:l})=>t.createElementVNode(t.Fragment,null,[d.value.map(({raw:e,...l})=>t.createVNode(Uh,l.props,{...a,default:a[`item.${l.value}`]})),a.default?.({prev:e,next:l,step:c.value})])})}),{}}}),Kh=Tt({inset:{type:[Boolean,String],default:!1},flat:Boolean,thumbColor:String,loading:{type:[Boolean,String],default:!1},...G(lr(),["glow"]),...Oo(),...Vn()},"VSwitch"),qh=["x-small","small","default","large","x-large"],Xh={"x-small":11,small:14,default:16,large:18,"x-large":22},Zh=Kt()({name:"VSwitch",inheritAttrs:!1,props:Kh(),emits:{"update:focused":e=>!0,"update:modelValue":e=>!0,"update:indeterminate":e=>!0},setup(e,{attrs:a,slots:l}){const n=_a(e,"indeterminate"),o=_a(e,"modelValue"),{loaderClasses:r}=Kn(e),{isFocused:i,focus:s,blur:u}=qo(e),{backgroundColorClasses:c,backgroundColorStyles:d}=Ol(()=>e.thumbColor),v=t.ref(),p=t.ref(),m=_&&window.matchMedia("(forced-colors: active)").matches,f=t.toRef(()=>g(e.loading)&&""!==e.loading?e.loading:e.color),h=t.useId(),y=t.toRef(()=>e.id||`switch-${h}`),b=t.toRef(()=>qh.includes(e.size)),w=t.toRef(()=>b.value?Xh[e.size]:Math.round(16*Number(e.size)/32))
function V(){n.value&&(n.value=!1)}function S(e){e.stopPropagation(),e.preventDefault(),v.value?.input?.click()}return sa(()=>{const[g,h]=J(a),k=nr.filterProps(e),x=jo.filterProps(e),N=["material","square"].includes(String(e.inset)),C=!m&&!!e.thumbColor
return t.createVNode(nr,t.mergeProps({ref:p,class:["v-switch",{"v-switch--flat":e.flat},{"v-switch--inset":!!e.inset},{"v-switch--inset-material":N},{"v-switch--inset-square":"square"===e.inset},{"v-switch--indeterminate":n.value},b.value?`v-switch--size-${e.size}`:void 0,r.value,e.class]},g,k,{modelValue:o.value,"onUpdate:modelValue":e=>o.value=e,id:y.value,focused:i.value,style:[{"--v-switch-scale":b.value?void 0:Number(e.size)/32},e.style]}),{...l,default:({id:a,messagesId:r,isDisabled:i,isReadonly:p,isValid:g})=>{const y={model:o,isValid:g}
return t.createVNode(jo,t.mergeProps({ref:v},x,{modelValue:o.value,"onUpdate:modelValue":[e=>o.value=e,V],id:a.value,"aria-describedby":r.value,type:"checkbox","aria-checked":n.value?"mixed":void 0,disabled:i.value,readonly:p.value,onFocus:s,onBlur:u},h),{...l,default:({backgroundColorClasses:e,backgroundColorStyles:a})=>t.createElementVNode("div",{class:t.normalizeClass(["v-switch__track",m?void 0:e.value]),style:t.normalizeStyle(a.value),onClick:S},[l["track-true"]&&t.createElementVNode("div",{key:"prepend",class:"v-switch__track-true"},[l["track-true"](y)]),l["track-false"]&&t.createElementVNode("div",{key:"append",class:"v-switch__track-false"},[l["track-false"](y)])]),input:({inputNode:a,icon:n,model:o,backgroundColorClasses:r,backgroundColorStyles:i,textColorClasses:s,textColorStyles:u})=>t.createElementVNode(t.Fragment,null,[a,t.createElementVNode("div",{class:t.normalizeClass(["v-switch__thumb",{"v-switch__thumb--filled":n||e.loading},m?void 0:C&&o.value?c.value:N?r.value:e.inset?void 0:r.value]),style:t.normalizeStyle([C&&o.value?d.value:N?r.value.length||i.value.backgroundColor?{backgroundColor:"currentColor"}:void 0:e.inset?void 0:i.value])},[l.thumb?t.createVNode(Bl,{defaults:{VIcon:{icon:n,size:N?w.value:"x-small"}}},{default:()=>[l.thumb({...y,icon:n})]}):t.createVNode(Vl,null,{default:()=>[e.loading?t.createVNode(qn,{name:"v-switch",active:!0,color:!1===g.value?void 0:f.value},{default:e=>l.loader?l.loader(e):t.createVNode(Hn,{active:e.isActive,color:e.color,indeterminate:!0,size:w.value,width:"2"},null)}):n&&t.createVNode(Mn,{key:String(n),class:t.normalizeClass(N?s.value:void 0),style:t.normalizeStyle(N?u.value:void 0),icon:n,size:N?w.value:"x-small"},null)]})])])})}})}),ir({},p)}}),Qh=Tt({color:String,height:[Number,String],window:Boolean,...Ft(),...nn(),...Ca(),...Gl(),...ol(),...Ga()},"VSystemBar"),Jh=Kt()({name:"VSystemBar",props:Qh(),setup(e,{slots:a}){const{themeClasses:l}=tl(e),{backgroundColorClasses:n,backgroundColorStyles:o}=Ol(()=>e.color),{elevationClasses:r}=on(e),{roundedClasses:i,roundedStyles:s}=Kl(e),{ssrBootStyles:u}=mn(),c=t.computed(()=>e.height??(e.window?32:24)),{layoutItemStyles:d}=Ia({id:e.name,order:t.computed(()=>parseInt(e.order,10)),position:t.shallowRef("top"),layoutSize:c,elementSize:c,active:t.computed(()=>!0),absolute:t.toRef(()=>e.absolute)})
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-system-bar",{"v-system-bar--window":e.window},l.value,n.value,r.value,i.value,e.class]),style:t.normalizeStyle([o.value,d.value,u.value,s.value,e.style])},a)),{}}}),ey=Symbol.for("vuetify:v-tabs"),ty=Tt({fixed:Boolean,sliderColor:String,sliderTransition:String,sliderTransitionDuration:[String,Number],hideSlider:Boolean,inset:Boolean,direction:{type:String,default:"horizontal"},...G(wo({selectedClass:"v-tab--selected",variant:"text"}),["active","block","flat","location","position","symbol"])},"VTab"),ay=Kt()({name:"VTab",props:ty(),setup(e,{slots:a,attrs:l}){const{textColorClasses:n,textColorStyles:o}=Ll(()=>e.sliderColor),{backgroundColorClasses:r,backgroundColorStyles:i}=Ol(()=>e.sliderColor),s=t.ref(),u=t.ref(),c=t.computed(()=>"horizontal"===e.direction),d=t.computed(()=>s.value?.group?.isSelected.value??!1)
function v(e,t){return{opacity:[0,1]}}function p(t,a){return"vertical"===e.direction?{transform:["scaleY(0)","scaleY(1)"]}:{transform:["scaleX(0)","scaleX(1)"]}}function m(e,t){const a=t.getBoundingClientRect(),l=e.getBoundingClientRect(),n=c.value?"x":"y",o=c.value?"X":"Y",r=c.value?"right":"bottom",i=c.value?"width":"height",s=a[n]>l[n]?a[r]-l[r]:a[n]-l[n],u=Math.sign(s)>0?c.value?"right":"bottom":Math.sign(s)<0?c.value?"left":"top":"center",d=(Math.abs(s)+(Math.sign(s)<0?a[i]:l[i]))/Math.max(a[i],l[i])||0
return{transform:[`translate${o}(${s}px) scale${o}(${a[i]/l[i]||0})`,`translate${o}(${s/1.5}px) scale${o}(${(d-1)/1.5+1})`,"none"],transformOrigin:Array(3).fill(u)}}function f({value:t}){if(t){const t=s.value?.$el.parentElement?.querySelector(".v-tab--selected .v-tab__slider"),a=u.value
if(!t||!a)return
const l=getComputedStyle(t).backgroundColor,n={fade:v,grow:p,shift:m}[e.sliderTransition??"shift"]??m,o=Number(e.sliderTransitionDuration)||({fade:400,grow:350,shift:225}[e.sliderTransition??"shift"]??225)
Ke(a,{backgroundColor:[l,l],...n(a,t)},{duration:o,easing:Qt})}}return sa(()=>{const c=Vo.filterProps(e)
return t.createVNode(Vo,t.mergeProps({symbol:ey,ref:s,class:["v-tab",e.class,d.value&&e.inset?r.value:[]],style:[e.style,d.value&&e.inset?i.value:[],{backgroundColor:d.value&&e.inset?"transparent !important":void 0}],tabindex:d.value?0:-1,role:"tab","aria-selected":String(d.value),active:!1},c,l,{block:e.fixed,maxWidth:e.fixed?300:void 0,"onGroup:selected":f}),{...a,default:()=>t.createElementVNode(t.Fragment,null,[a.default?.()??e.text,!e.hideSlider&&t.createElementVNode("div",{ref:u,class:t.normalizeClass(["v-tab__slider",e.inset?r.value:n.value]),style:t.normalizeStyle([o.value,e.inset?i.value:n.value])},null)])})}),ir({},s)}}),ly=Tt({...G($d(),["continuous","nextIcon","prevIcon","showArrows","touch","mandatory"])},"VTabsWindow"),ny=Kt()({name:"VTabsWindow",props:ly(),emits:{"update:modelValue":e=>!0},setup(e,{slots:a}){const l=t.inject(ey,null),n=_a(e,"modelValue"),o=t.computed({get:()=>null==n.value&&l?l.items.value.find(e=>l.selected.value.includes(e.id))?.value:n.value,set(e){n.value=e}})
return sa(()=>{const l=Md.filterProps(e)
return t.createVNode(Md,t.mergeProps({_as:"VTabsWindow"},l,{modelValue:o.value,"onUpdate:modelValue":e=>o.value=e,class:["v-tabs-window",e.class],style:e.style,mandatory:!1,touch:!1}),a)}),{}}}),oy=Tt({...Od()},"VTabsWindowItem"),ry=Kt()({name:"VTabsWindowItem",props:oy(),setup:(e,{slots:a})=>(sa(()=>{const l=jd.filterProps(e)
return t.createVNode(jd,t.mergeProps({_as:"VTabsWindowItem"},l,{class:["v-tabs-window-item",e.class],style:e.style}),a)}),{})})
const iy=Tt({alignTabs:{type:String,default:"start"},color:String,fixedTabs:Boolean,items:{type:Array,default:()=>[]},stacked:Boolean,bgColor:String,grow:Boolean,height:{type:[Number,String],default:void 0},hideSlider:Boolean,inset:Boolean,insetPadding:[String,Number],insetRadius:[String,Number],sliderColor:String,...U(ty(),["spaced","sliderTransition","sliderTransitionDuration"]),...Pr({mandatory:"force",selectedClass:"v-tab-item--selected"}),...yn(),...ol()},"VTabs"),sy=Kt()({name:"VTabs",props:iy(),emits:{"update:modelValue":e=>!0},setup(e,{attrs:a,slots:l}){const n=_a(e,"modelValue"),o=t.computed(()=>function(e){return e?e.map(e=>b(e)?e:{text:e,value:e}):[]}(e.items)),{densityClasses:r}=bn(e),{backgroundColorClasses:i,backgroundColorStyles:s}=Ol(()=>e.bgColor),{scopeId:u}=ns()
return Ht({VTab:{color:t.toRef(e,"color"),direction:t.toRef(e,"direction"),stacked:t.toRef(e,"stacked"),fixed:t.toRef(e,"fixedTabs"),inset:t.toRef(e,"inset"),sliderColor:t.toRef(e,"sliderColor"),sliderTransition:t.toRef(e,"sliderTransition"),sliderTransitionDuration:t.toRef(e,"sliderTransitionDuration"),hideSlider:t.toRef(e,"hideSlider")}}),sa(()=>{const c=_r.filterProps(e),d=!!(l.window||e.items.length>0)
return t.createElementVNode(t.Fragment,null,[t.createVNode(_r,t.mergeProps(c,{modelValue:n.value,"onUpdate:modelValue":e=>n.value=e,class:["v-tabs",`v-tabs--${e.direction}`,`v-tabs--align-tabs-${e.alignTabs}`,{"v-tabs--fixed-tabs":e.fixedTabs,"v-tabs--grow":e.grow,"v-tabs--inset":e.inset,"v-tabs--stacked":e.stacked},r.value,i.value,e.class],style:[{"--v-tabs-height":z(e.height),"--v-tabs-inset-padding":e.inset?z(e.insetPadding):void 0,"--v-tabs-inset-radius":e.inset?z(e.insetRadius):void 0},s.value,e.style],role:"tablist",symbol:ey},u,a),{default:l.default??(()=>o.value.map(a=>l.tab?.({item:a})??t.createVNode(ay,t.mergeProps(a,{key:a.text,value:a.value,spaced:e.spaced}),{default:l[`tab.${a.value}`]?()=>l[`tab.${a.value}`]?.({item:a}):void 0}))),prev:l.prev,next:l.next}),d&&t.createVNode(ny,t.mergeProps({modelValue:n.value,"onUpdate:modelValue":e=>n.value=e,key:"tabs-window"},u),{default:()=>[o.value.map(e=>l.item?.({item:e})??t.createVNode(ry,{value:e.value},{default:()=>l[`item.${e.value}`]?.({item:e})})),l.window?.()]})])}),{}}}),uy=Tt({autoGrow:Boolean,autofocus:Boolean,counter:{type:[Boolean,Number,String],default:void 0},counterValue:Function,prefix:String,placeholder:String,persistentPlaceholder:Boolean,persistentCounter:Boolean,noResize:Boolean,rows:{type:[Number,String],default:5,validator:e=>!isNaN(parseFloat(e))},maxHeight:{type:[Number,String],validator:e=>!isNaN(parseFloat(e))},maxRows:{type:[Number,String],validator:e=>!isNaN(parseFloat(e))},suffix:String,modelModifiers:Object,...Es(),...G(lr(),["direction"]),...Ns()},"VTextarea"),cy=Kt()({name:"VTextarea",directives:{vIntersect:Jl},inheritAttrs:!1,props:uy(),emits:{"click:control":e=>!0,"mousedown:control":e=>!0,"update:focused":e=>!0,"update:modelValue":e=>!0,"update:rows":e=>!0},setup(e,{attrs:a,emit:l,slots:n}){const o=_a(e,"modelValue"),{isFocused:r,focus:i,blur:s}=qo(e),{onIntersect:u}=As(e),c=t.computed(()=>f(e.counterValue)?e.counterValue(o.value):(o.value||"").toString().length),d=t.computed(()=>a.maxlength?a.maxlength:e.counter&&(h(e.counter)||g(e.counter))?e.counter:void 0),v=t.ref(),p=t.ref(),m=t.shallowRef(""),y=t.ref(),b=t.ref(0),{platform:w}=yr(),V=Is(e),S=t.computed(()=>e.persistentPlaceholder||r.value||e.active)
function k(){V.isSuppressing.value&&V.update(),y.value!==be()&&y.value?.focus(),r.value||i()}function x(e){k(),l("click:control",e)}function N(e){l("mousedown:control",e)}function C(a){a.stopPropagation(),k(),t.nextTick(()=>{o.value="",he(e["onClick:clear"],a)})}function E(a){const l=a.target
if(!e.modelModifiers?.trim)return void(o.value=l.value)
const n=l.value,r=l.selectionStart,i=l.selectionEnd
o.value=n,t.nextTick(()=>{let e=0
n.trimStart().length===l.value.length&&(e=n.length-l.value.length),null!=r&&(l.selectionStart=r-e),null!=i&&(l.selectionEnd=i-e)})}const I=t.ref(),A=t.ref(Number(e.rows)),P=t.computed(()=>["plain","underlined"].includes(e.variant))
function _(){t.nextTick(()=>{if(!y.value)return
if(w.value.firefox)return void(b.value=12)
const{offsetWidth:e,clientWidth:t}=y.value
b.value=Math.max(0,e-t)}),e.autoGrow&&t.nextTick(()=>{if(!I.value||!p.value)return
const t=getComputedStyle(I.value),a=getComputedStyle(p.value.$el),l=parseFloat(t.getPropertyValue("--v-field-padding-top"))+parseFloat(t.getPropertyValue("--v-input-padding-top"))+parseFloat(t.getPropertyValue("--v-field-padding-bottom")),n=I.value.scrollHeight,o=parseFloat(t.lineHeight),r=ae(n??0,Math.max(parseFloat(e.rows)*o+l,parseFloat(a.getPropertyValue("--v-input-control-height"))),e.maxHeight?parseFloat(e.maxHeight):parseFloat(e.maxRows)*o+l||1/0)
A.value=Math.floor((r-l)/o),m.value=z(r)})}let R
return t.watchEffect(()=>{e.autoGrow||(A.value=Number(e.rows))}),t.onMounted(_),t.watch(o,_),t.watch(()=>e.rows,_),t.watch(()=>e.maxHeight,_),t.watch(()=>e.maxRows,_),t.watch(()=>e.density,_),t.watch(A,e=>{l("update:rows",e)}),t.watch(I,e=>{e?(R=new ResizeObserver(_),R.observe(I.value)):R?.disconnect()}),t.onBeforeUnmount(()=>{R?.disconnect()}),sa(()=>{const l=!(!n.counter&&void 0===e.counter&&null==e.counterValue),i=!1!==e.counter&&null!==e.counter&&(e.persistentCounter||r.value),f=!0!==e.hideDetails&&!(!n.details&&!l),g=!!(n.details||l&&i),[h,w]=J(a),{modelValue:_,...R}=nr.filterProps(e),D={...Cs.filterProps(e),"onClick:clear":C}
return t.createVNode(nr,t.mergeProps({ref:v,modelValue:o.value,"onUpdate:modelValue":e=>o.value=e,class:["v-textarea v-text-field",{"v-textarea--prefixed":e.prefix,"v-textarea--suffixed":e.suffix,"v-text-field--prefixed":e.prefix,"v-text-field--suffixed":e.suffix,"v-textarea--auto-grow":e.autoGrow,"v-textarea--no-resize":e.noResize||e.autoGrow,"v-input--plain-underlined":P.value},e.class],style:[{"--v-textarea-max-height":e.maxHeight?z(e.maxHeight):void 0,"--v-textarea-scroll-bar-width":z(b.value)},e.style]},h,R,{centerAffix:1===A.value&&!P.value,focused:r.value,detailsActive:g,indentDetails:e.indentDetails??!P.value}),{...n,default:({id:a,isDisabled:l,isDirty:i,isReadonly:c,isValid:d,hasDetails:v})=>t.createVNode(Cs,t.mergeProps({ref:p,style:{"--v-textarea-control-height":m.value},onClick:x,onMousedown:N,"onClick:prependInner":e["onClick:prependInner"],"onClick:appendInner":e["onClick:appendInner"]},D,{id:a.value,active:S.value||i.value,labelId:`${a.value}-label`,centerAffix:1===A.value&&!P.value,dirty:i.value||e.dirty,disabled:l.value,focused:r.value,details:v.value,error:!1===d.value}),{...n,default:({props:{class:n,...r},controlRef:i})=>t.createElementVNode(t.Fragment,null,[e.prefix&&t.createElementVNode("span",{class:"v-text-field__prefix"},[e.prefix]),t.withDirectives(t.createElementVNode("textarea",t.mergeProps({ref:e=>y.value=i.value=e,class:n,value:o.value,onInput:E,autofocus:e.autofocus,readonly:c.value,disabled:l.value,placeholder:e.placeholder,rows:e.rows,name:V.fieldName.value,autocomplete:V.fieldAutocomplete.value,onFocus:k,onBlur:s,"aria-labelledby":`${a.value}-label`},r,w),null),[[Jl,{handler:u},null,{once:!0}]]),e.autoGrow&&t.withDirectives(t.createElementVNode("textarea",{class:t.normalizeClass([n,"v-textarea__sizer"]),id:`${r.id}-sizer`,"onUpdate:modelValue":e=>o.value=e,ref:I,readonly:!0,"aria-hidden":"true"},null),[[t.vModelText,o.value]]),e.suffix&&t.createElementVNode("span",{class:"v-text-field__suffix"},[e.suffix])])}),details:f?a=>t.createElementVNode(t.Fragment,null,[n.details?.(a),l&&t.createElementVNode(t.Fragment,null,[t.createElementVNode("span",null,null),t.createVNode(Vs,{active:i,value:c.value,max:d.value,disabled:e.disabled},n.counter)])]):void 0})}),ir({},v,p,y)}}),dy=Tt({withBackground:Boolean,...Ft(),...Ga(),...ol()},"VThemeProvider"),vy=Kt()({name:"VThemeProvider",props:dy(),setup(e,{slots:a}){const{themeClasses:l}=tl(e)
return()=>e.withBackground?t.createVNode(e.tag,{class:t.normalizeClass(["v-theme-provider",l.value,e.class]),style:t.normalizeStyle(e.style)},{default:()=>[a.default?.()]}):a.default?.()}}),py=Tt({dotColor:String,fillDot:Boolean,hideDot:Boolean,icon:ua,iconColor:String,lineColor:String,...Ft(),...Gl(),...Vn(),...nn()},"VTimelineDivider"),my=Kt()({name:"VTimelineDivider",props:py(),setup(e,{slots:a}){const{sizeClasses:l,sizeStyles:n}=Sn(e,"v-timeline-divider__dot"),{backgroundColorStyles:o,backgroundColorClasses:r}=Ol(()=>e.dotColor),{roundedClasses:i,roundedStyles:s}=Kl(e,"v-timeline-divider__dot"),{elevationClasses:u}=on(e),{backgroundColorClasses:c,backgroundColorStyles:d}=Ol(()=>e.lineColor)
return sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-timeline-divider",{"v-timeline-divider--fill-dot":e.fillDot},e.class]),style:t.normalizeStyle(e.style)},[t.createElementVNode("div",{class:t.normalizeClass(["v-timeline-divider__before",c.value]),style:t.normalizeStyle(d.value)},null),!e.hideDot&&t.createElementVNode("div",{key:"dot",class:t.normalizeClass(["v-timeline-divider__dot",u.value,i.value,l.value]),style:t.normalizeStyle([n.value,s.value])},[t.createElementVNode("div",{class:t.normalizeClass(["v-timeline-divider__inner-dot",r.value,i.value]),style:t.normalizeStyle([o.value,s.value])},[a.default?t.createVNode(Bl,{key:"icon-defaults",disabled:!e.icon,defaults:{VIcon:{color:e.iconColor,icon:e.icon,size:e.size}}},a.default):t.createVNode(Mn,{key:"icon",color:e.iconColor,icon:e.icon,size:e.size},null)])]),t.createElementVNode("div",{class:t.normalizeClass(["v-timeline-divider__after",c.value]),style:t.normalizeStyle(d.value)},null)])),{}}}),fy=Tt({density:String,dotColor:String,fillDot:Boolean,hideDot:Boolean,hideOpposite:{type:Boolean,default:void 0},icon:ua,iconColor:String,lineInset:[Number,String],side:{type:String,validator:e=>null==e||["start","end"].includes(e)},...Ft(),...Tl(),...nn(),...Gl(),...Vn(),...ol()},"VTimelineItem"),gy=Kt()({name:"VTimelineItem",props:fy(),setup(e,{slots:a}){const{dimensionStyles:l}=Fl(e),n=t.shallowRef(0),o=t.ref()
return t.watch(o,e=>{e&&(n.value=e.$el.querySelector(".v-timeline-divider__dot")?.getBoundingClientRect().width??0)},{flush:"post"}),sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-timeline-item",{"v-timeline-item--fill-dot":e.fillDot,"v-timeline-item--side-start":"start"===e.side,"v-timeline-item--side-end":"end"===e.side},e.class]),style:t.normalizeStyle([{"--v-timeline-dot-size":z(n.value),"--v-timeline-line-inset":e.lineInset?`calc(var(--v-timeline-dot-size) / 2 + ${z(e.lineInset)})`:z(0)},e.style])},[t.createElementVNode("div",{class:"v-timeline-item__body",style:t.normalizeStyle(l.value)},[a.default?.()]),t.createVNode(my,{ref:o,hideDot:e.hideDot,icon:e.icon,iconColor:e.iconColor,size:e.size,elevation:e.elevation,dotColor:e.dotColor,fillDot:e.fillDot,rounded:e.rounded},{default:a.icon}),"compact"!==e.density&&t.createElementVNode("div",{class:"v-timeline-item__opposite"},[!e.hideOpposite&&a.opposite?.()])])),{}}}),hy=Tt({align:{type:String,default:"center",validator:e=>["center","start"].includes(e)},direction:{type:String,default:"vertical",validator:e=>["vertical","horizontal"].includes(e)},justify:{type:String,default:"auto",validator:e=>["auto","center"].includes(e)},side:{type:String,validator:e=>null==e||["start","end"].includes(e)},lineThickness:{type:[String,Number],default:2},lineColor:String,truncateLine:{type:String,validator:e=>["start","end","both"].includes(e)},...U(fy({lineInset:0}),["dotColor","fillDot","hideOpposite","iconColor","lineInset","size"]),...Ft(),...yn(),...ol(),...Ga()},"VTimeline"),yy=Kt()({name:"VTimeline",props:hy(),setup(e,{slots:a}){const{themeClasses:l}=tl(e),{densityClasses:n}=bn(e),{rtlClasses:o}=Ua()
Ht({VTimelineDivider:{lineColor:t.toRef(()=>e.lineColor)},VTimelineItem:{density:t.toRef(()=>e.density),dotColor:t.toRef(()=>e.dotColor),fillDot:t.toRef(()=>e.fillDot),hideOpposite:t.toRef(()=>e.hideOpposite),iconColor:t.toRef(()=>e.iconColor),lineColor:t.toRef(()=>e.lineColor),lineInset:t.toRef(()=>e.lineInset),size:t.toRef(()=>e.size)}})
const r=t.computed(()=>{const t=e.side?e.side:"default"!==e.density?"end":null
return t&&`v-timeline--side-${t}`}),i=t.computed(()=>{const t=["v-timeline--truncate-line-start","v-timeline--truncate-line-end"]
switch(e.truncateLine){case"both":return t
case"start":return t[0]
case"end":return t[1]
default:return null}})
return sa(()=>t.createVNode(e.tag,{class:t.normalizeClass(["v-timeline",`v-timeline--${e.direction}`,`v-timeline--align-${e.align}`,`v-timeline--justify-${e.justify}`,i.value,{"v-timeline--inset-line":!!e.lineInset},l.value,n.value,r.value,o.value,e.class]),style:t.normalizeStyle([{"--v-timeline-line-thickness":z(e.lineThickness)},e.style])},a)),{}}}),by=Tt({allowedValues:Function,ampm:Boolean,color:String,disabled:Boolean,displayedValue:null,double:Boolean,format:{type:Function,default:e=>e},max:{type:Number,required:!0},min:{type:Number,required:!0},scrollable:Boolean,readonly:Boolean,rotate:{type:Number,default:0},step:{type:Number,default:1},modelValue:{type:Number}},"VTimePickerClock"),wy=Kt()({name:"VTimePickerClock",props:by(),emits:{change:e=>!0,input:e=>!0},setup(e,{emit:a}){const l=t.ref(null),n=t.ref(null),o=t.ref(void 0),r=t.ref(!1),i=t.ref(null),s=t.ref(null),u=te(e=>a("change",e),750),{textColorClasses:c,textColorStyles:d}=Ll(()=>e.color),{backgroundColorClasses:v,backgroundColorStyles:p}=Ol(()=>e.color),m=t.computed(()=>e.max-e.min+1),f=t.computed(()=>e.double?m.value/2:m.value),g=t.computed(()=>360/f.value),h=t.computed(()=>g.value*Math.PI/180),y=t.computed(()=>null==e.modelValue?e.min:e.modelValue),b=t.computed(()=>.62),w=t.computed(()=>{const t=[]
for(let a=e.min;a<=e.max;a+=e.step)t.push(a)
return t})
function V(e){o.value!==e&&(o.value=e),a("input",e)}function S(t){return!e.allowedValues||e.allowedValues(t)}function k(t){if(!e.scrollable||e.disabled)return
t.preventDefault()
const a=Math.sign(-t.deltaY||1)
let l=y.value
do{l+=a,l=(l-e.min+m.value)%m.value+e.min}while(!S(l)&&l!==y.value)
l!==e.displayedValue&&V(l),u(l)}function x(t){return e.double&&t-e.min>=f.value}function N(e){return x(e)?b.value:1}function C(t,a){const l=(Math.round(t/g.value)+(a?f.value:0))%m.value+e.min
return t<360-g.value/2?l:a?e.max-f.value+1:e.min}function I(t){const{x:a,y:l}=function(t){const a=e.rotate*Math.PI/180
return{x:Math.sin((t-e.min)*h.value+a)*N(t),y:-Math.cos((t-e.min)*h.value+a)*N(t)}}(t)
return{left:`${Math.round(50+50*a)}%`,top:`${Math.round(50+50*l)}%`}}function A(e,t){const a=t.x-e.x,l=t.y-e.y
return Math.sqrt(a*a+l*l)}function P(e){null===i.value&&(i.value=e),s.value=e,V(e)}function _(t){if(t.preventDefault(),!r.value&&"click"!==t.type||!l.value)return
const{width:a,top:o,left:i}=l.value?.getBoundingClientRect(),{width:s}=n.value?.getBoundingClientRect()??{width:0},{clientX:u,clientY:c}="touches"in t?t.touches[0]:t,d={x:a/2,y:-a/2},v={x:u-i,y:o-c},p=Math.round(function(e,t){const a=2*Math.atan2(t.y-e.y-A(e,t),t.x-e.x)
return Math.abs(180*a/Math.PI)}(d,v)-e.rotate+360)%360,m=e.double&&A(d,v)<(s+s*b.value)/4,f=Math.ceil(15/g.value)
let h
for(let e=0;e<f;e++){if(h=C(p+e*g.value,m),S(h))return P(h)
if(h=C(p-e*g.value,m),S(h))return P(h)}}function R(t){e.disabled||(t.preventDefault(),window.addEventListener("mousemove",_),window.addEventListener("touchmove",_),window.addEventListener("mouseup",D),window.addEventListener("touchend",D),i.value=null,s.value=null,r.value=!0,_(t))}function D(e){e.stopPropagation(),B(),r.value=!1,null!==s.value&&S(s.value)&&a("change",s.value)}function B(){E&&(window.removeEventListener("mousemove",_),window.removeEventListener("touchmove",_),window.removeEventListener("mouseup",D),window.removeEventListener("touchend",D))}t.watch(()=>e.modelValue,e=>{o.value=e}),t.onScopeDispose(B),sa(()=>t.createElementVNode("div",{class:t.normalizeClass([{"v-time-picker-clock":!0,"v-time-picker-clock--indeterminate":null==e.modelValue,"v-time-picker-clock--readonly":e.readonly}]),onMousedown:R,onTouchstart:R,onWheel:k,ref:l},[t.createElementVNode("div",{class:"v-time-picker-clock__inner",ref:n},[t.createElementVNode("div",{class:t.normalizeClass([{"v-time-picker-clock__hand":!0,"v-time-picker-clock__hand--inner":x(e.modelValue)},c.value]),style:t.normalizeStyle([{transform:`rotate(${e.rotate+g.value*(y.value-e.min)}deg) scaleY(${N(y.value)})`},d.value])},null),w.value.map(a=>{const l=a===y.value
return t.createElementVNode("div",{class:t.normalizeClass([{"v-time-picker-clock__item":!0,"v-time-picker-clock__item--active":l,"v-time-picker-clock__item--disabled":e.disabled||!S(a)},l&&v.value]),style:t.normalizeStyle([I(a),l&&p.value])},[t.createElementVNode("span",null,[e.format(a)])])})])]))}}),Vy=Tt({active:Boolean,color:String,disabled:Boolean,label:String,modelValue:String,error:String,showHint:Boolean,readonly:Boolean},"VTimePickerField"),Sy=Kt()({name:"VTimePickerField",props:Vy(),emits:{"update:modelValue":e=>!0},setup(e,{emit:a}){const{textColorClasses:l,textColorStyles:n}=Ll(()=>e.color),o=t.ref(),r=t.shallowRef(!1)
function i(e){if(["Backspace","Delete"].includes(e.key)){e.preventDefault()
e.target.value="",a("update:modelValue",null)}}return sa(()=>t.createVNode(Rs,{ref:o,_as:"VTimePickerField",autocomplete:"off",class:t.normalizeClass(["v-time-picker-controls__time__field",{"v-time-picker-controls__time__field--active":e.active},e.active?l.value:[]]),style:t.normalizeStyle(e.active?n.value:[]),disabled:e.disabled,variant:"solo-filled",inputmode:"numeric",hideDetails:"auto","aria-label":e.label,"aria-invalid":!!e.error,"aria-errormessage":e.error,error:!!e.error,hint:e.showHint?e.label:void 0,persistentHint:!0,flat:!0,modelValue:e.modelValue??(r.value?"":"--"),"onUpdate:modelValue":e=>a("update:modelValue",e),onKeydown:i,onFocus:()=>r.value=!0,onBlur:()=>r.value=!1},null)),ir({},o)}})
function ky(e,t=2){return String(e).padStart(t,"0")}function xy(e){return e?(e-1)%12+1:12}function Ny(e,t){return e%12+("pm"===t?12:0)}function Cy(e){const t=e.replaceAll(/\D/g,"")
return t.length>0?Number(t):null}const Ey=Tt({allowedHours:[Function,Array],allowedMinutes:[Function,Array],allowedSeconds:[Function,Array],max:String,min:String},"time-validation")
function Iy(e){const a=t.computed(()=>{const t=e.min?Number(e.min.split(":")[0]):0,a=e.max?Number(e.max.split(":")[0]):23
return l=>!(l<t)&&(!(l>a)&&(Array.isArray(e.allowedHours)?e.allowedHours.includes(l):!f(e.allowedHours)||e.allowedHours(l)))}),l=t.computed(()=>{const[t,a]=e.min?e.min.split(":").map(Number):[0,0],[l,n]=e.max?e.max.split(":").map(Number):[23,59],o=60*t+a,r=60*l+n
return(t,a)=>{if(null!==t){const e=60*t+a
if(e<o)return!1
if(e>r)return!1}return Array.isArray(e.allowedMinutes)?e.allowedMinutes.includes(a):!f(e.allowedMinutes)||e.allowedMinutes(a)}}),n=t.computed(()=>{const[t,a,l]=e.min?e.min.split(":").map(Number):[0,0,0],[n,o,r]=e.max?e.max.split(":").map(Number):[23,59,59],i=3600*t+60*a+(l||0),s=3600*n+60*o+(r||0)
return(t,a,l)=>{if(null!==t&&null!==a){const e=3600*t+60*a+l
if(e<i)return!1
if(e>s)return!1}return Array.isArray(e.allowedSeconds)?e.allowedSeconds.includes(l):!f(e.allowedSeconds)||e.allowedSeconds(l)}})
return{isAllowedHour:a,isAllowedMinute:l,isAllowedSecond:n,findNextAllowed:function(e,t,o,r=null,i=null){const s="hour"===e?a.value:"minute"===e?e=>l.value(r,e):e=>n.value(r,i,e),u="hour"===e?e=>function(e,t){return 23===e&&t?{value:0}:0!==e||t?{value:e+(t?1:-1)}:{value:23}}(e,o).value:e=>function(e,t){return 59===e&&t?0:0!==e||t?e+(t?1:-1):59}(e,o),c="hour"===e?24:60
for(let e=1;e<=c&&!s(t=u(t));e++);return t}}}const Ay=Tt({ampm:Boolean,color:String,disabled:Boolean,inputHints:Boolean,hour:[Number,String],minute:[Number,String],second:[Number,String],period:String,readonly:Boolean,useSeconds:Boolean,value:Number,viewMode:String,...Ey()},"VTimePickerControls"),Py=Kt()({name:"VTimePickerControls",props:Ay(),emits:{"update:period":e=>!0,"update:viewMode":e=>!0,"update:hour":e=>!0,"update:minute":e=>!0,"update:second":e=>!0},setup(e,{emit:a}){const{t:l}=Ha(),{isAllowedHour:n,isAllowedMinute:o,isAllowedSecond:r,findNextAllowed:i}=Iy(e),s=t.computed(()=>null!==e.hour?e.ampm?Ny(Number(e.hour),e.period??"am"):Number(e.hour):null),u=t.computed(()=>null!==e.minute?Number(e.minute):null),c=t.computed(()=>null===e.hour||(n.value?.(Number(s.value))??!0)),d=t.computed(()=>null===e.minute||(o.value?.(s.value,Number(e.minute))??!0)),v=t.computed(()=>null===e.second||(r.value?.(s.value,u.value,Number(e.second))??!0)),p=t=>{if(null==t||isNaN(Number(t)))return null
const a=Number(t)
return e.ampm?ky(xy(a)):ky(a)},m=t=>{if(isNaN(Number(t))||null==t||""===t)return null
const a=g(t)?Cy(t):Number(t)
return null===a?null:e.ampm?Ny(a,e.period??"am"):ae(a,0,23)},f=_a(e,"hour",void 0,p,m),h=e=>null==e||isNaN(Number(e))?null:ky(`${e}`),y=e=>{if(isNaN(Number(e))||null==e||""===e)return null
const t=g(e)?Cy(e):Number(e)
return null!==t?ae(t,0,59):null},b=_a(e,"minute",void 0,h,y),w=_a(e,"second",void 0,h,y)
function V(l){if(!["ArrowUp","ArrowDown"].includes(l.key))return
l.preventDefault(),l.stopPropagation()
const n="am"===e.period,o=e.ampm?Ny(Number(f.value??0),n?"am":"pm"):Number(f.value??0),r=i("hour",o,"ArrowUp"===l.key),s=n&&r>=12||!n&&r<12
e.ampm&&s?(a("update:period","am"===e.period?"pm":"am"),t.nextTick(()=>f.value=ky(r))):f.value=ky(r)}function S(e){if(!["ArrowUp","ArrowDown"].includes(e.key))return
e.preventDefault(),e.stopPropagation()
const t=Number(b.value??0),a=i("minute",t,"ArrowUp"===e.key,s.value)
b.value=ky(a)}function k(e){if(!["ArrowUp","ArrowDown"].includes(e.key))return
e.preventDefault(),e.stopPropagation()
const t=Number(w.value??0),a=i("second",t,"ArrowUp"===e.key,s.value,u.value)
w.value=ky(a)}function x(t,a,l){return n=>{if(!n.data)return
const o=n.target,{value:r,selectionStart:i,selectionEnd:s}=o??{}
if(null===Cy(n.data))return void n.preventDefault()
const u=r?r.slice(0,i)+n.data+r.slice(s):n.data
if(u.length>2){if(i===s&&0===s&&n.data.trim().startsWith("0"))return n.preventDefault(),o.value=u.trim().substring(0,2),l(o.value),void(1===n.data.trim().length&&o.setSelectionRange(1,1))
if(i===s&&1===s&&r.startsWith("0"))return n.preventDefault(),o.value=u.trim().substring(0,2),void l(o.value)
const t="hour"===e.viewMode?e.ampm?12:23:59
if(Cy(u)>t)return n.preventDefault(),o.value=ky(String(Cy(n.data)).substring(0,2)),void l(o.value)}const c=t(u)
a(c)&&n.preventDefault()}}function N(e){a("update:period",e)}const C=t.ref(),E=t.ref(),I=t.ref()
t.watch(()=>e.viewMode,(e,t)=>{switch(t){case"hour":C.value.blur()
break
case"minute":E.value.blur()
break
case"second":I.value.blur()}})
const A=x(m,e=>p(e)===f.value,e=>f.value=e),P=x(y,e=>h(e)===b.value,e=>b.value=e),_=x(y,e=>h(e)===w.value,e=>w.value=e)
return sa(()=>t.createElementVNode("div",{class:"v-time-picker-controls"},[t.createElementVNode("div",{class:t.normalizeClass({"v-time-picker-controls__time":!0,"v-time-picker-controls__time--with-ampm":e.ampm,"v-time-picker-controls__time--with-seconds":e.useSeconds})},[t.createVNode(Sy,{ref:C,active:"hour"===e.viewMode,color:e.color,disabled:e.disabled,label:l("$vuetify.timePicker.hour"),showHint:e.inputHints,error:c.value?void 0:l("$vuetify.timePicker.notAllowed"),modelValue:f.value,"onUpdate:modelValue":e=>f.value=e,onKeydown:V,onBeforeinput:A,onFocus:()=>a("update:viewMode","hour")},null),t.createElementVNode("span",{class:"v-time-picker-controls__time__separator"},[t.createTextVNode(":")]),t.createVNode(Sy,{ref:E,active:"minute"===e.viewMode,color:e.color,disabled:e.disabled,label:l("$vuetify.timePicker.minute"),showHint:e.inputHints,error:d.value?void 0:l("$vuetify.timePicker.notAllowed"),modelValue:b.value,"onUpdate:modelValue":e=>b.value=e,onKeydown:S,onBeforeinput:P,onFocus:()=>a("update:viewMode","minute")},null),e.useSeconds&&t.createElementVNode("span",{key:"secondsDivider",class:"v-time-picker-controls__time__separator"},[t.createTextVNode(":")]),e.useSeconds&&t.createElementVNode(t.Fragment,null,[t.createVNode(Sy,{key:"secondsVal",ref:I,active:"second"===e.viewMode,color:e.color,disabled:e.disabled,label:l("$vuetify.timePicker.second"),showHint:e.inputHints,error:v.value?void 0:l("$vuetify.timePicker.notAllowed"),modelValue:w.value,"onUpdate:modelValue":e=>w.value=e,onKeydown:k,onBeforeinput:_,onFocus:()=>a("update:viewMode","second")},null)]),e.ampm&&t.createElementVNode("div",{class:"v-time-picker-controls__ampm"},[t.createVNode(Vo,{active:"am"===e.period,color:"am"===e.period?e.color:void 0,class:t.normalizeClass({"v-time-picker-controls__ampm__am":!0,"v-time-picker-controls__ampm__btn":!0,"v-time-picker-controls__ampm__btn__active":"am"===e.period}),disabled:e.disabled,text:l("$vuetify.timePicker.am"),variant:e.disabled&&"am"===e.period?"elevated":"tonal",onClick:()=>"am"!==e.period?N("am"):null},null),t.createVNode(Vo,{active:"pm"===e.period,color:"pm"===e.period?e.color:void 0,class:t.normalizeClass({"v-time-picker-controls__ampm__pm":!0,"v-time-picker-controls__ampm__btn":!0,"v-time-picker-controls__ampm__btn__active":"pm"===e.period}),disabled:e.disabled,text:l("$vuetify.timePicker.pm"),variant:e.disabled&&"pm"===e.period?"elevated":"tonal",onClick:()=>"pm"!==e.period?N("pm"):null},null)])])])),{}}}),_y=Tt({disabled:Boolean,format:{type:String,default:"ampm"},viewMode:{type:String,default:"hour"},period:{type:String,default:"am",validator:e=>["am","pm"].includes(e)},modelValue:null,readonly:Boolean,scrollable:Boolean,useSeconds:Boolean,variant:{type:String,default:"dial"},...Ey(),...G(hv({title:"$vuetify.timePicker.title"}),["landscape"]),...yn()},"VTimePicker"),Ry=Kt()({name:"VTimePicker",props:_y(),emits:{"update:hour":e=>!0,"update:minute":e=>!0,"update:period":e=>!0,"update:second":e=>!0,"update:modelValue":e=>!0,"update:viewMode":e=>!0},setup(e,{emit:a,slots:l}){const{t:n}=Ha(),{densityClasses:o}=bn(e),r=t.ref(null),i=t.ref(null),s=t.ref(null),u=t.ref(null),c=t.ref(null),d=t.ref(null),v=_a(e,"period","am"),p=_a(e,"viewMode","hour"),m=t.ref(null),f=t.ref(null),g=t.computed(()=>"ampm"===e.format),{isAllowedHour:h,isAllowedMinute:y,isAllowedSecond:b}=Iy(e),w=t.toRef(()=>null!==e.modelValue&&null===r.value&&null===i.value&&(!e.useSeconds||null===s.value))
function V(){const t=S()
null!==t&&t!==e.modelValue&&a("update:modelValue",t),w.value&&a("update:modelValue",null)}function S(){return null==r.value||null==i.value||e.useSeconds&&null==s.value?null:`${ky(r.value)}:${ky(i.value)}`+(e.useSeconds?`:${ky(s.value)}`:"")}function k(e){if(null==e||""===e)r.value=null,i.value=null,s.value=null
else if(e instanceof Date)r.value=e.getHours(),i.value=e.getMinutes(),s.value=e.getSeconds()
else{const[t,,a,,l,n]=e.trim().toLowerCase().match(/^(\d+):(\d+)(:(\d+))?([ap]m)?$/)||new Array(6)
r.value=n?Ny(parseInt(t,10),n):parseInt(t,10),i.value=parseInt(a,10),s.value=parseInt(l||0,10)}v.value=null==r.value||r.value<12?"am":"pm"}function x(e){"hour"===p.value?r.value=g.value?Ny(e,v.value):e:"minute"===p.value?i.value=e:s.value=e}function N(t){switch(p.value||"hour"){case"hour":a("update:hour",t)
break
case"minute":a("update:minute",t)
break
case"second":a("update:second",t)}const l=null!==r.value&&null!==i.value&&(!e.useSeconds||null!==s.value)
if("hour"===p.value?p.value="minute":e.useSeconds&&"minute"===p.value&&(p.value="second"),r.value===u.value&&i.value===c.value&&(!e.useSeconds||s.value===d.value))return
null!==S()&&(u.value=r.value,c.value=i.value,e.useSeconds&&(d.value=s.value),l&&V())}t.watch(r,V),t.watch(i,V),t.watch(s,V),t.watch(v,(e,t)=>{null!=r.value&&e!==t&&("pm"===e&&r.value<12?r.value=r.value+12:"am"===e&&r.value>=12&&(r.value=r.value-12))}),t.watch(()=>e.modelValue,e=>k(e)),t.watch(()=>e.useSeconds,(e,t)=>{t&&!e&&"second"===p.value&&(p.value="minute"),e||null===s.value||(s.value=null)}),t.onMounted(()=>{k(e.modelValue)}),sa(()=>{const a=G(yv.filterProps(e),["hideHeader"]),u=Py.filterProps(e),c=wy.filterProps(G(e,["format","modelValue","min","max"])),d="hour"===p.value?h.value:"minute"===p.value?e=>y.value(r.value,e):e=>b.value(r.value,i.value,e)
return t.createVNode(yv,t.mergeProps(a,{color:void 0,class:["v-time-picker",`v-time-picker--variant-${e.variant}`,e.class,o.value],hideHeader:e.hideHeader&&"input"!==e.variant,style:e.style}),{title:()=>l.title?.()??t.createElementVNode("div",{class:"v-time-picker__title"},[n(e.title)]),header:()=>t.createVNode(Py,t.mergeProps(u,{ampm:g.value,hour:r.value,minute:i.value,period:v.value,second:s.value,viewMode:p.value,inputHints:"input"===e.variant,"onUpdate:hour":e=>r.value=e,"onUpdate:minute":e=>i.value=e,"onUpdate:second":e=>s.value=e,"onUpdate:period":e=>v.value=e,"onUpdate:viewMode":e=>p.value=e,ref:m}),null),default:()=>t.createVNode(wy,t.mergeProps(c,{allowedValues:d,double:"hour"===p.value&&!g.value,format:"hour"===p.value?g.value?xy:e=>e:e=>ky(e,2),max:"hour"===p.value?g.value&&"am"===v.value?11:23:59,min:"hour"===p.value&&g.value&&"pm"===v.value?12:0,size:20,step:"hour"===p.value?1:5,modelValue:"hour"===p.value?r.value:"minute"===p.value?i.value:s.value,onChange:N,onInput:x,ref:f}),null),actions:l.actions})})}}),Dy=Tt({...Ft(),...Nn({variant:"text"})},"VToolbarItems"),By=Kt()({name:"VToolbarItems",props:Dy(),setup:(e,{slots:a})=>(Ht({VBtn:{color:t.toRef(()=>e.color),height:"inherit",variant:t.toRef(()=>e.variant)}}),sa(()=>t.createElementVNode("div",{class:t.normalizeClass(["v-toolbar-items",e.class]),style:t.normalizeStyle(e.style)},[a.default?.()])),{})}),Ty=Tt({...G(li({collapseIcon:"$treeviewCollapse",expandIcon:"$treeviewExpand"}),["subgroup"])},"VTreeviewGroup"),Fy=Kt()({name:"VTreeviewGroup",props:Ty(),setup(e,{slots:a}){const l=t.ref(),n=t.computed(()=>l.value?.isOpen?e.collapseIcon:e.expandIcon),o=t.computed(()=>({VTreeviewItem:{prependIcon:void 0,appendIcon:void 0,toggleIcon:n.value}}))
return sa(()=>{const n=ni.filterProps(e)
return t.createVNode(ni,t.mergeProps(n,{ref:l,class:["v-treeview-group",e.class],subgroup:!0}),{...a,activator:a.activator?e=>t.createElementVNode(t.Fragment,null,[t.createVNode(Bl,{defaults:o.value},{default:()=>[a.activator?.(e)]})]):void 0})}),{}}}),$y=Symbol.for("vuetify:v-treeview"),My=Tt({loading:Boolean,hideActions:Boolean,hasCustomPrepend:Boolean,indentLines:Array,toggleIcon:ua,...si({slim:!0})},"VTreeviewItem"),zy=Kt()({name:"VTreeviewItem",props:My(),emits:{toggleExpand:e=>!0},setup(e,{slots:a,emit:l}){const n=t.inject($y,{visibleIds:t.ref()}).visibleIds,o=t.ref(),r=t.computed(()=>o.value?.root.activatable.value&&o.value?.isGroupActivator),i=t.computed(()=>!e.disabled&&!1!==e.link&&r.value),s=t.computed(()=>n.value&&!n.value.has(t.toRaw(o.value?.id)))
function u(e){o.value?.activate(!o.value?.isActivated,e)}function c(e){e.preventDefault(),e.stopPropagation(),l("toggleExpand",e)}return sa(()=>{const l=ui.filterProps(e),n=a.prepend||e.toggleIcon||e.indentLines||e.prependIcon||e.prependAvatar
return t.createVNode(ui,t.mergeProps({ref:o},l,{active:o.value?.isActivated||void 0,class:["v-treeview-item",{"v-treeview-item--activatable-group-activator":r.value,"v-treeview-item--filtered":s.value},e.class],role:"treeitem","aria-busy":e.loading||void 0,ripple:!1,onClick:i.value?u:void 0}),{...a,prepend:n?l=>t.createElementVNode(t.Fragment,null,[e.indentLines&&e.indentLines.length>0?t.createElementVNode("div",{key:"indent-lines",class:"v-treeview-indent-lines",style:{"--v-indent-parts":e.indentLines.length}},[e.indentLines.map(e=>t.createElementVNode("div",{class:t.normalizeClass(`v-treeview-indent-line v-treeview-indent-line--${e}`)},null))]):"",!e.hideActions&&t.createVNode(Ei,{start:!0},{default:()=>[e.toggleIcon?t.createElementVNode(t.Fragment,null,[a.toggle?t.createVNode(Bl,{key:"prepend-defaults",defaults:{VBtn:{density:"compact",icon:e.toggleIcon,variant:"text",loading:e.loading,tabindex:-1},VProgressCircular:{indeterminate:"disable-shrink",size:20,width:2}}},{default:()=>[a.toggle({...l,loading:e.loading,props:{onClick:c}})]}):t.createVNode(Vo,{key:"prepend-toggle",density:"compact",icon:e.toggleIcon,loading:e.loading,tabindex:-1,variant:"text","aria-hidden":"true",onClick:c},{loader:()=>t.createVNode(Hn,{indeterminate:"disable-shrink",size:"20",width:"2"},null)})]):t.createElementVNode("div",{class:"v-treeview-item__level"},null)]}),e.hasCustomPrepend?t.createVNode(Bl,{key:"prepend-defaults",defaults:{VAvatar:{density:e.density,image:e.appendAvatar},VIcon:{density:e.density,icon:e.appendIcon},VListItemAction:{start:!0}}},{default:()=>[a.prepend?.(l)]}):t.createElementVNode(t.Fragment,null,[a.prepend?.(l),e.prependAvatar&&t.createVNode(Bo,{key:"prepend-avatar",density:e.density,image:e.prependAvatar},null),e.prependIcon&&t.createVNode(Mn,{key:"prepend-icon",density:e.density,icon:e.prependIcon},null)])]):void 0})}),ir({},o)}})
function Ly(e){const t=e.closest(".v-treeview")
return t?ye(t).filter(e=>e.matches('[role="treeitem"]')):[]}function Oy(e,t){const a=Ly(e)
return a[a.indexOf(e)+t]??null}function jy(e,t){Oy(e,t)?.focus()}function Hy(e,t){const a=Ly(e);("first"===t?a[0]:a.at(-1))?.focus()}const Wy=["ArrowUp","ArrowDown","Home","End"]
function Uy(e,a){const{isRtl:l}=Ua(),n=t.inject(Zr,null)
function o(a){return e.returnObject?t.toRaw(a.raw):a.value}return{onKeydown:function(t,r){const i=n?.root
if(!i)return
const s=t.currentTarget,u=t.target===t.currentTarget
if(Wy.includes(t.key)){if(t.stopPropagation(),!u)return
return t.preventDefault(),void("ArrowDown"===t.key?jy(s,1):"ArrowUp"===t.key?jy(s,-1):"Home"===t.key?Hy(s,"first"):"End"===t.key&&Hy(s,"last"))}if("Tab"===t.key){const e=ye(s)
if(e.length)if(t.shiftKey||t.target!==e.at(-1))t.shiftKey&&t.target===e[0]&&(t.preventDefault(),s.focus())
else{const e=Oy(s,1)
e&&(t.preventDefault(),e.focus())}return}u&&function(t,n,r,i){const s=l.value?"ArrowLeft":"ArrowRight",u=l.value?"ArrowRight":"ArrowLeft",c=!!n.children,d=i.opened.value.has(o(n)),v=e.selectable&&(!n.children||!["leaf","single-leaf"].includes(e.selectStrategy)),p=()=>{a(n),i.open(o(n),!d,t)},m=()=>i.select(o(n),"on"!==i.selected.value.get(o(n)),t)
if("Enter"===t.key)t.preventDefault(),e.activatable&&i.activate(o(n),!i.activated.value.has(o(n)),t),c?p():v&&m()
else if(" "===t.key)t.preventDefault(),v?m():c&&p()
else if(t.key===s)t.preventDefault(),c&&!d?(a(n),i.open(o(n),!0,t)):d&&function(e){e.closest(".v-list-group")?.querySelector(':scope > .v-list-group__items [role="treeitem"]')?.focus()}(r)
else if(t.key===u)t.preventDefault(),c&&d?i.open(o(n),!1,t):function(e){const t=e.closest(".v-list-group__items")?.getAttribute("aria-labelledby")
t&&document.getElementById(t)?.focus()}(r)
else if("*"===t.key){t.preventDefault()
for(const l of e.items??[])l.children&&(a(l),i.open(o(l),!0,t))}}(t,r,s,i)}}}const Yy=Tt({fluid:Boolean,disabled:Boolean,loadChildren:Function,loadingIcon:{type:String,default:"$loading"},items:Array,openOnClick:{type:Boolean,default:void 0},indeterminateIcon:{type:ua,default:"$checkboxIndeterminate"},falseIcon:ua,trueIcon:ua,returnObject:Boolean,activatable:Boolean,selectable:Boolean,selectedColor:String,selectStrategy:[String,Function,Object],index:Number,isLastGroup:Boolean,separateRoots:Boolean,parentIndentLines:Array,indentLinesVariant:String,path:{type:Array,default:()=>[]},...U(My(),["hideActions"]),...yn()},"VTreeviewChildren"),Gy=Kt()({name:"VTreeviewChildren",props:Yy(),setup(e,{slots:a}){const l=t.reactive(new Set),n=t.ref([]),o=t.computed(()=>!e.disabled&&(null!=e.openOnClick?e.openOnClick:e.selectable&&!e.activatable))
async function r(t){try{if(!e.items?.length||!e.loadChildren)return
0===t?.children?.length&&(l.add(t.value),await e.loadChildren(t.raw))}finally{l.delete(t.value)}}function i(t,a){e.selectable&&t(a)}const{onKeydown:s}=Uy(e,r)
return()=>a.default?.()??e.items?.map((u,c,d)=>{const{children:v,props:p}=u,m=l.has(u.value),f=!!d.at(c+1)?.children,g=e.path?.length??0,h=d.length-1===c,y={index:c,depth:g,isFirst:0===c,isLast:h,path:[...e.path,c]},b=function({depth:e,isLast:t,isLastGroup:a,leafLinks:l,separateRoots:n,parentIndentLines:o,variant:r}){const i=t&&(!a||n||e>1)
return o&&e?"simple"===r?{leaf:[...o,"line"],node:[...o,"line"],children:[...o,"line"],footer:[...o,"line","line"]}:{leaf:[...o,i?"last-leaf":"leaf",...l?["leaf-link"]:[]],node:[...o,i?"last-leaf":"leaf"],children:[...o,i?"none":"line"],footer:[...o,i?"none":"line"]}:{leaf:void 0,node:void 0,children:o,footer:!o||i&&"simple"!==r?["none"]:[...o,n?"none":"line"]}}({depth:g,isLast:h,isLastGroup:e.isLastGroup,leafLinks:!e.hideActions&&!e.fluid,separateRoots:e.separateRoots,parentIndentLines:e.parentIndentLines,variant:e.indentLinesVariant}),w={...p,hideActions:e.hideActions,indentLines:v?b.node:b.leaf,onKeydown:e=>s(e,u)},V={toggle:a.toggle?e=>a.toggle?.({...e,...y,item:u.raw,internalItem:u,loading:m}):void 0,prepend:l=>t.createElementVNode(t.Fragment,null,[e.selectable&&(!v||v&&!["leaf","single-leaf"].includes(e.selectStrategy))&&t.createVNode(Ei,{start:!0},{default:()=>[t.createVNode(Wo,{key:u.value,"aria-hidden":"true",tabindex:-1,modelValue:l.isSelected,disabled:e.disabled||p.disabled,loading:m,color:e.selectedColor,density:e.density,indeterminate:l.isIndeterminate,indeterminateIcon:e.indeterminateIcon,falseIcon:e.falseIcon,trueIcon:e.trueIcon,"onUpdate:modelValue":e=>i(l.select,e),onClick:e=>e.stopPropagation()},null)]}),a.prepend?.({...l,...y,item:u.raw,internalItem:u})]),append:a.append?e=>a.append?.({...e,...y,item:u.raw,internalItem:u}):void 0,title:a.title?e=>a.title?.({...e,item:u.raw,internalItem:u}):void 0,subtitle:a.subtitle?e=>a.subtitle?.({...e,item:u.raw,internalItem:u}):void 0},S=Fy.filterProps(p),k=Gy.filterProps({...e,...y}),x={hideActions:e.hideActions,indentLines:b.footer}
return v?t.createVNode(Fy,t.mergeProps(S,{value:e.returnObject?u.raw:S?.value,rawId:S?.value}),{activator:({props:l,isOpen:s})=>{const v={...w,...l,value:w?.value,"aria-expanded":s,"aria-level":g+1,"aria-posinset":c+1,"aria-setsize":d.length,onToggleExpand:[()=>r(u),l.onClick],onClick:e.disabled||w.disabled?void 0:o.value?[()=>r(u),l.onClick]:()=>i(n.value[c]?.select,!n.value[c]?.isSelected)}
return Ce(a.header,{props:v,item:u.raw,internalItem:u,loading:m},()=>t.createVNode(zy,t.mergeProps({ref:e=>n.value[c]=e},v,{hasCustomPrepend:!!a.prepend,value:e.returnObject?u.raw:p.value,loading:m}),V))},default:()=>t.createElementVNode(t.Fragment,null,[t.createVNode(Gy,t.mergeProps(k,{items:v,indentLinesVariant:e.indentLinesVariant,parentIndentLines:b.children,isLastGroup:f,returnObject:e.returnObject}),a),a.footer?.({props:x,item:u.raw,internalItem:u,loading:m})])}):Ce(a.item,{props:w,item:u.raw,internalItem:u,...y},()=>"divider"===u.type?Ce(a.divider,{props:u.raw},()=>t.createVNode(zr,u.props,null)):"subheader"===u.type?Ce(a.subheader,{props:u.raw},()=>t.createVNode(di,u.props,null)):t.createVNode(zy,t.mergeProps(w,{hasCustomPrepend:!!a.prepend,"aria-level":g+1,"aria-posinset":c+1,"aria-setsize":d.length,value:e.returnObject?t.toRaw(u.raw):w.value}),V))})}})
function Ky(e,a,l,n){const o=_a(e,"opened",e.opened,e=>Array.isArray(e)?e:[]),r=new Set,i=new Set
function s(a){return e.returnObject?t.toRaw(a.raw):a.props.value}function u(e){return e.flatMap(e=>e.children?[s(e),...u(e.children)]:[])}const c=t.computed(()=>e.openAll?u(a.value).map(t.toRaw):[])
t.watch(c,(e,a=[])=>{const l=new Set(o.value.map(t.toRaw)),n=new Set(e),r=e.filter(e=>!a.includes(e)&&!l.has(e)),i=a.filter(e=>!n.has(e)&&l.has(e));(r.length||i.length)&&(r.forEach(e=>l.add(e)),i.forEach(e=>l.delete(e)),o.value=[...l])},{immediate:!0})
const d=t.computed(()=>{const a=t.toValue(n)
if(!e.search||!a)return[]
const o=l.value.flatMap(e=>{const t=a(s(e))
return e.children?t:t.slice(0,-1)})
return[...new Set(o.map(t.toRaw))]})
return t.watch(o,e=>{const a=new Set(e.map(t.toRaw))
r.forEach(e=>a.has(e)||i.add(e))}),t.watch(()=>e.search,()=>i.clear()),t.watch(d,e=>{const a=new Set(o.value.map(t.toRaw)),l=e.filter(e=>!a.has(e)&&!i.has(e))
l.length&&(l.forEach(e=>r.add(e)),o.value=[...o.value,...l])}),t.watch(()=>!e.search,e=>{if(!e||!r.size)return
const a=t.toValue(n),l=new Set(o.value.map(t.toRaw).filter(e=>!r.has(e)).flatMap(e=>a?.(e)??[e]).map(t.toRaw))
o.value=o.value.map(t.toRaw).filter(e=>!r.has(e)||l.has(e)),r.clear()}),o}function qy(e,t=[]){for(const a of e)t.push(a),a.children&&qy(a.children,t)
return t}const Xy=Tt({openAll:Boolean,indentLines:[Boolean,String],indentLinesColor:String,indentLinesOpacity:[String,Number],search:String,hideNoData:Boolean,noDataText:{type:String,default:"$vuetify.noDataText"},...eu({filterKeys:["title"]}),...G(Yy(),["index","path","indentLinesVariant","parentIndentLines","isLastGroup"]),...G(ki({collapseIcon:"$treeviewCollapse",expandIcon:"$treeviewExpand",slim:!0}),["nav","openStrategy"]),modelValue:Array},"VTreeview"),Zy=Kt()({name:"VTreeview",props:Xy(),emits:{"update:opened":e=>!0,"update:activated":e=>!0,"update:selected":e=>!0,"update:modelValue":e=>!0,"click:open":e=>!0,"click:select":e=>!0},setup(e,{slots:a,emit:l}){const{t:n}=Ha(),{items:o}=Si(e),r=t.toRef(()=>e.activeColor),i=t.toRef(()=>e.baseColor),s=t.toRef(()=>e.color),u=_a(e,"activated"),c=_a(e,"selected"),d=t.computed({get:()=>e.modelValue??c.value,set(e){c.value=e,l("update:modelValue",e)}}),v=t.ref(),p=t.computed(()=>qy(o.value)),m=t.toRef(()=>e.search),{filteredItems:f}=au(e,p,m),g=Ky(e,o,f,()=>v.value?.getPath),h=t.computed(()=>{if(!m.value)return null
const a=v.value?.getPath
return a?new Set(f.value.flatMap(l=>{const n=e.returnObject?l.raw:l.props.value
return[...a(n),...b(n)].map(t.toRaw)})):null})
function b(e){const a=[],l=(v.value?.children.get(t.toRaw(e))??[]).slice()
for(;l.length;){const e=l.shift()
e&&(a.push(e),l.push(...(v.value?.children.get(e)??[]).slice()))}return a}return t.provide($y,{visibleIds:h}),Ht({VTreeviewGroup:{activeColor:r,baseColor:i,color:s,collapseIcon:t.toRef(()=>e.collapseIcon),expandIcon:t.toRef(()=>e.expandIcon)},VTreeviewItem:{activeClass:t.toRef(()=>e.activeClass),activeColor:r,baseColor:i,color:s,density:t.toRef(()=>e.density),disabled:t.toRef(()=>e.disabled),lines:t.toRef(()=>e.lines),variant:t.toRef(()=>e.variant)}}),sa(()=>{const l=xi.filterProps(e),r=Gy.filterProps(e),i=y(e.indentLines)?"default":e.indentLines
return t.createVNode(xi,t.mergeProps({ref:v},l,{class:["v-treeview",{"v-treeview--fluid":e.fluid},e.class],role:"tree",openStrategy:"multiple",style:[{"--v-treeview-indent-line-color":e.indentLinesColor,"--v-treeview-indent-line-opacity":e.indentLinesOpacity},e.style],opened:g.value,"onUpdate:opened":e=>g.value=e,activated:u.value,"onUpdate:activated":e=>u.value=e,selected:d.value,"onUpdate:selected":e=>d.value=e}),{default:()=>[0===h.value?.size&&!e.hideNoData&&(a["no-data"]?.()??t.createVNode(ui,{key:"no-data",title:n(e.noDataText)},null)),t.createVNode(Gy,t.mergeProps(r,{density:e.density,returnObject:e.returnObject,items:o.value,parentIndentLines:e.indentLines?[]:void 0,indentLinesVariant:i}),a)]})}),{}}}),Qy=Kt()({name:"VValidation",props:tr(),emits:{"update:modelValue":e=>!0},setup(e,{slots:t}){const a=ar(e,"validation")
return()=>t.default?.(a)}})
var Jy=Object.freeze({__proto__:null,VAlert:Po,VAlertTitle:No,VApp:nl,VAppBar:gn,VAppBarNavIcon:ko,VAppBarTitle:xo,VAutocomplete:uu,VAvatar:Bo,VBadge:Ro,VBanner:mu,VBannerActions:du,VBannerText:vu,VBottomNavigation:gu,VBottomSheet:wu,VBreadcrumbs:Cu,VBreadcrumbsDivider:Su,VBreadcrumbsItem:xu,VBtn:Vo,VBtnGroup:In,VBtnToggle:Fn,VCalendar:yd,VCard:Ad,VCardActions:wd,VCardItem:Nd,VCardSubtitle:Sd,VCardText:Ed,VCardTitle:kd,VCarousel:Ld,VCarouselItem:Wd,VCheckbox:ur,VCheckboxBtn:Wo,VChip:Fr,VChipGroup:Br,VClassIcon:fa,VCode:Ud,VCol:cm,VColorInput:Nv,VColorPicker:wv,VCombobox:Ev,VComponentIcon:va,VConfirmEdit:Sv,VContainer:am,VCounter:Vs,VDataIterator:dp,VDataTable:qp,VDataTableFooter:fp,VDataTableHeaders:Tp,VDataTableRow:zp,VDataTableRows:Op,VDataTableServer:em,VDataTableVirtual:Qp,VDateInput:Zm,VDatePicker:Om,VDatePickerControls:Cm,VDatePickerHeader:Im,VDatePickerMonth:Tm,VDatePickerMonths:$m,VDatePickerYears:zm,VDefaultsProvider:Bl,VDialog:yu,VDialogBottomTransition:yl,VDialogTopTransition:bl,VDialogTransition:ml,VDivider:zr,VEmptyState:Jm,VExpandBothTransition:Rl,VExpandTransition:Pl,VExpandXTransition:_l,VExpansionPanel:rf,VExpansionPanelText:af,VExpansionPanelTitle:nf,VExpansionPanels:cf,VFab:vf,VFabTransition:hl,VFadeTransition:wl,VField:Cs,VFieldLabel:ks,VFileInput:bf,VFileUpload:_f,VFileUploadDropzone:Ef,VFileUploadItem:Vf,VFileUploadList:Af,VFooter:Df,VForm:Tf,VHotkey:Uf,VHover:Gf,VIcon:Mn,VIconBtn:Iu,VImg:tn,VInfiniteScroll:Xf,VInput:nr,VItem:eg,VItemGroup:Jf,VKbd:$f,VLabel:Fo,VLayout:ag,VLayoutItem:ng,VLazy:rg,VLigatureIcon:ma,VList:xi,VListGroup:ni,VListImg:Ni,VListItem:ui,VListItemAction:Ei,VListItemMedia:Ai,VListItemSubtitle:ri,VListItemTitle:ii,VListSubheader:di,VLocaleProvider:sg,VMain:cg,VMenu:hs,VMessages:Go,VNavigationDrawer:hg,VNoSsr:yg,VNumberInput:Ng,VOtpField:Ig,VOtpGroup:_g,VOtpInput:$g,VOtpSeparator:Rg,VOverlay:fs,VPagination:pp,VParallax:zg,VPicker:yv,VPickerTitle:gv,VProgressCircular:Hn,VProgressLinear:Yn,VPullToRefresh:Lg,VRadio:jg,VRadioGroup:Wg,VRangeSlider:Yg,VRating:Kg,VResponsive:Ml,VRow:km,VScaleTransition:Vl,VScrollXReverseTransition:kl,VScrollXTransition:Sl,VScrollYReverseTransition:Nl,VScrollYTransition:xl,VSelect:iu,VSelectionControl:jo,VSelectionControlGroup:Lo,VSheet:bs,VSkeletonLoader:th,VSlideGroup:_r,VSlideGroupItem:ah,VSlideXReverseTransition:El,VSlideXTransition:Cl,VSlideYReverseTransition:Al,VSlideYTransition:Il,VSlider:cv,VSnackbar:oh,VSnackbarQueue:ih,VSpacer:xm,VSparkline:Nh,VSparklineTooltip:dh,VSpeedDial:Eh,VStepper:Oh,VStepperActions:Ph,VStepperHeader:_h,VStepperItem:Bh,VStepperVertical:Gh,VStepperVerticalActions:Hh,VStepperVerticalItem:Uh,VStepperWindow:Fh,VStepperWindowItem:Mh,VSvgIcon:pa,VSwitch:Zh,VSystemBar:Jh,VTab:ay,VTable:Hp,VTabs:sy,VTabsWindow:ny,VTabsWindowItem:ry,VTextField:Rs,VTextarea:cy,VThemeProvider:vy,VTimePicker:Ry,VTimePickerClock:wy,VTimePickerControls:Py,VTimeline:yy,VTimelineItem:gy,VToolbar:vn,VToolbarItems:By,VToolbarTitle:il,VTooltip:uh,VTreeview:Zy,VTreeviewGroup:Fy,VTreeviewItem:zy,VValidation:Qy,VVirtualScroll:zs,VWindow:Md,VWindowItem:jd})
function eb(e,t){e._mutate?.[t.instance.$.uid]&&(e._mutate[t.instance.$.uid].observer.disconnect(),delete e._mutate[t.instance.$.uid])}const tb={mounted:function(e,t){const a=t.modifiers||{},l=t.value,{once:n,immediate:o,...r}=a,i=!Object.keys(r).length,s=f(l)?l:l.handler,u=f(l)?{attributes:r?.attr??i,characterData:r?.char??i,childList:r?.child??i,subtree:r?.sub??i}:l.options,c=new MutationObserver((a=[],l)=>{s?.(a,l),n&&eb(e,t)})
o&&s?.([],c),e._mutate=Object(e._mutate),e._mutate[t.instance.$.uid]={observer:c},c.observe(e,u)},unmounted:eb}
function ab(e,t){const{self:a=!1}=t.modifiers??{},l=t.value,n=(f(l)||!b(l)?void 0:l.options)||{passive:!0},o=f(l)||"handleEvent"in l?l:l.handler,r=a?e:t.arg?document.querySelector(t.arg):window
r&&(r.addEventListener("scroll",o,n),e._onScroll=Object(e._onScroll),e._onScroll[t.instance.$.uid]={handler:o,options:n,target:a?void 0:r})}function lb(e,t){if(!e._onScroll?.[t.instance.$.uid])return
const{handler:a,options:l,target:n=e}=e._onScroll[t.instance.$.uid]
n.removeEventListener("scroll",a,l),delete e._onScroll[t.instance.$.uid]}const nb={mounted:ab,unmounted:lb,updated:function(e,t){t.value!==t.oldValue&&(lb(e,t),ab(e,t))}}
const ob=function(e,a){const n=function(e,a){return function(n,o,r){const i=f(a)?a(o):a,s=b(o.value)?o.value.text:g(o.value)?o.value:i?.text,u=b(o.value)?o.value:{},c=()=>s??n.textContent,d=(r.ctx===o.instance.$?function(e,t){const a=new Set,n=t=>{for(const l of t){if(!l)continue
if(l===e||l.el&&e.el&&l.el===e.el)return!0
let t
if(a.add(l),l.suspense?t=n([l.ssContent]):Array.isArray(l.children)?t=n(l.children):l.component?.vnode&&(t=n([l.component?.subTree])),t)return t
a.delete(l)}return!1}
if(!n([t.subTree]))return l("Could not find original vnode, component will not inherit provides"),t
const o=Array.from(a).reverse()
for(const e of o)if(e.component)return e.component
return t}(r,o.instance.$)?.provides:r.ctx?.provides)??o.instance.$.provides,v=t.h(e,t.mergeProps(i,u),c)
v.appContext=Object.assign(Object.create(null),o.instance.$.appContext,{provides:d}),t.render(v,n)}}(g(e)?t.resolveComponent(e):e,a)
return{mounted:n,updated:n,unmounted(e){t.render(null,e)}}}(uh,e=>({activator:(b(e.value)?!e.value.text:["",!1,null,void 0].includes(e.value))?null:"parent",location:e.arg?.replace("-"," "),text:y(e.value)?void 0:e.value}))
var rb=Object.freeze({__proto__:null,ClickOutside:ds,Intersect:Jl,Mutate:tb,Resize:Bc,Ripple:bo,Scroll:nb,Tooltip:ob,Touch:Bd})
function ib(e){const t={svg:{component:pa},class:{component:fa}},a=e?.defaultSet??"mdi"
return"mdi"!==a||t.mdi||(t.mdi=ha),ie({defaultSet:a,sets:t,aliases:{...ga,vuetify:["M8.2241 14.2009L12 21L22 3H14.4459L8.2241 14.2009Z",["M7.26303 12.4733L7.00113 12L2 3H12.5261C12.5261 3 12.5261 3 12.5261 3L7.26303 12.4733Z",.6]],"vuetify-outline":"svg:M7.26 12.47 12.53 3H2L7.26 12.47ZM14.45 3 8.22 14.2 12 21 22 3H14.45ZM18.6 5 12 16.88 10.51 14.2 15.62 5ZM7.26 8.35 5.4 5H9.13L7.26 8.35Z","vuetify-play":["m6.376 13.184-4.11-7.192C1.505 4.66 2.467 3 4.003 3h8.532l-.953 1.576-.006.01-.396.677c-.429.732-.214 1.507.194 2.015.404.503 1.092.878 1.869.806a3.72 3.72 0 0 1 1.005.022c.276.053.434.143.523.237.138.146.38.635-.25 2.09-.893 1.63-1.553 1.722-1.847 1.677-.213-.033-.468-.158-.756-.406a4.95 4.95 0 0 1-.8-.927c-.39-.564-1.04-.84-1.66-.846-.625-.006-1.316.27-1.693.921l-.478.826-.911 1.506Z",["M9.093 11.552c.046-.079.144-.15.32-.148a.53.53 0 0 1 .43.207c.285.414.636.847 1.046 1.2.405.35.914.662 1.516.754 1.334.205 2.502-.698 3.48-2.495l.014-.028.013-.03c.687-1.574.774-2.852-.005-3.675-.37-.391-.861-.586-1.333-.676a5.243 5.243 0 0 0-1.447-.044c-.173.016-.393-.073-.54-.257-.145-.18-.127-.316-.082-.392l.393-.672L14.287 3h5.71c1.536 0 2.499 1.659 1.737 2.992l-7.997 13.996c-.768 1.344-2.706 1.344-3.473 0l-3.037-5.314 1.377-2.278.004-.006.004-.007.481-.831Z",.6]]}},e)}function sb(e={}){const{blueprint:a,...l}=e,n=ie(a,l),{aliases:o={},components:r={},directives:i={}}=n,s=t.effectScope()
return s.run(()=>{const e=function(e){return t.ref(e)}(n.defaults),a=gr(n.display,n.ssr),l=el(n.theme),u=ib(n.icons),c=ja(n.locale),d=function(e,t){const a=ie({adapter:kc,locale:{af:"af-ZA",bg:"bg-BG",ca:"ca-ES",ckb:"",cs:"cs-CZ",de:"de-DE",el:"el-GR",en:"en-US",et:"et-EE",fa:"fa-IR",fi:"fi-FI",hr:"hr-HR",hu:"hu-HU",he:"he-IL",id:"id-ID",it:"it-IT",ja:"ja-JP",ko:"ko-KR",lv:"lv-LV",lt:"lt-LT",nl:"nl-NL",no:"no-NO",pl:"pl-PL",pt:"pt-PT",ro:"ro-RO",ru:"ru-RU",sk:"sk-SK",sl:"sl-SI",srCyrl:"sr-SP",srLatn:"sr-SP",sv:"sv-SE",th:"th-TH",tr:"tr-TR",az:"az-AZ",uk:"uk-UA",vi:"vi-VN",zhHans:"zh-CN",zhHant:"zh-TW"}},e)
return{options:a,instance:Cc(a,t)}}(n.date,c),v=function(e,t){return{rtl:t.isRtl,options:ie(wr(),e)}}(n.goTo,c)
return{install:function(s){for(const e in i)s.directive(e,i[e])
for(const e in r)s.component(e,r[e])
for(const e in o)s.component(e,Gt({...o[e],name:e,aliasName:o[e].name}))
const p=t.effectScope()
if(p.run(()=>{l.install(s)}),s.onUnmount(()=>p.stop()),s.provide(Lt,e),s.provide(Ot,e),s.provide(dr,a),s.provide(Ya,l),s.provide(ca,u),s.provide(Oa,c),s.provide(xc,d.options),s.provide(Nc,d.instance),s.provide(br,v),E&&n.ssr)if(s.$nuxt)s.$nuxt.hook("app:suspense:resolve",()=>{a.update()})
else{const{mount:e}=s
s.mount=(...l)=>{const n=e(...l)
return t.nextTick(()=>a.update()),s.mount=e,n}}("boolean"!=typeof __VUE_OPTIONS_API__||__VUE_OPTIONS_API__)&&s.mixin({computed:{$vuetify(){return t.reactive({defaults:ub.call(this,Lt),display:ub.call(this,dr),theme:ub.call(this,Ya),icons:ub.call(this,ca),locale:ub.call(this,Oa),date:ub.call(this,Nc)})}}})},unmount:function(){s.stop()},defaults:e,display:a,theme:l,icons:u,locale:c,date:d,goTo:v}})}function ub(e){const t=this.$,a=t.parent?.provides??t.vnode.appContext?.provides
if(a&&e in a)return a[e]}sb.version="4.2.1"
const cb=(e={})=>sb({components:Jy,directives:rb,...e}),db="4.2.1"
cb.version=db,e.blueprints=Va,e.components=Jy,e.createRulesPlugin=function(e,a){return{install(l){l.provide(Jo,function(e,a){const{t:l}=a,n={required:e=>t=>0===t||!!t||l(e||"$vuetify.rules.required"),email:e=>t=>!t||g(t)&&/^.+@\S+\.\S+$/.test(t)||l(e||"$vuetify.rules.email"),number:e=>t=>!t||!isNaN(Number(t))||l(e||"$vuetify.rules.number"),integer:e=>t=>/^[\d]*$/.test(t)||l(e||"$vuetify.rules.integer"),capital:e=>t=>/^[A-Z]*$/.test(t)||l(e||"$vuetify.rules.capital"),maxLength:(e,t)=>a=>!a||a.length<=e||l(t||"$vuetify.rules.maxLength",e),minLength:(e,t)=>a=>!a||a.length>=e||l(t||"$vuetify.rules.minLength",e),strictLength:(e,t)=>a=>!a||a.length===e||l(t||"$vuetify.rules.strictLength",e),exclude:(e,t)=>a=>{let n=!0
for(const o of e)a.includes(o)&&(n=t||l("$vuetify.rules.exclude",o))
return n},notEmpty:e=>t=>t&&t.length>0||l(e||"$vuetify.rules.notEmpty"),pattern:(e,t)=>a=>!a||e.test(a)||l(t||"$vuetify.rules.pattern"),...e?.aliases}
return{resolve:function(e){return t.computed(()=>e().map(e=>{let t=null,a=[void 0]
return Array.isArray(e)?(t=e[0],a=e.slice(1)):g(e)&&(t=e),t?(t.startsWith("$")&&(t=t.slice(1)),n[t]?.(...a)):e}))},aliases:n}}(e,a))}}},e.createVuetify=cb,e.directives=rb,e.useDate=Ec,e.useDefaults=function(e={},t){const{props:a,provideSubDefaults:l}=Yt(e,t)
return l(),a},e.useDisplay=yr,e.useGoTo=xr,e.useHotkey=function(e,a,l={}){if(!E)return function(){}
const{event:n="keydown",inputs:o=!1,preventDefault:r=!0,sequenceTimeout:i=1e3}=l,s=navigator?.userAgent?.includes("Macintosh")??!1
let u,c=0,d=!1,v=0
function p(){v=0,clearTimeout(c)}function m(e){const l=u[v]
if(l&&!function(){if(t.toValue(o))return!1
const e=be()
return e&&("INPUT"===e.tagName||"TEXTAREA"===e.tagName||e.isContentEditable||"true"===e.contentEditable)}())if(Yc(e,l,s))if(t.toValue(r)&&e.preventDefault(),d){if(clearTimeout(c),v++,v===u.length)return a(e),void p()
c=window.setTimeout(p,t.toValue(i))}else a(e)
else d&&p()}function f(){window.removeEventListener(t.toValue(n),m),clearTimeout(c)}return t.watch(()=>t.toValue(e),e=>{if(f(),e){const a=Lc(e.toLowerCase())
if(a){const e=g(a)||"sequence"!==a.type?[a]:a.parts
d=e.length>1,u=e,p(),window.addEventListener(t.toValue(n),m)}}},{immediate:!0}),t.watch(()=>t.toValue(n),(e,t)=>{t&&u&&u.length>0&&(window.removeEventListener(t,m),window.addEventListener(e,m))}),t.onScopeDispose(f,!0),f},e.useLayout=Ea,e.useLocale=Ha,e.useMask=function(e){const a=t.computed(()=>g(e.mask)?e.mask in Gc?Gc[e.mask]:e.mask:e.mask?.mask??""),l=t.computed(()=>({...Kc,...b(e.mask)?e.mask.tokens:null}))
function n(e){return e in l.value}function o(e,t){if(!g(t)||!n(e))return!1
const a=l.value[e]
return a.pattern?a.pattern.test(t):a.test(t)}function r(e,t){const a=l.value[e]
return a.convert?a.convert(t):t}function i(e){const t=e?.trim().replace(/\s+/g," ")
if(!g(t))return""
if(!a.value.length||!t.length)return t
let l=0,i=0,s=""
for(;i<a.value.length;){const e=a.value[i],u=t[l]
if("\\"!==e){if(n(e)){if(!o(e,u)){if(l<t.length){l++
continue}break}s+=r(e,u),l++}else s+=e,u===e&&l++
i++}else s+=a.value[i+1],i+=2}return s}function s(e){if(!g(e))return null
if(!a.value.length||!e.length)return e
let t=""
const l=u(e)
for(let a=0;a<e.length;a++)l[a]||(t+=e[a])
return t}function u(e){if(!g(e)||!a.value.length||!e.length)return[]
let t=0,l=0
const n=Array.from({length:e.length},()=>!0)
for(;;){const r=a.value[l],i=e[t]
if(!g(i))break
if(g(r))if("\\"!==r)if(o(r,i))n[t]=!1,t++,l++
else if(r===i)t++,l++
else for(;;){const e=a.value[l++]
if(!g(e)||o(e,i))break}else i===a.value[l+1]&&t++,l+=2
else n[t]=!1,t++}return n}function c(e){return!!e&&s(e)===s(i(e))}return{isDelimiter:function(e,t){return!(!a.value.length||!e.length)&&!!u(e)[t]},isValid:c,isComplete:function(e){return!!e&&(i(e).length===a.value.length&&c(e))},mask:i,unmask:s}},e.useRtl=Ua,e.useRules=er,e.useTheme=al,e.version=db})
//# sourceMappingURL=vuetify.min.js.map
