"""Version information for `langchain-core`."""

VERSION = "1.7.6"
