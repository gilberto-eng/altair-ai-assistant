from ..OCP.GeomAbs import *
