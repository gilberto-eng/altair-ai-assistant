/*
 *    This file is part of CasADi.
 *
 *    CasADi -- A symbolic framework for dynamic optimization.
 *    Copyright (C) 2010-2023 Joel Andersson, Joris Gillis, Moritz Diehl,
 *                            KU Leuven. All rights reserved.
 *    Copyright (C) 2011-2014 Greg Horn
 *
 *    CasADi is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 3 of the License, or (at your option) any later version.
 *
 *    CasADi is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with CasADi; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */


#ifndef CASADI_GRAPH_BUILDER_HPP
#define CASADI_GRAPH_BUILDER_HPP

#include "function.hpp"

namespace casadi {

  class GraphBuilderInternal;

  /** \brief A mutable, format-neutral interface to a computational-graph model

      Two-stage workflow: explore and configure a model (introspection, dynamic-dimension
      binding) with GraphBuilder, then freeze it into an immutable, evaluable Function.

      \lang{cpp}
      \verbatim
      GraphBuilder b("model.onnx");
      b.bind_dim("batch", 4);
      Function f = b.create("net");
      \endverbatim
      \endlang

      \date 2026

      \identifier{2jd} */
  class CASADI_EXPORT GraphBuilder
    : public SharedObject,
      public SWIG_IF_ELSE(PrintableCommon, Printable<GraphBuilder>) {
   public:
    /// Readable name of the class
    std::string type_name() const { return "GraphBuilder"; }

    /// Default constructor
    GraphBuilder();

    /// Construct from a model file (import lifecycle; format from the file suffix)
    explicit GraphBuilder(const std::string& model_path, const Dict& opts = Dict());

    /// Construct from a CasADi Function (export lifecycle)
    explicit GraphBuilder(const Function& f, const Dict& opts = Dict());

#ifndef SWIG
    /// Construct from model data in memory
    GraphBuilder(const std::string& name, const std::vector<uint8_t>& model_data,
                 const std::string& format, const Dict& opts = Dict());
#endif // SWIG

    /// Name of the model
    const std::string& name() const;

    ///@{
    /** @name Model introspection */
    casadi_int n_in() const;
    casadi_int n_out() const;
    std::vector<std::string> name_in() const;
    std::vector<std::string> name_out() const;
    /// Declared shape of a tensor (input or output) by name; -1 for dynamic dimensions
    std::vector<casadi_int> dimension(const std::string& name) const;
    /// Element type name of a tensor (input or output) by name (FLOAT, INT64, ...)
    std::string dtype(const std::string& name) const;
    /// Per-axis symbolic dimension name of a tensor by name ("" for static axes)
    std::vector<std::string> dimension_param(const std::string& name) const;
    /// Names of the symbolic/dynamic dimensions in the model
    std::vector<std::string> dynamic_params() const;
    ///@}

    ///@{
    /** @name Configuration */
    /// Bind a symbolic/dynamic dimension to a concrete size
    void bind_dim(const std::string& param, casadi_int value);
    /// Pin the full shape of an input
    void bind_shape(const std::string& input_name, const std::vector<casadi_int>& shape);
    /// Bake a fixed value into an input; it is fed at create() and not exposed as a Function input
    void set(const std::string& input_name, const std::vector<double>& value);
    /// Bake a scalar value into an input
    void set(const std::string& input_name, double value);
    ///@}

    /** \brief Freeze into an evaluable Function

        For a file f.onnx, black-box derivatives fall back to sibling fwd_f.onnx,
        adj_f.onnx and jac_f.onnx when the model lacks the corresponding tensors.
        Forward/reverse siblings use dynamic nfwd/nadj dimensions (fwd_dim/adj_dim).
        Files are checked on derivative capability queries and loaded on demand.
        Derivative models use the same rule recursively, e.g. fwd_adj_f.onnx
        or adj_adj_f.onnx. Repeated AD modes follow CasADi tensor prefixes
        (adj2_, adj3_, ...; fwd2_, fwd3_, ...) and use seed dimensions
        nadj2, nadj3, ... or nfwd2, nfwd3, ... (suffixing adj_dim/fwd_dim).
        Serialized functions retain the absolute source path for derivative lookup;
        constructed derivative functions embed their model bytes.

        \param name      Name assigned to the resulting Function
        \param name_in   Names of the inputs to expose (empty = all model inputs)
        \param name_out  Names of the outputs to expose (empty = all model outputs)
        \param opts      "symbolic" (bool, default false) and "backend" (numeric backend,
                         default "ort"); any remaining options pass through to the backend.

        \identifier{2je} */
    Function create(const std::string& name,
      const std::vector<std::string>& name_in,
      const std::vector<std::string>& name_out,
      const Dict& opts = Dict()) const;

    /** \brief Freeze into an evaluable Function, exposing all model inputs and outputs

        \param name  Name assigned to the resulting Function
        \param opts  See the full create() overload

        \identifier{2jf} */
    Function create(const std::string& name, const Dict& opts = Dict()) const;

    /** \brief Freeze into an evaluable Function, default naming

        \identifier{2jg} */
    Function create() const { return create(name() + "_graph"); }

    /** \brief Export to an ONNX model file

        \identifier{2jh} */
    void export_onnx(const std::string& filename, const Dict& opts = Dict());

#ifndef SWIG
    ///@{
    /// Access functions of the node
    GraphBuilderInternal* operator->();
    const GraphBuilderInternal* operator->() const;
    GraphBuilderInternal* get() const;
    ///@}
#endif // SWIG
  };

} // namespace casadi

#endif // CASADI_GRAPH_BUILDER_HPP
