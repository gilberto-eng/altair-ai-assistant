from ..OCP.TNaming import *
