from ..OCP.TShort import *
