from ..OCP.GCPnts import *
