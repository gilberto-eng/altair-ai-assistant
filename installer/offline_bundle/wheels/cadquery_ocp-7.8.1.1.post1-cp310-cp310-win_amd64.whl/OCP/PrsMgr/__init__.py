from ..OCP.PrsMgr import *
