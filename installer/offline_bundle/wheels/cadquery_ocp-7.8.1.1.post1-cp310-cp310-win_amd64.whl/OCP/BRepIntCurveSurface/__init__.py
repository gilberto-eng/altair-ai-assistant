from ..OCP.BRepIntCurveSurface import *
