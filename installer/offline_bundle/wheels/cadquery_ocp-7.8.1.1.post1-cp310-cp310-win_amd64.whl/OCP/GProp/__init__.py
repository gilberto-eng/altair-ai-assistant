from ..OCP.GProp import *
