from ..OCP.TDocStd import *
