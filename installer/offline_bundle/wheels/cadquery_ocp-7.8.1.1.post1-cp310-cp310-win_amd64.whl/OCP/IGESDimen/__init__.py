from ..OCP.IGESDimen import *
