from ..OCP.BRepOffsetAPI import *
