from ..OCP.TDataXtd import *
